import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.PartialCharts
import PoincareLib.Geometry.Manifold.RegularLevel.OpenInclusion

/-! # Open reference-chart domains on the retained limit carrier -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.PointedGeometricConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable

variable {a b : ℝ} {S : PointedFlowSequence 3 a b}
  (G : PointedGeometricConvergence S)

def referenceOpenMap (q : G.limitCarrier.carrier)
    (U : Opens (EuclideanSpace ℝ (Fin 3))) : U → G.limitCarrier.carrier :=
  fun x => (extChartAt (𝓡 3) q).symm x

theorem referenceOpenMap_isLocalDiffeomorph (q : G.limitCarrier.carrier)
    (U : Opens (EuclideanSpace ℝ (Fin 3))) (hU : (U : Set _) ⊆ (extChartAt (𝓡 3) q).target) :
    IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ (G.referenceOpenMap q U) := by
  let d : PartialDiffeomorph (𝓡 3) (𝓡 3) G.limitCarrier.carrier
      (EuclideanSpace ℝ (Fin 3)) ∞ :=
    { toPartialEquiv := (chartAt (EuclideanSpace ℝ (Fin 3)) q).toPartialEquiv
      open_source := (chartAt (EuclideanSpace ℝ (Fin 3)) q).open_source
      open_target := (chartAt (EuclideanSpace ℝ (Fin 3)) q).open_target
      contMDiffOn_toFun := contMDiffOn_chart
      contMDiffOn_invFun := contMDiffOn_chart_symm }
  intro x
  have hx : (x : EuclideanSpace ℝ (Fin 3)) ∈ d.target := by
    simpa only [extChartAt_target, modelWithCornersSelf_coe,
      modelWithCornersSelf_coe_symm, preimage_id, range_id, inter_univ] using hU x.property
  exact (Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 3) U x).comp (𝓡 3)
    G.limitCarrier.carrier (d.symm.isLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞ hx)

theorem referenceOpenMap_mfderiv (q : G.limitCarrier.carrier)
    (U : Opens (EuclideanSpace ℝ (Fin 3))) (hU : (U : Set _) ⊆ (extChartAt (𝓡 3) q).target)
    (x : U) :
    mfderiv (𝓡 3) (𝓡 3) (G.referenceOpenMap q U) x =
      mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm (x : EuclideanSpace ℝ (Fin 3)) := by
  have hc := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q (hU x.property)).contMDiffAt
    (extChartAt_target_mem_nhds' (hU x.property))
  exact Poincare.Geometry.Manifold.RegularLevel.mfderiv_opens_restrict U
    (extChartAt (𝓡 3) q).symm (x := x) (hc.mdifferentiableAt (by simp))

theorem exists_countable_referenceChart_cover :
    ∃ q : ℕ → G.limitCarrier.carrier,
      ∀ x : G.limitCarrier.carrier, ∃ i, x ∈ (extChartAt (𝓡 3) (q i)).source := by
  let : Nonempty G.limitCarrier.carrier := ⟨G.limitFlow.base⟩
  obtain ⟨C, hC, hcover⟩ := TopologicalSpace.countable_cover_nhds
    (fun x : G.limitCarrier.carrier => extChartAt_source_mem_nhds (I := 𝓡 3) x)
  obtain ⟨q, hq⟩ := countable_iff_exists_subset_range.mp hC
  refine ⟨q, fun x => ?_⟩
  have hx : x ∈ ⋃ y ∈ C, (extChartAt (𝓡 3) y).source := hcover.symm ▸ mem_univ x
  obtain ⟨y, hy, hxy⟩ := mem_iUnion₂.mp hx
  obtain ⟨i, rfl⟩ := hq hy
  exact ⟨i, hxy⟩

end PoincareMT.PointedGeometricConvergence
