import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NullOrientation

/-!
# Global null-line geometry from local terminal sections

The local backward intervals need not agree. Rank one and actual local
parallel unit null sections construct the orientation covering directly;
on a simply connected manifold they give a global parallel potential.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Bundle
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT.RicciFlow.Splitting

variable {n : ℕ} {M : Type u} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
  {g : RiemannianMetric n M}

theorem exists_unit_ricci_null_vector_of_nullity_one (D : LeviCivitaData g)
    (x : M) (hdim : ricciNullity D x = 1) :
    ∃ v : TangentSpace (𝓡 n) x, g.inner x v v = 1 ∧ ∀ w, D.ricci x v w = 0 := by
  let : FiniteDimensional ℝ (TangentSpace (𝓡 n) x) := by
    unfold TangentSpace
    infer_instance
  obtain ⟨z, hz⟩ := Module.finrank_pos_iff_exists_ne_zero.mp
    (show 0 < ricciNullity D x by rw [hdim]; norm_num)
  have hz' : (z : TangentSpace (𝓡 n) x) ≠ 0 := fun he => hz (Subtype.ext he)
  let q := g.inner x z z
  have hq : 0 < q := g.pos x z hz'
  let v : TangentSpace (𝓡 n) x := (Real.sqrt q)⁻¹ • (z : TangentSpace (𝓡 n) x)
  refine ⟨v, ?_, (mem_ricciKernel _ _ _).mp ((ricciKernel D x).smul_mem _ z.property)⟩
  simp only [v, map_smul, smul_apply, smul_eq_mul]
  change (Real.sqrt q)⁻¹ * ((Real.sqrt q)⁻¹ * q) = 1
  field_simp [(Real.sqrt_pos.mpr hq).ne']
  exact (Real.sq_sqrt hq.le).symm

/-- Local sections alone construct the actual covering; no global backward
flow interval or curvature bound is needed. -/
theorem unitRicciKernel_covering_of_local_unit_sections
    (D : LeviCivitaData g) (hdim : ∀ y : M, ricciNullity D y = 1)
    (hlocal : ∀ p : UnitRicciKernel D,
      ∃ (U : Set M) (V : (y : M) → TangentSpace (𝓡 n) y),
        IsOpen U ∧ p.1.proj ∈ U ∧
        ContMDiffOn (𝓡 n) ((𝓡 n).prod (𝓡 n)) ∞ (T% V) U ∧
        ∀ y ∈ U, g.inner y (V y) (V y) = 1 ∧ ∀ w, D.ricci y (V y) w = 0) :
    IsCoveringMap (unitRicciKernelProjection D) ∧
      ∀ x : M, Nat.card (unitRicciKernelProjection D ⁻¹' {x}) = 2 := by
  have heven (x : M) : IsEvenlyCovered (unitRicciKernelProjection D) x LineSign := by
    obtain ⟨v, hu, hn⟩ := exists_unit_ricci_null_vector_of_nullity_one D x (hdim x)
    let p : UnitRicciKernel D := ⟨⟨x, v⟩, hu, hn⟩
    obtain ⟨U, V, hU, hx, hV, hunit⟩ := hlocal p
    exact ⟨inferInstance, U, hx, hU,
      hU.preimage (continuous_unitRicciKernelProjection D),
      unitRicciKernelLocalHomeomorph D V hV (fun y _ => hdim y)
        (fun y hy => (hunit y hy).1) (fun y hy => (hunit y hy).2), fun _ => rfl⟩
  refine ⟨fun x => (heven x).to_isEvenlyCovered_preimage, ?_⟩
  intro x
  rw [← Nat.card_congr (heven x).fiberHomeomorph.toEquiv]
  exact Set.ncard_pair (by norm_num : (1 : ℝ) ≠ -1)

/-- Pointwise terminal null-line data, possibly produced using a different
backward flow near each point, construct one global parallel coordinate. -/
theorem exists_parallel_potential_of_simplyConnected_local_null_sections
    [SimplyConnectedSpace M] (D : LeviCivitaData g)
    (hdim : ∀ y : M, ricciNullity D y = 1)
    (hlocal : ∀ p : UnitRicciKernel D,
      ∃ (U : Set M) (V : (y : M) → TangentSpace (𝓡 n) y),
        IsOpen U ∧ p.1.proj ∈ U ∧
        ContMDiffOn (𝓡 n) ((𝓡 n).prod (𝓡 n)) ∞ (T% V) U ∧ V p.1.proj = p.1.snd ∧
        ∀ y ∈ U, g.inner y (V y) (V y) = 1 ∧
          (∀ w, D.ricci y (V y) w = 0) ∧ ∀ w, D.connection V y w = 0)
    (p : M) :
    ∃ f : M → ℝ, ContMDiff (𝓡 n) 𝓘(ℝ, ℝ) ∞ f ∧ f p = 0 ∧
      RiemannianMetric.HasUnitGradient D f ∧ RiemannianMetric.HasZeroHessian D f := by
  have hc := (unitRicciKernel_covering_of_local_unit_sections D hdim (fun q => by
    obtain ⟨U, V, hU, hq, hV, _, hn⟩ := hlocal q
    exact ⟨U, V, hU, hq, hV, fun y hy => ⟨(hn y hy).1, (hn y hy).2.1⟩⟩)).1
  obtain ⟨v, hu, hn⟩ := exists_unit_ricci_null_vector_of_nullity_one D p (hdim p)
  let p₀ : UnitRicciKernel D := ⟨⟨p, v⟩, hu, hn⟩
  obtain ⟨V, hV, hparallel⟩ :=
    exists_parallel_unit_field_of_simplyConnected_null_cover D hc hdim hlocal p₀
  obtain ⟨f, hf, hfp, _, hgrad⟩ := D.exists_global_potential_of_parallel
    hV (fun y => (hparallel y).2.2) p 0
  refine ⟨f, hf, hfp, ?_, ?_⟩
  · intro y
    rw [hgrad]
    exact (hparallel y).1
  · intro y v w
    rw [D.hessian_eq_inner_connection_gradient (hf y), hgrad,
      (hparallel y).2.2 v, map_zero, zero_apply]

end PoincareMT.RicciFlow.Splitting
