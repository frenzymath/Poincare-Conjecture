import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Limit.Construction
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.ClockJets

/-! # All-order canonical jets on the included full horizon -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))
  (F₀ : RicciFlow 3 G.limitCarrier.carrier (Ioc (-tau 0 / 2) (tau 0 / 2)))
  (hF₀ : ∀ t ∈ Ioo (-tau 0 / 2) (tau 0 / 2), F₀.metric t = G.limitFlow.metricAt t)
  (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau ∪ {0}))
  (hmatch : ∀ t ∈ Ioc (-tau 0) 0, F.metric t = F₀.metric (t + tau 0 / 2))
  (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
  (htmono : Monotone tau) (hB : ∀ j, 0 ≤ B j)
  {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
  (hjets : ∀ q r K, IsCompact K → K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target →
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ r (horizonSpacetimeCoefficients G q (sigma k)))
      (iteratedFDeriv ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)) atTop K)

set_option quotPrecheck false in
local notation "U(" q ")" => Set.prod (horizonOpenTime tau ∪ {0}) (extChartAt (𝓡 3) q).target
local notation "basis(" a ")" => EuclideanSpace.basisFun (Fin 3) ℝ a

include htmono hsigma hjets

theorem tendstoUniformlyOn_horizon_scalarJet_open
    (q : G.limitCarrier.carrier) (r : ℕ) (a b : Fin 3)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKU : K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target) :
    TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r
        (fun z => horizonSpacetimeCoefficients G q (sigma k) z basis(a) basis(b)) U(q))
      (iteratedFDerivWithin ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2 basis(a) basis(b)) U(q))
      atTop K := by
  let g := fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
    (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2
  let L := NormalizedKappaSolutionSequence.coefficientEval a b
  let P := ContinuousLinearMap.compContinuousMultilinearMapL ℝ
    (fun _ : Fin r => ℝ × EuclideanSpace ℝ (Fin 3)) (SpacetimeBounds.MetricCoefficient 3) ℝ L
  have hm : (r : ℕ∞ω) ≤ ∞ := WithTop.coe_le_coe.mpr (le_top : (r : ℕ∞) ≤ ⊤)
  have hnhds (z) (hz : z ∈ K) : U(q) =ᶠ[𝓝 z] univ :=
    Filter.eventuallyEq_univ.mpr (mem_of_superset
      (((horizonOpenTime_isOpen tau).prod (isOpen_extChartAt_target q)).mem_nhds (hKU hz))
      (prod_mono subset_union_left Subset.rfl))
  have hg (z) (hz : z ∈ K) : ContDiffAt ℝ ∞ g z :=
    (fullHorizonInterior G F).smooth.contDiffAt_spacetime_pullbackCoefficients
      (horizonOpenTime_isOpen tau)
      ((contMDiffOn_extChartAt_symm (n := ∞) q).contMDiffAt
        ((isOpen_extChartAt_target q).mem_nhds (hKU hz).2)) (hKU hz).1
  have hc := P.uniformContinuous.comp_tendstoUniformlyOn (hjets q r K hK hKU)
  have hc' : TendstoUniformlyOn
      (fun k => P ∘ iteratedFDeriv ℝ r (horizonSpacetimeCoefficients G q (sigma k)))
      (iteratedFDerivWithin ℝ r (L ∘ g) U(q)) atTop K := hc.congr_right fun z hz => by
    rw [iteratedFDerivWithin_congr_set (hnhds z hz) r, iteratedFDerivWithin_univ,
      L.iteratedFDeriv_comp_left (hg z hz) hm]
    rfl
  apply hc'.congr
  filter_upwards [hsigma.tendsto_atTop.eventually
    (horizonSpacetimeCoefficients_locallyEventuallyContDiff G htmono q K hK hKU)]
    with k hk z hz
  obtain ⟨W, hWo, hKW, hkd⟩ := hk
  rw [iteratedFDerivWithin_congr_set (hnhds z hz) r, iteratedFDerivWithin_univ]
  exact (L.iteratedFDeriv_comp_left (hkd.contDiffAt (hWo.mem_nhds (hKW hz))) hm).symm

omit hjets in
theorem horizon_initial_domain_germ
    (q : G.limitCarrier.carrier) {z : ℝ × EuclideanSpace ℝ (Fin 3)}
    (hz : z.1 ∈ Ioc (-tau 0) 0) :
    U(q) =ᶠ[𝓝 z] (Ioc (-tau 0) 0 ×ˢ (extChartAt (𝓡 3) q).target) := by
  filter_upwards [(isOpen_Ioi.preimage continuous_fst).mem_nhds hz.1] with w hw
  apply propext
  constructor
  · intro hwU
    refine ⟨⟨hw, ?_⟩, hwU.2⟩
    rcases hwU.1 with ht | ht
    · obtain ⟨j, hj⟩ := mem_iUnion.mp ht
      exact hj.2.le
    · exact (mem_singleton_iff.mp ht).le
  · intro hwV
    rcases lt_or_eq_of_le hwV.1.2 with hneg | hzero
    · exact ⟨Or.inl (mem_iUnion.mpr ⟨0, hwV.1.1, hneg⟩), hwV.2⟩
    · exact ⟨Or.inr (mem_singleton_iff.mpr hzero), hwV.2⟩

include hF₀ hmatch P04 hAr hcompact hcomplete hB

omit hjets in
theorem tendstoUniformlyOn_horizon_scalarJet_initial
    (q : G.limitCarrier.carrier) (r : ℕ) (a b : Fin 3)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKU : K ⊆ Ioc (-tau 0) 0 ×ˢ (extChartAt (𝓡 3) q).target) :
    TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r
        (fun z => horizonSpacetimeCoefficients G q (sigma k) z basis(a) basis(b)) U(q))
      (iteratedFDerivWithin ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2 basis(a) basis(b)) U(q))
      atTop K := by
  let V := Ioc (-tau 0) 0 ×ˢ (extChartAt (𝓡 3) q).target
  have hc₀ := tendstoUniformlyOn_originalClock_scalarJet G F₀ hF₀ P04 (hB 0) hAr hcompact
    hcomplete q r a b hK hKU
  have hc : TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r (fun z => G.spatialSpacetimeCoefficients q (sigma k)
        (z.1 + tau 0 / 2, z.2) basis(a) basis(b)) V)
      (iteratedFDerivWithin ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F₀.metric (z.1 + tau 0 / 2)).pullbackCoefficients
          (extChartAt (𝓡 3) q).symm z.2 basis(a) basis(b)) V) atTop K :=
    fun u hu => hsigma.tendsto_atTop.eventually (hc₀ u hu)
  have htarget : TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r (fun z => G.spatialSpacetimeCoefficients q (sigma k)
        (z.1 + tau 0 / 2, z.2) basis(a) basis(b)) V)
      (iteratedFDerivWithin ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients
          (extChartAt (𝓡 3) q).symm z.2 basis(a) basis(b)) U(q)) atTop K := hc.congr_right fun z hz => by
    rw [iteratedFDerivWithin_congr_set (horizon_initial_domain_germ G htmono hsigma q (hKU hz).1) r]
    have heq : (fun w : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F₀.metric (w.1 + tau 0 / 2)).pullbackCoefficients (extChartAt (𝓡 3) q).symm w.2 basis(a) basis(b))
        =ᶠ[𝓝[V] z] (fun w => (F.metric w.1).pullbackCoefficients
          (extChartAt (𝓡 3) q).symm w.2 basis(a) basis(b)) := by
      filter_upwards [self_mem_nhdsWithin] with w hw
      rw [hmatch w.1 hw.1]
    exact heq.iteratedFDerivWithin_eq (heq.eq_of_nhdsWithin (hKU hz)) r
  apply htarget.congr
  exact Eventually.of_forall fun k z hz => by
    rw [iteratedFDerivWithin_congr_set (horizon_initial_domain_germ G htmono hsigma q (hKU hz).1) r]
    have heq : (fun w => horizonSpacetimeCoefficients G q (sigma k) w basis(a) basis(b))
        =ᶠ[𝓝[V] z] (fun w => G.spatialSpacetimeCoefficients q (sigma k)
          (w.1 + tau 0 / 2, w.2) basis(a) basis(b)) := by
      filter_upwards [self_mem_nhdsWithin] with w hw
      rw [horizonSpacetimeCoefficients_eq_initial G htmono q (sigma k) (Ioc_subset_Icc_self hw.1) w.2]
    exact (heq.iteratedFDerivWithin_eq (heq.eq_of_nhdsWithin (hKU hz)) r).symm

theorem tendstoUniformlyOn_horizon_scalarJet
    (q : G.limitCarrier.carrier) (r : ℕ) (a b : Fin 3)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K) (hKU : K ⊆ U(q)) :
    TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r
        (fun z => horizonSpacetimeCoefficients G q (sigma k) z basis(a) basis(b)) U(q))
      (iteratedFDerivWithin ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2 basis(a) basis(b)) U(q))
      atTop K := by
  apply (tendstoLocallyUniformlyOn_iff_tendstoUniformlyOn_of_compact hK).mp
  apply TendstoLocallyUniformlyOn.mono (s := U(q)) _ hKU
  apply tendstoLocallyUniformlyOn_of_forall_exists_nhds
  intro z hz
  rcases hz.1 with ht | ht
  · obtain ⟨rho, hrho, hsub⟩ := Metric.mem_nhds_iff.mp
      (((horizonOpenTime_isOpen tau).prod (isOpen_extChartAt_target q)).mem_nhds ⟨ht, hz.2⟩)
    let C := closedBall z (rho / 2)
    have hCsub := (closedBall_subset_ball (by linarith : rho / 2 < rho)).trans hsub
    exact ⟨C, mem_nhdsWithin_of_mem_nhds (closedBall_mem_nhds z (by positivity)),
      tendstoUniformlyOn_horizon_scalarJet_open G F htmono hsigma hjets q r a b
        (isCompact_closedBall _ _) hCsub⟩
  · have ht0 := mem_singleton_iff.mp ht
    obtain ⟨rho, hrho, hsub⟩ := Metric.mem_nhds_iff.mp
      ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds hz.2)
    let C := Icc (-tau 0 / 2) 0 ×ˢ closedBall z.2 (rho / 2)
    have hCsub : C ⊆ Ioc (-tau 0) 0 ×ˢ (extChartAt (𝓡 3) q).target :=
      prod_mono (fun t ht => ⟨by linarith [ht.1, htau 0], ht.2⟩)
        ((closedBall_subset_ball (by linarith)).trans hsub)
    have hCnhds : C ∈ 𝓝[U(q)] z := by
      have hn : Ioi (-tau 0 / 2) ×ˢ ball z.2 (rho / 2) ∈ 𝓝 z :=
        (isOpen_Ioi.prod isOpen_ball).mem_nhds ⟨by change -tau 0 / 2 < z.1; rw [ht0]; linarith [htau 0],
          mem_ball_self (by positivity)⟩
      apply mem_of_superset (inter_mem (mem_nhdsWithin_of_mem_nhds hn) self_mem_nhdsWithin)
      intro w hw
      refine ⟨⟨hw.1.1.le, ?_⟩, ball_subset_closedBall hw.1.2⟩
      rcases hw.2.1 with hneg | hzero
      · obtain ⟨j, hj⟩ := mem_iUnion.mp hneg
        exact hj.2.le
      · exact (mem_singleton_iff.mp hzero).le
    exact ⟨C, hCnhds, tendstoUniformlyOn_horizon_scalarJet_initial G F₀ hF₀ F hmatch P04 hAr
      hcompact hcomplete htmono hB hsigma q r a b (isCompact_Icc.prod (isCompact_closedBall _ _)) hCsub⟩

end PoincareMT.ControlledBlowupCompactness
