import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.SpatialJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.PullbackCurvature

/-!
# Terminal scalar curvature of controlled source limits
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)
  (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
  (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))

include hF P04 hB hAr hcompact hcomplete

/-- Actual scalar curvatures of retained source points converge through
the included terminal slice. -/
theorem tendsto_terminal_scalarCurvature
    {t : ℝ} (ht : t ∈ Icc 0 (T / 2)) (x : G.limitCarrier.carrier) :
    Tendsto (fun k => ((terminalSourceFlow G k).connection t).scalarCurvature
      ((G.embedding k).toFun (0, x)).2) atTop (𝓝 ((F.connection t).scalarCurvature x)) := by
  classical
  let c := extChartAt (𝓡 3) x
  let p := c x
  have hp : p ∈ c.target := mem_extChartAt_target x
  have hcx : c.symm p = x := c.left_inv (mem_extChartAt_source x)
  obtain ⟨g, D, V, hVo, hpV, _, heq⟩ := G.limitCarrier.exists_local_coordinate_realization
    (F.metric t) x t p hp
  have hg : ∀ᶠ y in 𝓝 p, ∀ a b : Fin 3,
      g.euclideanCoefficients y (EuclideanSpace.basisFun (Fin 3) ℝ a)
        (EuclideanSpace.basisFun (Fin 3) ℝ b) =
      G.limitCarrier.coordinateCoefficient x
        (fun _ y v w => G.limitCarrier.metricInner (F.metric t) y v w) a b (t, y) :=
    Filter.Eventually.mono (hVo.mem_nhds hpV) heq
  obtain ⟨ρ, hρ, hρc⟩ := G.exists_referenceBall_radius x
  have hzero : 0 ∈ Ioo (-T / 2) (T / 2) := ⟨by linarith, by linarith⟩
  have hφ : ∀ᶠ k : ℕ in atTop, ∀ᶠ y in 𝓝 p,
      ContMDiffAt (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap x k 0) y ∧
        Function.Injective (mfderiv (𝓡 3) (𝓡 3) (G.referenceChartMap x k 0) y) := by
    filter_upwards [G.eventually_subset_referencePartialChart_source x hzero
      (isCompact_closedBall _ _) hρc] with k hk
    filter_upwards [Metric.ball_mem_nhds p hρ] with y hy
    have hys := hk (ball_subset_closedBall hy)
    exact ⟨G.referenceChartMap_contMDiffAt x k hzero hys.1 hys.2,
      (G.referenceChartMap_mfderiv_isInvertible x k hzero hys.1 hys.2).injective⟩
  have hscalar := LeviCivitaData.tendsto_scalarCurvature_of_scalar_pullback_jets
    (fun k => (terminalSourceFlow G k).connection t)
    (fun k => G.referenceChartMap x k 0) D p hφ (by
      intro r _ a b
      rw [G.limitCarrier.iteratedFDeriv_coordinateCoefficient_eq_of_eventuallyEq
        x _ t p g hg r a b]
      exact tendsto_terminal_spatial_pullbackJet G F hF P04 hB hAr hcompact hcomplete
        x hp ht r a b)
  have hlim : D.scalarCurvature p = (F.connection t).scalarCurvature x := by
    have heqscalar := G.limitCarrier.scalarCurvature_eq_of_coordinate_germ
      (F.metric t) (F.connection t) x t p hp g D hg
    change D.scalarCurvature p = (F.connection t).scalarCurvature (c.symm p) at heqscalar
    rw [hcx] at heqscalar
    exact heqscalar
  rw [hlim] at hscalar
  change (extChartAt (𝓡 3) x).symm p = x at hcx
  simpa only [PointedGeometricConvergence.referenceChartMap, Function.comp_apply, hcx] using hscalar

/-- The actual included endpoint retains the exact base scalar normalization. -/
theorem terminal_scalar_normalized :
    (F.connection (T / 2)).scalarCurvature G.limitFlow.base = 1 := by
  have hlim := tendsto_terminal_scalarCurvature G F hF P04 hB hAr hcompact hcomplete
    (show T / 2 ∈ Icc 0 (T / 2) from ⟨by positivity, le_rfl⟩) G.limitFlow.base
  have hnorm (k : ℕ) : ((terminalSourceFlow G k).connection (T / 2)).scalarCurvature
      ((G.embedding k).toFun (0, G.limitFlow.base)).2 = 1 := by
    have hb := congrArg Prod.snd (G.base_preserving k)
    change ((G.embedding k).toFun (0, G.limitFlow.base)).2 =
      smallBase S (idx (G.subsequence k)) (hA _) at hb
    rw [hb]
    change (((e (G.subsequence k)).smallFlow (hA _) hT).connection
      (T / 2 + (-T / 2))).scalarCurvature _ = 1
    rw [show T / 2 + (-T / 2) = 0 by ring]
    exact (e (G.subsequence k)).smallFlow_scalar_normalized (hA _) hT
  exact tendsto_nhds_unique hlim (by simpa only [hnorm] using
    (tendsto_const_nhds : Tendsto (fun _ : ℕ => (1 : ℝ)) atTop (𝓝 1)))

end PoincareMT.ControlledBlowupCompactness
