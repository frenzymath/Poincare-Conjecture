import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Source
import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Coordinates.PartialCharts

/-!
# Actual terminal charts into controlled source balls

An injective local terminal parametrization captured in a source ball is an
actual partial diffeomorphism into that ball. Its normalized terminal metric
coefficients agree with the original component parametrization.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}
  (hA : 0 < A) {U : Set (EuclideanSpace ℝ (Fin 3))}
  (phi : EuclideanSpace ℝ (Fin 3) → S.terminalComponent k)
  (hball : ∀ z ∈ U, (phi z).val ∈ S.baseBall k A)

def terminalBallParametrization (z : EuclideanSpace ℝ (Fin 3)) : sourceBall S k A := by
  classical
  exact if hz : z ∈ U then ⟨(phi z).val, hball z hz⟩
    else ⟨(S.base k).2, base_mem_sourceBall hA⟩

theorem terminalBallParametrization_val {z : EuclideanSpace ℝ (Fin 3)} (hz : z ∈ U) :
    (terminalBallParametrization hA phi hball z).val = (phi z).val := by
  simp only [terminalBallParametrization, dif_pos hz]

theorem terminalBallParametrization_isLocalDiffeomorphOn
    (hU : IsOpen U) (hphi : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ phi U) :
    IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (terminalBallParametrization hA phi hball) U := by
  intro x
  have hx := x.property
  let f := terminalBallParametrization hA phi hball
  have hraw := (hphi x).comp (𝓡 3) _
    (Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 3) (S.terminalComponent k) (phi x))
  have hi := Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 3) (sourceBall S k A) (f x)
  have hval : (f x).val = (phi x).val := terminalBallParametrization_val hA phi hball hx
  have hinv : IsLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞ hi.localInverse (phi x).val := by
    rw [← hval]
    exact hi.localInverse_isLocalDiffeomorphAt
  apply (hraw.comp (𝓡 3) _ hinv).congr_of_eventuallyEq
  have hright : ∀ᶠ y in 𝓝 ((phi x).val), (hi.localInverse y).val = y := by
    rw [← hval]
    exact hi.localInverse_eventuallyEq_right
  filter_upwards [hU.mem_nhds hx, hraw.contMDiffAt.continuousAt.tendsto.eventually hright]
    with y hy hyeq
  apply Subtype.ext
  exact (terminalBallParametrization_val hA phi hball hy).trans hyeq.symm

theorem terminalBallParametrization_injOn (hphi : InjOn phi U) :
    InjOn (terminalBallParametrization hA phi hball) U := by
  intro x hx y hy hxy
  apply hphi hx hy
  apply Subtype.ext
  simpa only [terminalBallParametrization_val hA phi hball hx,
    terminalBallParametrization_val hA phi hball hy] using congrArg Subtype.val hxy

def terminalBallPartialChart (hU : IsOpen U)
    (hphi : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ phi U) (hinj : InjOn phi U) :
    PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3)) (sourceBall S k A) ∞ :=
  AncientCompactness.partialDiffeomorphOfInjOn hU
    (terminalBallParametrization hA phi hball)
    (terminalBallParametrization_injOn hA phi hball hinj)
    (terminalBallParametrization_isLocalDiffeomorphOn hA phi hball hU hphi)

theorem terminalBallPartialChart_source (hU : IsOpen U)
    (hphi : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ phi U) (hinj : InjOn phi U) :
    (terminalBallPartialChart hA phi hball hU hphi hinj).source = U := rfl

theorem terminalBallParametrization_terminal_coefficients
    (hU : IsOpen U) (hphi : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ phi U)
    (cyl : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    {z : EuclideanSpace ℝ (Fin 3)} (hz : z ∈ U) :
    ((cyl.ordinaryFlow hT).metric 0).pullbackCoefficients
      (terminalBallParametrization hA phi hball) z =
      (S.terminalComponentMetric k).pullbackCoefficients phi z := by
  let f := terminalBallParametrization hA phi hball
  have hf := terminalBallParametrization_isLocalDiffeomorphOn hA phi hball hU hphi ⟨z, hz⟩
  have hfeq : ((Subtype.val : sourceBall S k A → _) ∘ f) =ᶠ[𝓝 z]
      ((Subtype.val : S.terminalComponent k → _) ∘ phi) :=
    Filter.mem_of_superset (hU.mem_nhds hz)
      (fun x hx => terminalBallParametrization_val hA phi hball hx)
  have hdf := hfeq.mfderiv_eq (I := 𝓡 3) (I' := 𝓡 3)
  rw [mfderiv_comp z ((contMDiff_subtype_val (n := ∞)).mdifferentiable (by simp) (f z))
      (hf.mdifferentiableAt (by simp)),
    mfderiv_comp z ((contMDiff_subtype_val (n := ∞)).mdifferentiable (by simp) (phi z))
      ((hphi ⟨z, hz⟩).mdifferentiableAt (by simp))] at hdf
  ext v w
  change ((cyl.ordinaryFlow hT).metric 0).inner (f z)
    (mfderiv (𝓡 3) (𝓡 3) f z v) (mfderiv (𝓡 3) (𝓡 3) f z w) = _
  rw [cyl.ordinaryFlow_terminal_inner hT]
  change (S.normalizedTerminalMetric k).inner (f z).val
    (((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) (f z)).comp
      (mfderiv (𝓡 3) (𝓡 3) f z)) v)
    (((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) (f z)).comp
      (mfderiv (𝓡 3) (𝓡 3) f z)) w) =
    (S.normalizedTerminalMetric k).inner (phi z).val
    (((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : S.terminalComponent k → _) (phi z)).comp
      (mfderiv (𝓡 3) (𝓡 3) phi z)) v)
    (((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : S.terminalComponent k → _) (phi z)).comp
      (mfderiv (𝓡 3) (𝓡 3) phi z)) w)
  rw [hdf, terminalBallParametrization_val hA phi hball hz]

end PoincareMT.ControlledBlowupCylinder
