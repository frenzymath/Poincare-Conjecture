import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.CapExit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Geometry.Triangle
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Geometry.Depth
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Separation.Diameter

/-!
# A large nondegenerate triangle excludes an actual small cap core

Both minimizing sides from a cap core cross the same end sphere. That sphere
is small compared with its distance from the core, contradicting the
corresponding-side Toponogov lower bound on the transverse chord.
Reference: Morgan--Tian, Claim 11.14, pp. 276--277.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.CapCertificate

theorem exists_large_triangle_exclusion_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 1000 ∧
      ∀ {M : Type u} [TopologicalSpace M] [ConnectedSpace M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
        [MeasurableSpace M] [BorelSpace M] [T2Space M] [T3Space M]
        {g : RiemannianMetric 3 M},
        ∀ C : CapCertificate g, C.epsilon ≤ epsilon₀ →
        ∀ D : LeviCivitaData g, MetricComplete g → D.NonnegativeSectionalCurvature →
        ∀ {p y z : M} {d : ℝ}, 0 < d →
        d ≤ (g.edist y p).toReal → d ≤ (g.edist y z).toReal →
        (g.edist y p).toReal ≤ 3 * d / 2 → (g.edist y z).toReal ≤ 3 * d / 2 →
        d ≤ (g.edist p z).toReal → y ∈ C.core → p ∉ C.carrier → z ∉ C.carrier → False := by
  obtain ⟨epsilon₁, hepsilon₁, hsmall₁, hcross⟩ := exists_end_sphere_crossing_threshold.{u}
  have hdepthConstant := ControlledTerminal.centralNeckDepthConstant_pos
  let epsilon₂ := 1 / (8 * Real.pi * ControlledTerminal.centralNeckDepthConstant)
  have hepsilon₂ : 0 < epsilon₂ := by dsimp [epsilon₂]; positivity
  refine ⟨min epsilon₁ epsilon₂, lt_min hepsilon₁ hepsilon₂,
    (min_le_left _ _).trans hsmall₁, ?_⟩
  intro M _ _ _ _ _ _ _ _ g C hepsilon D hcomplete hsec p y z d hd ha hb ha' hb' hfar hy hp hz
  let a := (g.edist y p).toReal
  let b := (g.edist y z).toReal
  have ha0 : 0 < a := hd.trans_le ha
  have hb0 : 0 < b := hd.trans_le hb
  obtain ⟨gamma, hgamma0, hgammaa, hgamma, hgammaspeed, hgammamin⟩ :=
    g.exists_unit_speed_minimizing_geodesic_of_metricComplete hcomplete y p ha0
  obtain ⟨sigma, hsigma0, hsigmab, hsigma, hsigmaspeed, hsigmamin⟩ :=
    g.exists_unit_speed_minimizing_geodesic_of_metricComplete hcomplete y z hb0
  obtain ⟨r, hr, hrN⟩ := hcross C (hepsilon.trans (min_le_left _ _)) ha0.le
    hgamma.contMDiffOn.continuousOn (hgamma0.symm ▸ hy) (hgammaa.symm ▸ hp)
  obtain ⟨t, ht, htN⟩ := hcross C (hepsilon.trans (min_le_left _ _)) hb0.le
    hsigma.contMDiffOn.continuousOn (hsigma0.symm ▸ hy) (hsigmab.symm ▸ hz)
  have hynot : y ∉ C.end_neck.carrier := fun h =>
    disjoint_left.mp C.disjoint_closed_core_end (C.core_subset_closed_core hy) h
  have hdepth (w : M) (hw : w ∈ C.end_neck.central_sphere) :
      4 * Real.pi * C.end_neck.scale ≤ (g.edist y w).toReal := by
    apply le_trans _ (C.end_neck.central_sphere_depth_lower_bound_simple hynot hw)
    have hscalePos := C.end_neck.scale_pos
    have hneckPos := C.end_neck.epsilon_pos
    have hneckSmall : C.end_neck.epsilon ≤ epsilon₂ := by
      rw [C.end_neck_epsilon]
      exact hepsilon.trans (min_le_right _ _)
    apply (le_div_iff₀ (by positivity :
      0 < 2 * ControlledTerminal.centralNeckDepthConstant * C.end_neck.epsilon)).mpr
    have he := (le_div_iff₀ (by positivity :
      0 < 8 * Real.pi * ControlledTerminal.centralNeckDepthConstant)).mp hneckSmall
    have hh := mul_le_mul_of_nonneg_right he hscalePos.le
    nlinarith
  have hrmin := hgammamin 0 ⟨le_rfl, ha0.le⟩ r ⟨hr.1.le, hr.2⟩
  have htmin := hsigmamin 0 ⟨le_rfl, hb0.le⟩ t ⟨ht.1.le, ht.2⟩
  have hrdepth : 4 * Real.pi * C.end_neck.scale ≤ r := by
    have hh := hdepth (gamma r) hrN
    rw [hgamma0, zero_sub, abs_neg, abs_of_nonneg hr.1.le] at hrmin
    rw [hrmin, ENNReal.toReal_ofReal hr.1.le] at hh
    exact hh
  have htdepth : 4 * Real.pi * C.end_neck.scale ≤ t := by
    have hh := hdepth (sigma t) htN
    rw [hsigma0, zero_sub, abs_neg, abs_of_nonneg ht.1.le] at htmin
    rw [htmin, ENNReal.toReal_ofReal ht.1.le] at hh
    exact hh
  have hchord : (g.edist (gamma r) (sigma t)).toReal ≤ 2 * Real.pi * C.end_neck.scale := by
    have hh := ENNReal.toReal_mono ENNReal.ofReal_ne_top
      (C.end_neck.edist_central_sphere_le_two_pi_mul_scale hrN htN)
    rw [ENNReal.toReal_ofReal
      (mul_nonneg (mul_nonneg (by norm_num) Real.pi_pos.le) C.end_neck.scale_pos.le)] at hh
    exact hh
  have hrbound : (g.edist (gamma r) (sigma t)).toReal ≤ r / 2 := by linarith
  have htbound : (g.edist (gamma r) (sigma t)).toReal ≤ t / 2 := by linarith
  have hv : (g.edist (gamma r) (sigma t)).toReal ^ 2 ≤ r * t / 4 := by
    have hh := mul_le_mul hrbound htbound ENNReal.toReal_nonneg
      (div_nonneg hr.1.le (by norm_num))
    nlinarith
  have hfar' : d ≤ (g.edist (gamma a) (sigma b)).toReal := by
    rw [hgammaa, hsigmab]
    exact hfar
  exact (not_le_of_gt (g.transverse_chord_sq_gt_of_large_triangle D hcomplete hsec
    hd ha hb ha' hb' hfar' hgamma hsigma hgamma0 hsigma0 hgammaspeed hsigmaspeed
      hgammamin hsigmamin hr ht)) hv

end PoincareMT.CapCertificate
