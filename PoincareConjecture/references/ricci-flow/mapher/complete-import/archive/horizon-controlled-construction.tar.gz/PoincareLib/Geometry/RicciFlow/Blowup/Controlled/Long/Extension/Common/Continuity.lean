import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Geometry
import PoincareLib.Geometry.RicciFlow.Curvature.Theory
import PoincareLib.Geometry.Riemannian.Connection.Uniqueness

/-! # Compact scalar sampling near a bounded closed boundary slice -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongExtension

theorem scalarCurvature_eq_of_metric_eq
    {n : ℕ} {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    {g h : RiemannianMetric n M} (D : LeviCivitaData g) (E : LeviCivitaData h)
    (heq : g = h) (x : M) : D.scalarCurvature x = E.scalarCurvature x := by
  subst h
  exact D.scalarCurvature_eq E x

theorem exists_compact_scalar_sample_near_closed_boundary
    {M : Type u} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    (P04 : RicciFlowCurvatureTheory.{u}) {T B delta : ℝ} (hT : 0 < T) (hdelta : 0 < delta)
    (F : RicciFlow 3 M (Icc (-T) 0))
    (hboundary : ∀ x : M, (F.connection (-T)).scalarCurvature x ≤ B)
    {K : Set M} (hK : IsCompact K) :
    ∃ a ∈ Ioo (-T) 0, a < -T + delta ∧
      ∀ x ∈ K, (F.connection a).scalarCurvature x ≤ B + 1 := by
  have hregular := (P04.scalar_regular 3 M (Icc (-T) 0) F).continuousOn
  have hevent : ∀ᶠ a in 𝓝 (-T), ∀ x ∈ K, a ∈ Icc (-T) 0 →
      (F.connection a).scalarCurvature x < B + 1 := by
    apply hK.eventually_forall_of_forall_eventually
    intro x _
    have hh := (hregular (-T, x) ⟨⟨le_rfl, by linarith⟩, mem_univ x⟩).eventually
      (Iio_mem_nhds (show (F.connection (-T)).scalarCurvature x < B + 1 by
        linarith [hboundary x]))
    rw [eventually_nhdsWithin_iff] at hh
    exact hh.mono fun z hz ht => hz ⟨ht, mem_univ z.2⟩
  obtain ⟨r, hr, hrbound⟩ := Metric.mem_nhds_iff.mp hevent
  let s := min r (min delta T) / 2
  have hs : 0 < s := div_pos (lt_min hr (lt_min hdelta hT)) (by norm_num)
  have hsr : s < r := by
    have hh := min_le_left r (min delta T)
    dsimp [s]
    linarith
  have hsdelta : s < delta := by
    have hh := (min_le_right r (min delta T)).trans (min_le_left delta T)
    dsimp [s]
    linarith
  have hsT : s < T := by
    have hh := (min_le_right r (min delta T)).trans (min_le_right delta T)
    dsimp [s]
    linarith
  refine ⟨-T + s, ⟨by linarith, by linarith⟩, by linarith, ?_⟩
  intro x hx
  apply (hrbound ?_ x hx ⟨by linarith, by linarith⟩).le
  simpa only [Metric.mem_ball, Real.dist_eq, add_sub_cancel_left,
    abs_of_pos hs] using hsr

end PoincareMT.ControlledLongExtension
