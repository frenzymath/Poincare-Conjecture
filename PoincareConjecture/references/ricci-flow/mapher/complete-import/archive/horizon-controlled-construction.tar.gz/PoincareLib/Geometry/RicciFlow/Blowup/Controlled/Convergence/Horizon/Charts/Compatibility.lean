import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.Positivity

/-! # Compatibility of horizon coefficient limits on retained chart overlaps -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

theorem eventually_horizonSpacetimeCoefficients_compatible
    (p q : G.limitCarrier.carrier)
    {x y : EuclideanSpace ℝ (Fin 3)}
    (hx : x ∈ (extChartAt (𝓡 3) p).target) (hy : y ∈ (extChartAt (𝓡 3) q).target)
    (hxy : (extChartAt (𝓡 3) p).symm x = (extChartAt (𝓡 3) q).symm y)
    (v w a b : EuclideanSpace ℝ (Fin 3))
    (hv : mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) p).symm x v =
      mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm y a)
    (hw : mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) p).symm x w =
      mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm y b) :
    ∀ᶠ k in atTop, ∀ t,
      horizonSpacetimeCoefficients G p k (t, x) v w =
        horizonSpacetimeCoefficients G q k (t, y) a b := by
  have hzero : -tau 0 / 2 < 0 ∧ 0 < tau 0 / 2 :=
    ⟨by linarith [htau 0], by linarith [htau 0]⟩
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset
    (isCompact_singleton (x := (extChartAt (𝓡 3) p).symm x))
  filter_upwards [eventually_ge_atTop j] with k hk t
  have hxe := G.exhaustion_monotone hk (hj (mem_singleton _))
  have hye : (extChartAt (𝓡 3) q).symm y ∈ G.exhaustion k := hxy ▸ hxe
  have hcp := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) p hx).contMDiffAt
    (extChartAt_target_mem_nhds' hx)
  have hcq := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q hy).contMDiffAt
    (extChartAt_target_mem_nhds' hy)
  have hep := (G.embedding k).spatialMap_contMDiffAt (G.exhaustion_open k) hzero hxe
  have heq := (G.embedding k).spatialMap_contMDiffAt (G.exhaustion_open k) hzero hye
  unfold horizonSpacetimeCoefficients RiemannianMetric.pullbackCoefficients
    PointedGeometricConvergence.referenceChartMap
  rw [mfderiv_comp x (hep.mdifferentiableAt (by simp)) (hcp.mdifferentiableAt (by simp)),
    mfderiv_comp y (heq.mdifferentiableAt (by simp)) (hcq.mdifferentiableAt (by simp))]
  simp only [ContinuousLinearMap.bilinearComp_apply, ContinuousLinearMap.comp_apply, Function.comp_apply]
  rw [hxy]
  exact congrArg₂ (fun (c d : EuclideanSpace ℝ (Fin 3)) =>
    ((horizonSourceFlow hA htau e (G.subsequence k)).metric t).inner
      ((G.embedding k).toFun (0, (extChartAt (𝓡 3) q).symm y)).2
      (mfderiv (𝓡 3) (𝓡 3) (fun z => ((G.embedding k).toFun (0, z)).2)
        ((extChartAt (𝓡 3) q).symm y) c)
      (mfderiv (𝓡 3) (𝓡 3) (fun z => ((G.embedding k).toFun (0, z)).2)
        ((extChartAt (𝓡 3) q).symm y) d)) hv hw

theorem horizon_limit_compatible
    (p q : G.limitCarrier.carrier) {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    {f g : ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3}
    {t : ℝ} {x y : EuclideanSpace ℝ (Fin 3)}
    (hf : Tendsto (fun k => horizonSpacetimeCoefficients G p (sigma k) (t, x)) atTop (𝓝 (f (t, x))))
    (hg : Tendsto (fun k => horizonSpacetimeCoefficients G q (sigma k) (t, y)) atTop (𝓝 (g (t, y))))
    (hx : x ∈ (extChartAt (𝓡 3) p).target) (hy : y ∈ (extChartAt (𝓡 3) q).target)
    (hxy : (extChartAt (𝓡 3) p).symm x = (extChartAt (𝓡 3) q).symm y)
    (v w a b : EuclideanSpace ℝ (Fin 3))
    (hv : mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) p).symm x v =
      mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm y a)
    (hw : mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) p).symm x w =
      mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm y b) :
    f (t, x) v w = g (t, y) a b := by
  have heval (a b : EuclideanSpace ℝ (Fin 3)) :
      Continuous (fun D : SpacetimeBounds.MetricCoefficient 3 => D a b) :=
    (continuous_id.clm_apply continuous_const).clm_apply continuous_const
  apply tendsto_nhds_unique ((heval v w).tendsto _ |>.comp hf)
  apply (((heval a b).tendsto _).comp hg).congr'
  exact (hsigma.tendsto_atTop.eventually
    (eventually_horizonSpacetimeCoefficients_compatible G p q hx hy hxy v w a b hv hw)).mono
      fun k hk => (hk t).symm

end PoincareMT.ControlledBlowupCompactness
