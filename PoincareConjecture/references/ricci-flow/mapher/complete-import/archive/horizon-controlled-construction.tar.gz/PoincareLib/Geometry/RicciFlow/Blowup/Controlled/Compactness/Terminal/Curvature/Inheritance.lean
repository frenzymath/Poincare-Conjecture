import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Curvature.Static
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Curvature.Source

/-!
# Normalization and nonnegative curvature of terminal metric limits

The actual terminal metric jets preserve scalar normalization and pass the
vanishing normalized pinching error to nonnegative curvature operator.
Compact image bounds supply the radius before the source index is chosen.
Source: Morgan--Tian, Theorem 11.1, pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem curvature_of_terminal_metric_jets
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {g : RiemannianMetric 3 M} (D : LeviCivitaData g) (p : M)
    (E : ℕ → Set M) (hE : ∀ j, IsOpen (E j))
    (hEstep : ∀ j, closure (E j) ⊆ E (j + 1)) (hEcover : ⋃ j, E j = univ)
    (f : ∀ k, M → S.terminalComponent (sigma k))
    (hlocal : ∀ k, IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k))
    (hbase : ∀ k, f k p = S.terminalComponentBase (sigma k))
    (hconv : ∀ q m K, IsCompact K → K ⊆ (extChartAt (𝓡 3) q).target →
      TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ m ((S.terminalComponentMetric (sigma k)).pullbackCoefficients
          (f k ∘ (extChartAt (𝓡 3) q).symm)))
        (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm)) atTop K)
    (himage : ∀ K : Set M, IsCompact K → ∃ R : ℝ, 0 < R ∧ ∀ᶠ k in atTop,
      f k '' K ⊆ (S.terminalComponentMetric (sigma k)).ball (S.terminalComponentBase (sigma k)) R) :
    (∀ x : M, D.NonnegativeCurvatureOperator x) ∧ D.scalarCurvature p = 1 ∧
      ∀ K : Set M, IsCompact K →
        TendstoUniformlyOn
          (fun k x => (S.terminalComponentConnection (sigma k)).scalarCurvature (f k x))
          D.scalarCurvature atTop K := by
  have hmono : Monotone E := monotone_nat_of_le_succ fun j => subset_closure.trans (hEstep j)
  let Ds := fun k => S.terminalComponentConnection (sigma k)
  refine ⟨?_, ?_, ?_⟩
  · intro x
    obtain ⟨A, hA, hball⟩ := himage {x} isCompact_singleton
    have hnegative := H.tendsto_terminalComponent_negativePart_zero P04 hbound hsigma
      (fun k => f k x) ⟨A, hA, ?_⟩
    · exact ControlledTerminal.nonnegativeCurvatureOperator_of_spatial_metric_jets
        D Ds E hE hmono hEcover f hlocal hconv x hnegative (Eventually.of_forall fun _ => le_rfl)
    · filter_upwards [hball] with k hk
      rw [← S.terminalComponentMetric_image_ball]
      exact mem_image_of_mem Subtype.val (hk (mem_image_of_mem (f k) (mem_singleton x)))
  · have hh := (ControlledTerminal.tendsto_curvature D Ds E hE hmono hEcover f hlocal hconv p).1
    apply tendsto_nhds_unique hh
    apply tendsto_const_nhds.congr
    intro k
    rw [hbase k, S.terminalComponentConnection_scalar_base]
  · intro K hK
    exact ControlledTerminal.tendstoUniformlyOn_scalarCurvature D Ds E hE hmono hEcover f hlocal hconv hK

end PoincareMT.M30CommonBlowupControls
