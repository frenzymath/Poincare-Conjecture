import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.Selection
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Diagonal

/-!
# Compact scalar bounds from a uniform pointwise minimum

Connected scalar interpolation and the finite-time diameter estimate
provide the actual source diagonal excluded by M29.
Reference: Morgan--Tian, Lemma 11.10, pp. 274--275.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_uniform_compact_scalar_bound_of_minimum_bound
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {epsilon C : ℝ}
    (hM29 : ∀ S : GeneralizedBlowupSequence.{u},
      DenseGeneralizedBoundedDistanceHypotheses S epsilon C → GeneralizedBlowupBoundedDistance S)
    (H : DenseGeneralizedBoundedDistanceHypotheses S epsilon C)
    {K : Set G.limit.carrier.carrier} (hK : IsCompact K) (hconn : IsPreconnected K)
    {B : ℝ} (hmin : ∀ t ∈ Ioc (-T) 0, ∃ y ∈ K,
      (G.limit.flow.connection t).scalarCurvature y ≤ B) :
    ∃ D : ℝ, 0 < D ∧ ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
      (G.limit.flow.connection t).scalarCurvature x ≤ D := by
  have hbound : ∃ D : ℝ, ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
      (G.limit.flow.connection t).scalarCurvature x ≤ D := by
    by_contra hnot
    obtain ⟨A, B', hA, hB', t, y, z, ht, _, hyl, hyu, hz, hdist⟩ :=
      ControlledLongCompact.exists_curvature_contrast_sequence_of_unbounded
        P04 P06 hT G.limit hK hconn hmin hnot
    let J : SpacetimeInterval := ⟨Ioc (-T) 0, ordConnected_Ioc,
      ⟨-T / 2, ⟨by linarith, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩⟩
    exact G.not_unbounded_scalar_at_bounded_distance (J := J) P04 hM29 H t ht
      (fun m => (ht m).2) y z hA hB' (fun m => ⟨hyl m, hyu m⟩) hz hdist
  obtain ⟨D, hD⟩ := hbound
  exact ⟨max D 1, lt_of_lt_of_le zero_lt_one (le_max_right _ _),
    fun t ht x hx => (hD t ht x hx).trans (le_max_left _ _)⟩

end PoincareMT.GeneralizedBlowupConvergence
