import PoincareLib.Topology.Manifold.EmbeddedSphere.Separation.LocalParity
import PoincareLib.Topology.Manifold.NeckCap.Cylinder.Sphere
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Separation.Diameter
import Mathlib.Analysis.Convex.Contractible

/-!
# Small centered necks are ambient separating

A central sphere captured in a contractible neighborhood is null-homotopic.
The existing local-parity proof then separates its ambient manifold, without
a global topological classification or compactness assumption.

Reference: Morgan--Tian, Claim 11.14 and Proposition 15.12, p. 365.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

namespace PoincareMT.ControlledTerminal

/-- Euclidean charts supply actual contractible open neighborhoods. -/
theorem exists_contractible_open_neighborhood
    {n : ℕ} {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] (x : M) :
    ∃ U : Set M, IsOpen U ∧ x ∈ U ∧ ContractibleSpace U := by
  let e := chartAt (EuclideanSpace ℝ (Fin n)) x
  have hx : x ∈ e.source := mem_chart_source _ _
  obtain ⟨r, hr, hball⟩ := Metric.isOpen_iff.mp e.open_target (e x) (e.map_source hx)
  let U := e.symm '' Metric.ball (e x) r
  have hU : IsOpen U := e.symm.isOpen_image_of_subset_source Metric.isOpen_ball hball
  have hxU : x ∈ U := ⟨e x, Metric.mem_ball_self hr, e.left_inv hx⟩
  let : ContractibleSpace (Metric.ball (e x) r) :=
    (convex_ball (e x) r).contractibleSpace ⟨e x, Metric.mem_ball_self hr⟩
  exact ⟨U, hU, hxU,
    (e.symm.homeomorphOfImageSubsetSource hball rfl).contractibleSpace_iff.mp inferInstance⟩

end PoincareMT.ControlledTerminal

namespace PoincareMT.EpsilonNeck

variable {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
  [IsManifold (𝓡 3) ∞ M] [MeasurableSpace M] [BorelSpace M]
  [T2Space M] [T3Space M] [ConnectedSpace M] {g : RiemannianMetric 3 M}

/-- Capturing the actual central sphere in a contractible set proves ambient
separation; neither a ball filling nor an ambient diffeomorphism is assumed. -/
theorem isSeparating_of_central_sphere_subset_contractible
    (N : EpsilonNeck g) {U : Set M} [ContractibleSpace U]
    (hU : N.central_sphere ⊆ U) : N.IsSeparating := by
  let f : ContinuousMap UnitTwoSphere U :=
    ⟨fun q => ⟨N.coordinate_map (q, 0), hU (by
        rw [← N.centralSphere_range]
        exact mem_range_self q)⟩,
      N.centralSphere_contMDiff.continuous.subtype_mk _⟩
  let incl : ContinuousMap U M := ⟨Subtype.val, continuous_subtype_val⟩
  obtain ⟨p, hp⟩ := ((id_nullhomotopic U).comp_left f).comp_right incl
  let S : SmoothEmbeddedNullHomotopicSphere (M := M) :=
    { sphere := fun q => N.coordinate_map (q, 0)
      smooth_embedding := N.centralSphere_isSmoothEmbedding
      null_homotopic := ⟨N.centralSphere_contMDiff.continuous, p, hp⟩ }
  refine ⟨N.component_diff_central_sphere_nonempty, ?_⟩
  intro hconn
  apply Topology.EmbeddedSphere.sphere_complement_not_isPreconnected S
  have hpre := hconn.isPreconnected
  rw [PreconnectedSpace.connectedComponent_eq_univ, ← compl_eq_univ_sdiff] at hpre
  simpa only [S, N.centralSphere_range] using hpre

/-- For a fixed reference metric and center, sufficiently small spheres of
any distance-dominating metric are separating. The radius is chosen before
the second metric and its neck. -/
theorem exists_separating_radius_of_reference_metric
    (g₀ : RiemannianMetric 3 M) (p : M) :
    ∃ r : ℝ, 0 < r ∧ ∀ (g : RiemannianMetric 3 M) (N : EpsilonNeck g),
      N.center = p →
      (∀ x : M, (g₀.edist p x).toReal ≤ (g.edist p x).toReal) →
      2 * Real.pi * N.scale < r → N.IsSeparating := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
    ⟨g₀.toRiemannianMetric⟩
  let : IsContinuousRiemannianBundle (EuclideanSpace ℝ (Fin 3))
      (TangentSpace (𝓡 3) : M → Type _) :=
    ⟨⟨g₀.inner, g₀.toContinuousRiemannianMetric.continuous, fun _ _ _ => rfl⟩⟩
  let : EMetricSpace M := EMetricSpace.ofRiemannianMetric (𝓡 3) M
  obtain ⟨U, hU, hp, hcontract⟩ :=
    ControlledTerminal.exists_contractible_open_neighborhood (n := 3) p
  let : ContractibleSpace U := hcontract
  obtain ⟨δ, hδ, hδU⟩ := EMetric.mem_nhds_iff.mp (hU.mem_nhds hp)
  have hδ' : 0 < min δ 1 := lt_min hδ (by norm_num)
  have hfinite : min δ 1 ≠ ⊤ := ne_of_lt
    ((min_le_right δ 1).trans_lt (by norm_num : (1 : ℝ≥0∞) < ⊤))
  refine ⟨(min δ 1).toReal, ENNReal.toReal_pos hδ'.ne' hfinite, ?_⟩
  intro g N hcenter hdist hsmall
  apply N.isSeparating_of_central_sphere_subset_contractible (U := U)
  intro x hx
  apply hδU
  have hdiam := N.edist_central_sphere_le_two_pi_mul_scale N.center_on_central_sphere hx
  rw [hcenter] at hdiam
  have hreal := ENNReal.toReal_mono ENNReal.ofReal_ne_top hdiam
  rw [ENNReal.toReal_ofReal
    (mul_nonneg (mul_nonneg (by norm_num) Real.pi_pos.le) N.scale_pos.le)] at hreal
  have hlt := ((hdist x).trans hreal).trans_lt hsmall
  change edist x p < δ
  rw [edist_comm]
  exact ((ENNReal.toReal_lt_toReal (g₀.edist_ne_top p x) hfinite).mp hlt).trans_le
    (min_le_left _ _)

end PoincareMT.EpsilonNeck
