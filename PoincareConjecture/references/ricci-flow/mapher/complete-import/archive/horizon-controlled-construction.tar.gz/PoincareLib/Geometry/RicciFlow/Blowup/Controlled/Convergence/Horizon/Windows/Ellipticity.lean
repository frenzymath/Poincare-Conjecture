import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.Cylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourceCurvature

/-! # Uniform retained-chart ellipticity on longer controlled windows -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

theorem exists_eventually_reference_window_ellipticity
    {U V D : ℝ} (hTV : T / 2 ≤ V) (hVU : V ≤ U) (hD : 0 ≤ D)
    (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) :
    ∃ a b : ℝ, 0 < a ∧ 0 < b ∧ ∀ᶠ k in atTop,
      ∀ eta' : ℝ, ∀ d : ControlledBlowupCylinder S (idx (G.subsequence k))
        (A (G.subsequence k)) U D eta',
      ∀ s ∈ Icc (-V) 0, ∀ x ∈ K, ∀ v,
        a * ‖v‖ ^ 2 ≤
          ((d.smallFlow (hA _) (by linarith)).metric s).pullbackCoefficients
            (G.referenceChartMap q k 0) x v v ∧
        ((d.smallFlow (hA _) (by linarith)).metric s).pullbackCoefficients
            (G.referenceChartMap q k 0) x v v ≤ b * ‖v‖ ^ 2 := by
  have hzero : -T / 2 < 0 ∧ 0 < T / 2 := ⟨by linarith, by linarith⟩
  obtain ⟨α, β, hα, hβ, href⟩ := G.exists_eventually_reference_ellipticity q hzero hK hKc
  let C : ℝ := (3 : ℝ) ^ 3 * D
  have hC : 0 ≤ C := by dsimp [C]; positivity
  refine ⟨Real.exp (-(2 * C) * V) * α, Real.exp (2 * C * V) * β,
    mul_pos (Real.exp_pos _) hα, mul_pos (Real.exp_pos _) hβ, ?_⟩
  filter_upwards [href] with k hreference eta' d s hs x hx v
  have hU : 0 < U := by linarith
  let H := d.smallFlow (hA _) hU
  let f := G.referenceChartMap q k 0
  let w := mfderiv (𝓡 3) (𝓡 3) f x v
  have hnonneg (t : ℝ) : 0 ≤ (H.metric t).inner (f x) w w := by
    by_cases hw : w = 0
    · simp [hw]
    · exact ((H.metric t).pos _ _ hw).le
  have hsub : Icc (-V) 0 ⊆ Icc (-U) 0 := fun t ht => ⟨by linarith [ht.1], ht.2⟩
  have hRic : ∀ t ∈ Icc (-V) 0,
      |(H.connection t).ricci (f x) w w| ≤ C * (H.metric t).inner (f x) w w := by
    intro t ht
    have h := (H.connection t).abs_ricci_quadratic_le_curvatureTensorNorm (f x) w
    have hdim : Module.finrank ℝ (TangentSpace (𝓡 3) (f x)) = 3 := finrank_euclideanSpace_fin
    simp only [Fintype.card_fin, hdim] at h
    exact h.trans (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left ((le_abs_self _).trans
        (d.smallFlow_curvature_bound (hA _) hU t (hsub ht) (f x))) (by positivity)) (hnonneg t))
  have hτ : -T / 2 ∈ Icc (-V) 0 := ⟨by linarith, by linarith⟩
  have hcomp := H.metric_inner_self_exp_bounds (convex_Icc (-V) 0) hsub
    (f x) w C hRic hτ hs
  have hdist : |s - (-T / 2)| ≤ V := by
    rw [abs_le]
    constructor <;> linarith [hs.1, hs.2]
  have hreference := hreference x hx v
  change α * ‖v‖ ^ 2 ≤
      (((e (G.subsequence k)).smallFlow (hA _) hT).metric (0 + (-T / 2))).inner (f x) w w ∧
    (((e (G.subsequence k)).smallFlow (hA _) hT).metric (0 + (-T / 2))).inner (f x) w w ≤ β * ‖v‖ ^ 2
    at hreference
  rw [zero_add, (e (G.subsequence k)).smallFlow_metric_eq_on_common_time d (hA _) hT hU
    (-T / 2) ⟨by linarith, by linarith⟩ (hsub hτ)] at hreference
  constructor
  · calc
      (Real.exp (-(2 * C) * V) * α) * ‖v‖ ^ 2 =
          Real.exp (-(2 * C) * V) * (α * ‖v‖ ^ 2) := mul_assoc _ _ _
      _ ≤ Real.exp (-(2 * C) * V) * (H.metric (-T / 2)).inner (f x) w w :=
        mul_le_mul_of_nonneg_left hreference.1 (Real.exp_nonneg _)
      _ ≤ Real.exp (-(2 * C) * |s - (-T / 2)|) * (H.metric (-T / 2)).inner (f x) w w :=
        mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr
          (mul_le_mul_of_nonpos_left hdist (by linarith))) (hnonneg (-T / 2))
      _ ≤ _ := hcomp.1
  · calc
      _ ≤ Real.exp (2 * C * |s - (-T / 2)|) * (H.metric (-T / 2)).inner (f x) w w := hcomp.2
      _ ≤ Real.exp (2 * C * V) * (H.metric (-T / 2)).inner (f x) w w :=
        mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr
          (mul_le_mul_of_nonneg_left hdist (by positivity))) (hnonneg (-T / 2))
      _ ≤ Real.exp (2 * C * V) * (β * ‖v‖ ^ 2) :=
        mul_le_mul_of_nonneg_left hreference.2 (Real.exp_nonneg _)
      _ = (Real.exp (2 * C * V) * β) * ‖v‖ ^ 2 := (mul_assoc _ _ _).symm

end PoincareMT.ControlledBlowupCompactness
