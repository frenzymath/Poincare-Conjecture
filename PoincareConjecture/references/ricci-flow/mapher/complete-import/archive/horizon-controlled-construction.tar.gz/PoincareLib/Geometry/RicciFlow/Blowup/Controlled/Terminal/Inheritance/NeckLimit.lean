import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.CenteredBounds
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Normalization
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Transport

/-!
# Actual target necks from metric and scalar convergence

The original neck comparison supplies the source-jet bounds. Convergence
of unnormalized metric jets and the center scalar then constructs the
transported target neck with the prescribed larger accuracy parameter.

Reference: Morgan--Tian, Claim 11.6 and Proposition 9.79(3).
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.TerminalNeck

open MetricSurgery

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem eventually_transported_necks_of_metric_and_scalar_errors
    {X : ℕ → Type u} [∀ k, TopologicalSpace (X k)] [∀ k, ChartedSpace E (X k)]
    [∀ k, IsManifold (𝓡 3) ∞ (X k)]
    {M : Type v} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    (g : ∀ k, RiemannianMetric 3 (X k)) (h : RiemannianMetric 3 M)
    (N : ∀ k, EpsilonNeck (g k)) (e : ∀ k, OpenPartialHomeomorph (X k) M)
    (he : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source)
    (hei : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k).symm (e k).target)
    (hcapture : ∀ k, (N k).carrier ⊆ (e k).source) (D : LeviCivitaData h)
    {δ ε l u : ℝ} (hδ : 0 < δ) (hδε : δ < ε) (hε : ε < 1 / 2)
    (hNeq : ∀ k, (N k).epsilon = δ) (hl : 0 < l) (hu : 0 < u)
    (hscalar : ∀ k, l ≤ (N k).connection.scalarCurvature (N k).center ∧
      (N k).connection.scalarCurvature (N k).center ≤ u)
    (herror : ∀ η : ℝ, 0 < η → ∀ᶠ k in atTop, ∀ z : RoundCylinderSpace,
      z.2 ∈ Ioo (-(N k).epsilon⁻¹) (N k).epsilon⁻¹ → ∀ j, j ≤ ⌊ε⁻¹⌋₊ →
        ‖iteratedFDeriv ℝ j (fun p =>
          (g k).parametrizedCoefficients (centeredNeckLift (N k) z.1 z.2) p -
          h.parametrizedCoefficients (e k ∘ centeredNeckLift (N k) z.1 z.2) p) 0‖ ≤ η)
    (hgap : ∀ η : ℝ, 0 < η → ∀ᶠ k in atTop,
      |D.scalarCurvature (e k (N k).center) -
        (N k).connection.scalarCurvature (N k).center| ≤ η) :
    ∀ᶠ k in atTop, ∃ L : EpsilonNeck h, L.epsilon = ε ∧
      L.center = e k (N k).center ∧ L.connection = D ∧
      L.central_sphere = e k '' (N k).central_sphere ∧
      L.carrier = e k '' (N k).region (-ε⁻¹) ε⁻¹ := by
  let r := ⌊ε⁻¹⌋₊
  have hr (k : ℕ) : r ≤ ⌊(N k).epsilon⁻¹⌋₊ := by
    rw [hNeq k]
    exact Nat.floor_mono ((inv_le_inv₀ (hδ.trans hδε) hδ).2 hδε.le)
  let Z := {z : RoundCylinderSpace // z.2 ∈ Ioo (-δ⁻¹) δ⁻¹}
  let f := fun k (z : Z) => centeredNeckLift (N k) z.1.1 z.1.2
  let a := fun k (z : Z) => (g k).parametrizedCoefficients (f k z)
  let b := fun k (z : Z) => h.parametrizedCoefficients (e k ∘ f k z)
  let q := fun k (_z : Z) => (N k).connection.scalarCurvature (N k).center
  let Q := fun k (_z : Z) => D.scalarCurvature (e k (N k).center)
  have hz (k : ℕ) (z : Z) : z.1.2 ∈ Ioo (-(N k).epsilon⁻¹) (N k).epsilon⁻¹ := by
    rw [hNeq k]
    exact z.property
  have hsmooth (k : ℕ) (z : Z) : ContDiffAt ℝ ∞ (a k z) 0 ∧ ContDiffAt ℝ ∞ (b k z) 0 := by
    have hf := centeredNeckLift_contMDiffAt (N k) z.1.1 z.1.2
      (zero_mem_centeredNeckDomain (N k) (hz k z))
    have hes := (he k).contMDiffAt ((e k).open_source.mem_nhds
      (hcapture k ((N k).coordinate_map_mem ⟨mem_univ _, hz k z⟩)))
    have hes' : ContMDiffAt (𝓡 3) (𝓡 3) ∞ (e k) (f k z 0) := by
      simpa only [f, centeredNeckLift_zero] using hes
    exact ⟨(g k).contDiffAt_parametrizedCoefficients hf,
      h.contDiffAt_parametrizedCoefficients (hes'.comp (0 : E) hf)⟩
  obtain ⟨C, hC, hsource⟩ := exists_centered_neck_jet_bound_of_scalar_lower.{u} r
  obtain ⟨η, hη, htransport⟩ := EpsilonNeck.exists_transported_neck_tolerance.{u, v} hδ hδε hε
  have herrors : ∀ d : ℝ, 0 < d → ∀ᶠ k in atTop, ∀ z : Z, ∀ j, j ≤ r →
      ‖iteratedFDeriv ℝ j (fun p => b k z p - a k z p) 0‖ ≤ d := by
    intro d hd
    filter_upwards [herror d hd] with k hk z j hj
    have hswap : (fun p => b k z p - a k z p) =
        fun p => -(a k z p - b k z p) := by
      funext p
      exact (neg_sub (a k z p) (b k z p)).symm
    rw [hswap]
    change ‖iteratedFDeriv ℝ j (-(fun p : E => a k z p - b k z p)) (0 : E)‖ ≤ d
    rw [iteratedFDeriv_neg_apply, norm_neg]
    exact hk z.1 (hz k z) j hj
  have hnormalized := eventually_small_normalized_jet_errors a b q Q (fun _ : Z => (0 : E)) r
    (div_pos hC hl).le hu.le (Eventually.of_forall hsmooth)
    (Eventually.of_forall fun k z j hj =>
      hsource (N k) hl (hscalar k).1 (hr k) z.1 (hz k z) j hj)
    (Eventually.of_forall fun k _z => by
      rw [abs_of_pos (N k).scalar_center_pos]
      exact (hscalar k).2)
    herrors (fun d hd => (hgap d hd).mono fun k hk _z => hk) hη
  have hpositive : ∀ᶠ k in atTop, 0 < D.scalarCurvature (e k (N k).center) := by
    filter_upwards [hgap (l / 2) (by positivity)] with k hk
    have hh := (abs_le.mp hk).1
    linarith [(hscalar k).1]
  filter_upwards [hnormalized, hpositive] with k hk hQ
  apply htransport (X k) M (g k) h (N k) (hNeq k) (e k)
    (he k) (hei k) (hcapture k) D hQ
  intro z hznew j hj
  exact hk ⟨z, DeepHorn.neckInterval_subset hδ hδε.le hznew⟩ j hj

end PoincareMT.TerminalNeck
