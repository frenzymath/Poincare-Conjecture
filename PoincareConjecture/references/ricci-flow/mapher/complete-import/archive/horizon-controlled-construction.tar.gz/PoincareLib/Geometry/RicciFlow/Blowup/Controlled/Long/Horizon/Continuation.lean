import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Horizon.Geometry
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.FullHorizon
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Cylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Ancient.Convergence
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Theory

/-!
# Full controlled horizons from finite backward extension

The maximal-stage argument retains one original source subsequence. Its
finite extension input is a common cylinder bound, chosen before radius and
error; complete convergence, scale-bounded noncollapse, and infinite-horizon
ancient identification are then constructed on that subsequence.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped ENNReal Topology

universe u

namespace PoincareMT.ControlledBlowupHorizon

theorem nonempty_long_conclusion_of_finite_extensions
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ} {T₀ : ℝ≥0∞}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    (hbounded : GeneralizedBlowupBoundedDistance S)
    (hseed : ∃ (sigma : ℕ → ℕ) (hsigma : StrictMono sigma) (V : ℝ), 0 < V ∧
      Nonempty (M30GeometricLongControls (S.subsequence sigma hsigma) (ENNReal.ofReal V)))
    (hextend : ∀ (sigma : ℕ → ℕ) (hsigma : StrictMono sigma) (T : ℝ),
      0 < T → ENNReal.ofReal T < T₀ →
      ∀ G : GeneralizedBlowupConvergence (S.subsequence sigma hsigma) (Ioc (-T) 0),
      ∃ V B : ℝ, T < V ∧ ENNReal.ofReal V < T₀ ∧ 0 ≤ B ∧
        ∀ A : ℝ, 0 < A → ∀ eta : ℝ, 0 < eta → ∀ᶠ k in atTop,
          Nonempty (ControlledBlowupCylinder (S.subsequence sigma hsigma)
            (G.subsequence k) A V B eta)) :
    Nonempty (RepairedLongControlledBlowupConclusion S kappa r₀ T₀) := by
  classical
  obtain ⟨sigma₀, hsigma₀, V₀, _hV₀, ⟨HG₀⟩⟩ := hseed
  let : Nonempty (Stage S T₀) := ⟨Stage.ofGeometricControls HG₀ H.horizon_pos⟩
  have hvolume := H.toM30CommonBlowupControls.terminal_volume_of_boundedDistance P.m04 hbounded
  have hstage : ∀ a : Stage S T₀, a.horizon < T₀ →
      ∃ b : Stage S T₀, Stage.Refines a b ∧ a.horizon < b.horizon := by
    intro a ha
    have hfinite : a.horizon ≠ ⊤ := ne_top_of_lt (ha.trans_le le_top)
    let T := a.horizon.toReal
    have hT : 0 < T := ENNReal.toReal_pos a.horizon_pos.ne' hfinite
    have heq : ENNReal.ofReal T = a.horizon := ENNReal.ofReal_toReal hfinite
    have hT₀ : ENNReal.ofReal T < T₀ := heq ▸ ha
    obtain ⟨G⟩ := ControlledBlowupCompactness.nonempty_generalizedBlowupConvergence_of_geometricLongControls
      P (a.toGeometricControls H.balls_compact hvolume)
    rw [← heq, blowupBackwardInterval_ofReal_eq hT] at G
    obtain ⟨V, B, hTV, hV₀, hB, hcyl⟩ := hextend a.index a.strictMono T hT hT₀ G
    have hV : 0 < V := hT.trans hTV
    apply a.exists_refinement_of_uniform_cylinders G.subsequence_strictMono hV
      (by rw [← heq]; exact (ENNReal.ofReal_lt_ofReal_iff hV).mpr hTV) hV₀.le hB
    intro A hA eta heta
    filter_upwards [hcyl A hA eta heta] with k hk
    obtain ⟨e⟩ := hk
    exact ⟨{ embedding := e.embedding
             zero_identity := e.zero_identity
             curvature_bound := e.curvature_bound
             negative_curvature_bound := e.negative_curvature_bound }⟩
  obtain ⟨a, ha⟩ := Stage.exists_full_horizon hstage
  have HG := a.toGeometricControls H.balls_compact hvolume
  rw [ha] at HG
  obtain ⟨G⟩ := ControlledBlowupCompactness.nonempty_generalizedBlowupConvergence_of_geometricLongControls P HG
  let G' := G.ofSubsequence
  exact ⟨{
    convergence := G'
    noncollapsed := G'.noncollapsedAtScale_of_longControls H
    ancient := by
      intro h
      subst T₀
      exact G'.nonempty_m30AncientKappaIdentification_of_longControls P.m04 H }⟩

end PoincareMT.ControlledBlowupHorizon
