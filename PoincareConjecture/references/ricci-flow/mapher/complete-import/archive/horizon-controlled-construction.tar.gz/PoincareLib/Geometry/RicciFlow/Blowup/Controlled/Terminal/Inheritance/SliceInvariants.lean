import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.SliceMaps
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Curvature.Source

/-! # Scalar and tangent-norm identities for the actual slice comparison maps -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

theorem sliceMap_scalarCurvature
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (D : LeviCivitaData (rescaledMetric
      ((S.flow k).metric ((S.base k).1 + s / S.scale k))
      (S.scale k) (S.base_scalar_pos k))) (x : sourceBall S k A) :
    D.scalarCurvature (cyl.sliceMap s hs x) =
      ((cyl.ordinaryFlow hT).connection s).scalarCurvature x := by
  exact (((cyl.ordinaryFlow hT).connection s).scalarCurvature_eq_of_local_isometry D
    isOpen_univ (cyl.sliceMap_isLocalDiffeomorph s hs).contMDiff.contMDiffOn
    (fun y _ v w => (cyl.sliceMap_pullback_inner hT s hs y v w).symm)
    (mem_univ x)).symm

theorem ordinaryFlow_terminal_scalarCurvature
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (x : sourceBall S k A) :
    ((cyl.ordinaryFlow hT).connection 0).scalarCurvature x =
      (S.normalizedTerminalConnection k).scalarCurvature x.val :=
  ((cyl.ordinaryFlow hT).connection 0).scalarCurvature_eq_of_local_isometry
    (S.normalizedTerminalConnection k) isOpen_univ contMDiff_subtype_val.contMDiffOn
    (fun y _ v w => cyl.ordinaryFlow_terminal_inner hT y v w) (mem_univ x)

theorem ordinaryFlow_terminal_scalarCurvature_eq_component
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (x : sourceBall S k A) (y : S.terminalComponent k)
    (hxy : x.val = y.val) :
    ((cyl.ordinaryFlow hT).connection 0).scalarCurvature x =
      (S.terminalComponentConnection k).scalarCurvature y := by
  rw [cyl.ordinaryFlow_terminal_scalarCurvature hT x,
    S.terminalComponentConnection_scalarCurvature, hxy]

variable {M : Type v} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]

theorem ordinaryFlow_terminal_inner_of_component_map
    (cyl : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    (Phi : M → sourceBall S k A) (f : M → S.terminalComponent k)
    {x : M} (hPhi : MDifferentiableAt (𝓡 3) (𝓡 3) Phi x)
    (hf : MDifferentiableAt (𝓡 3) (𝓡 3) f x)
    (heq : (fun y => (Phi y).val) =ᶠ[𝓝 x] fun y => (f y).val)
    (v w : TangentSpace (𝓡 3) x) :
    ((cyl.ordinaryFlow hT).metric 0).inner (Phi x)
      (mfderiv (𝓡 3) (𝓡 3) Phi x v) (mfderiv (𝓡 3) (𝓡 3) Phi x w) =
      (S.terminalComponentMetric k).inner (f x)
        (mfderiv (𝓡 3) (𝓡 3) f x v) (mfderiv (𝓡 3) (𝓡 3) f x w) := by
  have hdf := heq.mfderiv_eq (I := 𝓡 3) (I' := 𝓡 3)
  have hval1 : MDifferentiableAt (𝓡 3) (𝓡 3)
      (Subtype.val : sourceBall S k A → _) (Phi x) :=
    (contMDiff_subtype_val (n := ∞)).mdifferentiable (by simp) _
  have hval2 : MDifferentiableAt (𝓡 3) (𝓡 3)
      (Subtype.val : S.terminalComponent k → _) (f x) :=
    (contMDiff_subtype_val (n := ∞)).mdifferentiable (by simp) _
  change mfderiv (𝓡 3) (𝓡 3) (Subtype.val ∘ Phi) x =
    mfderiv (𝓡 3) (𝓡 3) (Subtype.val ∘ f) x at hdf
  rw [mfderiv_comp x hval1 hPhi, mfderiv_comp x hval2 hf] at hdf
  rw [cyl.ordinaryFlow_terminal_inner hT]
  change (S.normalizedTerminalMetric k).inner (Phi x).val
    (((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) (Phi x)).comp
      (mfderiv (𝓡 3) (𝓡 3) Phi x)) v)
    (((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) (Phi x)).comp
      (mfderiv (𝓡 3) (𝓡 3) Phi x)) w) =
    (S.normalizedTerminalMetric k).inner (f x).val
    (((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : S.terminalComponent k → _) (f x)).comp
      (mfderiv (𝓡 3) (𝓡 3) f x)) v)
    (((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : S.terminalComponent k → _) (f x)).comp
      (mfderiv (𝓡 3) (𝓡 3) f x)) w)
  have hpoint : (Phi x).val = (f x).val := heq.self_of_nhds
  simp only [hdf]
  dsimp only [TangentSpace] at *
  rw [hpoint]

omit [IsManifold (𝓡 3) ∞ M] in
theorem stageSlicePartialDiffeomorph_tangentNorm
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (hT : 0 < T) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (Phi : PartialDiffeomorph (𝓡 3) (𝓡 3) M (sourceBall S k A) ∞)
    {x : M} (hx : x ∈ Phi.source) (v : TangentSpace (𝓡 3) x) :
    (rescaledMetric ((S.flow k).metric ((S.base k).1 + s / S.scale k))
      (S.scale k) (S.base_scalar_pos k)).tangentNorm
        (cyl.stageSlicePartialDiffeomorph hA s hs Phi x)
        (mfderiv (𝓡 3) (𝓡 3) (cyl.stageSlicePartialDiffeomorph hA s hs Phi) x v) =
      ((cyl.ordinaryFlow hT).metric s).tangentNorm (Phi x)
        (mfderiv (𝓡 3) (𝓡 3) Phi x v) := by
  have hPhi := (Phi.isLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞ hx).mdifferentiableAt (by simp)
  have hd := (cyl.sliceMap_isLocalDiffeomorph s hs (Phi x)).mdifferentiableAt (by simp)
  have hinner := cyl.sliceMap_pullback_inner hT s hs (Phi x)
    (mfderiv (𝓡 3) (𝓡 3) Phi x v) (mfderiv (𝓡 3) (𝓡 3) Phi x v)
  have hderiv : mfderiv (𝓡 3) (𝓡 3) (cyl.stageSlicePartialDiffeomorph hA s hs Phi) x =
      (mfderiv (𝓡 3) (𝓡 3) (cyl.sliceMap s hs) (Phi x)).comp
        (mfderiv (𝓡 3) (𝓡 3) Phi x) := mfderiv_comp x hd hPhi
  unfold RiemannianMetric.tangentNorm
  rw [hderiv]
  exact congrArg Real.sqrt hinner

end PoincareMT.ControlledBlowupCylinder
