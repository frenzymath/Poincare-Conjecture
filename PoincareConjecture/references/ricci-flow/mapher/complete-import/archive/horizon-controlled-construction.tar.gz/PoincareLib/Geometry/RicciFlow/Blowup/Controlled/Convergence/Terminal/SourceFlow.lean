import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourcePositivity
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.PartialCharts
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.ChartFlow

/-!
# Actual terminal chart flows of controlled blow-up sequences
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

/-- The actual source flow on the included terminal half of the shifted slab. -/
def terminalSourceFlow (k : ℕ) : RicciFlow 3
    ((interiorSequence S idx A eta T B hA hT e).carrier (G.subsequence k)).carrier
      (Icc 0 (T / 2)) :=
  ((e (G.subsequence k)).smallFlow (hA _) hT).translate (-T / 2)
    (by rintro _ ⟨t, ht, rfl⟩; exact ⟨by linarith [ht.1], by linarith [ht.2]⟩)
    ordConnected_Icc (by refine ⟨0, ⟨le_rfl, by linarith⟩,
      T / 2, ⟨by linarith, le_rfl⟩, by linarith⟩)

theorem terminalSourceFlow_coefficients (q : G.limitCarrier.carrier) (k : ℕ)
    (z : ℝ × EuclideanSpace ℝ (Fin 3)) :
    ((terminalSourceFlow G k).metric z.1).pullbackCoefficients
      (G.referencePartialChart q k (show 0 ∈ Ioo (-T / 2) (T / 2) from
        ⟨by linarith, by linarith⟩)) z.2 = G.spatialSpacetimeCoefficients q k z := rfl

/-- Closed terminal chart flows come from the actual source coefficients;
their interior metric is exactly the original M07 limit coefficient. -/
theorem exists_terminal_chart_flow
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier) {x₀ : EuclideanSpace ℝ (Fin 3)} {ρ : ℝ} (hρ : 0 < ρ)
    (hchart : Metric.closedBall x₀ ρ ⊆ (extChartAt (𝓡 3) q).target)
    (U : Opens (EuclideanSpace ℝ (Fin 3)))
    (hU : (U : Set (EuclideanSpace ℝ (Fin 3))) ⊆ ball x₀ ρ) :
    ∃ F : RicciFlow 3 U (Icc 0 (T / 2)),
      (∀ t ∈ Ioo 0 (T / 2), ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
        (F.metric t).inner x v w = (G.limitFlow.metricAt t).pullbackCoefficients
          (extChartAt (𝓡 3) q).symm x v w) ∧
      ∃ C : ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3,
        ContDiffOn ℝ ∞ C (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ) ∧
        (∀ t ∈ Icc 0 (T / 2), ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
          (F.metric t).inner x v w = C (t, x) v w) ∧
        ∀ m, TendstoUniformlyOn
          (fun k => iteratedFDerivWithin ℝ m (G.spatialSpacetimeCoefficients q k)
            (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ))
          (iteratedFDerivWithin ℝ m C (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ))
          atTop (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ) := by
  obtain ⟨C, hC, hsymm, ⟨α, β, hα, _, hell⟩, hinterior, hconv⟩ :=
    exists_smooth_positive_terminal_source_coefficients G P04 hB hAr hcompact
      hcomplete q hρ hchart
  have hzero : 0 ∈ Ioo (-T / 2) (T / 2) := ⟨by linarith, by linarith⟩
  obtain ⟨F, hF⟩ := ControlledConvergence.exists_flow_of_eventual_partial_chart_coefficients
    (show 0 < T / 2 by linarith)
    (fun k => (interiorSequence S idx A eta T B hA hT e).carrier (G.subsequence k)) hρ
    (terminalSourceFlow G) (fun k => G.referencePartialChart q k hzero)
    (G.eventually_subset_referencePartialChart_source q hzero
      (isCompact_closedBall x₀ ρ) hchart) U hU C hC
    (fun t ht x hx => hsymm (t, x) ⟨ht, ball_subset_closedBall (hU hx)⟩)
    (fun t ht x hx => ⟨α, hα, fun v =>
      (hell (t, x) ⟨ht, ball_subset_closedBall (hU hx)⟩ v).1⟩)
    (by intro r; simpa only [terminalSourceFlow_coefficients G] using hconv r)
  refine ⟨F, ?_, C, hC, hF, hconv⟩
  intro t ht x v w
  rw [hF t ⟨ht.1.le, ht.2.le⟩]
  have h := hinterior 0 (x := (t, (x : EuclideanSpace ℝ (Fin 3)))) ⟨ht, hU x.property⟩
  have heval := congrArg (fun L => L (fun j : Fin 0 => Fin.elim0 j)) h
  simpa only [iteratedFDeriv_zero_apply, iteratedFDerivWithin_zero_apply] using
    congrArg (fun D => D v w) heval.symm

end PoincareMT.ControlledBlowupCompactness
