import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Limit.SpatialConvergence
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.PullbackCurvature
import PoincareLib.Geometry.RicciFlow.Compactness.Convergence.Curvature.MovingJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.NegativeCurvature

/-! # Curvature inheritance throughout the open backward horizon -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))
  (htmono : Monotone tau) {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
  (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau))
  (hjets : ∀ q r K, IsCompact K → K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target →
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ r (horizonSpacetimeCoefficients G q (sigma k)))
      (iteratedFDeriv ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)) atTop K)

include htmono hsigma hjets

theorem tendsto_horizon_curvatureTensorNorm
    {t : ℝ} (ht : t ∈ horizonOpenTime tau) (x : G.limitCarrier.carrier) :
    Tendsto (fun k => ((horizonSourceFlow hA htau e (G.subsequence (sigma k))).connection t).curvatureTensorNorm
      ((G.embedding (sigma k)).toFun (0, x)).2)
      atTop (𝓝 ((F.connection t).curvatureTensorNorm x)) := by
  let c := extChartAt (𝓡 3) x
  let p := c x
  have hp : p ∈ c.target := mem_extChartAt_target x
  have hcx : c.symm p = x := c.left_inv (mem_extChartAt_source x)
  obtain ⟨g, D, V, hVo, hpV, _, heq⟩ := G.limitCarrier.exists_local_coordinate_realization
    (F.metric t) x t p hp
  have hg : ∀ᶠ y in 𝓝 p, ∀ a b : Fin 3,
      g.euclideanCoefficients y (EuclideanSpace.basisFun (Fin 3) ℝ a)
        (EuclideanSpace.basisFun (Fin 3) ℝ b) =
      G.limitCarrier.coordinateCoefficient x
        (fun _ y v w => G.limitCarrier.metricInner (F.metric t) y v w) a b (t, y) :=
    Filter.eventually_of_mem (hVo.mem_nhds hpV) heq
  obtain ⟨rho, hrho, hchart⟩ := G.exists_referenceBall_radius x
  have hzero : 0 ∈ Ioo (-tau 0 / 2) (tau 0 / 2) :=
    ⟨by linarith [htau 0], by linarith [htau 0]⟩
  have hphi : ∀ᶠ k in atTop, ∀ᶠ y in 𝓝 p,
      ContMDiffAt (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap x (sigma k) 0) y ∧
        Function.Injective (mfderiv (𝓡 3) (𝓡 3) (G.referenceChartMap x (sigma k) 0) y) := by
    filter_upwards [hsigma.tendsto_atTop.eventually
      (G.eventually_subset_referencePartialChart_source x hzero (isCompact_closedBall _ _) hchart)]
      with k hk
    filter_upwards [ball_mem_nhds p hrho] with y hy
    have hys := hk (ball_subset_closedBall hy)
    exact ⟨G.referenceChartMap_contMDiffAt x (sigma k) hzero hys.1 hys.2,
      (G.referenceChartMap_mfderiv_isInvertible x (sigma k) hzero hys.1 hys.2).injective⟩
  have hnorm := LeviCivitaData.tendsto_curvatureTensorNorm_of_moving_scalar_pullback_jets
    (fun k => (horizonSourceFlow hA htau e (G.subsequence (sigma k))).connection t)
    (fun k => G.referenceChartMap x (sigma k) 0) D (fun _ : ℕ => p) p hphi (by
      intro r _ a b
      rw [G.limitCarrier.iteratedFDeriv_coordinateCoefficient_eq_of_eventuallyEq x _ t p g hg r a b]
      exact tendsto_horizon_spatial_pullbackJet G htmono hsigma F x (hjets x) ht hp r a b)
  have hlim : D.curvatureTensorNorm p = (F.connection t).curvatureTensorNorm x := by
    have hn := G.limitCarrier.curvatureTensorNorm_eq_of_coordinate_germ
      (F.metric t) (F.connection t) x t p hp g D hg
    change D.curvatureTensorNorm p = (F.connection t).curvatureTensorNorm (c.symm p) at hn
    simpa only [hcx] using hn
  rw [hlim] at hnorm
  change (extChartAt (𝓡 3) x).symm p = x at hcx
  simpa only [PointedGeometricConvergence.referenceChartMap, Function.comp_apply, hcx] using hnorm

theorem horizon_curvatureTensorNorm_le
    {j : ℕ} {t : ℝ} (ht : t ∈ Ioo (-tau j) 0) (x : G.limitCarrier.carrier) :
    (F.connection t).curvatureTensorNorm x ≤ B j := by
  apply le_of_tendsto (tendsto_horizon_curvatureTensorNorm G htmono hsigma F hjets
    (mem_iUnion.mpr ⟨j, ht⟩) x)
  filter_upwards [(G.subsequence_strictMono.comp hsigma).tendsto_atTop.eventually_ge_atTop j]
    with k hk
  exact (le_abs_self _).trans (horizonSourceFlow_curvature_bound hA htau e htmono
    (G.subsequence (sigma k)) j hk t (Ioo_subset_Icc_self ht) _)

end PoincareMT.ControlledBlowupCompactness
