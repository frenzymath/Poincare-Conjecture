import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.CapturedAlternatives

/-!
# Quantitative location of a captured cap end center

The full canonical neighborhood is captured on a fixed comparison ball.
Its end center is captured on the smaller scalar-scale ball, retaining the
distance estimate needed when the selected scalar curvature grows.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Topology Bundle ENNReal

universe u v

namespace PoincareMT.ControlledTerminal

variable {M : Type v} [TopologicalSpace M] [T3Space M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
  {X : Type u} [TopologicalSpace X] [T3Space X]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) X] [IsManifold (𝓡 3) ∞ X]
  [MeasurableSpace X] [BorelSpace X]

theorem cap_end_center_capture_of_metric_control
    (g : RiemannianMetric 3 M) (h : RiemannianMetric 3 X)
    (hcomplete : MetricComplete g) (e : OpenPartialHomeomorph M X)
    (he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e e.source)
    (hei : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e.symm e.target)
    (p : M) (N : CapCertificate h) (hp : e p ∈ N.carrier)
    {l r C : ℝ} (hl : 0 < l) (hconstant : N.cap_constant ≤ C)
    (hscalar : l ≤ N.connection.scalarCurvature (e p))
    (hradius : C * l ^ (-1 / 2 : ℝ) ≤ r)
    (hsource : closure (g.ball p (2 * r + 1)) ⊆ e.source)
    (hbound : ∀ x ∈ closure (g.ball p (2 * r + 1)), ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ 2 * h.tangentNorm (e x) (mfderiv (𝓡 3) (𝓡 3) e x v)) :
    e.symm N.end_neck.center ∈ closure (g.ball p (2 * C * l ^ (-1 / 2 : ℝ))) := by
  have hC : 0 < C := N.cap_constant_pos.trans_le hconstant
  let r' := C * l ^ (-1 / 2 : ℝ)
  have hr' : 0 < r' := by positivity
  have hsub : closure (g.ball p (2 * r' + 1)) ⊆
      closure (g.ball p (2 * r + 1)) := by
    apply closure_mono
    intro x hx
    exact hx.trans_le (ENNReal.ofReal_le_ofReal (by dsimp [r']; linarith))
  have hc : N.end_neck.center ∈ N.carrier := N.end_neck_subset
    (N.end_neck.central_sphere_subset N.end_neck.center_on_central_sphere)
  have hsmall : ({N.end_neck.center} : Set X) ⊆ h.ball (e p) r' := by
    rintro x rfl
    exact (N.edist_lt_at_point hconstant hp hc).trans_le
      (ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_left
        (Real.rpow_le_rpow_of_nonpos hl hscalar (by norm_num)) hC.le))
  have hcap := compact_capture_of_inverse_tangent_control g h hcomplete e he hei p
    hr' (hsub.trans hsource) (fun x hx => hbound x (hsub hx)) hsmall
  simpa only [r', mul_assoc] using hcap.2 (mem_image_of_mem e.symm (mem_singleton _))

theorem exists_captured_neck_with_center_control_of_neck_or_cap
    (g : RiemannianMetric 3 M) (h : RiemannianMetric 3 X) (D : LeviCivitaData h)
    (hcomplete : MetricComplete g) (e : OpenPartialHomeomorph M X)
    (he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e e.source)
    (hei : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e.symm e.target)
    (p : M) {delta C l u r : ℝ} (hC : 1 ≤ C) (hl : 0 < l) (hu : 0 < u)
    (hscalar : l ≤ D.scalarCurvature (e p) ∧ D.scalarCurvature (e p) ≤ u)
    (hneckradius : (2 * Real.pi + 2 * delta⁻¹) * l ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hcapradius : C * l ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hsource : closure (g.ball p (2 * r + 1)) ⊆ e.source)
    (hbound : ∀ x ∈ closure (g.ball p (2 * r + 1)), ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ 2 * h.tangentNorm (e x) (mfderiv (𝓡 3) (𝓡 3) e x v))
    (hcanonical : (∃ N : EpsilonNeck h,
      N.epsilon = delta ∧ N.center = e p ∧ N.connection = D) ∨
      ∃ N : CapCertificate h,
        N.epsilon = delta ∧ N.cap_constant ≤ C ∧ e p ∈ N.core ∧ N.connection = D) :
    ∃ N : EpsilonNeck h, N.epsilon = delta ∧ N.connection = D ∧
      l / C ≤ D.scalarCurvature N.center ∧ D.scalarCurvature N.center ≤ C * u ∧
      D.scalarCurvature (e p) ≤ C * D.scalarCurvature N.center ∧
      N.carrier ⊆ e.target ∧ e.symm '' N.carrier ⊆ closure (g.ball p (2 * r)) ∧
      e.symm N.center ∈ closure (g.ball p (2 * C * l ^ (-1 / 2 : ℝ))) := by
  have hCpos : 0 < C := zero_lt_one.trans_le hC
  rcases hcanonical with ⟨N, hNe, hNc, hND⟩ | ⟨N, hNe, hNC, hpN, hND⟩
  · have hcapture := neck_closure_capture_of_metric_control g h hcomplete e he hei p N hNc
      hl (by simpa only [hND, hNc] using hscalar.1)
      (by simpa only [hNe] using hneckradius) hsource hbound
    refine ⟨N, hNe, hND, ?_, ?_, ?_, subset_closure.trans hcapture.1,
      (image_mono subset_closure).trans hcapture.2, ?_⟩
    · rw [hNc]
      exact (div_le_self hl.le hC).trans hscalar.1
    · rw [hNc]
      exact hscalar.2.trans (le_mul_of_one_le_left hu.le hC)
    · rw [hNc]
      exact le_mul_of_one_le_left (hl.trans_le hscalar.1).le hC
    · have hr : 0 < r := lt_of_lt_of_le (by positivity) hcapradius
      let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
        ⟨g.toRiemannianMetric⟩
      have hp : p ∈ g.ball p (2 * r + 1) := by
        change g.edist p p < ENNReal.ofReal (2 * r + 1)
        simp only [RiemannianMetric.edist, Manifold.riemannianEDist_self]
        exact ENNReal.ofReal_pos.mpr (by positivity)
      rw [hNc, e.left_inv (hsource (subset_closure hp))]
      apply subset_closure
      change g.edist p p < ENNReal.ofReal (2 * C * l ^ (-1 / 2 : ℝ))
      simp only [RiemannianMetric.edist, Manifold.riemannianEDist_self]
      exact ENNReal.ofReal_pos.mpr (by positivity)
  · have hpN' : e p ∈ N.carrier := N.core_subset_carrier hpN
    have hsN : l ≤ N.connection.scalarCurvature (e p) ∧
        N.connection.scalarCurvature (e p) ≤ u := by simpa only [hND] using hscalar
    have hcapture := cap_closure_capture_of_metric_control g h hcomplete e he hei p N hpN'
      hl hNC hsN.1 hcapradius hsource hbound
    have hbounds := N.end_center_scalar_bounds_of_point_bounds hpN' hNC hsN.1 hsN.2
    have hc := N.end_neck_subset
      (N.end_neck.central_sphere_subset N.end_neck.center_on_central_sphere)
    refine ⟨N.end_neck, N.end_neck_epsilon.trans hNe, N.end_neck_connection.trans hND,
      ?_, ?_, ?_, N.end_neck_subset.trans (subset_closure.trans hcapture.1),
      (image_mono (N.end_neck_subset.trans subset_closure)).trans hcapture.2, ?_⟩
    · simpa only [N.end_neck_connection, hND] using hbounds.1
    · simpa only [N.end_neck_connection, hND] using hbounds.2
    · rw [← hND]
      exact (N.scalar_lt_constant_mul hc hpN').le.trans
        (mul_le_mul_of_nonneg_right hNC (N.scalar_pos _ hc).le)
    · exact cap_end_center_capture_of_metric_control g h hcomplete e he hei p N hpN'
        hl hNC hsN.1 (by linarith) hsource hbound

end PoincareMT.ControlledTerminal
