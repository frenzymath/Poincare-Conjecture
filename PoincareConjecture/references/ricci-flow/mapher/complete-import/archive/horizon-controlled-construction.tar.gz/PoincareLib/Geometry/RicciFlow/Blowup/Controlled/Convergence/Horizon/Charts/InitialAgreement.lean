import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.Positivity

/-! # The full-horizon coefficient limit retains the initial M07 flow -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

theorem horizonSpacetimeCoefficients_eq_initial
    (htmono : Monotone tau) (q : G.limitCarrier.carrier) (k : ℕ)
    {s : ℝ} (hs : s ∈ Icc (-tau 0) 0) (x : EuclideanSpace ℝ (Fin 3)) :
    horizonSpacetimeCoefficients G q k (s, x) =
      G.spatialSpacetimeCoefficients q k (s + tau 0 / 2, x) := by
  unfold horizonSpacetimeCoefficients
  rw [horizonSourceFlow_metric_eq hA htau e htmono (G.subsequence k) 0 (Nat.zero_le _) s hs]
  have ht : (s + tau 0 / 2) + (-tau 0 / 2) = s := by ring
  conv_rhs =>
    unfold PointedGeometricConvergence.spatialSpacetimeCoefficients
    dsimp only [interiorSequence, BasedFlow.metricAt, RicciFlow.translate]
    rw [ht]
  rfl

theorem tendsto_horizonSpacetimeCoefficients_initial
    (htmono : Monotone tau) (q : G.limitCarrier.carrier)
    {s : ℝ} (hs : s ∈ Ioo (-tau 0) 0) {x : EuclideanSpace ℝ (Fin 3)}
    (hx : x ∈ (extChartAt (𝓡 3) q).target) :
    Tendsto (fun k => horizonSpacetimeCoefficients G q k (s, x)) atTop
      (𝓝 ((G.limitFlow.metricAt (s + tau 0 / 2)).pullbackCoefficients
        (extChartAt (𝓡 3) q).symm x)) := by
  have hzero : -tau 0 / 2 < 0 ∧ 0 < tau 0 / 2 :=
    ⟨by linarith [htau 0], by linarith [htau 0]⟩
  have hp : (s + tau 0 / 2, x) ∈ Ioo (-tau 0 / 2) (tau 0 / 2) ×ˢ
      (extChartAt (𝓡 3) q).target := ⟨⟨by linarith [hs.1], by linarith [hs.2]⟩, hx⟩
  have h := G.tendstoUniformlyOn_spatialSpacetimeCoefficients_jets hzero q 0
    isCompact_singleton (singleton_subset_iff.mpr hp)
  have he := (ContinuousMultilinearMap.uniformContinuous_eval_const
    (0 : Fin 0 → ℝ × EuclideanSpace ℝ (Fin 3))).comp_tendstoUniformlyOn h
  have hpconv : Tendsto (fun k => G.spatialSpacetimeCoefficients q k (s + tau 0 / 2, x))
      atTop (𝓝 ((G.limitFlow.metricAt (s + tau 0 / 2)).pullbackCoefficients
        (extChartAt (𝓡 3) q).symm x)) := by
    simpa only [Function.comp_apply, iteratedFDeriv_zero_apply] using he.tendsto_at (mem_singleton _)
  exact hpconv.congr fun k =>
    (horizonSpacetimeCoefficients_eq_initial G htmono q k (Ioo_subset_Icc_self hs) x).symm

theorem horizon_limit_eq_initial
    (htmono : Monotone tau) (q : G.limitCarrier.carrier)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    {f : ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3}
    (hpoint : ∀ z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target,
      Tendsto (fun k => horizonSpacetimeCoefficients G q (sigma k) z) atTop (𝓝 (f z)))
    {s : ℝ} (hs : s ∈ Ioo (-tau 0) 0) {x : EuclideanSpace ℝ (Fin 3)}
    (hx : x ∈ (extChartAt (𝓡 3) q).target) :
    f (s, x) = (G.limitFlow.metricAt (s + tau 0 / 2)).pullbackCoefficients
      (extChartAt (𝓡 3) q).symm x :=
  tendsto_nhds_unique (hpoint (s, x) ⟨mem_iUnion.mpr ⟨0, hs⟩, hx⟩)
    ((tendsto_horizonSpacetimeCoefficients_initial G htmono q hs hx).comp hsigma.tendsto_atTop)

end PoincareMT.ControlledBlowupCompactness
