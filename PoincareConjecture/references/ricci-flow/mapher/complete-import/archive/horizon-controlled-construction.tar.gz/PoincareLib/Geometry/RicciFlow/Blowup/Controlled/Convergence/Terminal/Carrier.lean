import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.SourceFlow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Gluing
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.TimeLocality
import PoincareLib.Geometry.Manifold.RegularLevel.OpenInclusion

/-!
# Terminal flow on the original pointed limit carrier
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

theorem exists_terminal_reference_ball_flow
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier) {ρ : ℝ} (hρ : 0 < ρ)
    (hchart : closedBall (extChartAt (𝓡 3) q q) ρ ⊆ (extChartAt (𝓡 3) q).target) :
    ∃ F : RicciFlow 3 (G.referenceBall q ρ) (Icc 0 (T / 2)),
      ∀ t ∈ Ioo 0 (T / 2), ∀ (x : G.referenceBall q ρ)
        (v w : TangentSpace (𝓡 3) x),
        (F.metric t).inner x v w =
          (G.limitFlow.metricAt t).inner (G.referenceBallMap q ρ x)
            (mfderiv (𝓡 3) (𝓡 3) (G.referenceBallMap q ρ) x v)
            (mfderiv (𝓡 3) (𝓡 3) (G.referenceBallMap q ρ) x w) := by
  obtain ⟨F, hF, _⟩ := exists_terminal_chart_flow G P04 hB hAr hcompact hcomplete
    q hρ hchart (G.referenceBall q ρ) subset_rfl
  refine ⟨F, ?_⟩
  intro t ht x v w
  have hx := hchart (ball_subset_closedBall x.property)
  have hc := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q hx).contMDiffAt
    (extChartAt_target_mem_nhds' hx)
  have hd := Poincare.Geometry.Manifold.RegularLevel.mfderiv_opens_restrict
    (G.referenceBall q ρ) (extChartAt (𝓡 3) q).symm (x := x)
      (hc.mdifferentiableAt (by simp))
  rw [hF t ht x v w]
  change (G.limitFlow.metricAt t).inner ((extChartAt (𝓡 3) q).symm x)
    (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm (x : EuclideanSpace ℝ (Fin 3)) v)
    (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm (x : EuclideanSpace ℝ (Fin 3)) w) =
    (G.limitFlow.metricAt t).inner ((extChartAt (𝓡 3) q).symm x)
      (mfderiv (𝓡 3) (𝓡 3) (fun y : G.referenceBall q ρ => (extChartAt (𝓡 3) q).symm y) x v)
      (mfderiv (𝓡 3) (𝓡 3) (fun y : G.referenceBall q ρ => (extChartAt (𝓡 3) q).symm y) x w)
  rw [hd]
  rfl

/-- The source-derived terminal chart flows descend to an actual closed
terminal slab on the exact original M07 limit carrier. -/
theorem exists_closed_terminal_flow_on_carrier
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0)) :
    ∃ F : RicciFlow 3 G.limitCarrier.carrier (Icc 0 (T / 2)),
      ∀ t ∈ Ioo 0 (T / 2), F.metric t = G.limitFlow.metricAt t := by
  classical
  let : Nonempty G.limitCarrier.carrier := ⟨G.limitFlow.base⟩
  choose ρ hρ hchart using G.exists_referenceBall_radius
  choose Fchart hFchart using fun q => exists_terminal_reference_ball_flow
    G P04 hB hAr hcompact hcomplete q (hρ q) (hchart q)
  let Fint : RicciFlow 3 G.limitCarrier.carrier (Ioo 0 (T / 2)) :=
    Poincare.Geometry.RicciFlow.Harnack.restrictFlow G.limitFlow.flow
      (by intro t ht; exact ⟨by linarith [ht.1], ht.2⟩)
      ordConnected_Ioo (by refine ⟨T / 6, ⟨by linarith, by linarith⟩,
        T / 3, ⟨by linarith, by linarith⟩, by linarith⟩)
  obtain ⟨F, hF, _⟩ := RicciFlow.exists_extension_of_covering_chart_flows
    Ioo_subset_Icc_self (by rw [closure_Ioo (show 0 ≠ T / 2 by linarith)])
    Fint Fchart (fun q => G.referenceBallMap q (ρ q))
    (fun q => G.referenceBallMap_isLocalDiffeomorph q (ρ q)
      (ball_subset_closedBall.trans (hchart q)))
    (G.referenceBallMap_covers ρ hρ) (fun t ht q x v w => hFchart q t ht x v w)
  exact ⟨F, hF⟩

/-- The complete original interior time interval and its included terminal
time carry one actual Ricci flow on the unchanged spatial carrier. -/
theorem exists_shifted_terminal_flow_on_carrier
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0)) :
    ∃ F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)),
      ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t := by
  obtain ⟨H, hH⟩ := exists_closed_terminal_flow_on_carrier G P04 hB hAr hcompact hcomplete
  obtain ⟨F, hF, _⟩ := RicciFlow.exists_attach_terminal_slab
    (show -T / 2 < 0 by linarith) (show 0 < T / 2 by linarith)
    G.limitFlow.flow H hH
  exact ⟨F, hF⟩

/-- Return to the normalized source clock, retaining every original time
and its exact interior metric while including time zero. -/
theorem exists_terminal_flow_on_carrier
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0)) :
    ∃ F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T) 0),
      ∀ t ∈ Ioo (-T) 0, F.metric t = G.limitFlow.metricAt (t + T / 2) := by
  obtain ⟨H, hH⟩ := exists_shifted_terminal_flow_on_carrier G P04 hB hAr hcompact hcomplete
  let F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T) 0) :=
    H.translate (T / 2)
      (by rintro _ ⟨t, ht, rfl⟩; exact ⟨by linarith [ht.1], by linarith [ht.2]⟩)
      ordConnected_Ioc (by refine ⟨-T / 2, ⟨by linarith, by linarith⟩,
        0, ⟨by linarith, le_rfl⟩, by linarith⟩)
  exact ⟨F, fun t ht => hH (t + T / 2) ⟨by linarith [ht.1], by linarith [ht.2]⟩⟩

end PoincareMT.ControlledBlowupCompactness
