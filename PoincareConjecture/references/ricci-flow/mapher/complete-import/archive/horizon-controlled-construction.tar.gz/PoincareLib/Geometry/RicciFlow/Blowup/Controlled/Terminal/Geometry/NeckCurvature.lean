import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Geometry.NeckTriangle
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Overlap.ScaleComparison

/-!
# High-curvature necks separate large-triangle endpoints

The cutoff is chosen from the fixed reference metric, center, triangle scale
and accuracy, before the comparison metric. It forces both capture in a
contractible chart and escape of the two triangle endpoints from the neck.

Reference: Morgan--Tian, Claims 11.13--11.14, pp. 276--277.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle

namespace PoincareMT.EpsilonNeck

variable {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
  [IsManifold (𝓡 3) ∞ M] {g : RiemannianMetric 3 M}

theorem scale_mul_lt_of_scalar_center_gt (N : EpsilonNeck g) (D : LeviCivitaData g)
    {B r : ℝ} (hB : 0 < B) (hr : 0 < r)
    (hscalar : (B / r) ^ 2 < D.scalarCurvature N.center) : B * N.scale < r := by
  have hs := N.scale_pos
  have hscaled : N.scale ^ 2 * (B / r) ^ 2 < 1 := by
    calc
      _ < N.scale ^ 2 * D.scalarCurvature N.center :=
        mul_lt_mul_of_pos_left hscalar (sq_pos_of_pos hs)
      _ = 1 := N.scale_sq_mul_scalar_center_of_connection D
  have heq : N.scale ^ 2 * (B / r) ^ 2 = (B * N.scale) ^ 2 / r ^ 2 := by ring
  rw [heq] at hscaled
  have hsq : (B * N.scale) ^ 2 < r ^ 2 := by
    simpa only [one_mul] using (div_lt_iff₀ (sq_pos_of_pos hr)).mp hscaled
  exact (sq_lt_sq₀ (mul_pos hB hs).le hr.le).mp hsq

variable [MeasurableSpace M] [BorelSpace M] [T2Space M] [T3Space M] [ConnectedSpace M]

/-- The scalar cutoff is uniform in all distance-dominating comparison
metrics; canonical accuracy is fixed before those metrics. -/
theorem exists_high_curvature_separator_cutoff
    (g₀ : RiemannianMetric 3 M) (y : M) {epsilon d : ℝ}
    (hepsilon : 0 < epsilon) (hsmall : epsilon ≤ 1 / (400 * Real.pi))
    (hd : 0 < d) :
    ∃ cutoff : ℝ, 0 < cutoff ∧
      ∀ (g : RiemannianMetric 3 M) (D : LeviCivitaData g),
        MetricComplete g → D.NonnegativeSectionalCurvature →
        (∀ x : M, (g₀.edist y x).toReal ≤ (g.edist y x).toReal) →
      ∀ (N : EpsilonNeck g), N.epsilon = epsilon → N.center = y →
        cutoff < D.scalarCurvature y → ∀ p z : M,
        d ≤ (g.edist y p).toReal → d ≤ (g.edist y z).toReal →
        (g.edist y p).toReal ≤ 3 * d / 2 → (g.edist y z).toReal ≤ 3 * d / 2 →
        d ≤ (g.edist p z).toReal →
        ∀ P : Path p z, ∃ s, P s ∈ N.central_sphere := by
  obtain ⟨r, hr, hseparating⟩ := exists_separating_radius_of_reference_metric g₀ y
  let B := 2 * Real.pi + 2 * epsilon⁻¹
  have hB : 0 < B := by dsimp [B]; positivity
  let cutoff := max ((2 * Real.pi / r) ^ 2) ((B / d) ^ 2)
  have hcutoff : 0 < cutoff :=
    (sq_pos_of_pos (div_pos (by positivity : 0 < 2 * Real.pi) hr)).trans_le
      (le_max_left _ _)
  refine ⟨cutoff, hcutoff, ?_⟩
  intro g D hcomplete hsec hdist N heq hcenter hlarge p z ha hb ha' hb' hfar
  have hchart : 2 * Real.pi * N.scale < r :=
    N.scale_mul_lt_of_scalar_center_gt D (by positivity) hr
      (by rw [hcenter]; exact (le_max_left _ _).trans_lt hlarge)
  have hsize : (2 * Real.pi + 2 * N.epsilon⁻¹) * N.scale < d := by
    rw [heq]
    exact N.scale_mul_lt_of_scalar_center_gt D hB hd
      (by rw [hcenter]; exact (le_max_right _ _).trans_lt hlarge)
  exact N.every_path_meets_central_sphere_of_endpoint_distances D hcomplete hsec
    (hseparating g N hcenter hdist hchart) (heq.trans_le hsmall) hd
    (hcenter.symm ▸ ha) (hcenter.symm ▸ hb) (hcenter.symm ▸ ha') (hcenter.symm ▸ hb')
    hfar hsize

end PoincareMT.EpsilonNeck
