import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Approximation
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Recenter
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Subsequence
import PoincareLib.Geometry.RicciFlow.Rescaling.Volume
import PoincareLib.Topology.Sequences.Diagonal

/-!
# Recentered source diagonal excludes unbounded scalar ratios

Each row uses convergence at one fixed time and two fixed limit points.
A strict diagonal then gives one actual generalized blow-up sequence to
which the frozen M29 service applies. This is the contradiction in
Morgan--Tian Lemma 11.10, pp. 274--275.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable

theorem not_unbounded_scalar_at_bounded_distance
    {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
    (G : GeneralizedBlowupConvergence S J.domain)
    (P04 : RicciFlowCurvatureTheory.{u}) {epsilon C : ℝ}
    (hM29 : ∀ S : GeneralizedBlowupSequence.{u},
      DenseGeneralizedBoundedDistanceHypotheses S epsilon C → GeneralizedBlowupBoundedDistance S)
    (H : DenseGeneralizedBoundedDistanceHypotheses S epsilon C)
    (t : ℕ → ℝ) (ht : ∀ m, t m ∈ J.domain) (ht0 : ∀ m, t m ≤ 0)
    (y z : ℕ → G.limit.carrier.carrier) {A B : ℝ} (hA : 0 < A) (hB : 0 < B)
    (hy : ∀ m, 2 ≤ (G.limit.flow.connection (t m)).scalarCurvature (y m) ∧
      (G.limit.flow.connection (t m)).scalarCurvature (y m) ≤ B)
    (hz : ∀ m : ℕ, (m : ℝ) + 2 ≤ (G.limit.flow.connection (t m)).scalarCurvature (z m))
    (hdist : ∀ m, z m ∈ (G.limit.flow.metric (t m)).ball (y m) A) : False := by
  classical
  let R (m k : ℕ) : Prop := ∃ htk : t m ∈ Icc (-G.exhaustion.time k) 0,
    1 ≤ (G.normalizedSourceConnection k (t m)).scalarCurvature
      ((G.embedding k).forward (t m) htk (y m)) ∧
    (G.normalizedSourceConnection k (t m)).scalarCurvature
      ((G.embedding k).forward (t m) htk (y m)) ≤ B + 1 ∧
    (m : ℝ) + 1 ≤ (G.normalizedSourceConnection k (t m)).scalarCurvature
      ((G.embedding k).forward (t m) htk (z m)) ∧
    (G.embedding k).forward (t m) htk (z m) ∈
      (G.normalizedSourceMetric k (t m)).ball
        ((G.embedding k).forward (t m) htk (y m)) (2 * A)
  have hR (m : ℕ) : ∀ᶠ k in atTop, R m k := by
    let K : Set (ℝ × G.limit.carrier.carrier) := {(t m, y m), (t m, z m)}
    have hK : IsCompact K := isCompact_singleton.insert _
    have hKJ : ∀ w ∈ K, w.1 ∈ J.domain := by
      intro w hw
      rcases hw with rfl | rfl
      · exact ht m
      · exact ht m
    filter_upwards [G.eventually_normalizedSource_scalar_error_on_compact P04 hK hKJ
      (by norm_num : (0 : ℝ) < 1 / 2),
      G.eventually_normalizedSource_image_ball_subset (ht m) (ht0 m) (y m) hA
        (by norm_num : (1 : ℝ) < 2),
      G.exhaustion.time_cofinal {t m} isCompact_singleton (singleton_subset_iff.mpr (ht m))]
      with k hk himage htime
    have htk := htime (mem_singleton (t m))
    have hye := abs_lt.mp (hk (t m, y m) (by exact Or.inl rfl) htk)
    have hze := abs_lt.mp (hk (t m, z m) (by exact Or.inr rfl) htk)
    exact ⟨htk, by linarith [(hy m).1], by linarith [(hy m).2],
      by linarith [hz m], himage htk (mem_image_of_mem _ (hdist m))⟩
  obtain ⟨sigma, hsigma, hselected⟩ := Poincare.exists_strictMono_forall_le_of_eventually hR
  have hdiag (m : ℕ) := hselected m m le_rfl
  choose htime hlow hupp hhigh hball using hdiag
  let idx := G.subsequence ∘ sigma
  have hidx : StrictMono idx := G.subsequence_strictMono.comp hsigma
  let S' := S.subsequence idx hidx
  let p (m : ℕ) : (S'.flow m).point :=
    (G.embedding (sigma m)).pointMap (t m) (htime m) (y m)
  let q (m : ℕ) : ((S'.flow m).slice (p m).1).carrier :=
    (G.embedding (sigma m)).forward (t m) (htime m) (z m)
  have hnorm (m : ℕ) (w : G.limit.carrier.carrier) :
      (G.normalizedSourceConnection (sigma m) (t m)).scalarCurvature
        ((G.embedding (sigma m)).forward (t m) (htime m) w) =
      (S'.scale m)⁻¹ * (S'.flow m).scalar
        ((G.embedding (sigma m)).pointMap (t m) (htime m) w) := by
    rw [normalizedSourceConnection, rescaledMetric_scalarCurvature]
    rfl
  have hp (m : ℕ) : S'.scale m ≤ (S'.flow m).scalar (p m) := by
    have hh := hlow m
    rw [hnorm] at hh
    have hQ : 0 < S'.scale m := S'.base_scalar_pos m
    have := (le_div_iff₀ hQ).mp (show 1 ≤ (S'.flow m).scalar (p m) / S'.scale m by
      simpa only [div_eq_mul_inv, mul_comm] using hh)
    simpa only [one_mul] using this
  have hpupper (m : ℕ) : (S'.flow m).scalar (p m) ≤ (B + 1) * S'.scale m := by
    have hh := hupp m
    rw [hnorm] at hh
    have hQ : 0 < S'.scale m := S'.base_scalar_pos m
    change (S'.scale m)⁻¹ * (S'.flow m).scalar (p m) ≤ B + 1 at hh
    exact (div_le_iff₀ hQ).mp (by
      simpa only [div_eq_mul_inv, mul_comm] using hh)
  have hptime (m : ℕ) : (p m).1 ≤ (S'.base m).1 := by
    change (S.base (idx m)).1 + t m / S.scale (idx m) ≤ (S.base (idx m)).1
    exact add_le_of_nonpos_right (div_nonpos_of_nonpos_of_nonneg (ht0 m)
      (S.base_scalar_pos (idx m)).le)
  have HS' : DenseGeneralizedBoundedDistanceHypotheses S' epsilon C :=
    ⟨fun m => H.branch (idx m), fun m => H.canonical (idx m)⟩
  have hbound := (hM29 (S'.recenter p hp) (HS'.recenter p hptime hp)).original_normalization_of_recenter
    p hp (show 0 < B + 1 by linarith) hpupper
  obtain ⟨D, hD, hDsource⟩ := hbound (2 * A) (by positivity)
  have hlarge : ∀ᶠ m : ℕ in atTop, D < (m : ℝ) + 1 :=
    (tendsto_natCast_atTop_atTop.eventually (eventually_gt_atTop D)).mono
      (fun m hm => by linarith)
  obtain ⟨m, hm, hlarge⟩ := (hDsource.and hlarge).exists
  have hqball : q m ∈ ((S'.flow m).metric (p m).1).ball (p m).2
      ((2 * A) / Real.sqrt (S'.scale m)) := by
    have hh := hball m
    rw [normalizedSourceMetric, rescaledMetric_ball_allDimensions] at hh
    exact hh
  have hupper := hm (q m) hqball
  have hq := hhigh m
  rw [hnorm] at hq
  change (m : ℝ) + 1 ≤ (S'.scale m)⁻¹ * (S'.flow m).scalar ⟨(p m).1, q m⟩ at hq
  have hQ : 0 < S'.scale m := S'.base_scalar_pos m
  have hlower : ((m : ℝ) + 1) * S'.scale m ≤ (S'.flow m).scalar ⟨(p m).1, q m⟩ :=
    (le_div_iff₀ hQ).mp (by
      simpa only [div_eq_mul_inv, mul_comm] using hq)
  nlinarith

end PoincareMT.GeneralizedBlowupConvergence
