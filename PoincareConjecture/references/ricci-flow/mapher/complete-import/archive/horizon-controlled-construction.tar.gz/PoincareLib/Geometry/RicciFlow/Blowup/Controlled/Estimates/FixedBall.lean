import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Terminal
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Worldline

/-!
# Radius-dependent backward scalar control

M29 and the actual maximal-worldline hypothesis provide a common positive
time on each fixed normalized ball. The guarded scalar comparison then
controls every supplied worldline over that ball, as in Morgan--Tian
Lemma 11.2 and Corollary 11.3, pp. 268--269.
-/

set_option autoImplicit false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem eventually_scalar_bounded_worldlines
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u})
    (hbound : GeneralizedBlowupBoundedDistance S) (A : ℝ) (hA : 0 < A) :
    ∃ T B : ℝ, 0 < T ∧ 0 < B ∧ ∀ᶠ k : ℕ in atTop,
      ∀ x ∈ S.baseBall k A, ∃ W : GeneralizedMaximalBackwardFlowLine
        (S.flow k) ⟨(S.base k).1, x⟩ (S.scale k) (m30BackwardDuration S k x mu),
        ∃ hI : Icc (-T) 0 ⊆ W.maximal_interval,
          ∀ s (hs : s ∈ Icc (-T) 0),
            (S.flow k).scalar (W.embedding.pointMap s (hI hs) x) < B * S.scale k := by
  classical
  obtain ⟨D, hD, hscalar⟩ := hbound A hA
  obtain ⟨T₁, hT₁, hworldline⟩ := H.eventually_uniform_worldline_duration hbound A hA
  let K : ℝ := max 4 D + 1
  have hK : 4 ≤ K := by dsimp [K]; linarith [le_max_left (4 : ℝ) D]
  have hKpos : 0 < K := by linarith
  have hDK : D < K := by dsimp [K]; linarith [le_max_right (4 : ℝ) D]
  let T : ℝ := min (T₁ / 2) (1 / (8 * (H.analytic_constant + 1) * K))
  have hden : 0 < 4 * (H.analytic_constant + 1) * K := by
    have := H.analytic_constant_pos
    positivity
  have hT : 0 < T := by
    dsimp [T]
    apply lt_min (by positivity)
    have := H.analytic_constant_pos
    positivity
  have hTT₁ : T ≤ T₁ := (min_le_left _ _).trans (by linarith)
  have hshort : T < 1 / (4 * (H.analytic_constant + 1) * K) := by
    apply lt_of_le_of_lt (min_le_right _ _)
    apply one_div_lt_one_div_of_lt hden
    nlinarith
  refine ⟨T, 2 * K, hT, by positivity, ?_⟩
  filter_upwards [hscalar, hworldline] with k hk hW
  intro x hx
  obtain ⟨W, hW⟩ := hW x hx
  have hI : Icc (-T) 0 ⊆ W.maximal_interval :=
    (Icc_subset_Icc_left (neg_le_neg hTT₁)).trans hW
  let f : ℝ → ℝ := fun s => if hs : s ∈ W.maximal_interval then
    (S.flow k).scalar (W.embedding.pointMap s hs x) else 0
  have hf (s : ℝ) (hs : s ∈ W.maximal_interval) :
      f s = (S.flow k).scalar (W.embedding.pointMap s hs x) := dif_pos hs
  have hzero : f 0 < K * S.scale k := by
    rw [hf 0 W.maximal_interval_mem_zero, W.zero_identity]
    exact (hk x hx).trans_lt (mul_lt_mul_of_pos_right hDK (S.base_scalar_pos k))
  have hcontrol := H.cylinder_scalar_lt_two_mul P04 k W.embedding (mem_singleton x)
    hf hK hI hzero hshort
  refine ⟨W, hI, ?_⟩
  intro s hs
  simpa only [hf s (hI hs)] using hcontrol s hs

end PoincareMT.M30CommonBlowupControls
