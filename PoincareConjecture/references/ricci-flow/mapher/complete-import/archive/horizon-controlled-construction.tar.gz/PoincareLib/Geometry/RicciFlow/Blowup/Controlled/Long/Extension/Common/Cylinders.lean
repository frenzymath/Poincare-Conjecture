import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Common.Continuity
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Common.Scalar
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Common.Source
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.PinchingBounds

/-!
# One source extension duration from a bounded boundary slice

The boundary bound fixes an ODE duration before the spatial radius. Compact
continuity chooses a radius-dependent interior sampling time, and scalar
propagation covers a common strip on both sides of the old horizon. The old
flow's global bound on a fixed compact time interval controls the remaining
part of every source cylinder.
Reference: Morgan--Tian, Proposition 11.10, pp. 272--278, especially p. 278.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_common_controlled_source_extension_of_closed_boundary_bound
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u})
    {epsilon C kappa r₀ mu : ℝ} {T₀ : ℝ≥0∞}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    (horizon : ENNReal.ofReal T < T₀)
    (F : RicciFlow 3 G.limit.carrier.carrier (Icc (-T) 0))
    (hmetric : ∀ t ∈ Ioc (-T) 0, F.metric t = G.limit.flow.metric t)
    {B : ℝ} (hboundary : ∀ x, (F.connection (-T)).scalarCurvature x ≤ B) :
    ∃ T' Q : ℝ, T < T' ∧ ENNReal.ofReal T' < T₀ ∧ 0 < Q ∧
      ∀ A : ℝ, 0 < A → ∀ eta : ℝ, 0 < eta → ∀ᶠ k in atTop,
        Nonempty (ControlledBlowupCylinder S (G.subsequence k) A T' Q eta) := by
  classical
  let J : SpacetimeInterval := ⟨Ioc (-T) 0, ordConnected_Ioc,
    ⟨-T / 2, ⟨by linarith, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩⟩
  let Rseed := max B 4 + 2
  have hseedFour : 4 ≤ Rseed := by dsimp [Rseed]; linarith [le_max_right B 4]
  have hseedPos : 0 < Rseed := by linarith
  have hseedBound : B + 1 + 1 ≤ Rseed := by dsimp [Rseed]; linarith [le_max_left B 4]
  obtain ⟨V, _, hTV, hV₀⟩ := ENNReal.lt_iff_exists_real_btwn.mp horizon
  have hTVreal : T < V := (ENNReal.ofReal_lt_ofReal_iff'.mp hTV).1
  have hV : 0 < V := hT.trans hTVreal
  let delta := min ((V - T) / 2) (min (T / 4)
    (1 / (32 * (H.analytic_constant + 1) * Rseed)))
  have hdelta : 0 < delta := lt_min (by linarith) (lt_min (by linarith)
    (by positivity [H.analytic_constant_pos]))
  have hdeltaV : delta ≤ (V - T) / 2 := min_le_left _ _
  have hdeltaT : delta ≤ T / 4 := (min_le_right _ _).trans (min_le_left _ _)
  have hdeltaSeed : delta ≤ 1 / (32 * (H.analytic_constant + 1) * Rseed) :=
    (min_le_right _ _).trans (min_le_right _ _)
  have hshort : delta < 1 / (4 * (H.analytic_constant + 1) * Rseed) := by
    apply hdeltaSeed.trans_lt
    apply one_div_lt_one_div_of_lt
    · positivity [H.analytic_constant_pos]
    · nlinarith [H.analytic_constant_pos]
  let T' := T + delta / 2
  let b := -T + delta / 2
  have hTT' : T < T' := by dsimp [T']; linarith
  have hT'V : T' < V := by dsimp [T']; linarith
  have hb : b < 0 := by dsimp [b]; linarith
  have hbJ : b ∈ J.domain := ⟨by dsimp [b]; linarith, hb.le⟩
  have hIb : Icc b 0 ⊆ J.domain := fun t ht => ⟨hbJ.1.trans_le ht.1, ht.2⟩
  have hIV : Icc (-T') 0 ⊆ Ioc (-V) 0 := fun t ht => ⟨by linarith [ht.1], ht.2⟩
  have hzero : (0 : ℝ) ∈ Ioc (-V) 0 := ⟨by linarith, le_rfl⟩
  obtain ⟨D, hD, hlate⟩ := G.limit.curvature_locally_bounded_in_time
    (Icc b 0) isCompact_Icc hIb
  have hlateScalar : ∀ t ∈ Icc b 0, ∀ x,
      (G.limit.flow.connection t).scalarCurvature x ≤ 3 * D := by
    intro t ht x
    exact ((G.limit.flow.connection t).scalarCurvature_le_curvatureTensorNorm_sharp x).trans
      (mul_le_mul_of_nonneg_left ((le_abs_self _).trans (hlate t ht x)) (by norm_num))
  let Q := max (2 * Rseed) (3 * D + 1)
  have hQ : 0 < Q := (mul_pos (by norm_num) hseedPos).trans_le (le_max_left _ _)
  refine ⟨T', 13 * max Q 1, hTT',
    (ENNReal.ofReal_lt_ofReal_iff hV).mpr hT'V |>.trans hV₀, by positivity, ?_⟩
  intro A hA eta heta
  let K := closure ((G.limit.flow.metric 0).ball G.limit.base (2 * A))
  have hK : IsCompact K := (G.limit.flow.metric 0).isCompact_closure_ball_of_metricComplete
    (G.limit.complete 0 G.limit.zero_mem) G.limit.base (2 * A)
  obtain ⟨a, ha, hanear, hsample⟩ :=
    ControlledLongExtension.exists_compact_scalar_sample_near_closed_boundary
      P04 hT (show 0 < delta / 4 by positivity) F hboundary hK
  have haJ : a ∈ J.domain := ⟨ha.1, ha.2.le⟩
  have hab : a < b := by dsimp [b]; linarith
  have haT' : -T' < a := by dsimp [T']; linarith [ha.1]
  have haV : a ∈ Ioc (-V) 0 := hIV ⟨haT'.le, ha.2.le⟩
  have hsampleOld : ∀ x ∈ K, (G.limit.flow.connection a).scalarCurvature x ≤ B + 1 := by
    intro x hx
    rw [← ControlledLongExtension.scalarCurvature_eq_of_metric_eq
      (F.connection a) (G.limit.flow.connection a) (hmetric a haJ) x]
    exact hsample x hx
  filter_upwards [G.eventually_scalar_bound_on_source_trajectories_of_limit_bound
    (J := J) P04 hA isCompact_singleton (singleton_subset_iff.mpr haJ)
    (B := B + 1) (by intro t ht x hx; rcases mem_singleton_iff.mp ht with rfl; exact hsampleOld x hx),
    G.eventually_scalar_bound_on_source_trajectories_of_limit_bound
      (J := J) P04 hA isCompact_Icc hIb (B := 3 * D) (fun t ht x _ => hlateScalar t ht x),
    G.subsequence_strictMono.tendsto_atTop.eventually (H.slabs V hV hV₀ A hA),
    G.subsequence_strictMono.tendsto_atTop.eventually
      (DeepHorn.eventually_full_and_negative_curvature_bounds P04 S H.branch hQ.le heta)]
    with k hseedSource hlateSource hslab hcurv
  obtain ⟨d⟩ := hslab
  have hseed := hseedSource _ d.embedding ordConnected_Ioc hzero (d.zero_identity hzero)
  have hafter := hlateSource _ d.embedding ordConnected_Ioc hzero (d.zero_identity hzero)
  have hscalar : ∀ s (hs : s ∈ Icc (-T') 0), ∀ x ∈ S.baseBall (G.subsequence k) A,
      (S.flow (G.subsequence k)).scalar (d.embedding.pointMap s (hIV hs) x) <
        Q * S.scale (G.subsequence k) := by
    intro s hs x hx
    have hscale : 0 < S.scale (G.subsequence k) := S.base_scalar_pos (G.subsequence k)
    by_cases hsb : b ≤ s
    · exact (hafter s ⟨hsb, hs.2⟩ (hIV hs) x hx).trans_le
        (mul_le_mul_of_nonneg_right (le_max_right _ _) hscale.le)
    let f : ℝ → ℝ := fun t => if ht : t ∈ Ioc (-V) 0 then
      (S.flow (G.subsequence k)).scalar (d.embedding.pointMap t ht x) else 0
    have hf : ∀ t (ht : t ∈ Ioc (-V) 0),
        f t = (S.flow (G.subsequence k)).scalar (d.embedding.pointMap t ht x) :=
      fun t ht => dif_pos ht
    have hseedf : f a < Rseed * S.scale (G.subsequence k) := by
      rw [hf a haV]
      exact (hseed a (mem_singleton a) haV x hx).trans_le
        (mul_le_mul_of_nonneg_right hseedBound hscale.le)
    have htwo : f s < (2 * Rseed) * S.scale (G.subsequence k) := by
      by_cases hsa : s ≤ a
      · exact H.toM30CommonBlowupControls.cylinder_scalar_lt_two_mul_before_time
          P04 (G.subsequence k) d.embedding hx hf hseedFour
          (fun t ht => hIV ⟨ht.1, ht.2.trans ha.2.le⟩) ha.2.le hseedf
          (show a - (-T') < 1 / (4 * (H.analytic_constant + 1) * Rseed) by
            apply lt_trans _ hshort; dsimp [T']; linarith)
          s ⟨hs.1, hsa⟩
      · exact H.toM30CommonBlowupControls.cylinder_scalar_lt_two_mul_after_time
          P04 (G.subsequence k) d.embedding hx hf hseedFour
          (fun t ht => hIV ⟨haT'.le.trans ht.1, ht.2.trans hb.le⟩) hb.le hseedf
          (show b - a < 1 / (4 * (H.analytic_constant + 1) * Rseed) by
            apply lt_trans _ hshort; dsimp [b]; linarith [ha.1])
          s ⟨(lt_of_not_ge hsa).le, (lt_of_not_ge hsb).le⟩
    rw [hf s (hIV hs)] at htwo
    exact htwo.trans_le (mul_le_mul_of_nonneg_right (le_max_left _ _) hscale.le)
  refine ⟨{
    embedding := d.embedding.restrict hIV Subset.rfl
    zero_identity := fun h x hx => d.zero_identity (hIV h) x hx
    curvature_bound := ?_
    negative_curvature_bound := ?_ }⟩
  · intro s hs x hx
    let p := d.embedding.pointMap s (hIV hs) x
    exact (hcurv p.1 ((S.flow (G.subsequence k)).slice_nonempty_iff p.1 |>.mp ⟨p.2⟩)
      p.2 (hscalar s hs x hx).le).1
  · intro s hs x hx
    let p := d.embedding.pointMap s (hIV hs) x
    exact (hcurv p.1 ((S.flow (G.subsequence k)).slice_nonempty_iff p.1 |>.mp ⟨p.2⟩)
      p.2 (hscalar s hs x hx).le).2

end PoincareMT.GeneralizedBlowupConvergence
