import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Data
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.Cylinders.Clock
import PoincareLib.Geometry.RicciFlow.Surgery.Induction.EpochExtension.Spacetime.GeneralizedCylinderRestriction

/-!
# Terminal volume from controlled cylinders

Pointwise noncollapse applies at the original radius divided by the square
root of the blow-up scale. Reclocking the actual cylinder supplies its
parabolic premise. Reference: Morgan--Tian Claim 11.5, p. 270.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.GeneralizedBlowupSequence

theorem base_mem_baseBall (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
    {A : ℝ} (hA : 0 < A) : (S.base k).2 ∈ S.baseBall k A := by
  simp only [baseBall, RiemannianMetric.ball, mem_ofPred_eq,
    RiemannianMetric.edist, Manifold.riemannianEDist_self]
  exact ENNReal.ofReal_pos.mpr (div_pos hA (Real.sqrt_pos.mpr (S.base_scalar_pos k)))

theorem eventually_original_radius_le
    (S : GeneralizedBlowupSequence.{u}) {rho r₀ : ℝ} (hr₀ : 0 < r₀) :
    ∀ᶠ k : ℕ in atTop, rho / Real.sqrt (S.scale k) ≤ r₀ := by
  have hdiv := Real.tendsto_sqrt_atTop.comp S.scalar_diverges
  filter_upwards [hdiv.eventually (eventually_ge_atTop (rho / r₀))] with k hk
  change rho / r₀ ≤ Real.sqrt (S.scale k) at hk
  have hsqrt : 0 < Real.sqrt (S.scale k) := Real.sqrt_pos.mpr (S.base_scalar_pos k)
  exact (div_le_iff₀ hsqrt).mpr (by
    have := (div_le_iff₀ hr₀).mp hk
    nlinarith)

end PoincareMT.GeneralizedBlowupSequence

namespace PoincareMT.ControlledBlowupCylinder

/-- A normalized curvature-controlled cylinder supplies the literal volume
lower bound at every smaller radius whose backward parabolic interval fits. -/
theorem terminal_volume_lower
    {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta rho kappa r₀ : ℝ}
    (e : ControlledBlowupCylinder S k A T B eta)
    (hrho : 0 < rho) (hrhoA : rho ≤ A) (htime : rho ^ 2 ≤ T)
    (hcurvature : B * rho ^ 2 ≤ 1)
    (hradius : rho / Real.sqrt (S.scale k) ≤ r₀)
    (hnoncollapsed : GeneralizedKappaNoncollapsedAt (S.flow k) (S.base k) kappa r₀) :
    ENNReal.ofReal (kappa * rho ^ 3 / (Real.sqrt (S.scale k)) ^ 3) ≤
      calibratedMetricVolume ((S.flow k).metric (S.base k).1) (S.baseBall k rho) := by
  let q := S.scale k
  let r := rho / Real.sqrt q
  have hq : 0 < q := S.base_scalar_pos k
  have hsqrt : 0 < Real.sqrt q := Real.sqrt_pos.mpr hq
  have hr : 0 < r := div_pos hrho hsqrt
  have hrsq : r ^ 2 * q = rho ^ 2 := by
    dsimp [r]
    rw [div_pow, Real.sq_sqrt hq.le]
    exact div_mul_cancel₀ _ hq.ne'
  have hsource : S.baseBall k rho ⊆ S.baseBall k A := by
    intro x hx
    exact hx.trans_le (ENNReal.ofReal_le_ofReal
      (div_le_div_of_nonneg_right hrhoA hsqrt.le))
  let d := e.embedding.restrict Subset.rfl hsource
  have hclock : ∀ s ∈ Ioc (-r ^ 2) 0,
      ((S.base k).1 + s / 1 - (S.base k).1) * S.scale k ∈ Icc (-T) 0 := by
    intro s hs
    simp only [div_one, add_sub_cancel_left]
    have hl := mul_le_mul_of_nonneg_right hs.1.le hq.le
    have hu := mul_nonpos_of_nonpos_of_nonneg hs.2 hq.le
    constructor
    · change -T ≤ s * q
      nlinarith [hrsq]
    · exact hu
  let c := d.reclock (S.base k).1 1 zero_lt_one hclock
  have hinterval : Ioc ((S.base k).1 - r ^ 2) (S.base k).1 ⊆ (S.flow k).interval := by
    intro t ht
    have hs : t - (S.base k).1 ∈ Ioc (-r ^ 2) 0 := ⟨by linarith [ht.1], by linarith [ht.2]⟩
    have h := ((S.flow k).slice_nonempty_iff _).mp
      ⟨c.forward (t - (S.base k).1) hs (S.base k).2⟩
    simpa only [div_one, add_sub_cancel] using h
  have hzero : ∀ h₀, ∀ x ∈ S.baseBall k rho,
      c.pointMap 0 h₀ x = (⟨(S.base k).1, x⟩ : (S.flow k).point) := by
    intro h₀ x hx
    rw [GeneralizedFlowCylinder.reclock_pointMap]
    simp only [zero_div, add_zero, sub_self, zero_mul]
    exact e.zero_identity _ x (hsource hx)
  have hbound : ∀ s hs, ∀ x ∈ S.baseBall k rho,
      |(S.flow k).curvatureNorm (c.pointMap s hs x)| ≤ r⁻¹ ^ 2 := by
    intro s hs x hx
    rw [GeneralizedFlowCylinder.reclock_pointMap]
    apply (e.curvature_bound _ _ x (hsource hx)).trans
    have hr2 : 0 < r ^ 2 := sq_pos_of_pos hr
    have hprod : (B * q) * r ^ 2 ≤ 1 := by
      calc
        (B * q) * r ^ 2 = B * (r ^ 2 * q) := by ring
        _ = B * rho ^ 2 := by rw [hrsq]
        _ ≤ 1 := hcurvature
    have hh := (le_div_iff₀ hr2).mpr hprod
    simpa only [one_div, inv_pow] using hh
  have hv := hnoncollapsed r hr hradius hinterval c hzero hbound
  convert hv using 1
  · congr 1
    dsimp [r, q]
    ring
  · rfl

end PoincareMT.ControlledBlowupCylinder

namespace PoincareMT.M30CommonBlowupControls

/-- One fixed-ball controlled cylinder suffices for the terminal-volume
input of geometric compactness. No neck certificate is required. -/
theorem terminal_volume_of_eventual_cylinders
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    {A T B eta : ℝ} (hA : 0 < A) (hT : 0 < T) (hB : 0 ≤ B)
    (hcylinders : ∀ᶠ k : ℕ in atTop, Nonempty (ControlledBlowupCylinder S k A T B eta)) :
    ∃ rho v : ℝ, 0 < rho ∧ 0 < v ∧ ∀ᶠ k : ℕ in atTop,
      ENNReal.ofReal (v / (Real.sqrt (S.scale k)) ^ 3) ≤
        calibratedMetricVolume ((S.flow k).metric (S.base k).1) (S.baseBall k rho) := by
  let rho : ℝ := min A (min 1 (min T (1 / (B + 1))))
  have hrho : 0 < rho := lt_min hA (lt_min zero_lt_one (lt_min hT (by positivity)))
  have hrhoA : rho ≤ A := min_le_left _ _
  have hrho1 : rho ≤ 1 := (min_le_right _ _).trans (min_le_left _ _)
  have hrhoT : rho ≤ T :=
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
  have hrhoB : rho ≤ 1 / (B + 1) :=
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _))
  have hrhosq : rho ^ 2 ≤ rho := by nlinarith
  have htime : rho ^ 2 ≤ T := hrhosq.trans hrhoT
  have hcurvature : B * rho ^ 2 ≤ 1 := by
    have h := (le_div_iff₀ (by positivity : 0 < B + 1)).mp hrhoB
    nlinarith [mul_le_mul_of_nonneg_left hrhosq hB]
  refine ⟨rho, kappa * rho ^ 3, hrho, mul_pos H.kappa_pos (pow_pos hrho _), ?_⟩
  filter_upwards [hcylinders, H.noncollapsed_at_zero A hA,
    S.eventually_original_radius_le (rho := rho) H.radius_pos] with k hk hnc hradius
  obtain ⟨e⟩ := hk
  exact e.terminal_volume_lower hrho hrhoA htime hcurvature hradius
    (by simpa only [Sigma.eta] using hnc (S.base k).2 (S.base_mem_baseBall k hA))

end PoincareMT.M30CommonBlowupControls
