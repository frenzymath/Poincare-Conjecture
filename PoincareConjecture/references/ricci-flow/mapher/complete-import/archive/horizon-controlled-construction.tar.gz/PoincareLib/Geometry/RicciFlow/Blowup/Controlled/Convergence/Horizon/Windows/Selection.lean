import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.GeometricWindow

/-!
# Simultaneous finite-horizon cylinder selection

One increasing subsequence satisfies all earlier horizon controls on its
current expanding spatial ball. The curvature constant remains attached to
the fixed horizon, independently of the selected source index.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

theorem exists_simultaneous_horizon_cylinders
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀)
    (tau : ℕ → ℝ) (htau : ∀ j, 0 < tau j)
    (hhorizon : ∀ j, ENNReal.ofReal (tau j) < T₀) :
    ∃ B : ℕ → ℝ, (∀ j, 0 ≤ B j) ∧ ∃ idx : ℕ → ℕ, StrictMono idx ∧
      (∀ i, IsCompact (closure (S.baseBall (idx i) (expandingRadius i)))) ∧
      (∃ rho v : ℝ, 0 < rho ∧ 0 < v ∧ ∀ i,
        ENNReal.ofReal (v / Real.sqrt (S.scale (idx i)) ^ 3) ≤
          calibratedMetricVolume ((S.flow (idx i)).metric (S.base (idx i)).1)
            (S.baseBall (idx i) rho)) ∧
      ∀ i j, j ≤ i → Nonempty (ControlledBlowupCylinder S (idx i)
        (expandingRadius i) (tau j) (B j) ((expandingRadius i)⁻¹)) := by
  classical
  choose B hB hcyl using fun j => H.cylinders (tau j) (htau j) (hhorizon j)
  obtain ⟨rho, v, hrho, hv, hvolume⟩ := H.terminal_volume
  let Q (i k : ℕ) : Prop := IsCompact (closure (S.baseBall k (expandingRadius i))) ∧
    ENNReal.ofReal (v / Real.sqrt (S.scale k) ^ 3) ≤
      calibratedMetricVolume ((S.flow k).metric (S.base k).1) (S.baseBall k rho) ∧
    ∀ j ≤ i, Nonempty (ControlledBlowupCylinder S k
      (expandingRadius i) (tau j) (B j) ((expandingRadius i)⁻¹))
  have hQ (i : ℕ) : ∀ᶠ k in atTop, Q i k := by
    filter_upwards [H.balls_compact _ (expandingRadius_pos i), hvolume,
      (eventually_all_finite (Set.finite_Iic i)).mpr (fun j _ =>
        hcyl j (expandingRadius i) (expandingRadius_pos i) ((expandingRadius i)⁻¹)
          (inv_pos.mpr (expandingRadius_pos i)))] with k hk hvk hck
    exact ⟨hk, hvk, hck⟩
  obtain ⟨idx, hidx, hsel⟩ := Poincare.exists_strictMono_forall_le_of_eventually hQ
  exact ⟨B, hB, idx, hidx, fun i => (hsel i i le_rfl).1,
    ⟨rho, v, hrho, hv, fun i => (hsel i i le_rfl).2.1⟩,
    fun i j hji => (hsel i i le_rfl).2.2 j hji⟩

end PoincareMT.ControlledBlowupCompactness
