import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.FarPoint
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Distance.Bound
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Distance.Monotonicity
import PoincareLib.Geometry.Curvature.Operator.SectionalBounds

/-!
# Fixed distant triangles retain their shape throughout the past interval

A sufficiently distant terminal vertex has a fixed companion making a large
triangle at every earlier time. Additive distance control and monotonicity
preserve the quantitative inequalities uniformly up to the open past endpoint.
Reference: Morgan--Tian, Claims 11.11--11.14, pp. 274--277.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongGeometry

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_uniform_past_large_triangles
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T : ℝ} (hT : 0 < T) (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    (p : L.carrier.carrier) :
    ∃ A : ℝ, 0 < A ∧ ∀ y : L.carrier.carrier,
      A ≤ ((L.flow.metric 0).edist p y).toReal →
      ∃ z : L.carrier.carrier, ∀ t ∈ Ioc (-T) 0,
        let d := ((L.flow.metric 0).edist p y).toReal
        d ≤ ((L.flow.metric t).edist y p).toReal ∧
        d ≤ ((L.flow.metric t).edist y z).toReal ∧
        ((L.flow.metric t).edist y p).toReal ≤ 3 * d / 2 ∧
        ((L.flow.metric t).edist y z).toReal ≤ 3 * d / 2 ∧
        d ≤ ((L.flow.metric t).edist p z).toReal := by
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  have hsec : (L.flow.connection 0).NonnegativeSectionalCurvature := fun y v w =>
    (L.flow.connection 0).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
      y (L.nonnegative_curvature_operator 0 L.zero_mem y) v w
  obtain ⟨A, hA, hcompanion⟩ := exists_distant_equidistant_companion
    (L.flow.metric 0) (L.flow.connection 0) (L.complete 0 L.zero_mem) hsec p
  obtain ⟨C, _, hdist⟩ :=
    ControlledLongDistance.exists_uniform_additive_distance_bound P04 P06 hT L
  refine ⟨max A (2 * C), hA.trans_le (le_max_left _ _), ?_⟩
  intro y hy
  have hyA := (le_max_left A (2 * C)).trans hy
  have hyC := (le_max_right A (2 * C)).trans hy
  have hd : 0 < ((L.flow.metric 0).edist p y).toReal := hA.trans_le hyA
  obtain ⟨z, hyz, hpz⟩ := hcompanion y hyA
  refine ⟨z, ?_⟩
  intro t ht
  have hloyp := ControlledLongDistance.terminal_toReal_edist_le P04 L ht y p
  have hloyz := ControlledLongDistance.terminal_toReal_edist_le P04 L ht y z
  have hlopz := ControlledLongDistance.terminal_toReal_edist_le P04 L ht p z
  have hhiyp := hdist t ht y p
  have hhiyz := hdist t ht y z
  have hcomm : (L.flow.metric 0).edist y p = (L.flow.metric 0).edist p y := by
    let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : L.carrier.carrier → Type _) :=
      ⟨(L.flow.metric 0).toRiemannianMetric⟩
    exact Manifold.riemannianEDist_comm
  rw [hcomm] at hloyp hhiyp
  rw [hyz] at hloyz hhiyz
  exact ⟨hloyp, hloyz, by linarith, by linarith, by linarith⟩

end PoincareMT.ControlledLongGeometry
