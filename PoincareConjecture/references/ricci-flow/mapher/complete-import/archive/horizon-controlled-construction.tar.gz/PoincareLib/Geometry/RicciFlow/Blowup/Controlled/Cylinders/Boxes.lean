import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.Cylinders.TimeGluing
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.NeckTransfer

/-!
# Actual flow boxes as local cylinders

These constructions promote the original adapted boxes to normalized cylinders
and pull a second cylinder back to a neighborhood in the first source. They
provide the spatial enlargement needed for controlled blowup cylinders in
Morgan--Tian, Theorem 11.1, pp. 268-271.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Function
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT.GeneralizedFlowCylinder

/-- An original adapted box, restricted to any normalized time interval. -/
noncomputable def ofBox {F : GeneralizedRicciFlowData.{u}}
    (b : F.box_index) {origin scale : ℝ} (hq : 0 < scale)
    {I : Set ℝ} (hI : ∀ s ∈ I, origin + s / scale ∈ (F.box b).interval) :
    GeneralizedFlowCylinder F (F.box b).carrier origin scale I univ where
  scale_pos := hq
  forward s hs := (F.box b).forward _ (hI s hs)
  inverse s hs := (F.box b).inverse _ (hI s hs)
  forward_smooth s hs := (F.box b).forward_smooth _ _ |>.contMDiffOn
  inverse_smooth s hs := by
    simpa only [image_univ] using (F.box b).inverse_smooth (origin + s / scale) (hI s hs)
  left_inverse s hs _ _ := (F.box b).left_inverse _ _ _
  right_inverse s hs := by
    simpa only [image_univ] using (F.box b).right_inverse (origin + s / scale) (hI s hs)
  embedding := by
    let clock : ℝ ≃ₜ ℝ := (Homeomorph.mulRight₀ scale⁻¹ (inv_ne_zero hq.ne')).trans
      (Homeomorph.addLeft origin)
    have hc (s : ℝ) : clock s = origin + s / scale := by simp [clock, div_eq_mul_inv]
    have hm : MapsTo clock I (F.box b).interval := by
      intro s hs
      rw [hc]
      exact hI s hs
    have h := (F.box_openEmbedding b).isEmbedding.comp
      ((clock.isEmbedding.restrict hm).prodMap
        (Topology.IsEmbedding.subtypeVal :
          Topology.IsEmbedding (Subtype.val : ↥(univ : Set (F.box b).carrier.carrier) → _)))
    convert h using 1 <;> rfl
  vertical_compatibility s hs x _ := ⟨b, x, 1, zero_lt_one,
    fun s' hs' _ => ⟨hI s' hs', rfl⟩⟩

/-- A second cylinder pulls back through a common slice chart to an open
neighborhood of any point where the two slice images meet. -/
theorem exists_rebased_neighborhood
    {F : GeneralizedRicciFlowData.{u}} {C D : GeneralizedSliceCarrier.{u}}
    {origin scale : ℝ} {I J : Set ℝ} {U : Set C.carrier} {W : Set D.carrier}
    (d : GeneralizedFlowCylinder F C origin scale I U)
    (e : GeneralizedFlowCylinder F D origin scale J W)
    (hU : IsOpen U) (hW : IsOpen W)
    {t : ℝ} (ht : t ∈ I) (ht' : t ∈ J)
    {x : C.carrier} (hx : x ∈ U) {y : D.carrier} (hy : y ∈ W)
    (hxy : d.pointMap t ht x = e.pointMap t ht' y) :
    ∃ V : Set C.carrier, IsOpen V ∧ x ∈ V ∧ V ⊆ U ∧
      ∃ n : GeneralizedFlowCylinder F C origin scale J V,
        ∀ z ∈ V, n.pointMap t ht' z = d.pointMap t ht z := by
  let f := (d.sliceHomeomorph hU t ht).trans (e.sliceHomeomorph hW t ht').symm
  have hVU : f.source ⊆ U := fun _ hz => hz.1
  have hVW : f.target ⊆ W := fun _ hz => hz.1
  have hxV : x ∈ f.source := by
    refine ⟨hx, ?_⟩
    change d.forward t ht x ∈ e.forward t ht' '' W
    exact ⟨y, hy, (eq_of_heq (Sigma.mk.inj_iff.mp hxy).2).symm⟩
  have hf : ContMDiffOn (𝓡 3) (𝓡 3) ∞ f f.source :=
    (e.inverse_smooth t ht').comp ((d.forward_smooth t ht).mono hVU)
      (fun _ hz => hz.2)
  have hfi : ContMDiffOn (𝓡 3) (𝓡 3) ∞ f.symm f.target :=
    (d.inverse_smooth t ht).comp ((e.forward_smooth t ht').mono hVW)
      (fun _ hz => hz.2)
  refine ⟨f.source, f.open_source, hxV, hVU,
    e.rebasePartialSource f hVW hf hfi, ?_⟩
  intro z hz
  apply congrArg (fun w => (⟨origin + t / scale, w⟩ : F.point))
  exact e.right_inverse t ht' hz.2

/-- Overlapping time cylinders that meet along one trajectory extend one
another on an actual open neighborhood of that trajectory's source. -/
theorem exists_local_time_extension
    {F : GeneralizedRicciFlowData.{u}} {C D : GeneralizedSliceCarrier.{u}}
    {origin scale a b c d : ℝ} {U : Set C.carrier} {W : Set D.carrier}
    (old : GeneralizedFlowCylinder F C origin scale (Icc b d) U)
    (patch : GeneralizedFlowCylinder F D origin scale (Icc a c) W)
    (hU : IsOpen U) (hW : IsOpen W)
    (hab : a ≤ b) (hbc : b < c) (hcd : c ≤ d)
    {t : ℝ} (ht : t ∈ Icc b d) (ht' : t ∈ Icc a c)
    {x : C.carrier} (hx : x ∈ U) {y : D.carrier} (hy : y ∈ W)
    (hxy : old.pointMap t ht x = patch.pointMap t ht' y) :
    ∃ V : Set C.carrier, IsOpen V ∧ x ∈ V ∧ V ⊆ U ∧
      ∃ n : GeneralizedFlowCylinder F C origin scale (Icc a d) V,
        ∀ s (hs : s ∈ Icc b d) z, z ∈ V →
          n.pointMap s ⟨hab.trans hs.1, hs.2⟩ z = old.pointMap s hs z := by
  obtain ⟨V, hV, hxV, hVU, n, hn⟩ :=
    old.exists_rebased_neighborhood patch hU hW ht ht' hx hy hxy
  obtain ⟨g, _, hg⟩ := n.exists_glued_time_Icc_of_pointMap_eq
    (old.restrict Subset.rfl hVU) hab hbc hcd ht' ht hn
  exact ⟨V, hV, hxV, hVU, g, hg⟩

end PoincareMT.GeneralizedFlowCylinder
