import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Metric
import PoincareLib.Geometry.RicciFlow.AncientKappa.Asymptotic.Compactness.Coordinates.SpacetimeJets

/-!
# Coordinate coefficients of retained generalized cylinders

The actual generalized pullback coefficients, in the lifted limit atlas,
are the fixed spatial M07 coefficients with the midpoint time shift undone.
This identity includes terminal time zero.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold
  normedAddCommGroupTangentSpaceVectorSpace normedSpaceTangentSpaceVectorSpace

open ControlledBlowupCylinder

private theorem pullbackCoefficients_apply {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    (g : RiemannianMetric 3 M) (f : EuclideanSpace ℝ (Fin 3) → M)
    (x v w : EuclideanSpace ℝ (Fin 3)) :
    g.pullbackCoefficients f x v w = g.inner (f x)
      (mfderiv (𝓡 3) (𝓡 3) f x v) (mfderiv (𝓡 3) (𝓡 3) f x w) := rfl

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

theorem retainedCylinder_chart_inner (k : ℕ) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (q : (liftedSliceCarrier.{u} G.limitCarrier).carrier)
    (z : EuclideanSpace ℝ (Fin 3)) (hz : z ∈ (extChartAt (𝓡 3) q).target)
    (hx : ((extChartAt (𝓡 3) q).symm z).down ∈ G.exhaustion k)
    (v w : EuclideanSpace ℝ (Fin 3)) :
    (retainedCylinder G k).pullbackInner s hs ((extChartAt (𝓡 3) q).symm z)
      (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z v)
      (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z w) =
      G.spatialSpacetimeCoefficients q.down k (s + T / 2, z) v w := by
  rw [retainedCylinder_pullbackInner G k s hs _ hx]
  have hchart := ((contMDiffOn_extChartAt_symm (n := ∞) q).contMDiffAt
    ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds hz)).mdifferentiableAt (by simp)
  have hmap := (retainedSmallMap_contMDiffAt G k hx).mdifferentiableAt (by simp)
  have hder := mfderiv_comp z hmap hchart
  have hderv := congrArg (fun L => L v) hder
  have hderw := congrArg (fun L => L w) hder
  change _ = mfderiv (𝓡 3) (𝓡 3) (retainedSmallMap G k) ((extChartAt (𝓡 3) q).symm z)
    (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z v) at hderv
  change _ = mfderiv (𝓡 3) (𝓡 3) (retainedSmallMap G k) ((extChartAt (𝓡 3) q).symm z)
    (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z w) at hderw
  rw [← hderv, ← hderw]
  have hmetric :
      ((interiorSequence S idx A eta T B hA hT e).flow (G.subsequence k)).metricAt (s + T / 2) =
        ((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).metric s := by
    change ((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).metric
      ((s + T / 2) + (-T / 2)) = _
    rw [show (s + T / 2) + (-T / 2) = s by ring]
  unfold PointedGeometricConvergence.spatialSpacetimeCoefficients
  rw [hmetric, pullbackCoefficients_apply]
  rfl

end PoincareMT.ControlledBlowupCompactness
