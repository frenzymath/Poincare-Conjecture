import PoincareLib.Geometry.RicciFlow.Surgery.Induction.EpochExtension.Spacetime.GeneralizedCylinderMetric
import PoincareLib.Geometry.Spacetime.Realization
import PoincareLib.Geometry.RicciFlow.Generalized.Gauge.Assembly
import PoincareLib.Geometry.Riemannian.Connection.Construction
import PoincareLib.Geometry.Riemannian.Normalization.Connection.Regularity
import PoincareLib.Geometry.Riemannian.Curvature.IntrinsicCalculus
import PoincareLib.Geometry.RicciFlow.Rescaling.Flow

/-!
# Ordinary Ricci flows on controlled generalized cylinders

The actual generalized cylinder carries its normalized pullback Ricci flow.
The construction uses the existing spacetime realization and gauge theorems;
connection existence and tensor calculus are proved metric constructions.
This is the ordinary-flow input to Morgan--Tian Theorems 11.1 and 11.8,
pp. 267--279, using Definition 3.38 and Remark 3.37, pp. 60--61.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

private theorem metricPredecessors (n : ℕ) : M12MetricPredecessors.{u} n where
  connection_exists := fun _ _ _ _ _ _ g => ⟨g.leviCivitaData⟩
  connection_regular := fun _ _ _ _ _ D _ hU Y hY =>
    D.normalization_contMDiffOn_connection hU Y hY
  curvature_calculus := fun _ _ _ _ _ D => D.intrinsicCurvatureTensorCalculus

private theorem gaugeTheory : GeneralizedRicciGaugeTheory.{u} 3 :=
  generalizedRicciGaugeGeometry 3 (generalizedSpacetimeGeometry 3)
    (metricPredecessors 3) (metricPredecessors 3)

end PoincareMT.ControlledBlowupCompactness

namespace PoincareMT.GeneralizedFlowCylinder

open EpochExtension.Spacetime

/-- A generalized cylinder on an open source has an ordinary Ricci flow with
exactly the prescribed normalized pullback metric, including its time endpoints. -/
theorem exists_ordinary_pullback_flow
    {F : GeneralizedRicciFlowData.{u}} {C : GeneralizedSliceCarrier.{u}}
    {a q : ℝ} {J : SpacetimeInterval} {U : TopologicalSpace.Opens C.carrier}
    (e : GeneralizedFlowCylinder F C a q J.domain U) (hC : Nonempty C.carrier) :
    ∃ G : RicciFlow 3 U J.domain,
      ∀ s (hs : s ∈ J.domain) (x : U) (v w : TangentSpace (𝓡 3) x),
        (G.metric s).inner x v w = e.pullbackInner s hs x.val
          (mfderiv (𝓡 3) (𝓡 3) (Subtype.val : U → C.carrier) x v)
          (mfderiv (𝓡 3) (𝓡 3) (Subtype.val : U → C.carrier) x w) := by
  obtain ⟨R⟩ := flowBoxRicciGeometry F (generalizedSpacetimeGeometry 3)
    ControlledBlowupCompactness.gaugeTheory
  have hI : (cylinderPhysicalInterval a q e.scale_pos J).domain ⊆ F.interval := by
    rintro t ⟨s, hs, rfl⟩
    exact (F.slice_nonempty_iff _).mp (hC.map (e.forward s hs))
  let d := rawCylinderTransport R.realization e hI
  let M := rawCylinderMetric R.realization e hI
  have H := ControlledBlowupCompactness.gaugeTheory.gauges F.point Sigma.fst
    (flowInterval F) R.realization.spacetime R.realization.slices
    R.realization.timeIntervals R.realization.gaugeCover R.leafwise
  obtain ⟨W⟩ := H.compatible_ordinary U (cylinderPhysicalInterval a q e.scale_pos J)
    d M (fun p _ => R.equation p)
  let G := W.flow.parabolicRescale q e.scale_pos a
    (fun s hs => ⟨s, hs, rfl⟩) J.ordConnected J.nontrivial
  refine ⟨G, ?_⟩
  intro s hs x v w
  change q * (W.flow.metric (a + s / q)).inner x v w = _
  rw [W.metric_eq]
  rw [rawCylinderMetric_eq R.realization e hI M ⟨s, hs⟩
    (R.sliceIdentification (a + s / q)) x v w]
  exact mul_div_cancel₀ _ e.scale_pos.ne'

/-- The ordinary normalized flow on the actual cylinder source. -/
noncomputable def ordinaryPullbackFlow
    {F : GeneralizedRicciFlowData.{u}} {C : GeneralizedSliceCarrier.{u}}
    {a q : ℝ} {J : SpacetimeInterval} {U : TopologicalSpace.Opens C.carrier}
    (e : GeneralizedFlowCylinder F C a q J.domain U) (hC : Nonempty C.carrier) :
    RicciFlow 3 U J.domain :=
  Classical.choose (e.exists_ordinary_pullback_flow hC)

theorem ordinaryPullbackFlow_inner
    {F : GeneralizedRicciFlowData.{u}} {C : GeneralizedSliceCarrier.{u}}
    {a q : ℝ} {J : SpacetimeInterval} {U : TopologicalSpace.Opens C.carrier}
    (e : GeneralizedFlowCylinder F C a q J.domain U) (hC : Nonempty C.carrier)
    (s : ℝ) (hs : s ∈ J.domain) (x : U) (v w : TangentSpace (𝓡 3) x) :
    ((e.ordinaryPullbackFlow hC).metric s).inner x v w = e.pullbackInner s hs x.val
      (mfderiv (𝓡 3) (𝓡 3) (Subtype.val : U → C.carrier) x v)
      (mfderiv (𝓡 3) (𝓡 3) (Subtype.val : U → C.carrier) x w) :=
  Classical.choose_spec (e.exists_ordinary_pullback_flow hC) s hs x v w

end PoincareMT.GeneralizedFlowCylinder
