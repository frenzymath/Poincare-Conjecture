import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Scalar
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.NegativeCurvature

/-!
# Curvature sign through the controlled terminal slice
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)

include hF

/-- Vanishing actual source pinching yields a nonnegative operator at every
point of the included terminal half-slab. -/
theorem terminal_nonnegativeCurvatureOperator
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (heta : Tendsto eta atTop (𝓝 0))
    {t : ℝ} (ht : t ∈ Icc 0 (T / 2)) (x : G.limitCarrier.carrier) :
    (F.connection t).NonnegativeCurvatureOperator x := by
  classical
  let c := extChartAt (𝓡 3) x
  let p := c x
  have hp : p ∈ c.target := mem_extChartAt_target x
  have hcx : c.symm p = x := c.left_inv (mem_extChartAt_source x)
  obtain ⟨g, D, V, hVo, hpV, _, heq⟩ := G.limitCarrier.exists_local_coordinate_realization
    (F.metric t) x t p hp
  have hg : ∀ᶠ y in 𝓝 p, ∀ a b : Fin 3,
      g.euclideanCoefficients y (EuclideanSpace.basisFun (Fin 3) ℝ a)
        (EuclideanSpace.basisFun (Fin 3) ℝ b) =
      G.limitCarrier.coordinateCoefficient x
        (fun _ y v w => G.limitCarrier.metricInner (F.metric t) y v w) a b (t, y) :=
    Filter.Eventually.mono (hVo.mem_nhds hpV) heq
  obtain ⟨ρ, hρ, hρc⟩ := G.exists_referenceBall_radius x
  have hzero : 0 ∈ Ioo (-T / 2) (T / 2) := ⟨by linarith, by linarith⟩
  have hφ : ∀ᶠ k : ℕ in atTop, ∀ᶠ y in 𝓝 p,
      ContMDiffAt (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap x k 0) y ∧
        Function.Injective (mfderiv (𝓡 3) (𝓡 3) (G.referenceChartMap x k 0) y) := by
    filter_upwards [G.eventually_subset_referencePartialChart_source x hzero
      (isCompact_closedBall _ _) hρc] with k hk
    filter_upwards [Metric.ball_mem_nhds p hρ] with y hy
    have hys := hk (ball_subset_closedBall hy)
    exact ⟨G.referenceChartMap_contMDiffAt x k hzero hys.1 hys.2,
      (G.referenceChartMap_mfderiv_isInvertible x k hzero hys.1 hys.2).injective⟩
  have hpos := LeviCivitaData.nonnegativeCurvatureOperator_of_scalar_pullback_jets
    (fun k => (terminalSourceFlow G k).connection t)
    (fun k => G.referenceChartMap x k 0) D p hφ (by
      intro r _ a b
      rw [G.limitCarrier.iteratedFDeriv_coordinateCoefficient_eq_of_eventuallyEq
        x _ t p g hg r a b]
      exact tendsto_terminal_spatial_pullbackJet G F hF P04 hB hAr hcompact hcomplete
        x hp ht r a b)
    (heta.comp G.subsequence_strictMono.tendsto_atTop) (Eventually.of_forall fun k =>
      (e (G.subsequence k)).smallFlow_negativeCurvaturePart_le (hA _) hT
        (t + (-T / 2)) ⟨by linarith [ht.1], by linarith [ht.2]⟩ _)
  have hequiv := G.limitCarrier.nonnegativeCurvatureOperator_iff_of_coordinate_germ
    (F.metric t) (F.connection t) x t p hp g D hg
  have hresult := hequiv.mp hpos
  change (F.connection t).NonnegativeCurvatureOperator (c.symm p) at hresult
  simpa only [hcx] using hresult

end PoincareMT.ControlledBlowupCompactness
