import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Horizon.Stages
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Cylinders.Restriction

/-! # Geometric controls and compatible horizon stages -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped ENNReal Topology

universe u

namespace PoincareMT.ControlledBlowupHorizon.Stage

variable {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}

def ofGeometricControls {sigma : ℕ → ℕ} {hsigma : StrictMono sigma} {T : ℝ≥0∞}
    (H : M30GeometricLongControls (S.subsequence sigma hsigma) T) (hT₀ : 0 < T₀) :
    Stage S T₀ where
  horizon := min T T₀
  horizon_pos := lt_min H.horizon_pos hT₀
  horizon_le := min_le_right _ _
  index := sigma
  strictMono := hsigma
  cylinders t ht hth := by
    obtain ⟨B, hB, hcyl⟩ := H.cylinders t ht (hth.trans_le (min_le_left _ _))
    refine ⟨B, hB, fun A hA eta heta => ?_⟩
    change ∀ᶠ k in atTop, Nonempty (ControlledBlowupCylinder S (sigma k) A t B eta)
    filter_upwards [hcyl A hA eta heta] with k hk
    obtain ⟨e⟩ := hk
    exact ⟨{ embedding := e.embedding
             zero_identity := e.zero_identity
             curvature_bound := e.curvature_bound
             negative_curvature_bound := e.negative_curvature_bound }⟩

def toGeometricControls (a : Stage S T₀) (hballs : BlowupBaseBallsCompact S)
    (hvolume : ∃ rho v : ℝ, 0 < rho ∧ 0 < v ∧
      ∀ᶠ k in atTop, ENNReal.ofReal (v / (Real.sqrt (S.scale k)) ^ 3) ≤
        calibratedMetricVolume ((S.flow k).metric (S.base k).1) (S.baseBall k rho)) :
    M30GeometricLongControls (S.subsequence a.index a.strictMono) a.horizon where
  horizon_pos := a.horizon_pos
  balls_compact A hA := a.strictMono.tendsto_atTop.eventually (hballs A hA)
  terminal_volume := by
    obtain ⟨rho, v, hrho, hv, hvol⟩ := hvolume
    exact ⟨rho, v, hrho, hv, a.strictMono.tendsto_atTop.eventually hvol⟩
  cylinders t ht hth := by
    obtain ⟨B, hB, hcyl⟩ := a.cylinders t ht hth
    refine ⟨B, hB, fun A hA eta heta => ?_⟩
    have h := hcyl A hA eta heta
    change ∀ᶠ k in atTop, Nonempty (ControlledBlowupCylinder S (a.index k) A t B eta) at h
    filter_upwards [h] with k hk
    obtain ⟨e⟩ := hk
    exact ⟨{ embedding := e.embedding
             zero_identity := e.zero_identity
             curvature_bound := e.curvature_bound
             negative_curvature_bound := e.negative_curvature_bound }⟩

/-- A common cylinder past the old horizon gives a proper refinement, with
the original source indices and their eventual properties retained. -/
theorem exists_refinement_of_uniform_cylinders (a : Stage S T₀)
    {tau : ℕ → ℕ} (htau : StrictMono tau) {V B : ℝ}
    (hV : 0 < V) (hgreater : a.horizon < ENNReal.ofReal V)
    (hhorizon : ENNReal.ofReal V ≤ T₀) (hB : 0 ≤ B)
    (hcyl : ∀ A : ℝ, 0 < A → ∀ eta : ℝ, 0 < eta →
      ∀ᶠ k in atTop, Nonempty (ControlledBlowupCylinder S (a.index (tau k)) A V B eta)) :
    ∃ b : Stage S T₀, Refines a b ∧ a.horizon < b.horizon := by
  let b : Stage S T₀ := {
    horizon := ENNReal.ofReal V
    horizon_pos := ENNReal.ofReal_pos.mpr hV
    horizon_le := hhorizon
    index := a.index ∘ tau
    strictMono := a.strictMono.comp htau
    cylinders := by
      intro t ht hth
      have htV : t < V := (ENNReal.ofReal_lt_ofReal_iff hV).mp hth
      refine ⟨B, hB, fun A hA eta heta => ?_⟩
      change ∀ᶠ k in atTop, Nonempty (ControlledBlowupCylinder S (a.index (tau k)) A t B eta)
      filter_upwards [hcyl A hA eta heta] with k hk
      exact hk.map (fun e => e.restrictTime htV.le) }
  refine ⟨b, Or.inr ⟨hgreater, ?_⟩, hgreater⟩
  change map (a.index ∘ tau) atTop ≤ map a.index atTop
  rw [← map_map]
  exact map_mono htau.tendsto_atTop

end PoincareMT.ControlledBlowupHorizon.Stage
