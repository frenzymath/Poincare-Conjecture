import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Sequence.Necks
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.ComponentRatio
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Alternatives
import PoincareLib.Geometry.RicciFlow.Generalized.BoundedDistance.Dense

/-!
# Excluding canonical component alternatives above the terminal cutoff

The connected comparison stage joins the selected point to the normalized
basepoint. Frequent whole-component alternatives force a scalar bound at
the selected point. Above that bound the actual neck or cap alternative
holds on a tail, and gives a transported terminal neck.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Topology Bundle

universe u v

namespace PoincareMT.ControlledTerminal

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem exists_terminal_neck_above_canonical_component_cutoff
    {M : Type v} [TopologicalSpace M] [T3Space M]
    [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    (F : ℕ → GeneralizedRicciFlowData.{u}) (t scale : ℕ → ℝ)
    (hscale : ∀ k, 0 < scale k)
    (g : RiemannianMetric 3 M) (D : LeviCivitaData g) (hcomplete : MetricComplete g)
    (e : ∀ k, OpenPartialHomeomorph M ((F k).slice (t k)).carrier)
    (he : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source)
    (hei : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k).symm (e k).target)
    {U : Set M} (hU : IsOpen U) (hUc : IsPreconnected U)
    (hUe : ∀ k, U ⊆ (e k).source) (p x : M) (hp : p ∈ U) (hx : x ∈ U)
    {delta epsilon C l u r : ℝ} (hdelta : 0 < delta) (hsmall : delta < 1 / 200)
    (hround : delta ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold)
    (haccuracy : delta < epsilon) (hepsilon : epsilon < 1 / 2)
    (hl : 0 < l) (hlx : l < D.scalarCurvature x) (hxu : D.scalarCurvature x < u)
    (hxlarge : max 4 (max (C / 6) 2) < D.scalarCurvature x)
    (hcanonical : ∀ k, generalizedSliceStrongCanonicalNeighborhoods (F k) delta C
      (4 * scale k) (t k))
    (hneckradius : (2 * Real.pi + 2 * delta⁻¹) * l ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hcapradius : max C 1 * l ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hsource : closure (g.ball x (2 * r + 1)) ⊆ U)
    (hbound : ∀ k y, y ∈ closure (g.ball x (2 * r + 1)) →
      ∀ v : TangentSpace (𝓡 3) y, g.tangentNorm y v ≤
        2 * (rescaledMetric ((F k).metric (t k)) (scale k) (hscale k)).tangentNorm
          (e k y) (mfderiv (𝓡 3) (𝓡 3) (e k) y v))
    {ι : Type*} (s : Finset ι) (q : ι → M) (K : ι → Set M)
    (hK : ∀ i ∈ s, IsCompact (K i) ∧ K i ⊆ U ∩ (extChartAt (𝓡 3) (q i)).source)
    (hcover : ∀ y ∈ closure (g.ball x (2 * r)), ∃ i ∈ s, y ∈ K i)
    (hjet : ∀ i ∈ s, ∀ m, TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((rescaledMetric ((F k).metric (t k))
        (scale k) (hscale k)).parametrizedCoefficients
          (e k ∘ (extChartAt (𝓡 3) (q i)).symm)))
      (iteratedFDeriv ℝ m (g.parametrizedCoefficients (extChartAt (𝓡 3) (q i)).symm))
      atTop ((extChartAt (𝓡 3) (q i)) '' K i))
    (hscalarconv : TendstoUniformlyOn
      (fun k y => (scale k)⁻¹ * ((F k).connection (t k)).scalarCurvature (e k y))
      D.scalarCurvature atTop (closure (g.ball x (2 * r))))
    (hbase : Tendsto
      (fun k => (scale k)⁻¹ * ((F k).connection (t k)).scalarCurvature (e k p)) atTop (𝓝 1)) :
    ∃ N : EpsilonNeck g, N.epsilon = epsilon ∧ N.connection = D ∧
      D.scalarCurvature x ≤ 2 * max C 1 * D.scalarCurvature N.center := by
  let h := fun k => rescaledMetric ((F k).metric (t k)) (scale k) (hscale k)
  let Ds := fun k => rescaledMetric_connection ((F k).metric (t k))
    ((F k).connection (t k)) (scale k) (hscale k)
  have hxpos : 0 < D.scalarCurvature x := hl.trans hlx
  have hupos : 0 < u := hxpos.trans hxu
  have hCpos : 0 < max C 1 := lt_max_of_lt_right zero_lt_one
  have hr : 0 < r := lt_of_lt_of_le (by positivity) hcapradius
  have hxA : x ∈ closure (g.ball x (2 * r)) := by
    apply subset_closure
    let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
      ⟨g.toRiemannianMetric⟩
    change g.edist x x < ENNReal.ofReal (2 * r)
    rw [RiemannianMetric.edist]
    rw [Manifold.riemannianEDist_self]
    exact ENNReal.ofReal_pos.mpr (by positivity : 0 < 2 * r)
  have hscalarx := hscalarconv.tendsto_at hxA
  let Q := fun k => (∃ N : SingularCComponent ((F k).metric (t k))
      ((F k).connection (t k)) C, e k x ∈ N.carrier) ∨
    ∃ N : SingularRoundComponent ((F k).metric (t k)) delta, e k x ∈ N.carrier
  have hnot : ¬ ∃ᶠ k in atTop, Q k := by
    intro hfreq
    have hle := normalized_scalar_limit_le_of_frequent_component_alternative
      (fun k => (F k).metric (t k)) (fun k => (F k).connection (t k))
      (fun k => e k) scale hscale hUc
      (Eventually.of_forall fun k => ((he k).mono (hUe k)).continuousOn)
      hp hx hround hbase hscalarx hfreq
    exact (not_le_of_gt ((le_max_right _ _).trans_lt hxlarge)) hle
  have hneckcap : ∀ᶠ k in atTop,
      l ≤ (Ds k).scalarCurvature (e k x) ∧ (Ds k).scalarCurvature (e k x) ≤ u ∧
      ((∃ N : EpsilonNeck (h k),
        N.epsilon = delta ∧ N.center = e k x ∧ N.connection = Ds k) ∨
        ∃ N : CapCertificate (h k), N.epsilon = delta ∧
          N.cap_constant ≤ max C 1 ∧ e k x ∈ N.core ∧ N.connection = Ds k) := by
    have hnQ : ∀ᶠ k in atTop, ¬ Q k := not_frequently.mp hnot
    filter_upwards [hnQ, hscalarx.eventually (eventually_gt_nhds hlx),
      hscalarx.eventually (eventually_lt_nhds hxu),
      hscalarx.eventually (eventually_gt_nhds ((le_max_left _ _).trans_lt hxlarge))]
      with k hk hkl hku hk4
    have hscaled : (Ds k).scalarCurvature (e k x) =
        (scale k)⁻¹ * ((F k).connection (t k)).scalarCurvature (e k x) :=
      rescaledMetric_scalarCurvature _ _ _ _ _
    refine ⟨hscaled ▸ hkl.le, hscaled ▸ hku.le, ?_⟩
    have habsolute : 4 * scale k ≤ (F k).scalar ⟨t k, e k x⟩ := by
      have hmul := mul_le_mul_of_nonneg_left hk4.le (hscale k).le
      rw [← mul_assoc, mul_inv_cancel₀ (hscale k).ne', one_mul] at hmul
      change 4 * scale k ≤ ((F k).connection (t k)).scalarCurvature (e k x)
      simpa only [mul_comm] using hmul
    obtain ⟨can⟩ := hcanonical k (e k x) habsolute
    rcases can.normalized_spatial_alternatives (hsmall.trans (by norm_num))
      (scale k) (hscale k) with hn | hc | hco | hro
    · exact Or.inl hn
    · obtain ⟨N, hNe, hNC, hNx, hND⟩ := hc
      exact Or.inr ⟨N, hNe, hNC.trans (le_max_left C 1), hNx, hND⟩
    · exact (hk (Or.inl hco)).elim
    · exact (hk (Or.inr hro)).elim
  obtain ⟨a, ha⟩ := eventually_atTop.mp hneckcap
  have hat (k : ℕ) := ha (k + a) (Nat.le_add_left a k)
  apply exists_terminal_neck_of_convergent_canonical_alternatives g D
    (fun k => h (k + a)) (fun k => Ds (k + a)) hcomplete (fun k => e (k + a))
    (fun k => he (k + a)) (fun k => hei (k + a)) hU (fun k => hUe (k + a))
    x hxpos hdelta hsmall haccuracy hepsilon (le_max_right C 1) hl hupos
    (fun k => ⟨(hat k).1, (hat k).2.1⟩) hneckradius hcapradius hsource
    (fun k => hbound (k + a)) (fun k => (hat k).2.2) s q K hK hcover
    (fun i hi m => (hjet i hi m).seq_tendstoUniformlyOn
      (fun k => k + a) (tendsto_add_atTop_nat a))
  simpa only [Ds, rescaledMetric_scalarCurvature] using
    hscalarconv.seq_tendstoUniformlyOn (fun k => k + a) (tendsto_add_atTop_nat a)

end PoincareMT.ControlledTerminal
