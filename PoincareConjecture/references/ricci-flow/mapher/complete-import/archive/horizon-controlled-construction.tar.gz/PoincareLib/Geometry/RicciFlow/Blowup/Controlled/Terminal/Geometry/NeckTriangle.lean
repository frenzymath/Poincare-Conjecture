import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Geometry.NeckSeparator
import PoincareLib.Geometry.Alexandrov.Riemannian.MinimizingSegments

/-!
# Pointwise large-triangle neck separation

Completeness constructs the actual minimizing geodesics. The carrier diameter
places their endpoints outside the half-neck, so the geometric inputs are
expressed solely by endpoint distances and the actual neck scale.

Reference: Morgan--Tian, Claims 11.13--11.14, pp. 276--277.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle

namespace PoincareMT.EpsilonNeck

variable {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
  [IsManifold (𝓡 3) ∞ M] [MeasurableSpace M] [BorelSpace M]
  [T2Space M] [T3Space M] [ConnectedSpace M] {g : RiemannianMetric 3 M}

theorem every_path_meets_central_sphere_of_endpoint_distances
    (N : EpsilonNeck g) (D : LeviCivitaData g)
    (hcomplete : MetricComplete g) (hsec : D.NonnegativeSectionalCurvature)
    (hsep : N.IsSeparating) (hsmall : N.epsilon ≤ 1 / (400 * Real.pi))
    {p z : M} {d : ℝ} (hd : 0 < d)
    (ha : d ≤ (g.edist N.center p).toReal)
    (hb : d ≤ (g.edist N.center z).toReal)
    (ha' : (g.edist N.center p).toReal ≤ 3 * d / 2)
    (hb' : (g.edist N.center z).toReal ≤ 3 * d / 2)
    (hfar : d ≤ (g.edist p z).toReal)
    (hsize : (2 * Real.pi + 2 * N.epsilon⁻¹) * N.scale < d) :
    ∀ P : Path p z, ∃ s, P s ∈ N.central_sphere := by
  have he := N.epsilon_pos
  have hs := N.scale_pos
  have hi := inv_pos.mpr he
  let a := (g.edist N.center p).toReal
  let b := (g.edist N.center z).toReal
  obtain ⟨γ, hγ0, hγa, hγ, hγspeed, hγmin⟩ :=
    g.exists_unit_speed_minimizing_geodesic_of_metricComplete hcomplete N.center p
      (hd.trans_le ha)
  obtain ⟨σ, hσ0, hσb, hσ, hσspeed, hσmin⟩ :=
    g.exists_unit_speed_minimizing_geodesic_of_metricComplete hcomplete N.center z
      (hd.trans_le hb)
  have hout (w : M) (hw : d ≤ (g.edist N.center w).toReal) :
      w ∉ N.coordinate_map '' (univ ×ˢ Icc (-N.epsilon⁻¹ / 2) (N.epsilon⁻¹ / 2)) := by
    intro hmem
    have hmem' : w ∈ N.carrier := ((N.mem_coordinate_slab_iff
      (by linarith : -N.epsilon⁻¹ < -N.epsilon⁻¹ / 2)
      (by linarith : N.epsilon⁻¹ / 2 < N.epsilon⁻¹)).mp hmem).1
    have hbound := ENNReal.toReal_mono ENNReal.ofReal_ne_top
      (N.edist_center_le_of_mem_carrier hmem')
    rw [ENNReal.toReal_ofReal (by positivity)] at hbound
    exact not_lt_of_ge hw (hbound.trans_lt hsize)
  have hfar' : d ≤ (g.edist (γ a) (σ b)).toReal := by
    rw [hγa, hσb]
    exact hfar
  have h := N.every_path_meets_central_sphere_of_large_triangle D hcomplete hsec hsep
    hsmall hd ha hb ha' hb' hfar' hγ hσ hγ0 hσ0 hγspeed hσspeed hγmin hσmin
    (hγa.symm ▸ hout p ha) (hσb.symm ▸ hout z hb)
  change ∀ P : Path (γ a) (σ b), ∃ s, P s ∈ N.central_sphere at h
  rw [hγa, hσb] at h
  exact h

end PoincareMT.EpsilonNeck
