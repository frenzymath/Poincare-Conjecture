import PoincareLib.Topology.Manifold.NeckCap.Cap.Core.TruncatedDomain

/-!
# Crossing the end sphere of an actual cap

A curve from the cap core to the complement of its carrier crosses the
central sphere of the supplied end neck. The compact truncated core and
its boundary are produced from the cap certificate.
Reference: Morgan--Tian, Claim 11.14, pp. 276--277.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongGeometry

theorem exists_curve_time_on_frontier
    {M : Type*} [TopologicalSpace M] {K : Set M} (hK : IsClosed K)
    {gamma : ℝ → M} {L : ℝ} (hL : 0 ≤ L)
    (hgamma : ContinuousOn gamma (Icc 0 L))
    (hstart : gamma 0 ∈ interior K) (hout : gamma L ∉ K) :
    ∃ s ∈ Ioc 0 L, gamma s ∈ frontier K := by
  let S := Icc 0 L ∩ gamma ⁻¹' (interior K)ᶜ
  have hSclosed : IsClosed S := hgamma.preimage_isClosed_of_isClosed isClosed_Icc
    isOpen_interior.isClosed_compl
  have hSne : S.Nonempty := ⟨L, ⟨⟨hL, le_rfl⟩, fun h => hout (interior_subset h)⟩⟩
  have hSbdd : BddBelow S := ⟨0, fun _ hs => hs.1.1⟩
  let s := sInf S
  have hsS : s ∈ S := hSclosed.csInf_mem hSne hSbdd
  have hs : s ∈ Ioc 0 L := ⟨lt_of_le_of_ne hsS.1.1 (by
    intro heq
    exact hsS.2 (heq ▸ hstart)), hsS.1.2⟩
  have hbefore : MapsTo gamma (Ico 0 s) (interior K) := by
    intro t ht
    by_contra hnot
    have htS : t ∈ S := ⟨⟨ht.1, ht.2.le.trans hs.2⟩, hnot⟩
    exact (not_le_of_gt ht.2) (csInf_le hSbdd htS)
  have hpre : IsClosed (Icc 0 L ∩ gamma ⁻¹' K) :=
    hgamma.preimage_isClosed_of_isClosed isClosed_Icc hK
  have hsub : Ico 0 s ⊆ Icc 0 L ∩ gamma ⁻¹' K :=
    fun t ht => ⟨⟨ht.1, ht.2.le.trans hs.2⟩,
      show gamma t ∈ K from interior_subset (hbefore ht)⟩
  have hsK : gamma s ∈ K := by
    have hh : s ∈ Icc 0 L ∩ gamma ⁻¹' K := by
      apply hpre.closure_subset_iff.mpr hsub
      rw [closure_Ico (ne_of_lt hs.1)]
      exact ⟨hs.1.le, le_rfl⟩
    exact hh.2
  refine ⟨s, hs, ?_⟩
  rw [frontier, hK.closure_eq]
  exact ⟨hsK, hsS.2⟩

end PoincareMT.ControlledLongGeometry

namespace PoincareMT.CapCertificate

theorem exists_end_sphere_crossing_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 1000 ∧
      ∀ {M : Type u} [TopologicalSpace M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
        [MeasurableSpace M] [BorelSpace M] [T2Space M] [T3Space M]
        {g : RiemannianMetric 3 M},
        ∀ C : CapCertificate g, C.epsilon ≤ epsilon₀ →
        ∀ {gamma : ℝ → M} {L : ℝ}, 0 ≤ L →
        ContinuousOn gamma (Icc 0 L) → gamma 0 ∈ C.core → gamma L ∉ C.carrier →
        ∃ s ∈ Ioc 0 L, gamma s ∈ C.end_neck.central_sphere := by
  obtain ⟨epsilon₀, hepsilon₀, hsmall, hcore⟩ := exists_truncated_core_domain_threshold.{u}
  refine ⟨epsilon₀, hepsilon₀, hsmall, ?_⟩
  intro M _ _ _ _ _ _ _ g C hepsilon gamma L hL hgamma hstart hout
  have hzero : (0 : ℝ) ∈ Ioo (-C.epsilon⁻¹) C.epsilon⁻¹ :=
    ⟨neg_neg_of_pos (inv_pos.mpr C.epsilon_pos), inv_pos.mpr C.epsilon_pos⟩
  obtain ⟨hK, hKsub, _, hfrontier, _, hcoreK⟩ := hcore C hepsilon 0 hzero
  obtain ⟨s, hs, hboundary⟩ := ControlledLongGeometry.exists_curve_time_on_frontier
    hK.isClosed hL hgamma (hcoreK (C.core_subset_closed_core hstart))
      (fun h => hout (hKsub h))
  rw [hfrontier] at hboundary
  obtain ⟨q, hq⟩ := hboundary
  refine ⟨s, hs, ?_⟩
  rw [C.end_neck.central_sphere_eq]
  exact ⟨(q, 0), ⟨mem_univ q, rfl⟩, hq⟩

end PoincareMT.CapCertificate
