import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.CylinderJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.LiftedCoefficients

/-! # Generalized convergence of actual finite controlled terminal limits -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)
  (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
  (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : ∀ t ∈ Ioo (-T / 2) (T / 2),
    G.limitCarrier.metricComplete (G.limitFlow.metricAt t))
  (hbound : ∀ t ∈ Ioo (-T / 2) (T / 2), ∀ x,
    (G.limitFlow.flow.connection t).curvatureTensorNorm x ≤ B)
  (heta : Tendsto eta atTop (𝓝 0))

local notation "theLimit" => liftedLimit (terminalLimit G F hF P04 hB hAr hcompact hcomplete hbound heta)

/-- The exact frozen compact-test and common-threshold metric clause holds
for the retained generalized cylinders, through the included terminal time. -/
theorem terminal_pullback_metric_CInfinity
    (q : (liftedSliceCarrier.{u} G.limitCarrier).carrier) (j r : ℕ)
    (K : Set (ℝ × EuclideanSpace ℝ (Fin 3))) (hK : IsCompact K)
    (hKU : K ⊆ {p | p ∈ blowupMetricChartDomain theLimit q ∧
      (extChartAt (𝓡 3) q).symm p.2 ∈ retainedSpace G j})
    (ε : ℝ) (hε : 0 < ε) :
    ∃ N : ℕ, j ≤ N ∧ ∀ k ≥ N,
      K ⊆ Icc (-finiteTimeRadius T k) 0 ×ˢ (extChartAt (𝓡 3) q).target ∧
      ∀ a b : Fin 3, ∀ p ∈ K,
        ‖iteratedFDerivWithin ℝ r
            (blowupPullbackCoefficient (L := theLimit) (finiteRetainedCylinder G k) q a b)
            (Icc (-finiteTimeRadius T k) 0 ×ˢ (extChartAt (𝓡 3) q).target) p -
          iteratedFDerivWithin ℝ r
            (FlowCarrier.coordinateCoefficient (theLimit).carrier q
              (fun t x v w => ((theLimit).flow.metric t).inner x v w) a b)
            (blowupMetricChartDomain theLimit q) p‖ < ε := by
  have hchart : (extChartAt (𝓡 3) q).target = (extChartAt (𝓡 3) q.down).target := by
    simp only [extChartAt_target]
    congr 1
    change (Homeomorph.ulift.toOpenPartialHomeomorph.trans
      (chartAt (EuclideanSpace ℝ (Fin 3)) q.down)).target = _
    simp
  have hKU0 : K ⊆ Ioc (-T) 0 ×ˢ (extChartAt (𝓡 3) q.down).target :=
    fun p hp => ⟨(hKU hp).1.1, hchart ▸ (hKU hp).1.2⟩
  have hc (a b : Fin 3) := Metric.tendstoUniformlyOn_iff.mp
    (tendstoUniformlyOn_originalClock_scalarJet G F hF P04 hB hAr hcompact
      (hcomplete 0 ⟨by linarith, by linarith⟩) q.down r a b hK hKU0) ε hε
  have hall := Filter.eventually_all.mpr fun a => Filter.eventually_all.mpr (hc a)
  have hs := eventually_finiteRetainedCylinder_jet_eq G F hF P04 hB hAr hcompact
    hcomplete hbound heta q j r hK hKU
  obtain ⟨N, hN⟩ := eventually_atTop.mp (hs.and hall)
  refine ⟨max j N, le_max_left _ _, fun k hk => ?_⟩
  have hh := hN k ((le_max_right j N).trans hk)
  refine ⟨hh.1.1, fun a b p hp => ?_⟩
  rw [hh.1.2 a b p hp, liftedLimit_coordinateJet
    (terminalLimit G F hF P04 hB hAr hcompact hcomplete hbound heta) q a b
    (blowupMetricChartDomain theLimit q) r p (hKU hp).1.2]
  change ‖iteratedFDerivWithin ℝ r _ (Ioc (-T) 0 ×ˢ (extChartAt (𝓡 3) q).target) p -
    iteratedFDerivWithin ℝ r
      (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric (z.1 + T / 2)).pullbackCoefficients (extChartAt (𝓡 3) q.down).symm z.2
          (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))
      (Ioc (-T) 0 ×ˢ (extChartAt (𝓡 3) q).target) p‖ < ε
  rw [hchart]
  simpa only [dist_eq_norm, norm_sub_rev] using hh.2 a b p hp

/-- Actual finite generalized convergence, using precisely the original
M07 subsequence, retained spatial maps, and source cylinders. -/
def terminalConvergence (hidx : StrictMono idx) :
    GeneralizedBlowupConvergence S (Ioc (-T) 0) where
  limit := theLimit
  subsequence := idx ∘ G.subsequence
  subsequence_strictMono := hidx.comp G.subsequence_strictMono
  exhaustion := terminalExhaustion G F hF P04 hB hAr hcompact hcomplete hbound heta
  embedding := finiteRetainedCylinder G
  base_preserving := finiteRetainedCylinder_base G
  source_balls_in_image := fun _ hr => finiteRetainedCylinder_eventually_covers_baseBall G hAr
    (hcomplete 0 ⟨by linarith, by linarith⟩) hr
  pullback_metric_CInfinity := terminal_pullback_metric_CInfinity G F hF P04 hB hAr hcompact
    hcomplete hbound heta

end PoincareMT.ControlledBlowupCompactness
