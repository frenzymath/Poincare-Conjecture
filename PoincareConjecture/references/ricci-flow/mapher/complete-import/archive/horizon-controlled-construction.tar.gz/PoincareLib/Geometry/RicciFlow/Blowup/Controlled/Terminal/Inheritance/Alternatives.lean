import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Neck.Spatial
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Ancient.Compact.Normalization.CapRescale

/-!
# Normalized source alternatives at a canonical slice

Necks and caps retain their accuracy and scalar ratios under the actual
blow-up metric scaling. The two component alternatives retain their original
certificates, whose scalar ratios are invariant under the same scaling.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff

universe u

namespace PoincareMT.GeneralizedCanonicalControl

theorem normalized_spatial_alternatives
    {F : GeneralizedRicciFlowData.{u}} {t epsilon C : ℝ}
    {x : (F.slice t).carrier} (H : GeneralizedCanonicalControl (F := F) t x epsilon C)
    (hepsilon : epsilon < 1 / 2) (q : ℝ) (hq : 0 < q) :
    (∃ N : EpsilonNeck (rescaledMetric (F.metric t) q hq),
      N.epsilon = epsilon ∧ N.center = x ∧
      N.connection = rescaledMetric_connection (F.metric t) (F.connection t) q hq) ∨
    (∃ N : CapCertificate (rescaledMetric (F.metric t) q hq),
      N.epsilon = epsilon ∧ N.cap_constant ≤ C ∧ x ∈ N.core ∧
      N.connection = rescaledMetric_connection (F.metric t) (F.connection t) q hq) ∨
    (∃ N : SingularCComponent (F.metric t) (F.connection t) C, x ∈ N.carrier) ∨
    ∃ N : SingularRoundComponent (F.metric t) epsilon, x ∈ N.carrier := by
  cases H with
  | neck N hcenter =>
    exact Or.inl ⟨(N.spatialNeck hepsilon).rescale q hq, rfl, hcenter, rfl⟩
  | cap N heq hC hconnection hcore =>
    refine Or.inr (Or.inl ⟨N.rescale q hq, heq, hC, hcore, ?_⟩)
    change rescaledMetric_connection (F.metric t) N.connection q hq = _
    rw [hconnection]
  | component N hx => exact Or.inr (Or.inr (Or.inl ⟨N, hx⟩))
  | round N hx => exact Or.inr (Or.inr (Or.inr ⟨N, hx⟩))

end PoincareMT.GeneralizedCanonicalControl
