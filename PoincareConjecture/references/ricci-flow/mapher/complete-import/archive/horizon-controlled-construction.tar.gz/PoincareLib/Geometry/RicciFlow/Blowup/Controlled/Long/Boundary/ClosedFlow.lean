import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Charts
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Gluing
import PoincareLib.Geometry.RicciFlow.Harnack.Regularity

/-! # Gluing the backward endpoint into the existing Ricci flow -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledBlowupBoundary

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space

/-- Actual local extensions give a complete global closed flow on the same
carrier. The metric and all local extensions are retained at every old time. -/
theorem exists_complete_closed_flow_of_chart_extensions
    {n : ℕ} (C : FlowCarrier n) (p : C.carrier) {T : ℝ} (hT : 0 < T)
    (F : RicciFlow n C.carrier (Ioc (-T) 0))
    (hcomplete : C.metricComplete (F.metric 0))
    (hext : ∀ q : C.carrier, ∃ rho V : ℝ, 0 < rho ∧ T < V ∧
      ball (extChartAt (𝓡 n) q q) rho ⊆ (extChartAt (𝓡 n) q).target ∧
      let U : Opens (EuclideanSpace ℝ (Fin n)) := ⟨ball (extChartAt (𝓡 n) q q) rho, isOpen_ball⟩
      ∃ L : RicciFlow n U (Icc (-V) 0),
        (∀ t ∈ Icc (-V) 0, ∀ x : U, (L.connection t).NonnegativeCurvatureOperator x) ∧
        ∀ t ∈ Ioc (-T) 0, ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
          (L.metric t).inner x v w = (F.metric t).pullbackCoefficients
            (extChartAt (𝓡 n) q).symm x v w) :
    ∃ G : RicciFlow n C.carrier (Icc (-T) 0),
      (∀ t ∈ Ioc (-T) 0, G.metric t = F.metric t) ∧
      (∀ t ∈ Icc (-T) 0, C.metricComplete (G.metric t)) ∧
      (∀ t ∈ Icc (-T) 0, ∀ x, (G.connection t).NonnegativeCurvatureOperator x) ∧
      ∀ q : C.carrier, ∃ rho V : ℝ, 0 < rho ∧ T < V ∧
        ball (extChartAt (𝓡 n) q q) rho ⊆ (extChartAt (𝓡 n) q).target ∧
        let U : Opens (EuclideanSpace ℝ (Fin n)) := ⟨ball (extChartAt (𝓡 n) q q) rho, isOpen_ball⟩
        ∃ L : RicciFlow n U (Icc (-V) 0),
          (∀ t ∈ Icc (-V) 0, ∀ x : U, (L.connection t).NonnegativeCurvatureOperator x) ∧
          ∀ t ∈ Icc (-T) 0, ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
            (L.metric t).inner x v w = (G.metric t).pullbackCoefficients
              (extChartAt (𝓡 n) q).symm x v w := by
  classical
  letI : Nonempty C.carrier := ⟨p⟩
  choose rho V hrho hV hchart L hnonnegative hpres using hext
  let U (q : C.carrier) : Opens (EuclideanSpace ℝ (Fin n)) :=
    ⟨ball (extChartAt (𝓡 n) q q) (rho q), isOpen_ball⟩
  let maps := fun q => chartMap C q (U q)
  have hmaps : ∀ q, IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (maps q) :=
    fun q => chartMap_isLocalDiffeomorph C q (U q) (hchart q)
  have hcover : ∀ y, ∃ q x, maps q x = y := by
    intro y
    refine ⟨y, ⟨extChartAt (𝓡 n) y y, mem_ball_self (hrho y)⟩, ?_⟩
    exact (extChartAt (𝓡 n) y).left_inv (mem_extChartAt_source y)
  have hsub (q : C.carrier) : Icc (-T) 0 ⊆ Icc (-V q) 0 :=
    Icc_subset_Icc (neg_le_neg (hV q).le) le_rfl
  have hnontrivial : (Icc (-T) (0 : ℝ)).Nontrivial :=
    ⟨-T, ⟨le_rfl, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩
  let Lclosed q := Poincare.Geometry.RicciFlow.Harnack.restrictFlow (L q)
    (hsub q) ordConnected_Icc hnontrivial
  have hpres' : ∀ t ∈ Ioc (-T) 0, ∀ q (x : U q) (a b : TangentSpace (𝓡 n) x),
      ((Lclosed q).metric t).inner x a b = (F.metric t).inner (maps q x)
        (mfderiv (𝓡 n) (𝓡 n) (maps q) x a) (mfderiv (𝓡 n) (𝓡 n) (maps q) x b) := by
    intro t ht q x a b
    rw [show mfderiv (𝓡 n) (𝓡 n) (maps q) x = _ from chartMap_mfderiv C q (U q) (hchart q) x]
    exact hpres q t ht x a b
  obtain ⟨G, hG, hlocal⟩ := RicciFlow.exists_extension_of_covering_chart_flows
    Ioc_subset_Icc_self (by rw [closure_Ioc (by linarith : -T ≠ 0)])
    F Lclosed maps hmaps hcover hpres'
  have hnonnegativeG : ∀ t ∈ Icc (-T) 0, ∀ y,
      (G.connection t).NonnegativeCurvatureOperator y := by
    intro t ht y
    obtain ⟨q, x, rfl⟩ := hcover y
    apply (((Lclosed q).connection t).nonnegativeCurvatureOperator_iff_of_local_isometry
      (G.connection t) isOpen_univ (hmaps q).contMDiff.contMDiffOn
      (fun x _ a b => hlocal t ht q x a b) (mem_univ x)).mp
    exact hnonnegative q t (hsub q ht) x
  have hzero : (0 : ℝ) ∈ Ioc (-T) 0 := ⟨by linarith, le_rfl⟩
  have hcompleteG : ∀ t ∈ Icc (-T) 0, C.metricComplete (G.metric t) := by
    intro t ht
    apply C.metricComplete_of_inner_le p (G.metric 0) (G.metric t)
      (by rw [hG 0 hzero]; exact hcomplete)
    intro y v
    exact G.inner_antitone_of_nonnegative_ricci (convex_Icc _ _)
      (fun s hs x v => (G.connection s).ricci_nonneg_of_nonnegative_curvatureOperator
        x (hnonnegativeG s hs x) v)
      ht (Ioc_subset_Icc_self hzero) ht.2 y v
  refine ⟨G, hG, hcompleteG, hnonnegativeG, ?_⟩
  intro q
  refine ⟨rho q, V q, hrho q, hV q, hchart q, L q, hnonnegative q, ?_⟩
  intro t ht x a b
  have h := hlocal t ht q x a b
  rw [show mfderiv (𝓡 n) (𝓡 n) (maps q) x = _ from chartMap_mfderiv C q (U q) (hchart q) x] at h
  exact h

end PoincareMT.ControlledBlowupBoundary
