import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.PathAvoidance
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Distance.Monotonicity
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Separation.Diameter
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Overlap.ScaleComparison

/-! # A fixed separating neck center has uniformly bounded past scalar curvature -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongGeometry

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem exists_uniform_scalar_bound_for_separating_necks
    (P04 : RicciFlowCurvatureTheory.{u}) {T : ℝ} (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    {p y z : L.carrier.carrier} (hpy : p ≠ y) (hzy : z ≠ y) :
    ∃ B : ℝ, 0 < B ∧ ∀ t ∈ Ioc (-T) 0,
      ∀ N : EpsilonNeck (L.flow.metric t), N.center = y →
      (∀ gamma : Path p z, ∃ s, gamma s ∈ N.central_sphere) →
      (L.flow.connection t).scalarCurvature y ≤ B := by
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  obtain ⟨r, hr, gamma, hgamma⟩ := exists_path_with_positive_distance
    (n := 1) (L.flow.metric 0) hpy hzy
  refine ⟨(2 * Real.pi / r) ^ 2, sq_pos_of_pos (div_pos (by positivity) hr), ?_⟩
  intro t ht N hcenter hseparator
  obtain ⟨s, hs⟩ := hseparator gamma
  have hdiam : ((L.flow.metric t).edist y (gamma s)).toReal ≤ (2 * Real.pi) * N.scale := by
    have hh := N.edist_central_sphere_le_two_pi_mul_scale N.center_on_central_sphere hs
    rw [hcenter] at hh
    have hhreal := ENNReal.toReal_mono ENNReal.ofReal_ne_top hh
    rw [ENNReal.toReal_ofReal
      (mul_nonneg (mul_nonneg (by norm_num) Real.pi_pos.le) N.scale_pos.le)] at hhreal
    exact hhreal
  have hrscale : r ≤ (2 * Real.pi) * N.scale :=
    (hgamma s).trans ((ControlledLongDistance.terminal_toReal_edist_le P04 L ht y (gamma s)).trans hdiam)
  have hnorm := N.scale_sq_mul_scalar_center_of_connection (L.flow.connection t)
  rw [hcenter] at hnorm
  have hscalar : 0 < (L.flow.connection t).scalarCurvature y := by
    have hspos := sq_pos_of_pos N.scale_pos
    nlinarith
  have hsq : r ^ 2 ≤ (2 * Real.pi) ^ 2 * N.scale ^ 2 := by
    nlinarith [Real.pi_pos, N.scale_pos]
  rw [div_pow]
  apply (le_div_iff₀ (sq_pos_of_pos hr)).mpr
  calc
    (L.flow.connection t).scalarCurvature y * r ^ 2 =
        r ^ 2 * (L.flow.connection t).scalarCurvature y := mul_comm _ _
    _ ≤ ((2 * Real.pi) ^ 2 * N.scale ^ 2) * (L.flow.connection t).scalarCurvature y :=
      mul_le_mul_of_nonneg_right hsq hscalar.le
    _ = (2 * Real.pi) ^ 2 := by rw [mul_assoc, hnorm, mul_one]

theorem exists_uniform_scalar_bound_of_high_curvature_separating_necks
    (P04 : RicciFlowCurvatureTheory.{u}) {T : ℝ} (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    {p y z : L.carrier.carrier} (hpy : p ≠ y) (hzy : z ≠ y)
    {cutoff : ℝ}
    (hneck : ∀ t ∈ Ioc (-T) 0, cutoff < (L.flow.connection t).scalarCurvature y →
      ∃ N : EpsilonNeck (L.flow.metric t), N.center = y ∧
        ∀ gamma : Path p z, ∃ s, gamma s ∈ N.central_sphere) :
    ∃ B : ℝ, 0 < B ∧ ∀ t ∈ Ioc (-T) 0, (L.flow.connection t).scalarCurvature y ≤ B := by
  obtain ⟨B, hB, hbound⟩ := exists_uniform_scalar_bound_for_separating_necks P04 L hpy hzy
  refine ⟨max cutoff B, hB.trans_le (le_max_right _ _), ?_⟩
  intro t ht
  by_cases hsmall : (L.flow.connection t).scalarCurvature y ≤ cutoff
  · exact hsmall.trans (le_max_left _ _)
  obtain ⟨N, hcenter, hseparator⟩ := hneck t ht (lt_of_not_ge hsmall)
  exact (hbound t ht N hcenter hseparator).trans (le_max_right _ _)

end PoincareMT.ControlledLongGeometry
