import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Restriction.Window
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.NeckTransfer.Coefficients

/-! # Metric jets under restriction of the backward time interval -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupRestriction

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem iteratedFDerivWithin_timeRestriction
    {I J : Set ℝ} (hIJ : I ⊆ J) (hI : UniqueDiffOn ℝ I) (hJ : UniqueDiffOn ℝ J)
    {U V : Set (EuclideanSpace ℝ (Fin 3))} (hV : IsOpen V) (hVU : V ⊆ U)
    (f : ℝ × EuclideanSpace ℝ (Fin 3) → ℝ) (r : ℕ)
    (hf : ContDiffOn ℝ ∞ f (J ×ˢ V))
    (p : ℝ × EuclideanSpace ℝ (Fin 3)) (hp : p ∈ I ×ˢ V) :
    iteratedFDerivWithin ℝ r f (I ×ˢ U) p =
      iteratedFDerivWithin ℝ r f (J ×ˢ U) p := by
  have hlocal (W : Set ℝ) :
      iteratedFDerivWithin ℝ r f (W ×ˢ V) p = iteratedFDerivWithin ℝ r f (W ×ˢ U) p := by
    simpa only [prod_inter_prod, inter_univ, inter_eq_right.mpr hVU] using
      (iteratedFDerivWithin_inter_open (f := f) (s := W ×ˢ U) (n := r)
        (isOpen_univ.prod hV) (show p ∈ (univ : Set ℝ) ×ˢ V from ⟨mem_univ _, hp.2⟩))
  rw [← hlocal I, ← hlocal J]
  exact iteratedFDerivWithin_subset (prod_mono hIJ Subset.rfl)
    (hI.prod hV.uniqueDiffOn) (hJ.prod hV.uniqueDiffOn) (hf.of_le (by exact_mod_cast le_top)) hp

theorem cylinder_timeRestriction_jet
    {F : GeneralizedRicciFlowData.{u}} {K : Set ℝ} {L : BlowupLimitFlow.{u} K}
    {origin scale A B : ℝ} {U : TopologicalSpace.Opens L.sliceCarrier.carrier}
    (e : GeneralizedFlowCylinder F L.sliceCarrier origin scale (Icc (-B) 0) U)
    (hA : 0 < A) (hB : 0 < B) (hAB : A ≤ B)
    (q : L.sliceCarrier.carrier) (a b : Fin 3) (r : ℕ)
    (p : ℝ × EuclideanSpace ℝ (Fin 3))
    (hp : p ∈ Icc (-A) 0 ×ˢ (extChartAt (𝓡 3) q).target)
    (hx : (extChartAt (𝓡 3) q).symm p.2 ∈ U) :
    iteratedFDerivWithin ℝ r
      (blowupPullbackCoefficient
        (e.restrict (Icc_subset_Icc_left (neg_le_neg hAB)) Subset.rfl) q a b)
      (Icc (-A) 0 ×ˢ (extChartAt (𝓡 3) q).target) p =
    iteratedFDerivWithin ℝ r (blowupPullbackCoefficient e q a b)
      (Icc (-B) 0 ×ˢ (extChartAt (𝓡 3) q).target) p := by
  have hIJ : Icc (-A) (0 : ℝ) ⊆ Icc (-B) 0 := Icc_subset_Icc_left (neg_le_neg hAB)
  have heq : EqOn
      (blowupPullbackCoefficient (e.restrict hIJ Subset.rfl) q a b)
      (blowupPullbackCoefficient e q a b) (Icc (-A) 0 ×ˢ (extChartAt (𝓡 3) q).target) := by
    intro z hz
    simp only [blowupPullbackCoefficient, dif_pos hz.1, dif_pos (hIJ hz.1),
      GeneralizedFlowCylinder.restrict_pullbackInner]
  rw [iteratedFDerivWithin_congr heq hp r]
  let V := (extChartAt (𝓡 3) q).target ∩ (extChartAt (𝓡 3) q).symm ⁻¹' U
  have hV : IsOpen V :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
      (isOpen_extChartAt_target (I := 𝓡 3) q) U.isOpen
  let J : SpacetimeInterval := ⟨Icc (-B) 0, ordConnected_Icc,
    ⟨-B, ⟨le_rfl, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩⟩
  have hf := e.contDiffOn_pullbackCoefficient (J := J) q a b
  exact iteratedFDerivWithin_timeRestriction hIJ
    (uniqueDiffOn_Icc (by linarith)) (uniqueDiffOn_Icc (by linarith)) hV inter_subset_left
    (blowupPullbackCoefficient e q a b) r hf p ⟨hp.1, hp.2, hx⟩

theorem closedWindow_limit_jet {T T' : ℝ} (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    (hT' : 0 < T') (h : T' < T) (q : L.carrier.carrier)
    (a b : Fin 3) (r : ℕ) (p : ℝ × EuclideanSpace ℝ (Fin 3))
    (hp : p ∈ Icc (-T') 0 ×ˢ (extChartAt (𝓡 3) q).target) :
    iteratedFDerivWithin ℝ r
      ((closedWindowLimit L hT' h).carrier.coordinateCoefficient q
        (fun t x v w => ((closedWindowLimit L hT' h).flow.metric t).inner x v w) a b)
      (blowupMetricChartDomain (closedWindowLimit L hT' h) q) p =
    iteratedFDerivWithin ℝ r
      (L.carrier.coordinateCoefficient q (fun t x v w => (L.flow.metric t).inner x v w) a b)
      (blowupMetricChartDomain L q) p := by
  have hf := L.flow.contDiffOn_pullbackCoefficients_within (isOpen_extChartAt_target q)
    (contMDiffOn_extChartAt_symm (n := ∞) q)
  have hs := (hf.clm_apply (contDiffOn_const (c := EuclideanSpace.basisFun (Fin 3) ℝ a))).clm_apply
    (contDiffOn_const (c := EuclideanSpace.basisFun (Fin 3) ℝ b))
  exact iteratedFDerivWithin_subset (prod_mono (closedWindow_subset h) Subset.rfl)
    ((uniqueDiffOn_Icc (by linarith)).prod (isOpen_extChartAt_target q).uniqueDiffOn)
    ((uniqueDiffOn_Ioc (-T) 0).prod (isOpen_extChartAt_target q).uniqueDiffOn)
    (hs.of_le (by exact_mod_cast le_top)) hp

end PoincareMT.ControlledBlowupRestriction
