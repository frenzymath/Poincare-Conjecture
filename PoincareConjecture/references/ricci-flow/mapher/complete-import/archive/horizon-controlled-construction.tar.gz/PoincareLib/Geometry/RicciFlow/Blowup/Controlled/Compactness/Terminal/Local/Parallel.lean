import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.NullPlane
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.LocalNullLine

/-!
# Local parallel null sections from varying backward lifetimes

A smooth unit section of the static Ricci kernel pulls back to each actual
local backward flow. The terminal connection equation makes it parallel;
the local isometry transports that conclusion to the prescribed metric.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.ControlledTerminal

open RicciFlow.Splitting

attribute [local instance] RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

variable {M : Type v} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
  {g : RiemannianMetric 3 M}

theorem connection_eq_zero_of_local_terminal_flow
    {E : Type u} [TopologicalSpace E]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) E] [IsManifold (𝓡 3) ∞ E]
    (hC : RicciFlowCurvatureTheory.{u}) {a b : ℝ} (hab : a < b)
    (F : RicciFlow 3 E (Icc a b))
    (hoperator : ∀ t ∈ Icc a b, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    (D : LeviCivitaData g) {f : E → M}
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hmetric : ∀ x v w, (F.metric b).inner x v w = g.inner (f x)
      (mfderiv (𝓡 3) (𝓡 3) f x v) (mfderiv (𝓡 3) (𝓡 3) f x w))
    (x : E) (V : (y : M) → TangentSpace (𝓡 3) y)
    (hV : ContMDiffAt (𝓡 3) ((𝓡 3).prod (𝓡 3)) ∞ (T% V) (f x))
    (hnull : ∀ᶠ y in 𝓝 (f x), ∀ w, D.ricci y (V y) w = 0)
    (hunit : ∀ᶠ y in 𝓝 (f x), g.inner y (V y) (V y) = 1)
    (hdim : ricciNullity D (f x) = 1) (u : TangentSpace (𝓡 3) (f x)) :
    D.connection V (f x) u = 0 := by
  have hinv (y : E) : (mfderiv (𝓡 3) (𝓡 3) f y).IsInvertible :=
    ⟨hf.mfderivToContinuousLinearEquiv (by simp) y, rfl⟩
  let W := VectorField.mpullback (𝓡 3) (𝓡 3) f V
  have hmap (y : E) : mfderiv (𝓡 3) (𝓡 3) f y (W y) = V (f y) :=
    (hinv y).self_apply_inverse _
  have hW : ContMDiffAt (𝓡 3) ((𝓡 3).prod (𝓡 3)) ∞ (T% W) x :=
    hV.mpullback_vectorField_preimage (f := f) (hf.contMDiff x) (hinv x) (by simp)
  have hn : ∀ᶠ y in 𝓝 x, ∀ w, (F.connection b).ricci y (W y) w = 0 := by
    filter_upwards [(hf.contMDiff x).continuousAt.tendsto.eventually hnull] with y hy w
    rw [(F.connection b).ricci_eq_of_local_isometry D isOpen_univ
      hf.contMDiff.contMDiffOn (fun z _ => hmetric z) (mem_univ y), hmap]
    exact hy _
  have hu : ∀ᶠ y in 𝓝 x, (F.metric b).inner y (W y) (W y) = 1 := by
    filter_upwards [(hf.contMDiff x).continuousAt.tendsto.eventually hunit] with y hy
    rw [hmetric, hmap]
    exact hy
  have hd : ricciNullity (F.connection b) x = 1 :=
    (ricciNullity_eq_of_local_metric_pullback (F.connection b) D hf hmetric x).trans hdim
  let z := (mfderiv (𝓡 3) (𝓡 3) f x).inverse u
  have hz : mfderiv (𝓡 3) (𝓡 3) f x z = u := (hinv x).self_apply_inverse u
  have hzero := connection_eq_zero_of_terminal_unit_null hC hab F
    (fun t ht y v w => (F.connection t).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
      y (hoperator t ht y) v w) W hW hn hu hd z
  have hconn := (F.connection b).connection_mpullback_of_metric_pullback D (hf.contMDiff x)
    (Eventually.of_forall hinv) (Eventually.of_forall hmetric) (hV.mdifferentiableAt (by simp)) z
  change (F.connection b).connection W x z = _ at hconn
  rw [hconn, hz] at hzero
  have hh := congrArg (mfderiv (𝓡 3) (𝓡 3) f x) hzero
  simpa only [(hinv x).self_apply_inverse, map_zero] using hh

theorem connection_eq_zero_of_small_terminal_flow
    {E : Type} [TopologicalSpace E]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) E] [IsManifold (𝓡 3) ∞ E]
    (hC : RicciFlowCurvatureTheory.{u}) {a b : ℝ} (hab : a < b)
    (F : RicciFlow 3 E (Icc a b))
    (hoperator : ∀ t ∈ Icc a b, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    (D : LeviCivitaData g) {f : E → M}
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hmetric : ∀ x v w, (F.metric b).inner x v w = g.inner (f x)
      (mfderiv (𝓡 3) (𝓡 3) f x v) (mfderiv (𝓡 3) (𝓡 3) f x w))
    (x : E) (V : (y : M) → TangentSpace (𝓡 3) y)
    (hV : ContMDiffAt (𝓡 3) ((𝓡 3).prod (𝓡 3)) ∞ (T% V) (f x))
    (hnull : ∀ᶠ y in 𝓝 (f x), ∀ w, D.ricci y (V y) w = 0)
    (hunit : ∀ᶠ y in 𝓝 (f x), g.inner y (V y) (V y) = 1)
    (hdim : ricciNullity D (f x) = 1) (u : TangentSpace (𝓡 3) (f x)) :
    D.connection V (f x) u = 0 := by
  let e := Poincare.Manifold.uliftDiffeomorph (𝓡 3) E
  have hf' : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ (fun z : ULift.{u} E => f z.down) :=
    fun z => (e.isLocalDiffeomorph z).comp (𝓡 3) M (hf z.down)
  exact connection_eq_zero_of_local_terminal_flow hC hab F.ulift
    (fun t ht z => (F.ulift_nonnegativeCurvatureOperator_iff t z).mpr (hoperator t ht z.down))
    D hf' (uliftFlow_metric_pullback F b hf hmetric) (ULift.up x) V hV hnull hunit hdim u

variable (hflow : ∀ q : M, ∃ rho T : ℝ, 0 < rho ∧ 0 < T ∧
  ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target ∧
  ∃ F : RicciFlow 3 (⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩ : Opens _) (Icc (-T) 0),
    (∀ t ∈ Icc (-T) 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x) ∧
    ∀ x v w, (F.metric 0).inner x v w =
      g.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w)

include hflow in
theorem exists_local_parallel_unit_null_section_of_local_backward_flows
    (hC : RicciFlowCurvatureTheory.{u}) (D : LeviCivitaData g)
    (hD : D.CurvatureTensorCalculus) (hdim : ∀ y, ricciNullity D y = 1)
    (p : UnitRicciKernel D) :
    ∃ (U : Set M) (V : (y : M) → TangentSpace (𝓡 3) y),
      IsOpen U ∧ p.1.proj ∈ U ∧
      ContMDiffOn (𝓡 3) ((𝓡 3).prod (𝓡 3)) ∞ (T% V) U ∧ V p.1.proj = p.1.snd ∧
      ∀ y ∈ U, g.inner y (V y) (V y) = 1 ∧
        (∀ w, D.ricci y (V y) w = 0) ∧ ∀ w, D.connection V y w = 0 := by
  obtain ⟨U, V, hU, hp, hV, hVp, hun⟩ := exists_local_smooth_unit_ricci_null_section D hD
    (Eventually.of_forall fun y => (hdim y).trans (hdim p.1.proj).symm)
    p.1.snd p.2.2 p.2.1
  refine ⟨U, V, hU, hp, hV, hVp, fun y hy => ⟨(hun y hy).1, (hun y hy).2, ?_⟩⟩
  obtain ⟨rho, T, hrho, hT, hchart, F, hoperator, hmetric⟩ := hflow y
  let O : Opens (EuclideanSpace ℝ (Fin 3)) :=
    ⟨ball (extChartAt (𝓡 3) y y) rho, isOpen_ball⟩
  let x : O := ⟨extChartAt (𝓡 3) y y, mem_ball_self hrho⟩
  let f : O → M := fun z => (extChartAt (𝓡 3) y).symm z
  have hfx : f x = y := extChartAt_to_inv y
  have hzero : ∀ w, D.connection V (f x) w = 0 := by
    intro w
    apply connection_eq_zero_of_small_terminal_flow hC (by linarith : -T < (0 : ℝ))
      F hoperator D (partialChartMap_isLocalDiffeomorph (inverseMetricChart y) O hchart)
      (terminalChartFlow_metric_pullback y O hchart F 0 hmetric) x V
    · change ContMDiffAt (𝓡 3) ((𝓡 3).prod (𝓡 3)) ∞ (T% V) (f x)
      rw [hfx]
      exact hV.contMDiffAt (hU.mem_nhds hy)
    · change ∀ᶠ z in 𝓝 (f x), ∀ w, D.ricci z (V z) w = 0
      rw [hfx]
      filter_upwards [hU.mem_nhds hy] with z hz
      exact (hun z hz).2
    · change ∀ᶠ z in 𝓝 (f x), g.inner z (V z) (V z) = 1
      rw [hfx]
      filter_upwards [hU.mem_nhds hy] with z hz
      exact (hun z hz).1
    · exact hdim _
  exact hfx ▸ hzero

end PoincareMT.ControlledTerminal
