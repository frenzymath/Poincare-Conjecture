import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Ancient.Compact.Stability.Neck.Comparison
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.RegularLimit.Canonical.Neck.CenteredTensor
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.RegularLimit.Canonical.Neck.Static.Constructor

/-!
# Actual necks under finite normalized metric perturbations

A strict accuracy gap gives a universal finite-jet tolerance. Perturbing
the metric within that tolerance constructs the new neck with its actual
center scalar normalization, central sphere, and restricted carrier.

Reference: Morgan--Tian, Proposition 9.79(3) and Claim 11.6.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12

open Set Filter
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT.EpsilonNeck

open MetricSurgery

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem exists_perturbed_metric_neck_tolerance
    {δ ε : ℝ} (hδ : 0 < δ) (hδε : δ < ε) (hε : ε < 1 / 2) :
    ∃ η : ℝ, 0 < η ∧
      ∀ (M : Type u) [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M],
      ∀ (g h : RiemannianMetric 3 M) (N : EpsilonNeck g), N.epsilon = δ →
      ∀ D : LeviCivitaData h, 0 < D.scalarCurvature N.center →
      (∀ z : RoundCylinderSpace, z.2 ∈ Ioo (-ε⁻¹) ε⁻¹ → ∀ j, j ≤ ⌊ε⁻¹⌋₊ →
        ‖iteratedFDeriv ℝ j (fun p =>
          D.scalarCurvature N.center • h.parametrizedCoefficients
            (centeredNeckLift N z.1 z.2) p -
          N.connection.scalarCurvature N.center • g.parametrizedCoefficients
            (centeredNeckLift N z.1 z.2) p) 0‖ ≤ η) →
      ∃ N' : EpsilonNeck h, N'.epsilon = ε ∧ N'.center = N.center ∧
        N'.connection = D ∧ N'.central_sphere = N.central_sphere ∧
        N'.carrier = N.region (-ε⁻¹) ε⁻¹ := by
  obtain ⟨η, hη, htolerance⟩ := TerminalNeck.exists_staticCylinder_comparison_tolerance hδ hδε
  obtain ⟨C, hC, hcoeff⟩ := exists_cylinder_coefficient_jet_constant ⌊ε⁻¹⌋₊
  refine ⟨η / C, div_pos hη hC, ?_⟩
  intro M _ _ _ g h N hN D hR hjet
  have hNε : N.epsilon ≤ ε := hN.trans_le hδε.le
  let Q := D.scalarCurvature N.center
  let q := N.connection.scalarCurvature N.center
  let B₁ : RoundCylinderTwoTensor := fun z v w => Q * roundCylinderPullback h N.coordinate_map z v w
  let B₀ : RoundCylinderTwoTensor := fun z v w => q * roundCylinderPullback g N.coordinate_map z v w
  have hpow : N.scale⁻¹ ^ 2 = q := by
    rw [N.scale_eq_scalar, neg_div, Real.rpow_neg N.scalar_center_pos.le, inv_inv,
      ← Real.rpow_natCast, ← Real.rpow_mul N.scalar_center_pos.le]
    norm_num [q]
  have hclose₀ : RoundCylinderClose δ 0 B₀ := by
    simpa only [B₀, q, hpow, hN] using N.metric_comparison.close
  have hclose : RoundCylinderClose ε 0 B₁ := by
    apply htolerance B₀ B₁ hclose₀
    · apply roundCylinderTensorSmoothOn_smul_pullback
      exact N.coordinate_map_smooth.mono
        (prod_mono subset_rfl (DeepHorn.neckInterval_subset N.epsilon_pos hNε))
    · intro z hz j hj a b
      have hzold : z.2 ∈ Ioo (-N.epsilon⁻¹) N.epsilon⁻¹ :=
        DeepHorn.neckInterval_subset N.epsilon_pos hNε hz
      let f := centeredNeckLift N z.1 z.2
      let A₁ := h.parametrizedCoefficients f
      let A₀ := g.parametrizedCoefficients f
      have hf := centeredNeckLift_contMDiffAt N z.1 z.2 (zero_mem_centeredNeckDomain N hzold)
      have hs₁ : ContDiffAt ℝ ∞ A₁ 0 := h.contDiffAt_parametrizedCoefficients hf
      have hs₀ : ContDiffAt ℝ ∞ A₀ 0 := g.contDiffAt_parametrizedCoefficients hf
      have heq : (fun p : E => centeredCylinderMetric B₁ z.1 z.2 p -
          centeredCylinderMetric B₀ z.1 z.2 p) =ᶠ[𝓝 0] fun p => Q • A₁ p - q • A₀ p := by
        filter_upwards [(centeredNeckDomain_isOpen N z.2).mem_nhds
          (zero_mem_centeredNeckDomain N hzold)] with p hp
        rw [centeredCylinderMetric_smul, centeredCylinderMetric_smul,
          centeredCylinderMetric_pullback _ N.coordinate_map_smooth _ _ hp,
          centeredCylinderMetric_pullback _ N.coordinate_map_smooth _ _ hp]
        rfl
      have hs : ContDiffAt ℝ ∞ (fun p : E => centeredCylinderMetric B₁ z.1 z.2 p -
          centeredCylinderMetric B₀ z.1 z.2 p) 0 :=
        ((hs₁.const_smul Q).sub (hs₀.const_smul q)).congr_of_eventuallyEq heq
      have hjets : ∀ k ≤ ⌊ε⁻¹⌋₊, ‖iteratedFDeriv ℝ k (fun p : E =>
          centeredCylinderMetric B₁ z.1 z.2 p - centeredCylinderMetric B₀ z.1 z.2 p) 0‖ ≤ η / C := by
        intro k hk
        rw [(heq.iteratedFDeriv (𝕜 := ℝ) k).eq_of_nhds]
        exact hjet z hz k hk
      have hb := hcoeff B₁ B₀ z.1 z.2 hs (η / C) (div_pos hη hC).le hjets j hj a b
      simpa only [mul_div_cancel₀ _ hC.ne'] using hb
  exact ⟨N.withMetric h D hNε hε hR hclose, rfl, rfl, rfl, rfl,
    N.withMetric_carrier h D hNε hε hR hclose⟩

end PoincareMT.EpsilonNeck
