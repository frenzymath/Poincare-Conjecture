import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Component
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.NegativeCurvature

/-!
# Curvature on the normalized source terminal component

Component restriction preserves the normalized scalar, curvature norm, and
negative-curvature error. The based scalar equals one, and dense bounded
distance control makes the negative error vanish on each fixed terminal ball.
Source: Morgan--Tian, Theorem 11.1, pp. 267--269.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.GeneralizedBlowupSequence

def terminalComponentConnection (S : GeneralizedBlowupSequence.{u}) (k : ℕ) :
    LeviCivitaData (S.terminalComponentMetric k) := (S.terminalComponentMetric k).leviCivitaData

theorem normalizedTerminalConnection_scalarCurvature
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
    (x : ((S.flow k).slice (S.base k).1).carrier) :
    (S.normalizedTerminalConnection k).scalarCurvature x =
      (S.scale k)⁻¹ * ((S.flow k).connection (S.base k).1).scalarCurvature x :=
  rescaledMetric_scalarCurvature _ _ _ _ x

theorem normalizedTerminalConnection_negativeCurvaturePart
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
    (x : ((S.flow k).slice (S.base k).1).carrier) :
    (S.normalizedTerminalConnection k).negativeCurvaturePart x =
      ((S.flow k).connection (S.base k).1).negativeCurvaturePart x / S.scale k :=
  rescaledMetric_negativeCurvaturePart _ _ _ _ x

theorem terminalComponentConnection_scalarCurvature
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ) (x : S.terminalComponent k) :
    (S.terminalComponentConnection k).scalarCurvature x =
      (S.normalizedTerminalConnection k).scalarCurvature x.val :=
  (S.terminalComponentConnection k).scalarCurvature_eq_of_local_isometry
    (S.normalizedTerminalConnection k) isOpen_univ contMDiff_subtype_val.contMDiffOn
    (fun _ _ _ _ => rfl) (mem_univ x)

theorem terminalComponentConnection_curvatureTensorNorm
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ) (x : S.terminalComponent k) :
    (S.terminalComponentConnection k).curvatureTensorNorm x =
      (S.normalizedTerminalConnection k).curvatureTensorNorm x.val :=
  (S.terminalComponentConnection k).curvatureTensorNorm_eq_of_local_isometry
    (S.normalizedTerminalConnection k) isOpen_univ contMDiff_subtype_val.contMDiffOn
    (fun _ _ _ _ => rfl) (mem_univ x)

theorem terminalComponentConnection_negativeCurvaturePart
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ) (x : S.terminalComponent k) :
    (S.terminalComponentConnection k).negativeCurvaturePart x =
      (S.normalizedTerminalConnection k).negativeCurvaturePart x.val :=
  (S.terminalComponentConnection k).negativeCurvaturePart_eq_of_local_isometry
    (S.normalizedTerminalConnection k) isOpen_univ contMDiff_subtype_val.contMDiffOn
    (fun _ _ _ _ => rfl) (mem_univ x)

theorem terminalComponentConnection_scalar_base
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ) :
    (S.terminalComponentConnection k).scalarCurvature (S.terminalComponentBase k) = 1 := by
  rw [S.terminalComponentConnection_scalarCurvature,
    S.normalizedTerminalConnection_scalarCurvature]
  change (S.scale k)⁻¹ * S.scale k = 1
  exact inv_mul_cancel₀ (S.base_scalar_pos k).ne'

end PoincareMT.GeneralizedBlowupSequence

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem eventually_normalized_terminal_negativePart_le
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {A eta : ℝ} (hA : 0 < A) (heta : 0 < eta) :
    ∀ᶠ k in atTop, ∀ x ∈ S.baseBall k A,
      (S.normalizedTerminalConnection k).negativeCurvaturePart x ≤ eta := by
  obtain ⟨B, hB, hscalar⟩ := hbound A hA
  filter_upwards [hscalar,
    DeepHorn.eventually_full_and_negative_curvature_bounds P04 S H.branch hB.le heta]
    with k hk hcurv x hx
  rw [S.normalizedTerminalConnection_negativeCurvaturePart]
  apply (div_le_iff₀ (S.base_scalar_pos k)).mpr
  have htime := ((S.flow k).slice_nonempty_iff (S.base k).1).mp ⟨(S.base k).2⟩
  exact (hcurv _ htime x (hk x hx)).2

theorem tendsto_terminalComponent_negativePart_zero
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    (x : ∀ k, S.terminalComponent (sigma k))
    (hball : ∃ A : ℝ, 0 < A ∧ ∀ᶠ k in atTop, (x k).val ∈ S.baseBall (sigma k) A) :
    Tendsto (fun k => (S.terminalComponentConnection (sigma k)).negativeCurvaturePart (x k))
      atTop (𝓝 0) := by
  obtain ⟨A, hA, hAx⟩ := hball
  apply tendsto_order.mpr
  constructor
  · intro a ha
    exact Eventually.of_forall fun k => ha.trans_le (le_max_right _ _)
  · intro b hb
    filter_upwards [hAx, hsigma.tendsto_atTop.eventually
      (H.eventually_normalized_terminal_negativePart_le P04 hbound hA (half_pos hb))]
      with k hk hneg
    rw [S.terminalComponentConnection_negativeCurvaturePart]
    exact (hneg _ hk).trans_lt (half_lt_self hb)

end PoincareMT.M30CommonBlowupControls
