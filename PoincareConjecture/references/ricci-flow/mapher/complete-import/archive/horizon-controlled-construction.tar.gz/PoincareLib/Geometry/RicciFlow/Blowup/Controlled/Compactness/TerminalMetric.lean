import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.SmallCylinder
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.NeckTransfer
import PoincareLib.Geometry.Riemannian.Metric.Induced.Complete
import PoincareLib.Geometry.RicciFlow.MetricComparison
import PoincareLib.Geometry.RicciFlow.Curvature.Estimates.QuadraticRicci

/-!
# Terminal metrics of normalized controlled cylinders

The zero-slice identity identifies the constructed ordinary metric with the
restriction of the actual rescaled source metric. Source: Morgan--Tian,
Theorem 11.1, pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

/-- The terminal coordinate map is the identity on the actual source ball. -/
theorem zeroSliceHomeomorph_eq_self (e : ControlledBlowupCylinder S k A T B eta)
    (hzero : (0 : ℝ) ∈ Icc (-T) 0) {x : ((S.flow k).slice (S.base k).1).carrier}
    (hx : x ∈ sourceBall S k A) :
    e.embedding.zeroSliceHomeomorph (sourceBall S k A).isOpen hzero x = x := by
  have h := e.zero_identity hzero x hx
  rw [e.embedding.zeroSliceHomeomorph_pointMap (sourceBall S k A).isOpen hzero] at h
  exact eq_of_heq (Sigma.mk.inj h).2

/-- The exact terminal pullback tensor, including its normalization factor. -/
theorem ordinaryFlow_terminal_inner (e : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (x : sourceBall S k A) (v w : TangentSpace (𝓡 3) x) :
    ((e.ordinaryFlow hT).metric 0).inner x v w =
      (rescaledMetric ((S.flow k).metric (S.base k).1) (S.scale k)
        (S.base_scalar_pos k)).inner x.val
        (mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) x v)
        (mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) x w) := by
  have hzero : (0 : ℝ) ∈ Icc (-T) 0 := ⟨by linarith, le_rfl⟩
  rw [e.ordinaryFlow_inner hT 0 hzero]
  rw [e.embedding.zeroSliceHomeomorph_pullbackInner (sourceBall S k A).isOpen hzero]
  have hloc : e.embedding.zeroSliceHomeomorph (sourceBall S k A).isOpen hzero =ᶠ[𝓝 x.val] id :=
    mem_of_superset ((sourceBall S k A).isOpen.mem_nhds x.property)
      (fun _ hy => e.zeroSliceHomeomorph_eq_self hzero hy)
  rw [hloc.mfderiv_eq, mfderiv_id, e.zeroSliceHomeomorph_eq_self hzero x.property]
  rfl

/-- The ambient normalized distance never exceeds the intrinsic cylinder distance. -/
theorem terminal_edist_le (e : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (x y : sourceBall S k A) :
    (rescaledMetric ((S.flow k).metric (S.base k).1) (S.scale k)
      (S.base_scalar_pos k)).edist x.val y.val ≤
        ((e.ordinaryFlow hT).metric 0).edist x y :=
  RiemannianMetric.edist_map_le_of_metric_pullback _ _ contMDiff_subtype_val
    (e.ordinaryFlow_terminal_inner hT) x y

/-- Curvature control gives the needed two-way time comparison on every point. -/
theorem ordinaryFlow_tangentNorm_le (e : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (x : sourceBall S k A) (v : TangentSpace (𝓡 3) x)
    {s t : ℝ} (hs : s ∈ Icc (-T) 0) (ht : t ∈ Icc (-T) 0) :
    ((e.ordinaryFlow hT).metric t).tangentNorm x v ≤
      Real.exp (3 * B * |t - s|) * ((e.ordinaryFlow hT).metric s).tangentNorm x v := by
  apply (e.ordinaryFlow hT).tangentNorm_le_exp_of_ricci_bound
    (convex_Icc (-T) 0) Subset.rfl x v (3 * B) _ hs ht
  intro r hr
  have hb := (le_abs_self _).trans (e.ordinaryFlow_curvature_bound hT r hr x)
  have hq : 0 ≤ ((e.ordinaryFlow hT).metric r).inner x v v :=
    by
      by_cases hv : v = 0
      · simp [hv]
      · exact ((e.ordinaryFlow hT).metric r).pos x v hv |>.le
  exact (RicciFlowAnalysis.abs_ricci_le_curvatureTensorNorm
    ((e.ordinaryFlow hT).connection r) x v).trans
      (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hb (by norm_num)) hq)

end PoincareMT.ControlledBlowupCylinder
