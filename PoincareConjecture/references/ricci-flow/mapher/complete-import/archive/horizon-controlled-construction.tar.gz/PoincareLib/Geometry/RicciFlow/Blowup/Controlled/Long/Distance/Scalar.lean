import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Geometry
import PoincareLib.Geometry.RicciFlow.Harnack.Theory
import PoincareLib.Geometry.RicciFlow.Harnack.Regularity
import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.CurvatureControl
import PoincareLib.Geometry.Riemannian.Curvature.Scalar.SharpBounds

/-!
# Finite-origin scalar Harnack bounds through the terminal slice

The frozen M06 estimate on the open interval retains its elapsed-time
factor. Continuity passes its constant-path inequality to time zero.
Reference: Morgan--Tian, Claim 11.11, pp. 274--275.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongDistance

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem limit_curvatureOperator_bound (P04 : RicciFlowCurvatureTheory.{u})
    {J : Set ℝ} (L : BlowupLimitFlow.{u} J) {t : ℝ} (ht : t ∈ J) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ x, (L.flow.connection t).CurvatureOperatorBound B x := by
  obtain ⟨B, hB, hb⟩ := L.curvature_locally_bounded_in_time {t} isCompact_singleton
    (singleton_subset_iff.mpr ht)
  refine ⟨3 * B, by positivity, fun x A hA => ?_⟩
  have h := ((L.flow.connection t).curvatureOperatorBound_scalarCurvature
    (P04.tensor_calculus 3 L.carrier.carrier _ _) x (L.nonnegative_curvature_operator t ht x)).2 A hA
  apply h.trans
  apply mul_le_mul_of_nonneg_right _ (Finset.sum_nonneg fun _ _ => Finset.sum_nonneg fun _ _ => sq_nonneg _)
  exact ((L.flow.connection t).scalarCurvature_le_curvatureTensorNorm_sharp x).trans
    (mul_le_mul_of_nonneg_left ((le_abs_self _).trans (hb t (mem_singleton _) x)) (by norm_num))

theorem weighted_scalar_le_terminal
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T : ℝ} (hT : 0 < T) (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    {t : ℝ} (ht : t ∈ Ioc (-T) 0) (x : L.carrier.carrier) :
    (L.flow.connection t).scalarCurvature x * (t + T) ≤
      (L.flow.connection 0).scalarCurvature x * T := by
  by_cases ht0 : t = 0
  · subst t
    simp
  have htneg : t < 0 := lt_of_le_of_ne ht.2 ht0
  let F := Poincare.Geometry.RicciFlow.Harnack.restrictFlow L.flow
    (show Ioo (-T) 0 ⊆ Ioc (-T) 0 from Ioo_subset_Ioc_self) ordConnected_Ioo
    (show (Ioo (-T) (0 : ℝ)).Nontrivial from
      ⟨-3 * T / 4, ⟨by linarith, by linarith⟩, -T / 4,
        ⟨by linarith, by linarith⟩, by linarith⟩)
  have hineq (s : ℝ) (hs : s ∈ Ioo t 0) :
      (L.flow.connection t).scalarCurvature x * (t + T) ≤
        (L.flow.connection s).scalarCurvature x * (s + T) := by
    have hh := P06.finite_integrated 3 L.carrier.carrier (-T) 0 t s ht.1 hs.1 hs.2 F
      (fun r hr => L.complete r (Ioo_subset_Ioc_self hr))
      (fun r hr => L.nonnegative_curvature_operator r (Ioo_subset_Ioc_self hr))
      (fun r hr => limit_curvatureOperator_bound P04 L (Ioo_subset_Ioc_self hr))
      (fun _ => x) contMDiffOn_const x x rfl rfl
    simpa only [spacetimeEnergy, mfderiv_const, zero_apply, map_zero,
      intervalIntegral.integral_zero, neg_zero, zero_div, Real.exp_zero, mul_one, sub_neg_eq_add,
      F, Poincare.Geometry.RicciFlow.Harnack.restrictFlow]
      using hh
  have hcontinuous : ContinuousOn
      (fun s => (L.flow.connection s).scalarCurvature x * (s + T)) (Ioc (-T) 0) :=
    (Poincare.Geometry.RicciFlow.Harnack.scalarCurvature_continuousOn_time P04 _ L.flow x).mul
      (continuousOn_id.add continuousOn_const)
  have hzero : (0 : ℝ) ∈ closure (Ioo t 0) := by
    rw [closure_Ioo htneg.ne]
    exact ⟨htneg.le, le_rfl⟩
  have hend := ContinuousWithinAt.closure_le hzero continuousWithinAt_const
    ((hcontinuous 0 ⟨by linarith, le_rfl⟩).mono
      (fun s hs => ⟨ht.1.trans hs.1, hs.2.le⟩)) hineq
  simpa only [zero_add] using hend

theorem scalar_le_finite_origin_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T Q : ℝ} (hT : 0 < T) (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    (hQ : ∀ x, (L.flow.connection 0).scalarCurvature x ≤ Q)
    {t : ℝ} (ht : t ∈ Ioc (-T) 0) (x : L.carrier.carrier) :
    (L.flow.connection t).scalarCurvature x ≤ Q * T / (t + T) := by
  apply (le_div_iff₀ (by linarith [ht.1])).mpr
  exact (weighted_scalar_le_terminal P04 P06 hT L ht x).trans
    (mul_le_mul_of_nonneg_right (hQ x) hT.le)

end PoincareMT.ControlledLongDistance
