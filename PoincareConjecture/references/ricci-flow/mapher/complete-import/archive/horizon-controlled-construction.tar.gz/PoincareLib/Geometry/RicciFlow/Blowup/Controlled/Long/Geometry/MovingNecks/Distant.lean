import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.MovingNecks.Triangles
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.MovingNecks.Scalar

/-! # Past scalar bounds from distant necks with controlled center displacement -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongGeometry

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem exists_uniform_past_distant_controlled_neck_scalar_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T epsilon K : ℝ} (hT : 0 < T) (hepsilon : 0 < epsilon)
    (hsmall : epsilon ≤ 1 / (400 * Real.pi)) (hK : 0 < K)
    (L : BlowupLimitFlow.{u} (Ioc (-T) 0)) (p : L.carrier.carrier) :
    ∃ A : ℝ, 0 < A ∧ ∀ y : L.carrier.carrier,
      A ≤ ((L.flow.metric 0).edist p y).toReal → ∃ B : ℝ, 0 < B ∧
      ∀ t ∈ Ioc (-T) 0, ∀ N : EpsilonNeck (L.flow.metric t), N.epsilon = epsilon →
        ((L.flow.metric t).edist y N.center).toReal ≤
          K * (L.flow.connection t).scalarCurvature y ^ (-1 / 2 : ℝ) →
        (L.flow.connection t).scalarCurvature y ≤
          K * (L.flow.connection t).scalarCurvature N.center →
        (L.flow.connection t).scalarCurvature y ≤ B := by
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  obtain ⟨A, hA, htriangle⟩ := exists_uniform_past_triangle_control
    P04 P06 hT (by norm_num : (0 : ℝ) < 1 / 8) L p
  refine ⟨A, hA, ?_⟩
  intro y hy
  let d := ((L.flow.metric 0).edist p y).toReal
  have hd : 0 < d := hA.trans_le hy
  obtain ⟨z, hz⟩ := htriangle y hy
  have hpy : p ≠ y := by
    intro heq
    have hh : d = 0 := by
      simp only [d, heq, RiemannianMetric.edist, Manifold.riemannianEDist_self,
        ENNReal.toReal_zero]
    linarith
  have hzy : z ≠ y := by
    intro heq
    have hh := (hz 0 L.zero_mem).2.1
    simp only [heq, RiemannianMetric.edist, Manifold.riemannianEDist_self,
      ENNReal.toReal_zero] at hh
    exact (not_le_of_gt hd) hh
  obtain ⟨B, hB, hbound⟩ := exists_scalar_cutoff_for_necks_with_controlled_center
    (L.flow.metric 0) hpy hzy hepsilon hsmall hd hK
  refine ⟨B, hB, ?_⟩
  intro t ht N heq hcenter hscalar
  obtain ⟨ha, hb, ha', hb', hfar⟩ := hz t ht
  have hsec : (L.flow.connection t).NonnegativeSectionalCurvature := fun x v w =>
    (L.flow.connection t).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
      x (L.nonnegative_curvature_operator t ht x) v w
  apply hbound (L.flow.metric t) (L.flow.connection t) (L.complete t ht) hsec
    (ControlledLongDistance.terminal_toReal_edist_le P04 L ht y) ha hb
    (by linarith) (by linarith) (by linarith) N heq hcenter hscalar

end PoincareMT.ControlledLongGeometry
