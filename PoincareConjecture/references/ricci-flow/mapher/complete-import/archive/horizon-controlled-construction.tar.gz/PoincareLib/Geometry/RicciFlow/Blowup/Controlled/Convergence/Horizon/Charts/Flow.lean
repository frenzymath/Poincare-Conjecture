import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.Positivity
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.ChartFlow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.PartialCharts

/-! # Genuine local Ricci flows from the full-horizon chart limits -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

theorem exists_horizon_chart_flow_on_closed_slab
    (htmono : Monotone tau) (hB : ∀ j, 0 ≤ B j)
    (q : G.limitCarrier.carrier) {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    (f : ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3)
    (hf : ContDiffOn ℝ ∞ f (horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target))
    (hjets : ∀ m K, IsCompact K →
      K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target → TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ m (horizonSpacetimeCoefficients G q (sigma k)))
        (iteratedFDeriv ℝ m f) atTop K)
    {a b : ℝ} (hab : a < b) (hwindow : Icc a b ⊆ horizonOpenTime tau)
    {x₀ : EuclideanSpace ℝ (Fin 3)} {rho : ℝ} (hrho : 0 < rho)
    (hchart : closedBall x₀ rho ⊆ (extChartAt (𝓡 3) q).target)
    (U : Opens (EuclideanSpace ℝ (Fin 3))) (hU : (U : Set _) ⊆ ball x₀ rho) :
    ∃ F : RicciFlow 3 U (Icc a b), ∀ t ∈ Icc a b, ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
      (F.metric t).inner x v w = f (t, x) v w := by
  let K := Icc a b ×ˢ closedBall x₀ rho
  have hK : IsCompact K := isCompact_Icc.prod (isCompact_closedBall x₀ rho)
  have hKsub : K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target :=
    prod_mono hwindow hchart
  have hzero : 0 ∈ Ioo (-tau 0 / 2) (tau 0 / 2) :=
    ⟨by linarith [htau 0], by linarith [htau 0]⟩
  obtain ⟨j, hj⟩ := exists_horizonWindow_of_isCompact htmono isCompact_Icc hwindow
  have htime : ∀ᶠ k in atTop, Icc a b ⊆ Icc (-tau (G.subsequence (sigma k))) 0 := by
    filter_upwards [(G.subsequence_strictMono.comp hsigma).tendsto_atTop.eventually_ge_atTop j]
      with k hk t ht
    exact ⟨(neg_le_neg (htmono hk)).trans (hj ht).1.le, (hj ht).2.le⟩
  have hsource := hsigma.tendsto_atTop.eventually
    (G.eventually_subset_referencePartialChart_source q hzero (isCompact_closedBall x₀ rho) hchart)
  have hsmooth := hsigma.tendsto_atTop.eventually
    (horizonSpacetimeCoefficients_locallyEventuallyContDiff G htmono q K hK hKsub)
  obtain ⟨N, hN⟩ := eventually_atTop.mp (htime.and (hsource.and hsmooth))
  let index (k : ℕ) := sigma (max k N)
  let C (k : ℕ) :=
    (interiorSequence S idx A eta (tau 0) (B 0) hA (htau 0)
      (fun i => e i 0 (Nat.zero_le i))).carrier (G.subsequence (index k))
  let Fseq (k : ℕ) : RicciFlow 3 (C k).carrier (Icc a b) :=
    Poincare.Geometry.RicciFlow.Harnack.restrictFlow
      (horizonSourceFlow hA htau e (G.subsequence (index k))) (hN _ (le_max_right k N)).1
      ordConnected_Icc ⟨a, ⟨le_rfl, hab.le⟩, b, ⟨hab.le, le_rfl⟩, hab.ne⟩
  let Phi (k : ℕ) := G.referencePartialChart q (index k) hzero
  have hpoint (z : ℝ × EuclideanSpace ℝ (Fin 3))
      (hz : z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target) :
      Tendsto (fun k => horizonSpacetimeCoefficients G q (sigma k) z) atTop (𝓝 (f z)) := by
    have he := (ContinuousMultilinearMap.uniformContinuous_eval_const
      (0 : Fin 0 → ℝ × EuclideanSpace ℝ (Fin 3))).comp_tendstoUniformlyOn
        (hjets 0 {z} isCompact_singleton (singleton_subset_iff.mpr hz))
    simpa only [Function.comp_apply, iteratedFDeriv_zero_apply] using he.tendsto_at (mem_singleton z)
  apply ControlledConvergence.exists_flow_of_eventual_partial_chart_coefficients
    hab C hrho Fseq Phi
    (Eventually.of_forall fun k => (hN _ (le_max_right k N)).2.1) U hU f (hf.mono hKsub)
    (fun t ht x hx v w => horizon_limit_symmetric G q hpoint (hwindow ht)
      (hchart (ball_subset_closedBall (hU hx))) v w)
    (fun t ht x hx => horizon_limit_positive G htmono hB q hsigma hpoint (hwindow ht)
      (hchart (ball_subset_closedBall (hU hx))))
  intro m
  have huBall : UniqueDiffOn ℝ (closedBall x₀ rho) := by
    apply uniqueDiffOn_convex (convex_closedBall x₀ rho)
    rw [interior_closedBall x₀ hrho.ne']
    exact ⟨x₀, by simpa using hrho⟩
  have hu : UniqueDiffOn ℝ K := (uniqueDiffOn_Icc hab).prod huBall
  have hm : (m : ℕ∞ω) ≤ ∞ := WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤)
  have hlim := hjets m K hK hKsub
  have htarget : EqOn (iteratedFDeriv ℝ m f) (iteratedFDerivWithin ℝ m f K) K := by
    intro z hz
    exact (iteratedFDerivWithin_eq_iteratedFDeriv hu
      ((hf.contDiffAt (((horizonOpenTime_isOpen tau).prod
        (isOpen_extChartAt_target q)).mem_nhds (hKsub hz))).of_le hm) hz).symm
  apply (hlim.congr_right htarget).congr
  filter_upwards [eventually_ge_atTop N] with k hk z hz
  have hind : index k = sigma k := by simp only [index, max_eq_left hk]
  change iteratedFDeriv ℝ m (horizonSpacetimeCoefficients G q (sigma k)) z =
    iteratedFDerivWithin ℝ m (horizonSpacetimeCoefficients G q (index k)) K z
  rw [hind]
  obtain ⟨W, hW, hKW, hfd⟩ := (hN k hk).2.2
  exact (iteratedFDerivWithin_eq_iteratedFDeriv hu
    ((hfd.contDiffAt (hW.mem_nhds (hKW hz))).of_le hm) hz).symm

end PoincareMT.ControlledBlowupCompactness
