import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Data
import PoincareLib.Geometry.RicciFlow.Surgery.Induction.EpochExtension.Spacetime.GeneralizedCylinderRestriction

/-! # Restriction of controlled cylinders to shorter backward times -/

set_option autoImplicit false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

noncomputable def restrictTime {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T T' B eta : ℝ}
    (e : ControlledBlowupCylinder S k A T B eta) (hT : T' ≤ T) :
    ControlledBlowupCylinder S k A T' B eta where
  embedding := e.embedding.restrict (Icc_subset_Icc_left (neg_le_neg hT)) Subset.rfl
  zero_identity h₀ := e.zero_identity ((Icc_subset_Icc_left (neg_le_neg hT)) h₀)
  curvature_bound s hs := e.curvature_bound s ((Icc_subset_Icc_left (neg_le_neg hT)) hs)
  negative_curvature_bound s hs :=
    e.negative_curvature_bound s ((Icc_subset_Icc_left (neg_le_neg hT)) hs)

end PoincareMT.ControlledBlowupCylinder
