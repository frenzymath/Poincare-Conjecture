import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.Selection
import PoincareLib.Analysis.Parabolic.Maximum.CompactSlab

/-! # A normalized compact limit has scalar minimum at most one -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongCompact

theorem scalar_lower_bound_preserved_on_compact
    (P04 : RicciFlowCurvatureTheory.{u}) {n : ℕ} {M : Type u}
    [TopologicalSpace M] [ChartedSpace (EuclideanSpace ℝ (Fin n)) M]
    [IsManifold (𝓡 n) ∞ M] [CompactSpace M]
    {J : Set ℝ} (F : RicciFlow n M J) {a b c : ℝ}
    (hab : a < b) (hJ : Icc a b ⊆ J)
    (hinit : ∀ x : M, c ≤ (F.connection a).scalarCurvature x) :
    ∀ t ∈ Icc a b, ∀ x : M, c ≤ (F.connection t).scalarCurvature x := by
  have h := RicciFlowAnalysis.compact_subset_min_velocity_nonnegative_Icc
    (C := (univ : Set M)) isCompact_univ (K := 0) hab
    (fun t x => (F.connection t).scalarCurvature x - c)
    (fun t x => (F.connection t).laplacian (F.connection t).scalarCurvature x +
      2 * (F.connection t).ricciNormSq x)
    (by
      exact ((P04.scalar_regular n M J F).continuousOn.mono
        (prod_mono hJ Subset.rfl)).sub continuousOn_const)
    (by
      intro t ht x _
      exact ((P04.scalar_evolution n M J F t (hJ ht) x).mono hJ).sub_const c)
    (by
      intro t ht x _ hmin _
      have hminimum : IsLocalMin (F.connection t).scalarCurvature x :=
        Filter.Eventually.of_forall (fun y => by have hh := hmin y (mem_univ y); linarith)
      have hlap := (F.connection t).laplacian_nonneg_of_isLocalMinAt
        ((P04.tensor_calculus n M _ _).contMDiff_scalarCurvature.contMDiffAt (x := x)) hminimum
      have hnorm : 0 ≤ (F.connection t).ricciNormSq x := by
        unfold LeviCivitaData.ricciNormSq
        positivity
      simpa only [neg_zero, zero_mul] using add_nonneg hlap (mul_nonneg (by norm_num) hnorm))
    (fun x _ => sub_nonneg.mpr (hinit x))
  exact fun t ht x => sub_nonneg.mp (h t ht x (mem_univ x))

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_scalar_le_one_of_compact_limit
    (P04 : RicciFlowCurvatureTheory.{u}) {T : ℝ}
    (L : BlowupLimitFlow.{u} (Ioc (-T) 0)) [CompactSpace L.carrier.carrier]
    {t : ℝ} (ht : t ∈ Ioc (-T) 0) :
    ∃ x : L.carrier.carrier, (L.flow.connection t).scalarCurvature x ≤ 1 := by
  by_cases ht0 : t = 0
  · exact ⟨L.base, ht0 ▸ L.scalar_normalized.le⟩
  have htneg : t < 0 := lt_of_le_of_ne ht.2 ht0
  by_contra! hnot
  have hcont := (P04.tensor_calculus 3 L.carrier.carrier _ (L.flow.connection t)).contMDiff_scalarCurvature.continuous
  obtain ⟨p, _, hp⟩ := isCompact_univ.exists_isMinOn ⟨L.base, mem_univ _⟩ hcont.continuousOn
  have hJ : Icc t 0 ⊆ Ioc (-T) 0 := fun s hs => ⟨ht.1.trans_le hs.1, hs.2⟩
  have hbound := scalar_lower_bound_preserved_on_compact P04 L.flow htneg hJ
    (fun x => hp (mem_univ x)) 0 ⟨htneg.le, le_rfl⟩ L.base
  rw [L.scalar_normalized] at hbound
  exact (not_lt_of_ge hbound) (hnot p)

end PoincareMT.ControlledLongCompact
