import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Retained
import PoincareLib.Topology.Order.TimeInterval

/-!
# Exhaustions for retained generalized cylinders

The spatial exhaustion is transported by the actual universe-lifting
homeomorphism. The time intervals retain their closed terminal endpoint
while exhausting the open past endpoint of a finite limit window.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

def retainedSpace (k : ℕ) : Set (liftedSliceCarrier.{u} G.limitCarrier).carrier :=
  ULift.down ⁻¹' G.exhaustion k

theorem retainedSpace_open (k : ℕ) : IsOpen (retainedSpace G k) :=
  (G.exhaustion_open k).preimage Homeomorph.ulift.continuous

theorem retainedSpace_connected (k : ℕ) : IsConnected (retainedSpace G k) :=
  Homeomorph.ulift.isConnected_preimage.mpr (G.exhaustion_connected k)

theorem retainedSpace_compactClosure (k : ℕ) : IsCompact (closure (retainedSpace G k)) := by
  change IsCompact (closure (Homeomorph.ulift ⁻¹' G.exhaustion k))
  rw [← Homeomorph.preimage_closure]
  exact Homeomorph.ulift.isCompact_preimage.mpr (G.exhaustion_compactClosure k)

theorem retainedSpace_monotone : Monotone (retainedSpace G) :=
  fun _ _ h => preimage_mono (G.exhaustion_monotone h)

theorem retainedSpace_covers : ⋃ k, retainedSpace G k = univ := by
  change (⋃ k, ULift.down ⁻¹' G.exhaustion k) = univ
  rw [← preimage_iUnion, G.exhaustion_covers, preimage_univ]

theorem base_mem_retainedSpace (k : ℕ) : ULift.up G.limitFlow.base ∈ retainedSpace G k :=
  G.base_in_exhaustion k

noncomputable def finiteTimeRadius (T : ℝ) (k : ℕ) : ℝ :=
  T * ((k + 1 : ℝ) / (k + 2))

theorem finiteTimeRadius_pos {T : ℝ} (hT : 0 < T) (k : ℕ) :
    0 < finiteTimeRadius T k := by
  unfold finiteTimeRadius
  positivity

theorem finiteTimeRadius_lt {T : ℝ} (hT : 0 < T) (k : ℕ) :
    finiteTimeRadius T k < T := by
  apply mul_lt_of_lt_one_right hT
  exact (div_lt_one (by positivity)).mpr (by linarith)

theorem finiteTimeRadius_monotone {T : ℝ} (hT : 0 ≤ T) :
    Monotone (finiteTimeRadius T) := by
  intro m n hmn
  apply mul_le_mul_of_nonneg_left _ hT
  apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
  have hmn' : (m : ℝ) ≤ n := by exact_mod_cast hmn
  nlinarith

theorem finiteTimeRadius_interval_subset {T : ℝ} (hT : 0 < T) (k : ℕ) :
    Icc (-finiteTimeRadius T k) 0 ⊆ Ioc (-T) 0 := by
  intro t ht
  exact ⟨(neg_lt_neg (finiteTimeRadius_lt hT k)).trans_le ht.1, ht.2⟩

theorem finiteTimeRadius_interval_cofinal {T : ℝ} (hT : 0 < T)
    {I : Set ℝ} (hI : IsCompact I) (hIT : I ⊆ Ioc (-T) 0) :
    ∀ᶠ k in atTop, I ⊆ Icc (-finiteTimeRadius T k) 0 := by
  have hIopen : I ⊆ Ioo (-T) 1 := fun t ht =>
    ⟨(hIT ht).1, (hIT ht).2.trans_lt zero_lt_one⟩
  obtain ⟨j, hj⟩ := Poincare.TimeInterval.exists_exhaustion_superset
    (neg_neg_of_pos hT) zero_lt_one hI hIopen
  filter_upwards [eventually_ge_atTop j] with k hk
  intro t ht
  have htk := Poincare.TimeInterval.monotone_exhaustion
    (neg_neg_of_pos hT) zero_lt_one hk (interior_subset (hj ht))
  change -T * ((k + 1 : ℝ) / (k + 2)) ≤ t ∧ _ at htk
  exact ⟨by simpa only [finiteTimeRadius, neg_mul] using htk.1, (hIT ht).2⟩

end PoincareMT.ControlledBlowupCompactness
