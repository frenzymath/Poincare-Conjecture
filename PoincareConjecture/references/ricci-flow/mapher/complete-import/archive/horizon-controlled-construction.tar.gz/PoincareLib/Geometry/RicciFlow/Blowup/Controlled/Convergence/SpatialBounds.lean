import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Coordinates.SpatialBounds

/-!
# Spatial metric jets on finite closed flow intervals

The coordinate Ricci evolution propagates jets from a retained interior
reference time to both endpoints. Only finitely many source curvature and
reference jet bounds enter each estimate.

Reference: Morgan--Tian, Proposition 5.14, pp. 90--91.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxSynthPendingDepth 8
set_option synthInstance.maxHeartbeats 100000
set_option maxHeartbeats 800000

open Set Filter Bundle
open scoped Manifold ContDiff Topology

namespace PoincareMT.SpacetimeBounds

/-- All spatial jets through a finite closed interval are controlled by
ellipticity, curvature derivatives, and jets at one reference time. -/
theorem exists_chart_spatial_jet_bound_on_closed_interval
    (n m : ℕ) (K Z : ℕ → ℝ) (hK : ∀ j, 0 ≤ K j)
    {l r α β : ℝ} (hlr : l < r) (hα : 0 < α) (hβ : 0 ≤ β) :
    ∃ B : ℝ, 0 ≤ B ∧
      ∀ {M : Type*} [TopologicalSpace M]
        [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
        {J : Set ℝ} (F : RicciFlow n M J), Icc l r ⊆ J →
        ∀ {U : Set (EuclideanSpace ℝ (Fin n))}, IsOpen U →
        ∀ {e : EuclideanSpace ℝ (Fin n) → M}, ContMDiffOn (𝓡 n) (𝓡 n) ∞ e U →
        (∀ x ∈ U, (mfderiv (𝓡 n) (𝓡 n) e x).IsInvertible) →
        ∀ W : Set (EuclideanSpace ℝ (Fin n)), W ⊆ U →
        (∀ t ∈ Icc l r, ∀ x ∈ W, ∀ v,
          α * ‖v‖ ^ 2 ≤ (F.metric t).pullbackCoefficients e x v v ∧
          (F.metric t).pullbackCoefficients e x v v ≤ β * ‖v‖ ^ 2) →
        (∀ j ≤ m, ∀ t ∈ Icc l r, ∀ x ∈ W,
          (F.connection t).curvatureDerivativeNorm j (e x) ≤ K j) →
        ∀ {τ : ℝ}, τ ∈ Icc l r →
        (∀ j ≤ m, ∀ x ∈ W,
          ‖iteratedFDeriv ℝ j ((F.metric τ).pullbackCoefficients e) x‖ ≤ Z j) →
        ∀ t ∈ Icc l r, ∀ x ∈ W, ∀ j ≤ m,
          ‖iteratedFDeriv ℝ j ((F.metric t).pullbackCoefficients e) x‖ ≤ B := by
  induction m with
  | zero =>
      refine ⟨β, hβ, ?_⟩
      intro M _ _ _ J F hsub U hU e he hi W hWU hell hcurv τ hτ hreference t ht x hx j hj
      have hj0 : j = 0 := by omega
      subst j
      rw [norm_iteratedFDeriv_zero]
      apply HarmonicCoordinates.norm_bilinear_le_of_quadratic _ hβ
      · exact fun v w => (F.metric t).symm _ _ _
      · intro v
        rw [abs_of_nonneg (le_trans (by positivity) (hell t ht x hx v).1)]
        exact (hell t ht x hx v).2
  | succ q ih =>
      obtain ⟨B, hB, hprevious⟩ := ih
      let A : ℝ := max B 1
      have hA : 1 ≤ A := le_max_right _ _
      obtain ⟨C, hC, hevol⟩ := exists_affine_spatialJet_evolution_bound n q K hK hα hβ A hA
      let E : ℝ := max (Z (q + 1)) 1 * Real.exp ((C + C) * (r - l))
      have hE : 0 ≤ E := by dsimp [E]; positivity
      refine ⟨max B E, le_max_of_le_left hB, ?_⟩
      intro M _ _ _ J F hsub U hU e he hi W hWU hell hcurv τ hτ hreference t ht x hx j hj
      have hlower := hprevious F hsub hU he hi W hWU hell
        (fun d hd => hcurv d (by omega)) hτ (fun d hd => hreference d (by omega))
      rcases Nat.eq_or_lt_of_le hj with rfl | hj
      · apply le_trans _ (le_max_right B E)
        have hne : (Ioo l r).Nontrivial := by
          refine ⟨(2 * l + r) / 3, ⟨by linarith, by linarith⟩,
            (l + 2 * r) / 3, ⟨by linarith, by linarith⟩, by linarith⟩
        let Fopen := Poincare.Geometry.RicciFlow.Harnack.restrictFlow F
          (Ioo_subset_Icc_self.trans hsub) ordConnected_Ioo hne
        have hJ : UniqueDiffOn ℝ J := uniqueDiffOn_convex F.interval.convex
          (F.interval.convex.nontrivial_iff_nonempty_interior.mp F.nontrivial)
        have hjoint : ContDiffOn ℝ ∞
            (fun z : ℝ × EuclideanSpace ℝ (Fin n) =>
              iteratedFDeriv ℝ (q + 1) ((F.metric z.1).pullbackCoefficients e) z.2)
            (J ×ˢ U) := contDiffOn_spatialJet_within
          (F.contDiffOn_pullbackCoefficients_within hU he) hJ hU (q + 1)
        have hcont : ContinuousOn
            (fun s => iteratedFDeriv ℝ (q + 1) ((F.metric s).pullbackCoefficients e) x)
            (Icc l r) :=
          hjoint.continuousOn.comp (f := fun u : ℝ => (u, x))
            (continuous_id.prodMk continuous_const).continuousOn
            (fun _ hs => ⟨hsub hs, hWU hx⟩)
        have hdiff : ∀ s ∈ Ioo l r, DifferentiableAt ℝ
            (fun u => iteratedFDeriv ℝ (q + 1) ((F.metric u).pullbackCoefficients e) x) s := by
          intro s hs
          have hsm := contDiffOn_spatialJet
            (Fopen.contDiffOn_pullbackCoefficients isOpen_Ioo hU he) isOpen_Ioo hU (q + 1)
          exact ((hsm.contDiffAt (x := (s, x))
            ((isOpen_Ioo.prod hU).mem_nhds ⟨hs, hWU hx⟩)).comp s
            (contDiffAt_id.prodMk contDiffAt_const)).differentiableAt (by simp)
        have hbound : ∀ s ∈ Ioo l r,
            ‖deriv (fun u => iteratedFDeriv ℝ (q + 1)
              ((F.metric u).pullbackCoefficients e) x) s‖ ≤
            C + C * ‖iteratedFDeriv ℝ (q + 1) ((F.metric s).pullbackCoefficients e) x‖ := by
          intro s hs
          have hsclosed : s ∈ Icc l r := Ioo_subset_Icc_self hs
          have h := hevol Fopen isOpen_Ioo hU he hi hs (hWU hx)
            (fun v => (hell s hsclosed x hx v).1) (fun v => (hell s hsclosed x hx v).2)
            (fun d hd => hcurv d hd s hsclosed x hx)
            (fun d hd hdq => (hlower s hsclosed x hx d hdq).trans
              ((le_max_left B 1).trans (by
                simpa only [pow_one] using pow_le_pow_right₀ hA hd)))
          simpa only [Fopen, Poincare.Geometry.RicciFlow.Harnack.restrictFlow, mul_add, mul_one] using h
        have hprop := norm_le_exp_of_affine_deriv_bound_Icc_reference hcont hdiff hC hC
          hτ (hreference (q + 1) le_rfl x hx) hbound ht
        apply hprop.trans
        apply mul_le_mul_of_nonneg_left _ (le_trans (by norm_num) (le_max_right (Z (q + 1)) 1))
        apply Real.exp_le_exp.mpr
        apply mul_le_mul_of_nonneg_left _ (add_nonneg hC hC)
        rw [abs_le]
        constructor <;> linarith [ht.1, ht.2, hτ.1, hτ.2]
      · exact (hlower t ht x hx j (by omega)).trans (le_max_left B E)

end PoincareMT.SpacetimeBounds
