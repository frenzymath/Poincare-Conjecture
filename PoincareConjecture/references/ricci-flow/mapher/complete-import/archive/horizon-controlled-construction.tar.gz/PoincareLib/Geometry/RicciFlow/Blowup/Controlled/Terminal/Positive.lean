import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Separation.Scale
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Overlap.ScaleComparison
import PoincareLib.Topology.Manifold.NeckCap.Cap.Bounds

/-!
# Terminal scalar bounds from positive curvature and canonical neighborhoods

The neck scale lower bound on a complete positively curved three-manifold
also bounds curvature in cap cores, by the cap's scalar ratio estimate.
Thus a neck/cap cover above any fixed scalar threshold gives a global bound.

Reference: Morgan--Tian, Claim 11.7, p. 271, and Proposition 2.19,
pp. 31--32.
-/

set_option autoImplicit false

open Set
open scoped Manifold ContDiff

universe u

namespace PoincareMT

variable {M : Type u} [TopologicalSpace M] [T3Space M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
  [IsManifold (𝓡 3) ∞ M] [MeasurableSpace M] [BorelSpace M]
  {g : RiemannianMetric 3 M}

theorem EpsilonNeck.scalar_center_le_of_scale_lower
    (N : EpsilonNeck g) (D : LeviCivitaData g) {rho : ℝ}
    (hrho : 0 < rho) (hscale : rho ≤ N.scale) :
    D.scalarCurvature N.center ≤ 1 / rho ^ 2 := by
  have hscalar : 0 < D.scalarCurvature N.center := by
    rw [← N.connection.scalarCurvature_eq D]
    exact N.scalar_center_pos
  have hsquare : rho ^ 2 ≤ N.scale ^ 2 := by nlinarith [N.scale_pos]
  apply (le_div_iff₀ (sq_pos_of_pos hrho)).2
  have hprod := mul_le_mul_of_nonneg_right hsquare hscalar.le
  nlinarith [N.scale_sq_mul_scalar_center_of_connection D]

theorem CapCertificate.scalar_le_of_end_scale_lower
    (N : CapCertificate g) (D : LeviCivitaData g) {rho C : ℝ}
    (hrho : 0 < rho) (hscale : rho ≤ N.end_neck.scale)
    (hC : N.cap_constant ≤ C) {x : M} (hx : x ∈ N.carrier) :
    D.scalarCurvature x ≤ C * (1 / rho ^ 2) := by
  have hcenter : N.end_neck.center ∈ N.carrier :=
    N.end_neck_subset
      (N.end_neck.central_sphere_subset N.end_neck.center_on_central_sphere)
  have hscalar := N.scalar_lt_constant_mul hcenter hx
  have hbound := N.end_neck.scalar_center_le_of_scale_lower N.connection hrho hscale
  rw [← N.connection.scalarCurvature_eq D]
  calc
    N.connection.scalarCurvature x ≤
        N.cap_constant * N.connection.scalarCurvature N.end_neck.center := hscalar.le
    _ ≤ N.cap_constant * (1 / rho ^ 2) :=
      mul_le_mul_of_nonneg_left hbound N.cap_constant_pos.le
    _ ≤ C * (1 / rho ^ 2) := mul_le_mul_of_nonneg_right hC (by positivity)

/-- The accuracy threshold is chosen before the metric, cutoff, and cap
constant. No curvature bound is included in the neighborhood hypotheses. -/
theorem RiemannianMetric.exists_universal_neck_cap_scalar_bound_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ < 1 / 2 ∧
      ∀ (M : Type u) [TopologicalSpace M] [T3Space M]
        [ConnectedSpace M] [Nonempty M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
        [IsManifold (𝓡 3) ∞ M] [MeasurableSpace M] [BorelSpace M],
      ∀ (g : RiemannianMetric 3 M) (D : LeviCivitaData g),
        MetricComplete g → D.StrictlyPositiveSectionalCurvature →
      ∀ epsilon C cutoff : ℝ, 0 < epsilon → epsilon ≤ epsilon₀ →
        (∀ x : M, cutoff < D.scalarCurvature x →
          (∃ N : EpsilonNeck g, N.epsilon = epsilon ∧ N.center = x) ∨
          (∃ N : CapCertificate g,
            N.epsilon = epsilon ∧ N.cap_constant ≤ C ∧ x ∈ N.core)) →
        ∃ B : ℝ, 0 < B ∧ ∀ x : M, D.scalarCurvature x ≤ B := by
  obtain ⟨epsilon₀, hpos, hhalf, hscale⟩ :=
    RiemannianMetric.exists_universal_neck_scale_lower_bound.{u}
  refine ⟨epsilon₀, hpos, hhalf, ?_⟩
  intro M _ _ _ _ _ _ _ _ g D hcomplete hpositive epsilon C cutoff hepsilon hsmall hcover
  obtain ⟨rho, hrho, hneck⟩ :=
    hscale M g D hcomplete hpositive epsilon hepsilon hsmall
  refine ⟨max 1 (max cutoff (max (1 / rho ^ 2) (C * (1 / rho ^ 2)))),
    lt_of_lt_of_le zero_lt_one (le_max_left _ _), ?_⟩
  intro x
  by_cases hx : cutoff < D.scalarCurvature x
  · rcases hcover x hx with ⟨N, heq, rfl⟩ | ⟨N, heq, hC, hx⟩
    · exact (N.scalar_center_le_of_scale_lower D hrho (hneck N heq)).trans
        ((le_max_left _ _).trans ((le_max_right _ _).trans (le_max_right _ _)))
    · exact (N.scalar_le_of_end_scale_lower D hrho
        (hneck N.end_neck (N.end_neck_epsilon.trans heq)) hC
        (N.core_subset_carrier hx)).trans
        ((le_max_right _ _).trans ((le_max_right _ _).trans (le_max_right _ _)))
  · exact (le_of_not_gt hx).trans ((le_max_left _ _).trans (le_max_right _ _))

end PoincareMT
