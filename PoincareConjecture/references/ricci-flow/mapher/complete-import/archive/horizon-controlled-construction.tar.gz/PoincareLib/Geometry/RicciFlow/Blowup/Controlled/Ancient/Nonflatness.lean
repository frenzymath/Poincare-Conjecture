import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.SlabBounds
import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.Comparison
import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.CurvatureControl
import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.CurvatureControl.ScalarEvolution
import PoincareLib.Geometry.RicciFlow.Harnack.Matrix.Tensors
import PoincareLib.Geometry.Riemannian.Distance.Smoothing

/-!
# Backward nonflatness with bounds on compact time intervals

A scalar-flat slice cannot evolve to a positive scalar value when curvature
is bounded on compact time intervals. A buffered Shi estimate supplies the
smooth exhaustion needed for scalar comparison in the noncompact case.

References: Chow et al., Part II, Lemmas 15.23--15.24, pp. 283--287;
Kleiner--Lott, Proposition 41.13, p. 2678. This is the nonflatness step in
Morgan--Tian, Theorem 11.1, pp. 267--271.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle

universe u

namespace PoincareMT.RicciFlow

variable {n : ℕ} {M : Type u} [TopologicalSpace M] [T3Space M]
  [SecondCountableTopology M] [ConnectedSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]

private theorem scalarCurvature_nonpos_on_bounded_complete_slab
    (hC : RicciFlowCurvatureTheory.{u}) {T : ℝ} (F : RicciFlow n M (Icc 0 T))
    (hT : 0 ≤ T) (hcomplete : MetricComplete (F.metric 0))
    (hoperator : ∀ t ∈ Icc 0 T, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    {K D : ℝ} (hK : 0 ≤ K) (hD : 0 ≤ D)
    (hbound : ∀ t ∈ Icc 0 T, ∀ x, (F.connection t).curvatureTensorNorm x ≤ K)
    (hderiv : ∀ t ∈ Icc 0 T, ∀ x, (F.connection t).curvatureDerivativeNorm 1 x ≤ D)
    (hinit : ∀ x, (F.connection 0).scalarCurvature x ≤ 0) :
    ∀ x t, t ∈ Icc 0 T → (F.connection t).scalarCurvature x ≤ 0 := by
  classical
  have hzero : (0 : ℝ) ∈ Icc 0 T := ⟨le_rfl, hT⟩
  have hRic (t : ℝ) (ht : t ∈ Icc 0 T) (x : M) (v : TangentSpace (𝓡 n) x) :
      0 ≤ (F.connection t).ricci x v v :=
    ((F.connection t).ricci_bounds_of_nonnegative_curvatureOperator
      (hC.tensor_calculus n M (F.metric t) (F.connection t)) x (hoperator t ht x) v).1
  have hscalar (t : ℝ) (ht : t ∈ Icc 0 T) (x : M) :
      (F.connection t).scalarCurvature x ≤ (n : ℝ) ^ 2 * K :=
    (le_abs_self _).trans (((F.connection t).abs_scalarCurvature_le_curvatureTensorNorm x).trans
      (mul_le_mul_of_nonneg_left (hbound t ht x) (sq_nonneg _)))
  have hreg : ContinuousOn (fun z : M × ℝ => (F.connection z.2).scalarCurvature z.1)
      (univ ×ˢ Icc 0 T) :=
    (hC.scalar_regular n M (Icc 0 T) F).continuousOn.comp
      (f := fun z : M × ℝ => (z.2, z.1))
      (continuous_snd.prodMk continuous_fst).continuousOn (fun z hz => ⟨hz.2, hz.1⟩)
  have hsmooth (t : ℝ) (ht : t ∈ Icc 0 T) :
      ContMDiff (𝓡 n) 𝓘(ℝ, ℝ) ∞ (F.connection t).scalarCurvature :=
    Poincare.RicciFlow.Harnack.scalarCurvature_contMDiff_slice hC.toCalculus _ F t ht
  have hreaction (t : ℝ) (ht : t ∈ Icc 0 T) (x : M) :
      2 * (F.connection t).ricciNormSq x ≤
        (2 * ((n : ℝ) ^ 2 * K)) * (F.connection t).scalarCurvature x := by
    have hsq := (F.connection t).ricciNormSq_le_scalarCurvature_sq_of_ricci_nonneg
      (hC.tensor_calculus n M (F.metric t) (F.connection t)) x (hRic t ht x)
    have hnonneg : 0 ≤ (F.connection t).scalarCurvature x :=
      Finset.sum_nonneg (fun i _ => hRic t ht x _)
    have hmul := mul_le_mul_of_nonneg_right (hscalar t ht x) hnonneg
    nlinarith
  by_cases hc : IsCompact (univ : Set M)
  · apply Poincare.Parabolic.nonpos_of_deriv_le_mul_at_max_of_nonpos_outside_compact
      (K := univ) hc (F := fun x t => (F.connection t).scalarCurvature x)
      (F' := fun x t => (F.connection t).laplacian (F.connection t).scalarCurvature x +
        2 * (F.connection t).ricciNormSq x) (c := 2 * ((n : ℝ) ^ 2 * K))
      hreg
    · intro x t ht
      exact hC.scalar_evolution n M (Icc 0 T) F t ⟨ht.1.le, ht.2⟩ x
    · intro x t ht _ hmax
      have ht' : t ∈ Icc 0 T := ⟨ht.1.le, ht.2⟩
      have hlap := (F.connection t).laplacian_nonpos_of_isLocalMax (hsmooth t ht')
        (Filter.Eventually.of_forall hmax)
      linarith [hreaction t ht' x]
    · exact hinit
    · intro x hx
      exact False.elim (hx (mem_univ x))
  let : NoncompactSpace M := ⟨hc⟩
  obtain ⟨B, _, hsmoothing⟩ := RiemannianMetric.exists_uniform_smoothDistanceLike n hK
  let O : M := Classical.choice inferInstance
  obtain ⟨S, _⟩ := hsmoothing (F.metric 0) (F.connection 0) hcomplete (hbound 0 hzero) O
  have hRicDeriv : ∀ t ∈ Icc 0 T, ∀ x (v w z : TangentSpace (𝓡 n) x),
      |(F.connection t).covariantTensorDerivative (F.connection t).ricciEvaluation
        x ![v, w, z]| ≤ (n : ℝ) * D * (F.metric t).tangentNorm x v *
          (F.metric t).tangentNorm x w * (F.metric t).tangentNorm x z := by
    intro t ht x v w z
    apply ((F.connection t).abs_covariantTensorDerivative_ricci_le_curvatureDerivativeNorm
      (hC.tensor_calculus n M (F.metric t) (F.connection t)) x v w z).trans
    have hnorm (v : TangentSpace (𝓡 n) x) : 0 ≤ (F.metric t).tangentNorm x v :=
      Real.sqrt_nonneg _
    exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (hderiv t ht x) (Nat.cast_nonneg n))
        (hnorm v)) (hnorm w)) (hnorm z)
  let E := F.smoothExhaustionOfInitialOfCurvatureBound O 0 hzero S K ((n : ℝ) * D) T
    hK (by positivity)
    (fun t ht => by simpa only [sub_zero, abs_of_nonneg ht.1] using ht.2)
    hbound hRicDeriv
  apply E.nonpos_of_heat_le_mul_of_metricComplete hzero hcomplete
    (u := fun x t => (F.connection t).scalarCurvature x)
    (du := fun x t => (F.connection t).laplacian (F.connection t).scalarCurvature x +
      2 * (F.connection t).ricciNormSq x)
    (C := 2 * ((n : ℝ) ^ 2 * K)) (B := (n : ℝ) ^ 2 * K)
    (by positivity) Subset.rfl hreg hsmooth
  · intro x t ht
    exact hC.scalar_evolution n M (Icc 0 T) F t ⟨ht.1.le, ht.2⟩ x
  · exact fun x t ht => hscalar t ht x
  · intro x t ht
    linarith [hreaction t ⟨ht.1.le, ht.2⟩ x]
  · exact hinit

/-- Scalar nonpositivity propagates from one ancient slice to the terminal
slice using only the curvature bound on a buffered compact time interval. -/
theorem scalarCurvature_terminal_nonpos_of_locally_bounded_ancient_slice_nonpos
    (hC : RicciFlowCurvatureTheory.{u}) (F : RicciFlow n M (Iic 0))
    (hcomplete : ∀ t ≤ 0, MetricComplete (F.metric t))
    (hoperator : ∀ t ≤ 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    (hbound : ∀ a < 0, ∃ K : ℝ, 0 ≤ K ∧
      ∀ t ∈ Icc a 0, ∀ x, (F.connection t).curvatureTensorNorm x ≤ K)
    {a : ℝ} (ha : a < 0)
    (hinit : ∀ x, (F.connection a).scalarCurvature x ≤ 0) :
    ∀ x, (F.connection 0).scalarCurvature x ≤ 0 := by
  have hshift : (fun t : ℝ => t + a) '' Icc 0 (-a) ⊆ Iic 0 := by
    rintro _ ⟨t, ht, rfl⟩
    change t + a ≤ 0
    linarith [ht.2]
  have hne : (Icc 0 (-a)).Nontrivial := by
    refine ⟨0, ⟨le_rfl, by linarith⟩, -a, ⟨by linarith, le_rfl⟩, ?_⟩
    linarith
  let G := F.translate a hshift ordConnected_Icc hne
  obtain ⟨K, hK, hcurv⟩ := hbound (a - 1) (by linarith)
  obtain ⟨D, hD, hderiv⟩ := F.exists_curvatureDerivativeNorm_bound_on_buffered_slab
    hC.toCalculus (a := a - 1) (b := 0) (δ := 1) (by linarith)
    (fun _ ht => ht.2) (by norm_num) (hcomplete _ (by linarith)) hcurv 1
  have hresult : ∀ x t, t ∈ Icc 0 (-a) → (G.connection t).scalarCurvature x ≤ 0 := by
    refine scalarCurvature_nonpos_on_bounded_complete_slab hC G (by linarith)
      (by simpa only [G, translate, zero_add] using hcomplete a ha.le)
      (fun t ht => hoperator (t + a) (by linarith [ht.2])) hK hD.le ?_ ?_ ?_
    · intro t ht x
      exact hcurv (t + a) (by constructor <;> linarith [ht.1, ht.2]) x
    · intro t ht x
      exact hderiv (t + a) (by constructor <;> linarith [ht.1, ht.2]) x
    · intro x
      exact (congrArg (fun t => (F.connection t).scalarCurvature x ≤ 0) (zero_add a)).mpr
        (hinit x)
  intro x
  have hx := hresult x (-a) ⟨by linarith, le_rfl⟩
  change (F.connection (-a + a)).scalarCurvature x ≤ 0 at hx
  exact (congrArg (fun t => (F.connection t).scalarCurvature x ≤ 0) (neg_add_cancel a)).mp hx

/-- A positive terminal scalar value gives a nonflat slice at every ancient
time, under bounds uniform in space on compact time intervals. -/
theorem nonflat_of_terminal_scalar_pos_of_locally_bounded_ancient
    (hC : RicciFlowCurvatureTheory.{u}) (F : RicciFlow n M (Iic 0))
    (hcomplete : ∀ t ≤ 0, MetricComplete (F.metric t))
    (hoperator : ∀ t ≤ 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    (hbound : ∀ a < 0, ∃ K : ℝ, 0 ≤ K ∧
      ∀ t ∈ Icc a 0, ∀ x, (F.connection t).curvatureTensorNorm x ≤ K)
    (hnonflat : ∃ p : M, 0 < (F.connection 0).scalarCurvature p) :
    ∀ t ≤ 0, ∃ x : M, (F.connection t).curvatureTensorNorm x ≠ 0 := by
  intro t ht
  have hpos : ∃ x : M, 0 < (F.connection t).scalarCurvature x := by
    rcases lt_or_eq_of_le ht with ht | rfl
    · by_contra hn
      push Not at hn
      obtain ⟨p, hp⟩ := hnonflat
      exact hp.not_ge
        (F.scalarCurvature_terminal_nonpos_of_locally_bounded_ancient_slice_nonpos
          hC hcomplete hoperator hbound ht hn p)
    · exact hnonflat
  obtain ⟨x, hx⟩ := hpos
  refine ⟨x, fun hzero => ?_⟩
  have h := (F.connection t).abs_scalarCurvature_le_curvatureTensorNorm x
  rw [hzero, mul_zero, abs_of_pos hx] at h
  exact hx.not_ge h

end PoincareMT.RicciFlow
