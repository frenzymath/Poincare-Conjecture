import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.DistantTriangles
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.SeparatingNecks
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Geometry.NeckCurvature

/-!
# Uniform past scalar bounds at distant neck centers

For a fixed distant center, small high-curvature necks separate the two fixed
triangle endpoints. A fixed path avoiding the center then bounds their scale
away from zero throughout the past interval.
Reference: Morgan--Tian, Claims 11.13--11.14, pp. 276--277.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongGeometry

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem exists_uniform_past_distant_neck_center_scalar_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T epsilon : ℝ} (hT : 0 < T) (hepsilon : 0 < epsilon)
    (hsmall : epsilon ≤ 1 / (400 * Real.pi))
    (L : BlowupLimitFlow.{u} (Ioc (-T) 0)) (p : L.carrier.carrier) :
    ∃ A : ℝ, 0 < A ∧ ∀ y : L.carrier.carrier,
      A ≤ ((L.flow.metric 0).edist p y).toReal → ∃ B : ℝ, 0 < B ∧
      ∀ t ∈ Ioc (-T) 0, ∀ N : EpsilonNeck (L.flow.metric t),
        N.epsilon = epsilon → N.center = y →
        (L.flow.connection t).scalarCurvature y ≤ B := by
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  obtain ⟨A, hA, htriangle⟩ := exists_uniform_past_large_triangles P04 P06 hT L p
  refine ⟨A, hA, ?_⟩
  intro y hy
  let d := ((L.flow.metric 0).edist p y).toReal
  have hd : 0 < d := hA.trans_le hy
  obtain ⟨z, hz⟩ := htriangle y hy
  have hpy : p ≠ y := by
    intro heq
    have hh : d = 0 := by
      simp only [d, heq, RiemannianMetric.edist, Manifold.riemannianEDist_self,
        ENNReal.toReal_zero]
    linarith
  have hzy : z ≠ y := by
    intro heq
    have hh := (hz 0 L.zero_mem).2.1
    simp only [heq, RiemannianMetric.edist, Manifold.riemannianEDist_self,
      ENNReal.toReal_zero] at hh
    exact (not_le_of_gt hd) hh
  obtain ⟨cutoff, _, hseparator⟩ := EpsilonNeck.exists_high_curvature_separator_cutoff
    (L.flow.metric 0) y hepsilon hsmall hd
  obtain ⟨B, hB, hbound⟩ := exists_uniform_scalar_bound_for_separating_necks P04 L hpy hzy
  refine ⟨max cutoff B, hB.trans_le (le_max_right _ _), ?_⟩
  intro t ht N heq hcenter
  by_cases hlow : (L.flow.connection t).scalarCurvature y ≤ cutoff
  · exact hlow.trans (le_max_left _ _)
  obtain ⟨ha, hb, ha', hb', hfar⟩ := hz t ht
  have hsec : (L.flow.connection t).NonnegativeSectionalCurvature := fun x v w =>
    (L.flow.connection t).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
      x (L.nonnegative_curvature_operator t ht x) v w
  apply (hbound t ht N hcenter ?_).trans (le_max_right _ _)
  exact hseparator (L.flow.metric t) (L.flow.connection t) (L.complete t ht) hsec
    (ControlledLongDistance.terminal_toReal_edist_le P04 L ht y) N heq hcenter
    (lt_of_not_ge hlow) p z ha hb ha' hb' hfar

end PoincareMT.ControlledLongGeometry
