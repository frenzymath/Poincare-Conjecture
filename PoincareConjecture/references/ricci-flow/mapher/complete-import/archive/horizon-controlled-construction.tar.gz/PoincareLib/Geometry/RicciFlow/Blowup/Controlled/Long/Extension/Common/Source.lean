import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.SourceBounds

/-! # Transfer a prescribed compact scalar bound to original source trajectories -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable

theorem eventually_scalar_bound_on_source_trajectories_of_limit_bound
    {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
    (G : GeneralizedBlowupConvergence S J.domain)
    (P04 : RicciFlowCurvatureTheory.{u})
    {A B : ℝ} (hA : 0 < A) {I : Set ℝ} (hI : IsCompact I) (hIJ : I ⊆ J.domain)
    (hbound : ∀ t ∈ I, ∀ y ∈ closure ((G.limit.flow.metric 0).ball G.limit.base (2 * A)),
      (G.limit.flow.connection t).scalarCurvature y ≤ B) :
    ∀ᶠ k in atTop, ∀ V : Set ℝ,
      ∀ e : GeneralizedFlowCylinder (S.flow (G.subsequence k))
        ((S.flow (G.subsequence k)).slice (S.base (G.subsequence k)).1)
        (S.base (G.subsequence k)).1 (S.scale (G.subsequence k)) V
        (S.baseBall (G.subsequence k) A),
      V.OrdConnected → ∀ hzero : 0 ∈ V,
      (∀ x ∈ S.baseBall (G.subsequence k) A,
        e.pointMap 0 hzero x = (⟨(S.base (G.subsequence k)).1, x⟩ :
          (S.flow (G.subsequence k)).point)) →
      ∀ t ∈ I, ∀ ht : t ∈ V, ∀ x ∈ S.baseBall (G.subsequence k) A,
        (S.flow (G.subsequence k)).scalar (e.pointMap t ht x) <
          (B + 1) * S.scale (G.subsequence k) := by
  let K := closure ((G.limit.flow.metric 0).ball G.limit.base (2 * A))
  have hK : IsCompact K :=
    (G.limit.flow.metric 0).isCompact_closure_ball_of_metricComplete
      (G.limit.complete 0 G.limit.zero_mem) G.limit.base (2 * A)
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset hK
  filter_upwards [G.eventually_normalizedSource_scalar_error_on_compact P04 (hI.prod hK)
    (fun z hz => hIJ hz.1) (by norm_num : (0 : ℝ) < 1),
    G.eventually_baseBall_subset_zeroSliceEmbedding_image_ball hA (by norm_num : (1 : ℝ) < 2),
    G.exhaustion.time_cofinal I hI hIJ, eventually_ge_atTop j]
    with k hscalar hcover htime hjk V e hV hzero he t ht hte x hx
  obtain ⟨y, hy, hyx⟩ := hcover hx
  have hyK : y ∈ K := subset_closure hy
  have hyE : y ∈ G.exhaustion.space k := G.exhaustion.space_increasing hjk (hj hyK)
  have hz : (G.embedding k).pointMap 0 (G.zero_mem_cylinder k) y =
      e.pointMap 0 hzero x := by
    rw [(G.embedding k).zeroSliceHomeomorph_pointMap (G.exhaustion.space_open k), he x hx]
    exact congrArg (fun z => (⟨(S.base (G.subsequence k)).1, z⟩ :
      (S.flow (G.subsequence k)).point)) hyx
  have hsame := (G.embedding k).pointMap_eq_on_overlap e ordConnected_Icc hV hyE hx
    (G.zero_mem_cylinder k) hzero hz t (htime ht) hte
  have herror := (abs_lt.mp (hscalar (t, y) ⟨ht, hyK⟩ (htime ht))).2
  have hnorm : (G.normalizedSourceConnection k t).scalarCurvature
      ((G.embedding k).forward t (htime ht) y) =
      (S.scale (G.subsequence k))⁻¹ *
        (S.flow (G.subsequence k)).scalar (e.pointMap t hte x) := by
    rw [normalizedSourceConnection, rescaledMetric_scalarCurvature]
    change (S.scale (G.subsequence k))⁻¹ *
      (S.flow (G.subsequence k)).scalar ((G.embedding k).pointMap t (htime ht) y) = _
    rw [hsame]
  rw [hnorm] at herror
  have hQ : 0 < S.scale (G.subsequence k) := S.base_scalar_pos (G.subsequence k)
  apply (div_lt_iff₀ hQ).mp
  have hh : (S.scale (G.subsequence k))⁻¹ *
      (S.flow (G.subsequence k)).scalar (e.pointMap t hte x) < B + 1 := by
    linarith [hbound t ht y hyK]
  simpa only [div_eq_mul_inv, mul_comm] using hh

end PoincareMT.GeneralizedBlowupConvergence
