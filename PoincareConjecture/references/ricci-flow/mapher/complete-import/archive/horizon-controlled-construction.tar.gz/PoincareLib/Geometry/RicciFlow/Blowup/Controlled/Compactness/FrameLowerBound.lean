import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.NegativeCurvature
import PoincareLib.Geometry.Riemannian.Curvature.ThreeDimensional

/-!
# Curvature lower bounds in an arbitrary frame

In dimension three every unit two-form is a tangent plane. The native
negative sectional part therefore controls the curvature quadratic form
in any frame, with the induced metric quadratic form as its coefficient.
Source: Morgan--Tian, Theorem 11.1, pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open scoped Manifold ContDiff Bundle BigOperators

universe u

namespace PoincareMT.ControlledBlowupCompactness

private theorem inner_lower_bound_of_unit
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (T : E →ₗ[ℝ] E) (c : ℝ)
    (h : ∀ z : E, ‖z‖ = 1 → c ≤ inner ℝ z (T z)) (z : E) :
    c * inner ℝ z z ≤ inner ℝ z (T z) := by
  by_cases hz : z = 0
  · simp [hz]
  have hn : ‖z‖ ≠ 0 := norm_ne_zero_iff.mpr hz
  have hu : ‖‖z‖⁻¹ • z‖ = 1 := by
    rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hn]
  have hh := mul_le_mul_of_nonneg_left (h (‖z‖⁻¹ • z) hu) (sq_nonneg ‖z‖)
  rw [map_smul, real_inner_smul_left, real_inner_smul_right] at hh
  rw [real_inner_self_eq_norm_sq]
  calc
    c * ‖z‖ ^ 2 = ‖z‖ ^ 2 * c := mul_comm _ _
    _ ≤ ‖z‖ ^ 2 * (‖z‖⁻¹ * (‖z‖⁻¹ * inner ℝ z (T z))) := hh
    _ = inner ℝ z (T z) := by field_simp

end PoincareMT.ControlledBlowupCompactness

namespace PoincareMT.LeviCivitaData

theorem curvature_quadratic_lower_bound_of_negativePart
    {M : Type u} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {g : RiemannianMetric 3 M} (D : LeviCivitaData g) (x : M)
    {eta : ℝ} (hneg : D.negativeCurvaturePart x ≤ eta)
    {ι : Type*} [Fintype ι] (v : ι → TangentSpace (𝓡 3) x) (A : ι → ι → ℝ) :
    -eta * (∑ a, ∑ b, ∑ c, ∑ d, A a b * A c d *
      (g.inner x (v a) (v c) * g.inner x (v b) (v d) -
        g.inner x (v a) (v d) * g.inner x (v b) (v c))) ≤
      ∑ a, ∑ b, ∑ c, ∑ d,
        A a b * A c d * D.curvatureTensor x (v a) (v b) (v c) (v d) := by
  classical
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
    ⟨g.toRiemannianMetric⟩
  obtain ⟨b, hsym, hmetric, hunit, hpair, _⟩ :=
    D.three_dimensional_curvature_operator_spectrum D.intrinsicCurvatureTensorCalculus x
  let W (u v : TangentSpace (𝓡 3) x) : EuclideanSpace ℝ (Fin 3) :=
    WithLp.toLp 2 (crossProduct (b.repr u) (b.repr v))
  let T := Poincare.Geometry.Curvature.Operator.curvatureOperator
    (fun i j k l => D.curvatureTensor x (b i) (b j) (b k) (b l))
  let z := ∑ a, ∑ b, A a b • W (v a) (v b)
  have hu (w : EuclideanSpace ℝ (Fin 3)) (hw : ‖w‖ = 1) :
      -eta ≤ inner ℝ w (T w) := by
    obtain ⟨u, v, huv, hW⟩ := hunit w hw
    have hsection := MetricSurgery.neg_negativeCurvaturePart_le_sectional_of_orthonormal D x huv
    rw [MetricSurgery.sectional_eq_tensor_of_orthonormal D x huv, hpair, hW] at hsection
    exact (neg_le_neg hneg).trans hsection
  have hh := ControlledBlowupCompactness.inner_lower_bound_of_unit T (-eta) hu z
  have hgram : inner ℝ z z = ∑ a, ∑ b, ∑ c, ∑ d, A a b * A c d *
      (g.inner x (v a) (v c) * g.inner x (v b) (v d) -
        g.inner x (v a) (v d) * g.inner x (v b) (v c)) := by
    simp only [z, sum_inner, inner_sum, real_inner_smul_left, real_inner_smul_right]
    apply Finset.sum_congr rfl
    intro a _
    apply Finset.sum_congr rfl
    intro b _
    apply Finset.sum_congr rfl
    intro c _
    apply Finset.sum_congr rfl
    intro d _
    rw [show inner ℝ (W (v c) (v d)) (W (v a) (v b)) =
        inner ℝ (W (v a) (v b)) (W (v c) (v d)) from real_inner_comm _ _,
      show inner ℝ (W (v a) (v b)) (W (v c) (v d)) = _ from
      hmetric (v a) (v b) (v c) (v d)]
    ring
  have hcurve : inner ℝ z (T z) = ∑ a, ∑ b, ∑ c, ∑ d,
      A a b * A c d * D.curvatureTensor x (v a) (v b) (v c) (v d) := by
    simp only [z, map_sum, map_smul, sum_inner, inner_sum,
      real_inner_smul_left, real_inner_smul_right]
    apply Finset.sum_congr rfl
    intro a _
    apply Finset.sum_congr rfl
    intro b _
    apply Finset.sum_congr rfl
    intro c _
    apply Finset.sum_congr rfl
    intro d _
    rw [show inner ℝ (W (v c) (v d)) (T (W (v a) (v b))) =
        inner ℝ (T (W (v a) (v b))) (W (v c) (v d)) from real_inner_comm _ _,
      show inner ℝ (T (W (v a) (v b))) (W (v c) (v d)) =
        inner ℝ (W (v a) (v b)) (T (W (v c) (v d))) from hsym _ _, hpair]
    ring
  simpa only [hgram, hcurve] using hh

end PoincareMT.LeviCivitaData
