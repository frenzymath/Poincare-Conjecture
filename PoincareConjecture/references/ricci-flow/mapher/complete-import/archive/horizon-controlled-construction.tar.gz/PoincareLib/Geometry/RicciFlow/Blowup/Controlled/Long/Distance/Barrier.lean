import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.AncientVolume.Splitting.DistanceDistortion

/-! # Integrating the square-root distance-distortion barrier -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledLongDistance

theorem backward_add_barrier_le_of_upper_supports
    {f B dB : ℝ → ℝ} {a b : ℝ} (hab : a ≤ b)
    (hf : ContinuousOn f (Icc a b)) (hB : ContinuousOn B (Icc a b))
    (hdB : ∀ t ∈ Ioc a b, HasDerivAt B (dB t) t)
    (hsupport : ∀ t ∈ Ioc a b, ∃ u : ℝ → ℝ,
      u t = f t ∧ (∀ s, f s ≤ u s) ∧ DifferentiableAt ℝ u t ∧ -dB t ≤ deriv u t) :
    f a + B a ≤ f b + B b := by
  have hh := Poincare.AncientVolume.backward_image_le_add_of_upper_supports
    (f := fun t => f t + B t) (C := 0) hab (hf.add hB) (by
      intro t ht
      obtain ⟨u, heq, hupper, hu, hder⟩ := hsupport t ht
      have hd := hu.hasDerivAt.add (hdB t ht)
      refine ⟨fun s => u s + B s, by simp only [heq], fun s => add_le_add (hupper s) le_rfl,
        hd.differentiableAt, ?_⟩
      change -0 ≤ deriv (u + B) t
      rw [hd.deriv]
      linarith)
  simpa only [zero_mul, add_zero] using hh

theorem toReal_edist_add_sqrt_le
    {M : Type*} [TopologicalSpace M] [T3Space M] [ConnectedSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {J : Set ℝ} (F : RicciFlow 3 M J)
    {a b T Q : ℝ} (hT : 0 < T) (hQ : 0 < Q) (hab : a ≤ b)
    (ha : -T < a) (hJ : Icc a b ⊆ interior J)
    (hcomplete : ∀ t ∈ Icc a b, MetricComplete (F.metric t))
    (hRic : ∀ t ∈ Icc a b, ∀ x : M, ∀ v : TangentSpace (𝓡 3) x,
      0 ≤ (F.connection t).ricci x v v)
    (hupper : ∀ t ∈ Icc a b, ∀ x : M, ∀ v : TangentSpace (𝓡 3) x,
      (F.connection t).ricci x v v ≤ (Q * T / (t + T)) * (F.metric t).inner x v v)
    (p x : M) :
    ((F.metric a).edist p x).toReal + 40 * Real.sqrt (Q * T) * Real.sqrt (a + T) ≤
      ((F.metric b).edist p x).toReal + 40 * Real.sqrt (Q * T) * Real.sqrt (b + T) := by
  by_cases hpx : p = x
  · subst x
    simp only [RiemannianMetric.edist, Manifold.riemannianEDist_self, ENNReal.toReal_zero, zero_add]
    exact mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt (by linarith)) (by positivity)
  have hjoint := F.continuousOn_toReal_edist_of_ricci_nonneg_intrinsic hJ
    (hcomplete b ⟨hab, le_rfl⟩) hRic p
  have hcont : ContinuousOn (fun t => ((F.metric t).edist p x).toReal) (Icc a b) :=
    hjoint.comp (continuous_id.prodMk continuous_const).continuousOn (fun t ht => ⟨ht, mem_univ x⟩)
  apply backward_add_barrier_le_of_upper_supports hab hcont
    ((continuous_const.mul (Real.continuous_sqrt.comp (continuous_id.add continuous_const))).continuousOn)
    (dB := fun t => 20 * Real.sqrt (Q * T) / Real.sqrt (t + T))
  · intro t ht
    have htpos : 0 < t + T := by linarith [ht.1]
    convert (((hasDerivAt_id t).add_const T).sqrt htpos.ne').const_mul
      (40 * Real.sqrt (Q * T)) using 1 <;> first | rfl | (simp only [id_eq]; ring)
  · intro t ht
    have htpos : 0 < t + T := by linarith [ht.1]
    let lambda := Q * T / (t + T)
    let scale := Real.sqrt (Q * T) / Real.sqrt (t + T)
    have hlambda : 0 < lambda := div_pos (mul_pos hQ hT) htpos
    have hscale : 0 < scale := div_pos (Real.sqrt_pos.mpr (mul_pos hQ hT)) (Real.sqrt_pos.mpr htpos)
    have hsquare : lambda = scale ^ 2 := by
      dsimp [lambda, scale]
      rw [div_pow, Real.sq_sqrt (mul_pos hQ hT).le, Real.sq_sqrt htpos.le]
    have hconstant : 4 * (((2 + 1 : ℕ) : ℝ)) * scale + 8 * lambda / scale =
        20 * Real.sqrt (Q * T) / Real.sqrt (t + T) := by
      rw [hsquare]
      have heq : 4 * (((2 + 1 : ℕ) : ℝ)) * scale + 8 * scale ^ 2 / scale = 20 * scale := by
        norm_num
        field_simp
        ring
      rw [heq]
      dsimp [scale]
      ring
    let r := ((F.metric t).edist p x).toReal + 1
    have hr : 0 < r := by dsimp [r]; positivity
    have hx : x ∈ (F.metric t).ball p r := by
      change (F.metric t).edist p x < ENNReal.ofReal r
      rw [← ENNReal.ofReal_toReal ((F.metric t).edist_ne_top p x)]
      exact (ENNReal.ofReal_lt_ofReal_iff hr).mpr (by dsimp [r]; linarith)
    obtain ⟨U, rho, _, hxU, _, heq, habove, _, _, hd, hder⟩ :=
      F.exists_distance_spacetime_upper_support (hJ (Ioc_subset_Icc_self ht)) (by norm_num : 0 < 2)
        (hcomplete t (Ioc_subset_Icc_self ht)) (hRic t (Ioc_subset_Icc_self ht))
        hlambda.le hscale p x hx hpx (fun y _ v => hupper t (Ioc_subset_Icc_self ht) y v)
    refine ⟨fun s => rho s x, heq, fun s => habove s x hxU, hd, ?_⟩
    rw [hconstant] at hder
    exact hder

end PoincareMT.ControlledLongDistance
