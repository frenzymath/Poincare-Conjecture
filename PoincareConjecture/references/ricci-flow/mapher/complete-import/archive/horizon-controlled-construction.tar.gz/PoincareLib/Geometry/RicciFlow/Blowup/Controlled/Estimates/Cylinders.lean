import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Curvature
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Volume
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Cylinders.Compact
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.RegularLimit.Canonical.Cap.BallClosure

/-!
# Controlled cylinders on each fixed terminal ball

Compact spatial gluing promotes surviving worldlines to actual controlled
cylinders. Their duration and curvature bound may depend on the terminal
radius. Reference: Morgan--Tian Corollary 11.3, p. 269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.GeneralizedBlowupSequence

theorem closure_baseBall_subset (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
    {A A' : ℝ} (hA : 0 < A) (hAA' : A < A') :
    closure (S.baseBall k A) ⊆ S.baseBall k A' := by
  have hsqrt : 0 < Real.sqrt (S.scale k) := Real.sqrt_pos.mpr (S.base_scalar_pos k)
  rw [baseBall, ((S.flow k).metric (S.base k).1).closure_ball_eq_edist_le
    (S.base k).2 (div_pos hA hsqrt)]
  intro x hx
  exact hx.trans_lt ((ENNReal.ofReal_lt_ofReal_iff (div_pos (hA.trans hAA') hsqrt)).mpr
    (div_lt_div_of_pos_right hAA' hsqrt))

end PoincareMT.GeneralizedBlowupSequence

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

/-- The fixed-ball cylinder is built from the original maximal worldlines;
its estimates hold throughout the closed normalized time interval. -/
theorem eventually_controlled_cylinders_on_fixed_ball
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    (A : ℝ) (hA : 0 < A) :
    ∃ T B : ℝ, 0 < T ∧ 0 < B ∧ ∀ eta : ℝ, 0 < eta →
      ∀ᶠ k : ℕ in atTop, Nonempty (ControlledBlowupCylinder S k A T B eta) := by
  classical
  obtain ⟨T, B, hT, hB, hworldlines⟩ :=
    H.eventually_curvature_bounded_worldlines P04 hbound (A + 1) (by linarith)
  refine ⟨T, B, hT, hB, ?_⟩
  intro eta heta
  filter_upwards [hworldlines eta heta, H.balls_compact A hA] with k hk hcompact
  let K := closure (S.baseBall k A)
  have hKsub : K ⊆ S.baseBall k (A + 1) := S.closure_baseBall_subset k hA (by linarith)
  have hKne : K.Nonempty := ⟨(S.base k).2, subset_closure (S.base_mem_baseBall k hA)⟩
  choose W hI hcurv using fun x : K => hk x.1 (hKsub x.2)
  let w := fun x : K => (W x).embedding.restrict (hI x) Subset.rfl
  have hw0 : ∀ x : K, (w x).pointMap 0 ⟨by linarith, le_rfl⟩ x.1 =
      (⟨(S.base k).1, x.1⟩ : (S.flow k).point) := fun x => (W x).zero_identity
  obtain ⟨e, he0, hecurv⟩ :=
    GeneralizedFlowCylinder.exists_on_compact_of_singletons_preserving hcompact hKne
      (by linarith : -T ≤ 0) w hw0
      (fun _ _ p => |(S.flow k).curvatureNorm p| ≤ B * S.scale k ∧
        ((S.flow k).connection p.1).negativeCurvaturePart p.2 ≤ eta * S.scale k)
      (fun x s hs => hcurv x s hs)
  refine ⟨{
    embedding := e.restrict Subset.rfl subset_closure
    zero_identity := fun _ x hx => he0 x (subset_closure hx)
    curvature_bound := fun s hs x hx => (hecurv s hs x (subset_closure hx)).1
    negative_curvature_bound := fun s hs x hx => (hecurv s hs x (subset_closure hx)).2 }⟩

/-- Terminal volume follows from a single fixed-ball cylinder and the supplied
parabolic noncollapse at the basepoint. -/
theorem terminal_volume_of_boundedDistance
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S) :
    ∃ rho v : ℝ, 0 < rho ∧ 0 < v ∧ ∀ᶠ k : ℕ in atTop,
      ENNReal.ofReal (v / (Real.sqrt (S.scale k)) ^ 3) ≤
        calibratedMetricVolume ((S.flow k).metric (S.base k).1) (S.baseBall k rho) := by
  obtain ⟨T, B, hT, hB, hcyl⟩ :=
    H.eventually_controlled_cylinders_on_fixed_ball P04 hbound 1 zero_lt_one
  exact H.terminal_volume_of_eventual_cylinders zero_lt_one hT hB.le (hcyl 1 zero_lt_one)

end PoincareMT.M30CommonBlowupControls

namespace PoincareMT.M30ControlledBlowupPredecessors

/-- One threshold, chosen from dense M29, works for every fixed terminal radius. -/
theorem exists_fixed_ball_cylinder_threshold (P : M30ControlledBlowupPredecessors.{u}) :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 400 ∧
      ∀ (S : GeneralizedBlowupSequence.{u}) (epsilon C kappa r₀ mu : ℝ),
        epsilon ≤ 2 * epsilon₀ → M30CommonBlowupControls S epsilon C kappa r₀ mu →
        ∀ A : ℝ, 0 < A → ∃ T B : ℝ, 0 < T ∧ 0 < B ∧
          ∀ eta : ℝ, 0 < eta → ∀ᶠ k : ℕ in atTop,
            Nonempty (ControlledBlowupCylinder S k A T B eta) := by
  obtain ⟨epsilon₀, hpos, hsmall, hdistance⟩ :=
    M30CommonBlowupControls.exists_universal_boundedDistance_threshold P.m29
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro S epsilon C kappa r₀ mu hepsilon H A hA
  exact H.eventually_controlled_cylinders_on_fixed_ball P.m04
    (hdistance S epsilon C kappa r₀ mu hepsilon H) A hA

end PoincareMT.M30ControlledBlowupPredecessors
