import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Jets

/-! # Smooth retained source coefficients on the full finite domain -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

theorem source_contDiffOn_full_reference_domain (q : G.limitCarrier.carrier) (k : ℕ) :
    ContDiffOn ℝ ∞ (G.spatialSpacetimeCoefficients q k)
      (Ioc (-T / 2) (T / 2) ×ˢ G.referenceChartSource q k) := by
  have hzero : 0 ∈ Ioo (-T / 2) (T / 2) := ⟨by linarith, by linarith⟩
  have he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap q k 0)
      (G.referenceChartSource q k) := fun x hx =>
    (G.referenceChartMap_contMDiffAt q k hzero hx.1 hx.2).contMDiffWithinAt
  have hs : ContDiffOn ℝ ∞
      (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).metric z.1).pullbackCoefficients
          (G.referenceChartMap q k 0) z.2)
      (Icc (-T) 0 ×ˢ G.referenceChartSource q k) :=
    ((e (G.subsequence k)).smallFlow (hA _) hT).contDiffOn_pullbackCoefficients_within
      (G.referenceChartSource_open q k) he
  have hshift : ContDiff ℝ ∞ (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
      (z.1 + (-T / 2), z.2)) := (contDiff_fst.add contDiff_const).prodMk contDiff_snd
  have hp := hs.comp (s := Ioc (-T / 2) (T / 2) ×ˢ G.referenceChartSource q k)
    hshift.contDiffOn
      (fun z hz => ⟨⟨by linarith [hz.1.1], by linarith [hz.1.2]⟩, hz.2⟩)
  exact hp

/-- Every compact coordinate test set eventually lies in a smooth retained
source domain, with the canonical included-endpoint time derivative. -/
theorem eventually_source_contDiffWithinAt_full_domain
    (q : G.limitCarrier.carrier)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKU : K ⊆ Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target) :
    ∀ᶠ k in atTop, ∀ z ∈ K, ContDiffWithinAt ℝ ∞
      (G.spatialSpacetimeCoefficients q k)
      (Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target) z := by
  have hzero : 0 ∈ Ioo (-T / 2) (T / 2) := ⟨by linarith, by linarith⟩
  have hKs : Prod.snd '' K ⊆ (extChartAt (𝓡 3) q).target := by
    rintro _ ⟨z, hz, rfl⟩
    exact (hKU hz).2
  filter_upwards [G.eventually_subset_referencePartialChart_source q hzero
    (hK.image continuous_snd) hKs] with k hk z hz
  have hzs : z.2 ∈ G.referenceChartSource q k := hk (mem_image_of_mem Prod.snd hz)
  have hs := source_contDiffOn_full_reference_domain G q k z ⟨(hKU hz).1, hzs⟩
  apply hs.mono_of_mem_nhdsWithin
  have hn : Prod.snd ⁻¹' G.referenceChartSource q k ∈ 𝓝 z :=
    ((G.referenceChartSource_open q k).preimage continuous_snd).mem_nhds hzs
  apply mem_of_superset (inter_mem (mem_nhdsWithin_of_mem_nhds hn) self_mem_nhdsWithin)
  exact fun w hw => ⟨hw.2.1, hw.1⟩

end PoincareMT.ControlledBlowupCompactness
