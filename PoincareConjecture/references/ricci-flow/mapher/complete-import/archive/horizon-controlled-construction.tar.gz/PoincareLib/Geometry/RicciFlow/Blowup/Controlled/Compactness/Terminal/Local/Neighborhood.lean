import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Charts
import PoincareLib.Geometry.Manifold.InverseFunction.LocalDiffeomorph

/-!
# Captured terminal coordinate neighborhoods

An exhaustion embedding with uniformly bounded compact images gives actual
source-ball charts on a fixed neighborhood of each terminal point. A larger
source ball leaves the spatial buffer needed by the curvature estimates.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8
set_option maxHeartbeats 600000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.ControlledTerminal

open ControlledBlowupCylinder

theorem exists_captured_terminal_partial_charts
    {S : GeneralizedBlowupSequence.{u}} (sigma : ℕ → ℕ)
    {L : Type v} [TopologicalSpace L] [ChartedSpace (EuclideanSpace ℝ (Fin 3)) L]
    [IsManifold (𝓡 3) ∞ L]
    (E : ℕ → Set L) (hE : ∀ j, IsOpen (E j)) (hEmono : Monotone E)
    (hEcover : ⋃ j, E j = univ) (f : ∀ k, L → S.terminalComponent (sigma k))
    (hemb : ∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x))
    (hlocal : ∀ k, IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k))
    (himage : ∀ K : Set L, IsCompact K → ∃ R : ℝ, 0 < R ∧
      ∀ᶠ k in atTop, ∀ x ∈ K, (f k x).val ∈ S.baseBall (sigma k) R)
    (q : L) :
    ∃ rho R : ℝ, 0 < rho ∧ 0 < R ∧
      closedBall (extChartAt (𝓡 3) q q) (2 * rho) ⊆ (extChartAt (𝓡 3) q).target ∧
      ∀ A : ℝ, R ≤ A → ∀ᶠ k in atTop,
        ∃ Phi : PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
          (sourceBall S (sigma k) A) ∞,
          Phi.source = ball (extChartAt (𝓡 3) q q) (2 * rho) ∧
          (∀ z ∈ Phi.source, (Phi z).val = (f k ((extChartAt (𝓡 3) q).symm z)).val ∧
            (Phi z).val ∈ S.baseBall (sigma k) R) ∧
          ∀ (T B eta : ℝ) (cyl : ControlledBlowupCylinder S (sigma k) A T B eta)
            (hT : 0 < T), ∀ z ∈ Phi.source,
            ((cyl.ordinaryFlow hT).metric 0).pullbackCoefficients Phi z =
              (S.terminalComponentMetric (sigma k)).pullbackCoefficients
                (f k ∘ (extChartAt (𝓡 3) q).symm) z := by
  let c := extChartAt (𝓡 3) q
  obtain ⟨r, hr, hrc⟩ := Metric.mem_nhds_iff.mp
    ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds (mem_extChartAt_target q))
  let rho := r / 4
  have hrho : 0 < rho := by dsimp [rho]; positivity
  let K := closedBall (c q) (2 * rho)
  let U := ball (c q) (2 * rho)
  have hKc : K ⊆ c.target :=
    (closedBall_subset_ball (by dsimp [rho]; linarith : 2 * rho < r)).trans hrc
  have hK : IsCompact K := isCompact_closedBall _ _
  have hcompact : IsCompact (c.symm '' K) :=
    hK.image_of_continuousOn ((continuousOn_extChartAt_symm q).mono hKc)
  obtain ⟨j, hj⟩ := hcompact.elim_directed_cover E hE
    (by rw [hEcover]; exact subset_univ _) hEmono.directed_le
  obtain ⟨R, hR, himageR⟩ := himage _ hcompact
  refine ⟨rho, R, hrho, hR, hKc, fun A hRA => ?_⟩
  have hA : 0 < A := hR.trans_le hRA
  filter_upwards [himageR, eventually_ge_atTop j] with k hk hjk
  have hUE : ∀ x ∈ U, c.symm x ∈ E k := fun x hx =>
    hEmono hjk (hj (mem_image_of_mem _ (ball_subset_closedBall hx)))
  let phi := f k ∘ c.symm
  have hphi : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ phi U := by
    have hc : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ c.symm c.target := by
      apply Poincare.isLocalDiffeomorphOn_of_contMDiffOn_bijective_mfderiv
        (isOpen_extChartAt_target q) (contMDiffOn_extChartAt_symm q)
      intro x hx
      have hi : (mfderiv (𝓡 3) (𝓡 3) c.symm x).IsInvertible := by
        simpa only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] using
          isInvertible_mfderivWithin_extChartAt_symm (I := 𝓡 3) hx
      exact hi.bijective
    intro x
    exact (hc ⟨x, hKc (ball_subset_closedBall x.property)⟩).comp (𝓡 3) _
      (hlocal k ⟨c.symm x, hUE x x.property⟩)
  have hinj : InjOn phi U := by
    intro x hx y hy hxy
    apply c.symm.injOn (hKc (ball_subset_closedBall hx)) (hKc (ball_subset_closedBall hy))
    exact congrArg Subtype.val ((hemb k).injective
      (a₁ := ⟨c.symm x, hUE x hx⟩) (a₂ := ⟨c.symm y, hUE y hy⟩) hxy)
  have hballR : ∀ x ∈ U, (phi x).val ∈ S.baseBall (sigma k) R :=
    fun x hx => hk _ (mem_image_of_mem _ (ball_subset_closedBall hx))
  have hballA : ∀ x ∈ U, (phi x).val ∈ S.baseBall (sigma k) A := by
    intro x hx
    rw [← S.normalizedTerminalMetric_ball] at *
    exact (hballR x hx).trans_le (ENNReal.ofReal_le_ofReal hRA)
  let Phi := terminalBallPartialChart hA phi hballA isOpen_ball hphi hinj
  refine ⟨Phi, rfl, ?_, ?_⟩
  · intro z hz
    change z ∈ U at hz
    have heq := terminalBallParametrization_val hA phi hballA hz
    exact ⟨heq, heq ▸ hballR z hz⟩
  · intro T B eta cyl hT z hz
    exact terminalBallParametrization_terminal_coefficients hA phi hballA
      isOpen_ball hphi cyl hT hz

end PoincareMT.ControlledTerminal
