import PoincareLib.Topology.Manifold.NeckCap.Cap.Bounds

/-!
# Inheriting a cap's scalar control through its end neck

Uniform scalar convergence at the selected point and the transported end
center transfers the source cap ratio with a factor of two. This is the
cap information needed for terminal curvature boundedness.

Reference: Morgan--Tian, Claims 11.6 and 11.7, p. 271.
-/

set_option autoImplicit false

open Set
open scoped Manifold ContDiff

universe u v

namespace PoincareMT.CapCertificate

theorem end_center_scalar_bounds_of_point_bounds
    {X : Type u} [TopologicalSpace X] [T3Space X]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) X] [IsManifold (𝓡 3) ∞ X]
    [MeasurableSpace X] [BorelSpace X]
    {g : RiemannianMetric 3 X} (N : CapCertificate g)
    {x : X} (hx : x ∈ N.carrier) {l u C : ℝ}
    (hC : N.cap_constant ≤ C)
    (hl : l ≤ N.connection.scalarCurvature x)
    (hu : N.connection.scalarCurvature x ≤ u) :
    l / C ≤ N.end_neck.connection.scalarCurvature N.end_neck.center ∧
      N.end_neck.connection.scalarCurvature N.end_neck.center ≤ C * u := by
  have hCpos : 0 < C := N.cap_constant_pos.trans_le hC
  have hc := N.end_neck_subset
    (N.end_neck.central_sphere_subset N.end_neck.center_on_central_sphere)
  rw [N.end_neck_connection]
  constructor
  · apply (div_le_iff₀ hCpos).mpr
    calc
      l ≤ N.connection.scalarCurvature x := hl
      _ ≤ N.cap_constant * N.connection.scalarCurvature N.end_neck.center :=
        (N.scalar_lt_constant_mul hc hx).le
      _ ≤ C * N.connection.scalarCurvature N.end_neck.center :=
        mul_le_mul_of_nonneg_right hC (N.scalar_pos _ hc).le
      _ = _ := mul_comm _ _
  · exact (N.scalar_lt_constant_mul hx hc).le.trans
      ((mul_le_mul_of_nonneg_right hC (N.scalar_pos _ hx).le).trans
        (mul_le_mul_of_nonneg_left hu hCpos.le))

theorem scalar_le_twice_constant_mul_of_end_scalar_errors
    {X : Type u} [TopologicalSpace X] [T3Space X]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) X] [IsManifold (𝓡 3) ∞ X]
    [MeasurableSpace X] [BorelSpace X]
    {M : Type v} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {g : RiemannianMetric 3 X} {h : RiemannianMetric 3 M}
    (N : CapCertificate g) (D : LeviCivitaData h) (e : M → X)
    {x y : M} (hx : e x ∈ N.carrier) (hcenter : e y = N.end_neck.center)
    {l C : ℝ} (hC : N.cap_constant ≤ C)
    (hscalar : l ≤ D.scalarCurvature x)
    (hxerror : |D.scalarCurvature x - N.connection.scalarCurvature (e x)| ≤
      l / (2 * (C + 1)))
    (hyerror : |D.scalarCurvature y - N.connection.scalarCurvature (e y)| ≤
      l / (2 * (C + 1))) :
    D.scalarCurvature x ≤ 2 * C * D.scalarCurvature y := by
  have hCpos : 0 < C := N.cap_constant_pos.trans_le hC
  have hy : e y ∈ N.carrier := by
    rw [hcenter]
    exact N.end_neck_subset (N.end_neck.central_sphere_subset N.end_neck.center_on_central_sphere)
  have hratio : N.connection.scalarCurvature (e x) ≤
      C * N.connection.scalarCurvature (e y) :=
    (N.scalar_lt_constant_mul hy hx).le.trans
      (mul_le_mul_of_nonneg_right hC (N.scalar_pos _ hy).le)
  let d := l / (2 * (C + 1))
  have hd : d * (2 * (C + 1)) = l := div_mul_cancel₀ l (by positivity)
  have hxle : D.scalarCurvature x ≤ N.connection.scalarCurvature (e x) + d := by
    have hh := (abs_le.mp hxerror).2
    change _ ≤ d at hh
    linarith
  have hyle : N.connection.scalarCurvature (e y) ≤ D.scalarCurvature y + d := by
    have hh := (abs_le.mp hyerror).1
    change -d ≤ _ at hh
    linarith
  have hbound : D.scalarCurvature x ≤ C * D.scalarCurvature y + (C + 1) * d := by
    calc
      _ ≤ N.connection.scalarCurvature (e x) + d := hxle
      _ ≤ C * N.connection.scalarCurvature (e y) + d := add_le_add hratio le_rfl
      _ ≤ C * (D.scalarCurvature y + d) + d :=
        add_le_add (mul_le_mul_of_nonneg_left hyle hCpos.le) le_rfl
      _ = _ := by ring
  nlinarith

end PoincareMT.CapCertificate
