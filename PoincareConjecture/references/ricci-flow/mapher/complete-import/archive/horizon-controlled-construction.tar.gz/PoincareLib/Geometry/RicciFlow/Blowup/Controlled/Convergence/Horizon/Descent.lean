import PoincareLib.Geometry.RicciFlow.MetricFamily.Descent
import PoincareLib.Geometry.RicciFlow.Limit.Descent
import PoincareLib.Geometry.Riemannian.Connection.Construction

/-!
# Descent of metric families and local time equations

Spatial chart compatibility constructs a smooth family on the retained
carrier. Ricci equations may then descend from different time windows at
different points, with within-domain derivatives at included endpoints.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace Poincare.Gluing

theorem exists_smoothFamily_of_compatible_local_diffeomorphisms
    {n : ℕ} {ι : Type*} {U : ι → Type*} {M : Type*}
    [∀ i, TopologicalSpace (U i)] [TopologicalSpace M]
    [∀ i, ChartedSpace (EuclideanSpace ℝ (Fin n)) (U i)]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M]
    [∀ i, IsManifold (𝓡 n) ∞ (U i)] [IsManifold (𝓡 n) ∞ M]
    {J : Set ℝ} (hJ : J.Nonempty)
    (g : ∀ i, ℝ → PoincareMT.RiemannianMetric n (U i))
    (hg : ∀ i, PoincareMT.RiemannianMetric.IsSmoothFamilyOn (g i) J)
    (q : ∀ i, U i → M)
    (hq : ∀ i, IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (q i))
    (hcover : ∀ y, ∃ i x, q i x = y)
    (hcompat : ∀ t ∈ J, ∀ i j (x : U i) (y : U j), q i x = q j y →
      ∀ (a b : TangentSpace (𝓡 n) x) (c d : TangentSpace (𝓡 n) y),
        mfderiv (𝓡 n) (𝓡 n) (q i) x a = mfderiv (𝓡 n) (𝓡 n) (q j) y c →
        mfderiv (𝓡 n) (𝓡 n) (q i) x b = mfderiv (𝓡 n) (𝓡 n) (q j) y d →
        (g i t).inner x a b = (g j t).inner y c d) :
    ∃ gM : ℝ → PoincareMT.RiemannianMetric n M,
      PoincareMT.RiemannianMetric.IsSmoothFamilyOn gM J ∧
      ∀ t ∈ J, ∀ i (x : U i) (a b : TangentSpace (𝓡 n) x),
        (g i t).inner x a b = (gM t).inner (q i x)
          (mfderiv (𝓡 n) (𝓡 n) (q i) x a)
          (mfderiv (𝓡 n) (𝓡 n) (q i) x b) := by
  classical
  obtain ⟨t₀, ht₀⟩ := hJ
  let time (t : ℝ) := if t ∈ J then t else t₀
  have htime (t : ℝ) : time t ∈ J := by
    dsimp only [time]
    split_ifs with h
    · exact h
    · exact ht₀
  have hex (t : ℝ) := exists_unique_metric_of_covering_local_diffeomorphisms
    (fun i => g i (time t)) q hq hcover (hcompat (time t) (htime t))
  let gM (t : ℝ) := Classical.choose (hex t)
  have hpres (t : ℝ) (ht : t ∈ J) (i : ι) (x : U i)
      (a b : TangentSpace (𝓡 n) x) :
      (g i t).inner x a b = (gM t).inner (q i x)
        (mfderiv (𝓡 n) (𝓡 n) (q i) x a)
        (mfderiv (𝓡 n) (𝓡 n) (q i) x b) := by
    have h := (Classical.choose_spec (hex t)).1 i x a b
    change (g i (time t)).inner x a b = (gM t).inner (q i x)
      (mfderiv (𝓡 n) (𝓡 n) (q i) x a)
      (mfderiv (𝓡 n) (𝓡 n) (q i) x b) at h
    rwa [show time t = t from if_pos ht] at h
  exact ⟨gM, isSmoothFamilyOn_of_local_diffeomorphisms g gM hg q hq hcover hpres, hpres⟩

end Poincare.Gluing

namespace PoincareMT.RicciFlow

theorem exists_of_local_time_covering_diffeomorphisms
    {n : ℕ} {ι : Type*} {U : ι → Type*} {M : Type*}
    [∀ i, TopologicalSpace (U i)] [TopologicalSpace M]
    [∀ i, ChartedSpace (EuclideanSpace ℝ (Fin n)) (U i)]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M]
    [∀ i, IsManifold (𝓡 n) ∞ (U i)] [IsManifold (𝓡 n) ∞ M]
    {J : Set ℝ} (hJ : OrdConnected J) (hJnontrivial : J.Nontrivial)
    (K : ι → Set ℝ) (F : ∀ i, RicciFlow n (U i) (K i))
    (g : ℝ → RiemannianMetric n M) (hg : RiemannianMetric.IsSmoothFamilyOn g J)
    (q : ∀ i, U i → M)
    (hq : ∀ i, IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (q i))
    (hcover : ∀ t ∈ J, ∀ y, ∃ i x, t ∈ K i ∧ K i ∈ 𝓝[J] t ∧ q i x = y)
    (hpres : ∀ i, ∀ t ∈ K i, ∀ (x : U i) (a b : TangentSpace (𝓡 n) x),
      ((F i).metric t).inner x a b = (g t).inner (q i x)
        (mfderiv (𝓡 n) (𝓡 n) (q i) x a)
        (mfderiv (𝓡 n) (𝓡 n) (q i) x b)) :
    ∃ FM : RicciFlow n M J, FM.metric = g := by
  classical
  let D : ∀ t, LeviCivitaData (g t) := fun t => (g t).leviCivitaData
  refine ⟨{
    metric := g
    connection := D
    interval := hJ
    nontrivial := hJnontrivial
    smooth := hg
    equation := ?_ }, rfl⟩
  intro t ht y u v
  obtain ⟨i, x, hti, hKi, rfl⟩ := hcover t ht y
  let A := (hq i x).mfderivToContinuousLinearEquiv (by simp)
  obtain ⟨a, ha⟩ := A.surjective u
  obtain ⟨b, hb⟩ := A.surjective v
  have ha' : mfderiv (𝓡 n) (𝓡 n) (q i) x a = u := ha
  have hb' : mfderiv (𝓡 n) (𝓡 n) (q i) x b = v := hb
  have hRicci := ((F i).connection t).ricci_eq_of_local_isometry (D t)
    isOpen_univ (hq i).contMDiff.contMDiffOn
    (fun z _ a b => hpres i t hti z a b) (mem_univ x) a b
  have hderiv := (F i).equation t hti x a b
  rw [hRicci, ha', hb'] at hderiv
  apply HasDerivWithinAt.mono_of_mem_nhdsWithin (t := K i) _ hKi
  apply hderiv.congr_of_mem ?_ hti
  intro s hs
  simpa only [ha', hb'] using (hpres i s hs x a b).symm

end PoincareMT.RicciFlow
