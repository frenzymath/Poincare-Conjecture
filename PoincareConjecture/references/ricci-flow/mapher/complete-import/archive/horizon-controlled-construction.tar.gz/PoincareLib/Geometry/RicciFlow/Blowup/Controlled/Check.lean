import PoincareLib.Geometry.RicciFlow.Blowup.Controlled
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Theory
import Lean.Util.CollectAxioms

/-! Exact output checks for the proved M30 prerequisites. -/

set_option autoImplicit false

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT

example : M30ControlledBlowupPredecessors.{u} → RepairedControlledBlowupLimitTheory.{u} :=
  m30ControlledGeneralizedBlowupLimits

private theorem hornSelectionWithConstructedM30 (P : M30ControlledBlowupPredecessors.{u})
    (P32 : RepairedHornSelectionPredecessors.{u}) : RepairedHornSelectionTheory.{u} :=
  m32HornSelection { P32 with m30 := m30ControlledGeneralizedBlowupLimits P }

set_option pp.universes true in
#check m30ControlledGeneralizedBlowupLimits

example (P : M30ControlledBlowupPredecessors.{u})
    (S : GeneralizedBlowupSequence.{u}) (T₀ : ℝ≥0∞)
    (H : M30GeometricLongControls S T₀) :
    Nonempty (GeneralizedBlowupConvergence S (blowupBackwardInterval T₀)) :=
  ControlledBlowupCompactness.nonempty_generalizedBlowupConvergence_of_geometricLongControls P H

example (P : M30ControlledBlowupPredecessors.{u}) :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 400 ∧
      M30ShortLimitStatement.{u} epsilon₀ :=
  P.exists_short_limit_threshold

example (P : M30ControlledBlowupPredecessors.{u}) :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 400 ∧
      ∀ (S : GeneralizedBlowupSequence.{u}) (epsilon C kappa r₀ mu : ℝ),
        epsilon ≤ 2 * epsilon₀ → M30CommonBlowupControls S epsilon C kappa r₀ mu →
        ∀ A : ℝ, 0 < A → ∃ T B : ℝ, 0 < T ∧ 0 < B ∧
          ∀ eta : ℝ, 0 < eta → ∀ᶠ k : ℕ in atTop,
            Nonempty (ControlledBlowupCylinder S k A T B eta) :=
  P.exists_fixed_ball_cylinder_threshold

example {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    {epsilon C kappa r₀ mu : ℝ}
    (G : GeneralizedBlowupConvergence S (blowupBackwardInterval T₀))
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀) :
    M30LimitNoncollapsedAtScale G.limit kappa r₀ :=
  G.noncollapsedAtScale_of_longControls H

example (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (G : GeneralizedBlowupConvergence S (blowupBackwardInterval ⊤))
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu ⊤) :
    Nonempty (M30AncientKappaIdentification G.limit kappa) :=
  G.nonempty_m30AncientKappaIdentification_of_longControls P.m04 H

example (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀) {T : ℝ} (hT : 0 < T)
    (horizon : ENNReal.ofReal T < T₀) :
    Nonempty (GeneralizedBlowupConvergence S (blowupBackwardInterval (ENNReal.ofReal T))) :=
  ControlledBlowupCompactness.nonempty_generalizedBlowupConvergence_of_finite_subhorizon P H hT horizon

example (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu D : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (hscalar : ∀ A : ℝ, 0 < A → ∀ᶠ k in atTop, ∀ x ∈ S.baseBall k A,
      (S.flow k).scalar ⟨(S.base k).1, x⟩ ≤ D * S.scale k) :
    Nonempty (RepairedShortControlledBlowupConclusion S) :=
  H.nonempty_short_conclusion_of_uniform_scalar_bound P hscalar

#print axioms M30ControlledBlowupPredecessors.exists_fixed_ball_cylinder_threshold
#print axioms M30CommonBlowupControls.terminal_volume_of_boundedDistance
#print axioms M30LongBlowupControls.eventually_noncollapsed_on_cylinder
#print axioms ControlledBlowupCylinder.exists_uniform_curvatureDerivative_bound
#print axioms GeneralizedFlowCylinder.exists_on_compact_of_singletons_preserving
#print axioms GeneralizedFlowCylinder.exists_on_normalized_slice_ball
#print axioms GeneralizedBlowupConvergence.noncollapsed_of_longControls
#print axioms GeneralizedBlowupConvergence.nonempty_m30AncientKappaIdentification_of_longControls
#print axioms ControlledBlowupCompactness.exists_nonnegative_finite_window_limit_with_compact_balls
#print axioms M30CommonBlowupControls.exists_diagonal_terminal_normalChartCovers_with_metric_jets
#print axioms ControlledConvergence.exists_smooth_terminal_limit_on_closed_slab
#print axioms PointedGeometricConvergence.exists_eventually_reference_metric_jet_bound
#print axioms GeneralizedCanonicalControl.exists_universal_positive_scalar_bound_threshold
#print axioms RicciFlow.unitRicciKernel_doubleCover_of_closed_slab_terminal_null_plane
#print axioms RiemannianMetric.exists_neck_line_product_scalar_bound_threshold
#print axioms M30CommonBlowupControls.exists_terminal_metric_limit_with_escaping_boundaries
#print axioms GeneralizedCanonicalControl.exists_universal_local_null_scalar_bound_threshold
#print axioms MetricSurgery.exists_varying_centeredNeckAmbientCoordinates_jet_bound
#print axioms TerminalNeck.eventually_small_parametrized_metric_error_of_chart_bound
#print axioms EpsilonNeck.exists_perturbed_metric_neck_tolerance
#print axioms M30CommonBlowupControls.exists_complete_terminal_metric_limit
#print axioms ControlledBlowupCylinder.terminalPullbackFlow
#print axioms ControlledTerminal.exists_local_flow_with_terminal_metric
#print axioms ControlledTerminal.eventually_bounded_local_closed_spacetime_jets
#print axioms ControlledBlowupCompactness.nonempty_generalizedBlowupConvergence_of_finite_subhorizon
#print axioms M30CommonBlowupControls.curvature_of_terminal_metric_jets
#print axioms M30CommonBlowupControls.exists_local_backward_flow_at_terminal_limit
#print axioms ControlledTerminal.nonnegativeCurvatureOperator_of_local_closed_slab_jets
#print axioms TerminalNeck.eventually_small_transported_neck_metric_errors
#print axioms TerminalNeck.eventually_transported_necks_of_metric_and_scalar_errors
#print axioms TerminalNeck.eventually_end_necks_with_scalar_control_of_cap_convergence
#print axioms ControlledTerminal.normalized_scalar_limit_le_of_frequent_component_alternative
#print axioms ControlledTerminal.exists_universal_local_backward_scalar_bound_threshold
#print axioms ControlledTerminal.eventually_uniform_source_scalar_bound
#print axioms M30CommonBlowupControls.exists_uniform_controlled_cylinders
#print axioms M30CommonBlowupControls.nonempty_short_conclusion_of_uniform_scalar_bound
#print axioms RicciFlow.tendstoUniformlyOn_scalar_at_terminal
#print axioms ControlledBlowupCylinder.eventually_pullback_tangentNorm_lower
#print axioms Poincare.Gluing.exists_smoothFamily_of_compatible_local_diffeomorphisms
#print axioms RicciFlow.exists_of_local_time_covering_diffeomorphisms
#print axioms M30ControlledBlowupPredecessors.exists_short_limit_threshold
#print axioms M30CommonBlowupControls.terminal_neck_scalar_control_of_metric_extraction
#print axioms GeneralizedBlowupConvergence.not_unbounded_scalar_at_bounded_distance
#print axioms GeneralizedBlowupConvergence.exists_uniform_scalar_bound_of_compact_limit
#print axioms ControlledLongDistance.exists_uniform_additive_distance_bound
#print axioms ControlledLongDistance.terminal_toReal_edist_le
#print axioms ControlledLongGeometry.exists_distant_equidistant_companion
#print axioms ControlledLongGeometry.exists_path_with_positive_distance
#print axioms ControlledBlowupCompactness.windowRetainedCylinder_chart_inner
#print axioms ControlledBlowupCompactness.windowRetainedCylinder_eventually_covers_baseBall
#print axioms ControlledBlowupCompactness.nonempty_generalizedBlowupConvergence_of_geometricLongControls
#print axioms GeneralizedBlowupConvergence.exists_uniform_compact_scalar_bound_of_point_bound
#print axioms GeneralizedBlowupConvergence.exists_controlled_source_extension_on_fixed_ball
#print axioms GeneralizedBlowupConvergence.exists_captured_source_partial_charts
#print axioms GeneralizedBlowupConvergence.tendstoUniformlyOn_zeroSourceMetric_bilinear_jets
#print axioms ControlledTerminal.exists_local_backward_flow_on_subwindow
#print axioms ControlledLongGeometry.exists_uniform_scalar_bound_of_high_curvature_separating_necks
#print axioms M30ControlledBlowupPredecessors.exists_short_geometric_controls_threshold
#print axioms ControlledTerminal.exists_universal_local_backward_scalar_bound_threshold_without_normalization
#print axioms GeneralizedBlowupConvergence.exists_local_backward_extension_of_compact_scalar_bounds
#print axioms GeneralizedBlowupConvergence.exists_complete_backward_boundary_with_retained_extensions
#print axioms GeneralizedBlowupConvergence.exists_complete_closed_extension_of_compact_scalar_bounds
#print axioms GeneralizedBlowupConvergence.exists_uniform_compact_scalar_bound_of_controlled_neck_cover
#print axioms GeneralizedBlowupConvergence.exists_common_controlled_source_extension_of_closed_boundary_bound
#print axioms Poincare.exists_maximal_of_sequential_bounds
#print axioms Poincare.exists_strictMono_map_le_of_antitone
#print axioms ControlledBlowupHorizon.Stage.exists_full_horizon
#print axioms ControlledBlowupHorizon.nonempty_long_conclusion_of_finite_extensions
#print axioms M30ControlledBlowupPredecessors.exists_uniform_compact_scalar_bound_threshold
#print axioms ControlledBlowupBoundary.neck_cover_at_left_endpoint
#print axioms M30ControlledBlowupPredecessors.exists_finite_extension_threshold
#print axioms m30ControlledGeneralizedBlowupLimits

/-! Audit the actual entry and its M32 consumer recursively, including the
types of reachable declarations. Require the constructed inputs to occur in
the entry's dependency closure, so a detached helper check cannot pass. -/
open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let entry := ``m30ControlledGeneralizedBlowupLimits
  let consumer := ``hornSelectionWithConstructedM30
  let constructors := #[
    ``M30ControlledBlowupPredecessors.exists_short_limit_threshold,
    ``M30ControlledBlowupPredecessors.exists_short_geometric_controls_threshold,
    ``M30CommonBlowupControls.exists_complete_terminal_metric_limit,
    ``M30CommonBlowupControls.terminal_neck_scalar_control_of_metric_extraction,
    ``ControlledBlowupCompactness.nonempty_generalizedBlowupConvergence_of_geometricLongControls,
    ``M30ControlledBlowupPredecessors.exists_finite_extension_threshold,
    ``GeneralizedBlowupConvergence.exists_complete_closed_extension_of_compact_scalar_bounds,
    ``ControlledBlowupBoundary.neck_cover_at_left_endpoint,
    ``GeneralizedBlowupConvergence.exists_common_controlled_source_extension_of_closed_boundary_bound,
    ``ControlledBlowupHorizon.Stage.exists_full_horizon,
    ``ControlledBlowupHorizon.nonempty_long_conclusion_of_finite_extensions,
    ``GeneralizedBlowupConvergence.noncollapsedAtScale_of_longControls,
    ``GeneralizedBlowupConvergence.nonempty_m30AncientKappaIdentification_of_longControls]
  let standard := #[``propext, ``Classical.choice, ``Quot.sound]
  for root in #[entry, consumer] do
    let axioms ← collectAxioms root
    let mut pending := #[root]
    let mut seen : NameSet := {}
    let mut admissions : NameSet := {}
    while !pending.isEmpty do
      let name := pending.back!
      pending := pending.pop
      if seen.contains name then continue
      seen := seen.insert name
      let some info := env.checked.get.find? name
        | throwError "Cannot inspect {name}"
      if info.type.hasSorry || (info.value? (allowOpaque := true)).any Expr.hasSorry then
        admissions := admissions.insert name
      pending := pending ++ info.getUsedConstantsAsSet.toArray
    logInfo m!"{root}: {seen.size} reachable declarations; direct admissions: {admissions.toArray.qsort Name.lt}; axioms: {axioms}"
    unless admissions.isEmpty && axioms.all standard.contains do
      throwError "{root} has an unproved dependency"
    for constructor in constructors do
      unless seen.contains constructor do
        throwError "{root} does not consume {constructor}"
    if root == consumer then
      unless seen.contains entry && seen.contains ``m32HornSelection do
        throwError "M32 check does not consume the constructed M30 theory"

end PoincareMT
