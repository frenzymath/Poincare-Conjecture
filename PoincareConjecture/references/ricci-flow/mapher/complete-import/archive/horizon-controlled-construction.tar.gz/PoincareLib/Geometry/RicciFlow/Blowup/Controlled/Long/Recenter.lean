import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Predecessors

/-!
# Bounded-distance estimates at earlier basepoints

Earlier points with scalar curvature at least the original base scalar retain
the dense canonical hypothesis. When their scalar ratios are also bounded
above, the recentered M29 estimate controls balls in the original normalization.
This is the recentering step in Morgan--Tian Lemma 11.10, pp. 274--275.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT

theorem generalizedEarlierDenseStrongCanonicalNeighborhoods.recenter
    {F : GeneralizedRicciFlowData.{u}} {epsilon C t : ℝ}
    {x : (F.slice t).carrier}
    (h : generalizedEarlierDenseStrongCanonicalNeighborhoods F epsilon C t x)
    {s : ℝ} (y : (F.slice s).carrier) (hst : s ≤ t)
    (hscalar : F.scalar ⟨t, x⟩ ≤ F.scalar ⟨s, y⟩) :
    generalizedEarlierDenseStrongCanonicalNeighborhoods F epsilon C s y := by
  intro v hv hvs a hav
  obtain ⟨w, hw, haw, hwv, hcanonical⟩ := h v hv (hvs.trans hst) a hav
  refine ⟨w, hw, haw, hwv, fun z hz => hcanonical z ?_⟩
  exact (mul_le_mul_of_nonneg_left hscalar (by norm_num)).trans hz

def GeneralizedBlowupSequence.recenter
    (S : GeneralizedBlowupSequence.{u}) (y : ∀ k, (S.flow k).point)
    (hscalar : ∀ k, S.scale k ≤ (S.flow k).scalar (y k)) :
    GeneralizedBlowupSequence.{u} where
  flow := S.flow
  base := y
  base_scalar_pos k := (S.base_scalar_pos k).trans_le (hscalar k)
  scalar_diverges := tendsto_atTop_mono hscalar S.scalar_diverges

theorem DenseGeneralizedBoundedDistanceHypotheses.recenter
    {S : GeneralizedBlowupSequence.{u}} {epsilon C : ℝ}
    (H : DenseGeneralizedBoundedDistanceHypotheses S epsilon C)
    (y : ∀ k, (S.flow k).point)
    (htime : ∀ k, (y k).1 ≤ (S.base k).1)
    (hscalar : ∀ k, S.scale k ≤ (S.flow k).scalar (y k)) :
    DenseGeneralizedBoundedDistanceHypotheses (S.recenter y hscalar) epsilon C where
  branch := H.branch
  canonical k := (H.canonical k).recenter (y k).2 (htime k) (hscalar k)

theorem GeneralizedBlowupSequence.recenter_ball_subset
    (S : GeneralizedBlowupSequence.{u}) (y : ∀ k, (S.flow k).point)
    (hscalar : ∀ k, S.scale k ≤ (S.flow k).scalar (y k))
    {B : ℝ} (hB : 0 < B)
    (hupper : ∀ k, (S.flow k).scalar (y k) ≤ B * S.scale k)
    (k : ℕ) {A : ℝ} (hA : 0 ≤ A) :
    ((S.flow k).metric (y k).1).ball (y k).2 (A / Real.sqrt (S.scale k)) ⊆
      (S.recenter y hscalar).baseBall k (A * Real.sqrt B) := by
  have hQ : 0 < S.scale k := S.base_scalar_pos k
  have hR : 0 < (S.flow k).scalar (y k) := hQ.trans_le (hscalar k)
  have hsqrt := Real.sqrt_le_sqrt (hupper k)
  rw [Real.sqrt_mul hB.le] at hsqrt
  have hradius : A / Real.sqrt (S.scale k) ≤
      A * Real.sqrt B / Real.sqrt ((S.flow k).scalar (y k)) := by
    apply (div_le_div_iff₀ (Real.sqrt_pos.mpr hQ) (Real.sqrt_pos.mpr hR)).mpr
    nlinarith [mul_le_mul_of_nonneg_left hsqrt hA]
  intro z hz
  change ((S.flow k).metric (y k).1).edist (y k).2 z <
    ENNReal.ofReal (A / Real.sqrt (S.scale k)) at hz
  change ((S.flow k).metric (y k).1).edist (y k).2 z <
    ENNReal.ofReal (A * Real.sqrt B / Real.sqrt ((S.flow k).scalar (y k)))
  exact hz.trans_le (ENNReal.ofReal_le_ofReal hradius)

theorem GeneralizedBlowupBoundedDistance.original_normalization_of_recenter
    {S : GeneralizedBlowupSequence.{u}} (y : ∀ k, (S.flow k).point)
    (hscalar : ∀ k, S.scale k ≤ (S.flow k).scalar (y k))
    {B : ℝ} (hB : 0 < B)
    (hupper : ∀ k, (S.flow k).scalar (y k) ≤ B * S.scale k)
    (H : GeneralizedBlowupBoundedDistance (S.recenter y hscalar)) :
    ∀ A : ℝ, 0 < A → ∃ D : ℝ, 0 < D ∧ ∀ᶠ k in atTop,
      ∀ z ∈ ((S.flow k).metric (y k).1).ball (y k).2 (A / Real.sqrt (S.scale k)),
        (S.flow k).scalar ⟨(y k).1, z⟩ ≤ D * S.scale k := by
  intro A hA
  obtain ⟨D, hD, hbound⟩ := H (A * Real.sqrt B) (mul_pos hA (Real.sqrt_pos.mpr hB))
  refine ⟨D * B, mul_pos hD hB, ?_⟩
  filter_upwards [hbound] with k hk z hz
  have hb := hk z (S.recenter_ball_subset y hscalar hB hupper k hA.le hz)
  change (S.flow k).scalar ⟨(y k).1, z⟩ ≤ D * (S.flow k).scalar (y k) at hb
  exact hb.trans ((mul_le_mul_of_nonneg_left (hupper k) hD.le).trans_eq (mul_assoc _ _ _).symm)

theorem DenseGeneralizedBoundedDistanceTheory.exists_earlier_recenter_threshold
    (P : DenseGeneralizedBoundedDistanceTheory.{u}) :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 200 ∧
      ∀ epsilon : ℝ, 0 < epsilon → epsilon ≤ epsilon₀ →
      ∀ C : ℝ, 0 < C → ∀ S : GeneralizedBlowupSequence.{u},
      DenseGeneralizedBoundedDistanceHypotheses S epsilon C →
      ∀ y : ∀ k, (S.flow k).point,
      (∀ k, (y k).1 ≤ (S.base k).1) →
      (∀ k, S.scale k ≤ (S.flow k).scalar (y k)) →
      ∀ B : ℝ, 0 < B → (∀ k, (S.flow k).scalar (y k) ≤ B * S.scale k) →
      ∀ A : ℝ, 0 < A → ∃ D : ℝ, 0 < D ∧ ∀ᶠ k in atTop,
        ∀ z ∈ ((S.flow k).metric (y k).1).ball (y k).2 (A / Real.sqrt (S.scale k)),
          (S.flow k).scalar ⟨(y k).1, z⟩ ≤ D * S.scale k := by
  obtain ⟨epsilon₀, hpos, hsmall, hestimate⟩ := P.constants
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro epsilon hepsilon hle C hC S H y htime hscalar B hB hupper
  exact (hestimate epsilon hepsilon hle C hC (S.recenter y hscalar)
    (H.recenter y htime hscalar)).original_normalization_of_recenter y hscalar hB hupper

end PoincareMT
