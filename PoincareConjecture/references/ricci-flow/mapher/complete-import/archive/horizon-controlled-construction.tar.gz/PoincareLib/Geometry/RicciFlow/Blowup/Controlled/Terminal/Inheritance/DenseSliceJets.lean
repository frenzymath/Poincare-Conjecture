import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.DenseSelection
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.TimeJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.SliceMaps

/-!
# Canonical slices retaining the actual comparison metric jets

The dense good times preserve a finite family of compact metric-jet tests
and any additional terminal continuity conditions. The jet conclusion uses
the actual normalized earlier-slice metric and cylinder comparison map.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000

open Set Filter Metric
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

open ControlledBlowupCylinder
local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem exists_canonical_slices_preserving_metric_jets_and_properties
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (sigma : ℕ → ℕ) (A T B eta : ℕ → ℝ) (hT : ∀ k, 0 < T k)
    (cyl : ∀ k, ControlledBlowupCylinder S (sigma k) (A k) (T k) (B k) (eta k))
    (n m : ℕ → ℕ) (U K : ∀ k, Fin (n k) → Set E)
    (hU : ∀ k i, IsOpen (U k i)) (hK : ∀ k i, IsCompact (K k i))
    (hKU : ∀ k i, K k i ⊆ U k i)
    (phi : ∀ k, Fin (n k) → E → sourceBall S (sigma k) (A k))
    (hphi : ∀ k i, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (phi k i) (U k i))
    (P : ℕ → ℝ → Prop)
    (hP : ∀ k, ∀ᶠ s in 𝓝[Icc (-(T k)) 0] 0, P k s) :
    ∃ (s : ℕ → ℝ) (hs : ∀ k, s k ∈ Icc (-(T k)) 0),
      Tendsto s atTop (𝓝 0) ∧ ∀ k, P k (s k) ∧
        (S.base (sigma k)).1 + s k / S.scale (sigma k) ∈ (S.flow (sigma k)).interval ∧
        generalizedSliceStrongCanonicalNeighborhoods (S.flow (sigma k)) epsilon C
          (4 * S.scale (sigma k))
          ((S.base (sigma k)).1 + s k / S.scale (sigma k)) ∧
        ∀ i j, j ≤ m k → ∀ x ∈ K k i,
          ‖iteratedFDeriv ℝ j ((rescaledMetric
              ((S.flow (sigma k)).metric ((S.base (sigma k)).1 + s k / S.scale (sigma k)))
              (S.scale (sigma k)) (S.base_scalar_pos (sigma k))).pullbackCoefficients
                ((cyl k).sliceMap (s k) (hs k) ∘ phi k i)) x -
            iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric 0
              |>.pullbackCoefficients (phi k i)) x‖ ≤ ((k : ℝ) + 1)⁻¹ := by
  let Q := fun k s => ∀ i j, j ≤ m k → ∀ x ∈ K k i,
    ‖iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric s
        |>.pullbackCoefficients (phi k i)) x -
      iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric 0
        |>.pullbackCoefficients (phi k i)) x‖ ≤ ((k : ℝ) + 1)⁻¹
  have hQ (k : ℕ) : ∀ᶠ s in 𝓝[Icc (-(T k)) 0] 0, Q k s := by
    have hsingle (i : Fin (n k)) (j : ℕ) :
        ∀ᶠ s in 𝓝[Icc (-(T k)) 0] 0, ∀ x ∈ K k i,
          ‖iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric s
              |>.pullbackCoefficients (phi k i)) x -
            iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric 0
              |>.pullbackCoefficients (phi k i)) x‖ ≤ ((k : ℝ) + 1)⁻¹ := by
      have hh := ((cyl k).ordinaryFlow (hT k)).tendstoUniformlyOn_spatialMetricJets_at_terminal
        (hT k) (hU k i) (hK k i) (hKU k i) (phi k i) (hphi k i) j
      filter_upwards [Metric.tendstoUniformlyOn_iff.mp hh (((k : ℝ) + 1)⁻¹)
        (by positivity)] with s hs x hx
      simpa only [dist_eq_norm, norm_sub_rev] using (hs x hx).le
    have hall := (eventually_all_finite (finite_univ : (univ : Set (Fin (n k))).Finite)).mpr
      (fun i _ => (eventually_all_finite (finite_Iic (m k))).mpr (fun j _ => hsingle i j))
    exact hall.mono fun s hs i j hj => hs i (mem_univ i) j hj
  obtain ⟨s, hs0, hselect⟩ := H.exists_canonical_times_preserving_terminal_properties
    sigma T hT (fun k s => P k s ∧ Q k s) (fun k => (hP k).and (hQ k))
  refine ⟨s, fun k => (hselect k).1, hs0, fun k =>
    ⟨(hselect k).2.2.1.1, (hselect k).2.2.2.1, (hselect k).2.2.2.2, ?_⟩⟩
  intro i j hj x hx
  rw [(cyl k).sliceMap_pullback_metric_jet (hT k) (s k) (hselect k).1
    (phi k i) (hU k i) (hphi k i) (hKU k i hx) j]
  exact (hselect k).2.2.1.2 i j hj x hx

end PoincareMT.M30CommonBlowupControls
