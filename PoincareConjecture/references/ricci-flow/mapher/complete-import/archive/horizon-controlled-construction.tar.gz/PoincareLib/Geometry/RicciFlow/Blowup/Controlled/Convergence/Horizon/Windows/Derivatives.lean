import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourceDerivatives

/-! # Uniform derivative control on an arbitrary smaller backward window -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCylinder

/-- The time buffer can be any positive margin; neither the source radius
nor the source index enters the resulting derivative constant. -/
theorem exists_uniform_curvatureDerivative_bound_of_margins
    (P04 : RicciFlowCurvatureTheory.{u}) {T V B : ℝ}
    (hV : 0 ≤ V) (hVT : V < T) (hB : 0 ≤ B) (m : ℕ) :
    ∃ D : ℝ, 0 < D ∧ ∀ (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
      (A R eta : ℝ), 0 < R → R + 1 ≤ A →
      ∀ e : ControlledBlowupCylinder S k A T B eta,
      IsCompact (closure (S.baseBall k A)) →
      ∀ s ∈ Icc (-V) 0, ∀ x : sourceBall S k A, x.val ∈ S.baseBall k R →
        ((e.ordinaryFlow (hV.trans_lt hVT)).connection s).curvatureDerivativeNorm m x ≤ D := by
  let delta := T - V
  let K := B + 1
  let r := 1 / (2 * Real.exp (3 * B * T))
  have hT : 0 < T := hV.trans_lt hVT
  have hdelta : 0 < delta := sub_pos.mpr hVT
  have hK : 0 < K := by dsimp [K]; positivity
  have hr : 0 < r := by dsimp [r]; positivity
  obtain ⟨D, hD, hShi⟩ := P04.local_derivative_estimates 3 m K (K * delta) r
    hK (mul_pos hK hdelta) hr
  refine ⟨D / delta ^ ((m : ℝ) / 2), by positivity, ?_⟩
  intro S k A R eta hR hRA e hcompact s hs x hx
  have hstart : s - delta ∈ Icc (-T) 0 := by
    dsimp [delta]
    constructor <;> linarith [hs.1, hs.2]
  have hshift : (fun t : ℝ => t + (s - delta)) '' Icc 0 delta ⊆ Icc (-T) 0 := by
    rintro _ ⟨t, ht, rfl⟩
    constructor <;> dsimp [delta] at * <;> linarith [ht.1, ht.2, hs.1, hs.2]
  have hne : (Icc (0 : ℝ) delta).Nontrivial :=
    ⟨0, ⟨le_rfl, hdelta.le⟩, delta, ⟨hdelta.le, le_rfl⟩, hdelta.ne⟩
  let F := (e.ordinaryFlow hT).translate (s - delta) hshift ordConnected_Icc hne
  have hbuffer : Real.exp (3 * B * |s - delta|) * r ≤ (A - R) / 2 := by
    have habs : |s - delta| ≤ T := by
      rw [abs_of_nonpos hstart.2]
      linarith [hstart.1]
    calc
      Real.exp (3 * B * |s - delta|) * r ≤ Real.exp (3 * B * T) * r := by gcongr
      _ = 1 / 2 := by dsimp [r]; field_simp
      _ ≤ (A - R) / 2 := by linarith
  have hc : IsCompact (closure ((F.metric 0).ball x r)) := by
    change IsCompact (closure (((e.ordinaryFlow hT).metric (0 + (s - delta))).ball x r))
    rw [zero_add]
    exact e.ordinaryFlow_isCompact_closure_ball_at hT hcompact hR (by linarith)
      x hx hstart hbuffer
  have hcurv : ∀ t ∈ Icc 0 delta, ∀ y ∈ (F.metric 0).ball x r,
      (F.connection t).curvatureTensorNorm y ≤ K := by
    intro t ht y _
    exact ((le_abs_self _).trans
      (e.ordinaryFlow_curvature_bound hT _ (hshift ⟨t, ht, rfl⟩) y)).trans
      (by dsimp [K]; linarith)
  have htime : delta ≤ K * delta / K := by rw [mul_div_cancel_left₀ _ hK.ne']
  have hxball : x ∈ (F.metric 0).ball x (r / 2) := by
    simp only [RiemannianMetric.ball, mem_ofPred_eq, RiemannianMetric.edist,
      Manifold.riemannianEDist_self]
    exact ENNReal.ofReal_pos.mpr (half_pos hr)
  have h := hShi (sourceBall S k A) delta hdelta htime F x hc hcurv
    delta ⟨hdelta, le_rfl⟩ x hxball
  change ((e.ordinaryFlow hT).connection (delta + (s - delta))).curvatureDerivativeNorm m x ≤ _ at h
  rwa [show delta + (s - delta) = s by ring] at h

end PoincareMT.ControlledBlowupCylinder
