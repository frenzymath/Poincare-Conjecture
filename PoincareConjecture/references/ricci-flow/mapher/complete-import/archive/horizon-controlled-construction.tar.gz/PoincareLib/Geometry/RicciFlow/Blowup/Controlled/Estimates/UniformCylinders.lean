import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Cylinders

/-!
# Common backward cylinders from a uniform terminal scalar bound

The lifetime and guarded scalar comparison depend on the terminal bound,
not on the spatial radius. Compact gluing therefore gives a common closed
backward interval on every fixed ball. Source: Morgan--Tian, Claim 11.7,
p. 271.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem exists_uniform_backward_scalar_bound
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) {D : ℝ}
    (hscalar : ∀ A : ℝ, 0 < A → ∀ᶠ k in atTop, ∀ x ∈ S.baseBall k A,
      (S.flow k).scalar ⟨(S.base k).1, x⟩ ≤ D * S.scale k) :
    ∃ T B : ℝ, 0 < T ∧ 0 < B ∧ ∀ A : ℝ, 0 < A → ∀ᶠ k in atTop,
      ∀ x ∈ S.baseBall k A, ∃ W : GeneralizedMaximalBackwardFlowLine
        (S.flow k) ⟨(S.base k).1, x⟩ (S.scale k) (m30BackwardDuration S k x mu),
        ∃ hI : Icc (-T) 0 ⊆ W.maximal_interval,
          ∀ s (hs : s ∈ Icc (-T) 0),
            (S.flow k).scalar (W.embedding.pointMap s (hI hs) x) < B * S.scale k := by
  classical
  let K := max 4 D + 1
  have hK : 4 ≤ K := by dsimp [K]; linarith [le_max_left (4 : ℝ) D]
  have hKpos : 0 < K := by linarith
  have hDK : D < K := by dsimp [K]; linarith [le_max_right (4 : ℝ) D]
  let lifetime := mu / max 1 D
  have hlifetime : 0 < lifetime := div_pos H.mu_pos
    (lt_of_lt_of_le zero_lt_one (le_max_left _ _))
  let T := min (lifetime / 2) (1 / (8 * (H.analytic_constant + 1) * K))
  have hT : 0 < T := by
    have := H.analytic_constant_pos
    exact lt_min (half_pos hlifetime) (by positivity)
  have hTlifetime : T ≤ lifetime := (min_le_left _ _).trans (by linarith)
  have hshort : T < 1 / (4 * (H.analytic_constant + 1) * K) := by
    apply lt_of_le_of_lt (min_le_right _ _)
    apply one_div_lt_one_div_of_lt (by have := H.analytic_constant_pos; positivity)
    have := H.analytic_constant_pos
    nlinarith
  refine ⟨T, 2 * K, hT, by positivity, fun A hA => ?_⟩
  filter_upwards [hscalar A hA, H.maximal_worldlines A hA] with k hk hW x hx
  obtain ⟨W⟩ := hW x hx
  have hduration : lifetime ≤ m30BackwardDuration S k x mu :=
    le_m30BackwardDuration_of_scalar_le S k x (le_max_left _ _) H.mu_pos.le
      ((hk x hx).trans (mul_le_mul_of_nonneg_right (le_max_right _ _) (S.base_scalar_pos k).le))
  have hI : Icc (-T) 0 ⊆ W.maximal_interval :=
    (Icc_subset_Icc_left (neg_le_neg (hTlifetime.trans hduration))).trans W.requested_interval_subset
  let f : ℝ → ℝ := fun s => if hs : s ∈ W.maximal_interval then
    (S.flow k).scalar (W.embedding.pointMap s hs x) else 0
  have hf (s : ℝ) (hs : s ∈ W.maximal_interval) :
      f s = (S.flow k).scalar (W.embedding.pointMap s hs x) := dif_pos hs
  have hzero : f 0 < K * S.scale k := by
    rw [hf 0 W.maximal_interval_mem_zero, W.zero_identity]
    exact (hk x hx).trans_lt (mul_lt_mul_of_pos_right hDK (S.base_scalar_pos k))
  have hcontrol := H.cylinder_scalar_lt_two_mul P04 k W.embedding (mem_singleton x)
    hf hK hI hzero hshort
  exact ⟨W, hI, fun s hs => by simpa only [hf s (hI hs)] using hcontrol s hs⟩

theorem exists_uniform_controlled_cylinders
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) {D : ℝ}
    (hscalar : ∀ A : ℝ, 0 < A → ∀ᶠ k in atTop, ∀ x ∈ S.baseBall k A,
      (S.flow k).scalar ⟨(S.base k).1, x⟩ ≤ D * S.scale k) :
    ∃ T B : ℝ, 0 < T ∧ 0 < B ∧ ∀ A : ℝ, 0 < A → ∀ eta : ℝ, 0 < eta →
      ∀ᶠ k in atTop, Nonempty (ControlledBlowupCylinder S k A T B eta) := by
  classical
  obtain ⟨T, B, hT, hB, hworldlines⟩ := H.exists_uniform_backward_scalar_bound P04 hscalar
  refine ⟨T, 13 * max B 1, hT, by positivity, fun A hA eta heta => ?_⟩
  filter_upwards [hworldlines (A + 1) (by linarith), H.balls_compact A hA,
    DeepHorn.eventually_full_and_negative_curvature_bounds P04 S H.branch hB.le heta]
    with k hk hcompact hcurv
  let K := closure (S.baseBall k A)
  have hKsub : K ⊆ S.baseBall k (A + 1) := S.closure_baseBall_subset k hA (by linarith)
  have hKne : K.Nonempty := ⟨(S.base k).2, subset_closure (S.base_mem_baseBall k hA)⟩
  choose W hI hscalarW using fun x : K => hk x.1 (hKsub x.2)
  let w := fun x : K => (W x).embedding.restrict (hI x) Subset.rfl
  have hw0 : ∀ x : K, (w x).pointMap 0 ⟨by linarith, le_rfl⟩ x.1 =
      (⟨(S.base k).1, x.1⟩ : (S.flow k).point) := fun x => (W x).zero_identity
  obtain ⟨e, he0, hecurv⟩ :=
    GeneralizedFlowCylinder.exists_on_compact_of_singletons_preserving hcompact hKne
      (by linarith : -T ≤ 0) w hw0
      (fun _ _ p => |(S.flow k).curvatureNorm p| ≤ (13 * max B 1) * S.scale k ∧
        ((S.flow k).connection p.1).negativeCurvaturePart p.2 ≤ eta * S.scale k)
      (fun x s hs => by
        let p := (W x).embedding.pointMap s (hI x hs) x.val
        exact hcurv p.1 ((S.flow k).slice_nonempty_iff p.1 |>.mp ⟨p.2⟩) p.2
          (hscalarW x s hs).le)
  exact ⟨{
    embedding := e.restrict Subset.rfl subset_closure
    zero_identity := fun _ x hx => he0 x (subset_closure hx)
    curvature_bound := fun s hs x hx => (hecurv s hs x (subset_closure hx)).1
    negative_curvature_bound := fun s hs x hx => (hecurv s hs x (subset_closure hx)).2 }⟩

end PoincareMT.M30CommonBlowupControls
