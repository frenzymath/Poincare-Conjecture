import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourceCurvature
import PoincareLib.Geometry.RicciFlow.AncientKappa.Asymptotic.Compactness.Coordinates.SpacetimeJets

/-!
# Spacetime metric jets of the retained controlled sources

The actual Ricci coordinate equation upgrades the closed spatial estimates
to all mixed jets on the final half-window. The source coefficients are the
original M07 zero-time maps, with the original subsequence.

Reference: Morgan--Tian, Proposition 5.14, pp. 90--91.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder SpacetimeBounds SpacetimeBounds.Bootstrap

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

/-- All mixed derivatives are bounded uniformly up to the included source
terminal time from its interior side. -/
theorem exists_eventually_source_open_spacetime_jet_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k : ℕ in atTop,
      ∀ t ∈ Ioo 0 (T / 2), ∀ x ∈ K,
        ‖iteratedFDeriv ℝ m (G.spatialSpacetimeCoefficients q k) (t, x)‖ ≤ C := by
  let E := EuclideanSpace ℝ (Fin 3)
  let c := extChartAt (𝓡 3) q
  let f := G.spatialSpacetimeCoefficients q
  let U := fun k => c.target ∩ c.symm ⁻¹' G.exhaustion k
  let W := fun k => Ioo 0 (T / 2) ×ˢ (K ∩ U k)
  let F := fun k => ((interiorSequence S idx A eta T B hA hT e).flow (G.subsequence k)).flow
  have hzero : -T / 2 < 0 ∧ 0 < T / 2 := ⟨by linarith, by linarith⟩
  have hU (k : ℕ) : IsOpen (U k) :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
      (isOpen_extChartAt_target q) (G.exhaustion_open k)
  have he (k : ℕ) : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap q k 0) (U k) :=
    fun x hx => (G.referenceChartMap_contMDiffAt q k hzero hx.1 hx.2).contMDiffWithinAt
  have hi (k : ℕ) : ∀ x ∈ U k,
      (mfderiv (𝓡 3) (𝓡 3) (G.referenceChartMap q k 0) x).IsInvertible :=
    fun x hx => G.referenceChartMap_mfderiv_isInvertible q k hzero hx.1 hx.2
  have hf (k : ℕ) : ContDiffOn ℝ ∞ (f k) (Ioo (-T / 2) (T / 2) ×ˢ U k) :=
    (F k).contDiffOn_pullbackCoefficients isOpen_Ioo (hU k) (he k)
  have hrange (k : ℕ) : MapsTo (spatialJet 2 (f k))
      (Ioo (-T / 2) (T / 2) ×ˢ U k) (jetRicciFlowDomain 3) := by
    intro z hz
    change ((twoJetProjection 3 (spatialJet 2 (f k) z)).1).IsInvertible
    rw [twoJetProjection_spatialJet]
    change (((F k).metric z.1).pullbackCoefficients (G.referenceChartMap q k 0) z.2).IsInvertible
    exact ((F k).metric z.1).isInvertible_pullbackCoefficients
      (f := G.referenceChartMap q k 0) (x := z.2) (hi k z.2 hz.2).injective
  have hevol (k : ℕ) (z : ℝ × E) (hz : z ∈ Ioo (-T / 2) (T / 2) ×ˢ U k) :
      deriv (fun t => f k (t, z.2)) z.1 = jetRicciFlowOperator 3 (spatialJet 2 (f k) z) := by
    rw [jetRicciFlowOperator, Function.comp_apply, twoJetProjection_spatialJet]
    exact deriv_pullbackCoefficients_eq_ricciFlowOperator (F k)
      isOpen_Ioo (hU k) (he k) (hi k) hz.1 hz.2
  have hall (r : ℕ) : ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k : ℕ in atTop,
      ∀ z ∈ W k, ∀ j ≤ r, ‖iteratedFDeriv ℝ j (fun x => f k (z.1, x)) z.2‖ ≤ C := by
    obtain ⟨C, hC, hbound⟩ := exists_eventually_reference_closed_spatial_jet_bound
      G P04 hB hAr hcompact hcomplete q hK hKc r
    refine ⟨C, hC, hbound.mono ?_⟩
    intro k hk z hz j hj
    exact hk (z.1 + (-T / 2)) ⟨by linarith [hz.1.1], by linarith [hz.1.2]⟩ z.2 hz.2.1 j hj
  have hspatial (r : ℕ) : ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k : ℕ in atTop,
      ∀ z ∈ W k, ‖iteratedFDeriv ℝ r (fun x => f k (z.1, x)) z.2‖ ≤ C := by
    obtain ⟨C, hC, hbound⟩ := hall r
    exact ⟨C, hC, hbound.mono fun k hk z hz => hk z hz r le_rfl⟩
  obtain ⟨a, b, ha, _, hell⟩ := exists_eventually_reference_closed_ellipticity G hB q hK hKc
  have hbox (r : ℕ) : ∃ Q : Set (Jet E (MetricCoefficient 3) (2 + r)),
      IsCompact Q ∧ Q ⊆ (baseProjection 2 r) ⁻¹' jetRicciFlowDomain 3 ∧
        ∀ᶠ k : ℕ in atTop, MapsTo (spatialJet (2 + r) (f k)) (W k) Q := by
    obtain ⟨C, hC, hbound⟩ := hall (2 + r)
    obtain ⟨Q, hQ, hQU, hbox⟩ := exists_compact_elliptic_jet_box 3 r ha C
    refine ⟨Q, hQ, hQU, ?_⟩
    filter_upwards [hbound, hell] with k hk heq z hz
    apply hbox
    · exact (pi_norm_le_iff_of_nonneg hC).mpr (fun j => hk z hz j (by omega))
    · intro v
      exact (heq (z.1 + (-T / 2)) ⟨by linarith [hz.1.1], by linarith [hz.1.2]⟩ z.2 hz.2.1 v).1
  obtain ⟨C, hC, hbound⟩ := eventuallyBounded_spacetime_jets atTop
    (isOpen_jetRicciFlowDomain 3) (contDiffOn_jetRicciFlowOperator 3)
    f (fun _ => Ioo (-T / 2) (T / 2)) U W hf (fun _ => isOpen_Ioo) hU
    (fun _ _ hz => ⟨⟨by linarith [hz.1.1], hz.1.2⟩, hz.2.2⟩)
    hrange hevol hspatial hbox m
  have hc : ContinuousOn c.symm K :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset (hK.image_of_continuousOn hc)
  refine ⟨C, hC, ?_⟩
  filter_upwards [hbound, eventually_ge_atTop j] with k hk hjk t ht x hx
  exact hk (t, x) ⟨ht, hx, hKc hx, G.exhaustion_monotone hjk (hj (mem_image_of_mem _ hx))⟩

end PoincareMT.ControlledBlowupCompactness
