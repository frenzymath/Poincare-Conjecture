import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Limit.TerminalAttachment
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.AllCharts

/-! # Actual full-horizon flow with its retained terminal metric and jets -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

theorem exists_full_horizon_flow_with_open_jets
    (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (htmono : StrictMono tau) (hB : ∀ j, 0 ≤ B j) :
    ∃ F₀ : RicciFlow 3 G.limitCarrier.carrier (Ioc (-tau 0 / 2) (tau 0 / 2)),
      (∀ t ∈ Ioo (-tau 0 / 2) (tau 0 / 2), F₀.metric t = G.limitFlow.metricAt t) ∧
      ∃ sigma : ℕ → ℕ, StrictMono sigma ∧
      ∃ F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau ∪ {0}),
        (∀ t ∈ Ioc (-tau 0) 0, F.metric t = F₀.metric (t + tau 0 / 2)) ∧
        ∀ q : G.limitCarrier.carrier, ∀ r K, IsCompact K →
          K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target → TendstoUniformlyOn
            (fun k => iteratedFDeriv ℝ r (horizonSpacetimeCoefficients G q (sigma k)))
            (iteratedFDeriv ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
              (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)) atTop K := by
  classical
  obtain ⟨q, hcover⟩ := G.exists_countable_referenceChart_cover
  obtain ⟨sigma, hsigma, f, hf, hjets⟩ := exists_horizon_common_chart_extraction G P04 hAr
    hcompact hcomplete htmono hB q
  obtain ⟨Fo, hFo⟩ := exists_horizon_flow_of_chart_limits G htmono.monotone hB q hcover hsigma f hf hjets
  have hpoint (i : ℕ) (z : ℝ × EuclideanSpace ℝ (Fin 3))
      (hz : z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target) :
      Tendsto (fun k => horizonSpacetimeCoefficients G (q i) (sigma k) z) atTop (𝓝 (f i z)) := by
    have he := (ContinuousMultilinearMap.uniformContinuous_eval_const
      (0 : Fin 0 → ℝ × EuclideanSpace ℝ (Fin 3))).comp_tendstoUniformlyOn
        (hjets i 0 {z} isCompact_singleton (singleton_subset_iff.mpr hz))
    simpa only [Function.comp_apply, iteratedFDeriv_zero_apply] using he.tendsto_at (mem_singleton z)
  have hinterior : ∀ t ∈ Ioo (-tau 0) 0, Fo.metric t = G.limitFlow.metricAt (t + tau 0 / 2) :=
    fun t ht => horizon_flow_metric_eq_initial G htmono.monotone q hcover hsigma f hpoint Fo hFo ht
  obtain ⟨F₀, hF₀⟩ := exists_shifted_terminal_flow_on_carrier G P04 (hB 0) hAr hcompact hcomplete
  let H : RicciFlow 3 G.limitCarrier.carrier (Ioc (-tau 0) 0) :=
    F₀.translate (tau 0 / 2)
      (by rintro _ ⟨t, ht, rfl⟩; exact ⟨by linarith [ht.1], by linarith [ht.2]⟩)
      ordConnected_Ioc ⟨-tau 0 / 2, ⟨by linarith [htau 0], by linarith [htau 0]⟩,
        0, ⟨by linarith [htau 0], le_rfl⟩, by linarith [htau 0]⟩
  obtain ⟨F, hFopen, hFzero⟩ := exists_attach_horizon_terminal_flow (htau 0) Fo H (by
    intro t ht
    rw [hinterior t ht]
    exact (hF₀ (t + tau 0 / 2) ⟨by linarith [ht.1], by linarith [ht.2]⟩).symm)
  refine ⟨F₀, hF₀, sigma, hsigma, F, ?_, ?_⟩
  · intro t ht
    rcases lt_or_eq_of_le ht.2 with htneg | rfl
    · rw [hFopen t (mem_iUnion.mpr ⟨0, ht.1, htneg⟩), hinterior t ⟨ht.1, htneg⟩,
        hF₀ (t + tau 0 / 2) ⟨by linarith [ht.1], by linarith⟩]
    · exact hFzero
  · intro p r K hK hKsub
    have hc := tendstoUniformlyOn_horizon_jets_of_chart_cover G P04 hAr hcompact hcomplete htmono hB
      q hcover hsigma Fo (by
        intro i z hz
        have heq : f i z = (Fo.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm z.2 := by
          ext v w
          exact hFo z.1 hz.1 i z.2 hz.2 v w
        simpa only [heq] using hpoint i z hz) p r hK hKsub
    apply hc.congr_right
    intro z hz
    have heq : (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (Fo.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) p).symm z.2) =ᶠ[𝓝 z]
        (fun z => (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) p).symm z.2) := by
      filter_upwards [((horizonOpenTime_isOpen tau).prod isOpen_univ).mem_nhds
        (show z ∈ horizonOpenTime tau ×ˢ (univ : Set (EuclideanSpace ℝ (Fin 3))) from
          ⟨(hKsub hz).1, mem_univ _⟩)] with y hy
      rw [hFopen y.1 hy.1]
    exact (heq.iteratedFDeriv ℝ r).self_of_nhds

end PoincareMT.ControlledBlowupCompactness
