import PoincareLib.Geometry.RicciFlow.Compactness.GeometricLimit.Overlap.SmoothExtraction
import PoincareLib.Geometry.RicciFlow.Compactness.GeometricLimit.Overlap.ChosenChart
import PoincareLib.Geometry.RicciFlow.Compactness.GeometricLimit.Overlap.FlowCarrier
import PoincareLib.Geometry.RicciFlow.Compactness.GeometricLimit.Stages.SourceEmbedding.PointedExhaustion
import PoincareLib.Geometry.RicciFlow.Compactness.GeometricLimit.Stages.SourceEmbedding.MetricExhaustion
import PoincareLib.Geometry.RicciFlow.Compactness.GeometricLimit.Stages.SourceEmbedding.UniformMetric

/-!
# Pointed terminal metric extraction

Controlled source charts construct a smooth pointed metric on their actual
overlap quotient. The source embeddings retain all metric jets and their
exhaustion boundaries escape every fixed source ball. No Ricci-flow equation
is assigned to a time-constant metric family.
Reference: Morgan--Tian, Theorem 5.6, pp. 86-87, and Claim 11.5, p. 270.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8
set_option maxHeartbeats 800000

open Set Filter Metric Poincare.Gluing Poincare.Analysis.Calculus
open scoped Manifold ContDiff Topology NNReal ENNReal

namespace PoincareMT.ChartDistance

theorem exists_pointed_metric_limit_of_controlled_charts
    {n : ℕ} (U : ℕ → Set (EuclideanSpace ℝ (Fin n))) (hU : ∀ i, IsOpen (U i))
    [∀ i, Nonempty (Piece U i)]
    {M : ℕ → Type*} [∀ k, MetricSpace (M k)]
    [∀ k, ChartedSpace (EuclideanSpace ℝ (Fin n)) (M k)]
    [∀ k, IsManifold (𝓡 n) ∞ (M k)]
    (e : ∀ k i, Piece U i → M k)
    (L : ℕ → ℝ≥0) (he : ∀ k i, LipschitzWith (L i) (e k i))
    (c : ℕ → ℝ) (hc : ∀ i, 0 < c i)
    (hlower : ∀ k i x y, c i * dist x y ≤ dist (e k i x) (e k i y))
    (hopen : ∀ k i, Topology.IsOpenEmbedding (e k i))
    (hconn : ∀ k (p : M k) r, IsPreconnected (ball p r))
    (hsmooth : letI : ∀ i, ChartedSpace (EuclideanSpace ℝ (Fin n)) (Piece U i) :=
        fun i => (hU i).isOpenEmbedding_subtypeVal.singletonChartedSpace
      ∀ k i, IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (e k i))
    (hb : ∀ i j (x : Piece U i) (y : Piece U j), ∃ B : ℝ,
      ∀ k, dist (e k i x) (e k j y) ≤ B)
    {i₀ : ℕ} (p : Piece U i₀)
    (hcover : ∀ A : ℝ, 0 < A → ∃ s : Finset ℕ, ∃ K : ∀ i, Set (Piece U i),
      (∀ i ∈ s, IsCompact (K i)) ∧
        ∀ᶠ k in atTop, ball (e k i₀ p) A ⊆ ⋃ i ∈ s, e k i '' K i)
    (g : ∀ k, RiemannianMetric n (M k))
    (hjets : ∀ i, LocallyEventuallyBoundedDerivatives (U i)
      (fun k => (g k).pullbackCoefficients (chartParametrization U hU (e k i))))
    (helliptic : ∀ i K, IsCompact K → K ⊆ U i →
      ∃ a : ℝ, 0 < a ∧ ∀ᶠ k in atTop, ∀ x ∈ K, ∀ v,
        a * ‖v‖ ^ 2 ≤ (g k).pullbackCoefficients (chartParametrization U hU (e k i)) x v v) :
    ∃ sigma : ℕ → ℕ, StrictMono sigma ∧ ∃ C : FlowCarrier.{0} n,
      letI : TopologicalSpace C.carrier := C.topologicalSpace
      letI : ChartedSpace (EuclideanSpace ℝ (Fin n)) C.carrier := C.chartedSpace
      letI : IsManifold (𝓡 n) ∞ C.carrier := C.isManifold
      ∃ (gLimit : RiemannianMetric n C.carrier) (pLimit : C.carrier)
        (E : ℕ → Set C.carrier) (f : ∀ k, C.carrier → M (sigma k)),
        (∀ j, IsOpen (E j)) ∧ (∀ j, IsConnected (E j)) ∧
        (∀ j, pLimit ∈ E j) ∧ (∀ j, IsCompact (closure (E j))) ∧
        (∀ j, closure (E j) ⊆ E (j + 1)) ∧ (⋃ j, E j) = univ ∧
        (∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x) ∧
          IsLocalDiffeomorphOn (𝓡 n) (𝓡 n) ∞ (f k) (E k) ∧
          f k pLimit = e (sigma k) i₀ p) ∧
        (∀ q m K, IsCompact K → K ⊆ (extChartAt (𝓡 n) q).target →
          TendstoUniformlyOn
            (fun k => iteratedFDeriv ℝ m ((g (sigma k)).pullbackCoefficients
              (f k ∘ (extChartAt (𝓡 n) q).symm)))
            (iteratedFDeriv ℝ m (gLimit.pullbackCoefficients (extChartAt (𝓡 n) q).symm))
            atTop K) ∧
        (∀ K, IsCompact K → ∀ epsilon > 0, ∀ᶠ k in atTop,
          ∀ x ∈ K, ∀ v w : TangentSpace (𝓡 n) x,
            gLimit.tangentNorm x v ≤ 1 → gLimit.tangentNorm x w ≤ 1 →
            |(g (sigma k)).inner (f k x)
                (mfderiv (𝓡 n) (𝓡 n) (f k) x v)
                (mfderiv (𝓡 n) (𝓡 n) (f k) x w) - gLimit.inner x v w| < epsilon) ∧
        ∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop, ∀ x ∈ frontier (E j),
          ENNReal.ofReal A ≤ edist (e (sigma k) i₀ p) (f k x) := by
  classical
  let : ∀ i, ChartedSpace (EuclideanSpace ℝ (Fin n)) (Piece U i) :=
    fun i => (hU i).isOpenEmbedding_subtypeVal.singletonChartedSpace
  let : ∀ i, IsManifold (𝓡 n) ∞ (Piece U i) :=
    fun i => (hU i).isOpenEmbedding_subtypeVal.isManifold_singleton
  let : ∀ i, LocallyCompactSpace (Piece U i) := fun i => (hU i).locallyCompactSpace
  have hs (i k : ℕ) : ContDiffOn ℝ ∞
      ((g k).pullbackCoefficients (chartParametrization U hU (e k i))) (U i) := by
    intro x hx
    exact ((g k).contDiffAt_pullbackCoefficients
      ((contMDiffOn_chartParametrization U hU (hsmooth k i).contMDiff).contMDiffAt
        ((hU i).mem_nhds hx))).contDiffWithinAt
  obtain ⟨sigma, hsigma, B, hBsmooth, hBjets⟩ :=
    exists_common_smoothSubsequenceExtraction hU
      (fun i k => (g k).pullbackCoefficients (chartParametrization U hU (e k i))) hs hjets
  obtain ⟨tau, htau, D, hD⟩ := exists_pairwise_limits (fun k => e (sigma k)) L
    (fun k => he (sigma k)) (fun i j x y => by
      obtain ⟨B, hB⟩ := hb i j x y
      exact ⟨B, fun k => hB (sigma k)⟩)
  let rho := sigma ∘ tau
  have hrho : StrictMono rho := hsigma.comp htau
  have hpoint (i j : ℕ) (x : Piece U i) (y : Piece U j) :
      Tendsto (fun k => dist (e (rho k) i x) (e (rho k) j y)) atTop
        (𝓝 (D i j (x, y))) :=
    (hD i j).tendstoLocallyUniformlyOn.tendsto_at (mem_univ (x, y))
  have hBjets' : ∀ i m K, IsCompact K → K ⊆ U i → TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m
        ((g (rho k)).pullbackCoefficients (chartParametrization U hU (e (rho k) i))))
      (iteratedFDeriv ℝ m (B i)) atTop K := by
    intro i m K hK hKU V hV
    exact htau.tendsto_atTop.eventually (hBjets i m K hK hKU V hV)
  have hBlocal (i : ℕ) : TendstoLocallyUniformlyOn
      (fun k => (g (rho k)).pullbackCoefficients (chartParametrization U hU (e (rho k) i)))
      (B i) atTop (U i) :=
    CoordinateTransition.locallyUniformly_of_tendsto_zeroJet (hU i) (hBjets' i 0)
  have hjets' (i : ℕ) : LocallyEventuallyBoundedDerivatives (U i)
      (fun k => (g (rho k)).pullbackCoefficients (chartParametrization U hU (e (rho k) i))) := by
    intro K hK hKU m
    obtain ⟨B, hB⟩ := hjets i K hK hKU m
    exact ⟨B, hrho.tendsto_atTop.eventually hB⟩
  have helliptic' : ∀ i K, IsCompact K → K ⊆ U i →
      ∃ a : ℝ, 0 < a ∧ ∀ᶠ k in atTop, ∀ x ∈ K, ∀ v,
        a * ‖v‖ ^ 2 ≤ (g (rho k)).pullbackCoefficients
          (chartParametrization U hU (e (rho k) i)) x v v := by
    intro i K hK hKU
    obtain ⟨a, ha, hbound⟩ := helliptic i K hK hKU
    exact ⟨a, ha, hrho.tendsto_atTop.eventually hbound⟩
  have hbound := locallyEventuallyBoundedDerivatives_source_transition U hU hpoint L
    (fun k => he (rho k)) c hc (fun k => hlower (rho k)) (fun k => hopen (rho k))
    (fun k => hconn (rho k)) (fun k => hsmooth (rho k)) (fun k => g (rho k)) hjets' helliptic'
  let O := overlapSystem hpoint L (fun k => he (rho k)) c hc (fun k => hlower (rho k))
    (fun k => hopen (rho k)) (fun k => hconn (rho k))
  have hO := overlapSystem_smooth U hU hpoint L (fun k => he (rho k)) c hc
    (fun k => hlower (rho k)) (fun k => hopen (rho k)) (fun k => hconn (rho k))
    (fun k => hsmooth (rho k)) hbound
  have hclosed := overlapSystem_closed hpoint L (fun k => he (rho k)) c hc
    (fun k => hlower (rho k)) (fun k => hopen (rho k)) (fun k => hconn (rho k))
  let := quotientChartedSpace U hU O
  let := quotient_isManifold U hU O hO
  have hcover' : ∀ A : ℝ, 0 < A → ∃ s : Finset ℕ, ∃ K : ∀ i, Set (Piece U i),
      (∀ i ∈ s, IsCompact (K i)) ∧
        ∀ᶠ k in atTop, ball (e (rho k) i₀ p) A ⊆ ⋃ i ∈ s, e (rho k) i '' K i := by
    intro A hA
    obtain ⟨s, K, hK, hcov⟩ := hcover A hA
    exact ⟨s, K, hK, hrho.tendsto_atTop.eventually hcov⟩
  obtain ⟨hconnected, E, hE, hEc, hEp, hEK, hEstep, hEcover, nu, hnu,
      f, hf, happrox, hreadout, hescape⟩ :=
    exists_pointed_source_exhaustion_with_boundary_escape U hU hD L
      (fun k => he (rho k)) c hc (fun k => hlower (rho k)) (fun k => hopen (rho k))
      (fun k => hconn (rho k)) (fun k => hsmooth (rho k)) hbound p hcover'
  let : ConnectedSpace (Quotient O.setoid) := hconnected
  obtain ⟨gChart, hgChart, hcompat⟩ := exists_compatibleMetrics_of_coordinate_limits U hU
    hpoint L (fun k => he (rho k)) c hc (fun k => hlower (rho k))
    (fun k => hopen (rho k)) (fun k => hconn (rho k)) (fun k => hsmooth (rho k))
    (fun k => g (rho k)) B hBlocal hBsmooth (by
      intro i x hx
      obtain ⟨a, ha, hlow⟩ := helliptic' i {x} isCompact_singleton (singleton_subset_iff.mpr hx)
      exact ⟨a, ha, hlow.mono fun k hk => hk x (mem_singleton x)⟩) hbound
  let C := O.flowCarrier U hU hO hclosed
  let gLimit := quotientMetric U hU O hO gChart hcompat
  let : T2Space (Quotient O.setoid) := O.quotient_t2Space hclosed
  have hEmono : Monotone E := monotone_nat_of_le_succ fun j => subset_closure.trans (hEstep j)
  have hsourceJets := source_exhaustion_pullbackCoefficients_tendsto_jets U hU O hO hE
    hEmono hEcover f (fun k => (hf k).2.1) L (fun k => he (rho (nu k))) c hc
    (fun k => hlower (rho (nu k))) (fun k => hopen (rho (nu k)))
    (fun k => hconn (rho (nu k))) (fun k => hsmooth (rho (nu k))) happrox hreadout
    (fun k => g (rho (nu k))) B hBsmooth (by
      intro i m K hK hKU V hV
      exact hnu.tendsto_atTop.eventually (hBjets' i m K hK hKU V hV))
  have hzero (i : ℕ) (K : Set (EuclideanSpace ℝ (Fin n)))
      (hK : IsCompact K) (hKU : K ⊆ U i) : TendstoUniformlyOn
      (fun k => (g (rho (nu k))).pullbackCoefficients
        (chartParametrization U hU (f k ∘ O.include i))) (B i) atTop K := by
    simpa only [Function.comp_def, iteratedFDeriv_zero_apply] using
      (ContinuousMultilinearMap.uniformContinuous_eval_const
        (0 : Fin 0 → EuclideanSpace ℝ (Fin n))).comp_tendstoUniformlyOn
          (hsourceJets i 0 K hK hKU)
  have htensor := source_exhaustion_uniform_metric_error U hU O hO hE hEmono hEcover
    f (fun k => (hf k).2.1) (fun k _ => g (rho (nu k))) (fun i _ => gChart i)
    (fun _ => hcompat) (J := univ) (fun i z => B i z.2)
    (fun i => (hBsmooth i).continuousOn.comp continuous_snd.continuousOn
      (fun z hz => hz.2)) (fun i _ _ => hgChart i) (by
      intro i K hK hKU
      exact ((hzero i (Prod.snd '' K) (hK.image continuous_snd)
        (by rintro x ⟨z, hz, rfl⟩; exact (hKU hz).2)).comp Prod.snd).mono
          (subset_preimage_image Prod.snd K))
  refine ⟨rho ∘ nu, hrho.comp hnu, C, gLimit, O.include i₀ p,
    E, f, hE, hEc, hEp, hEK, hEstep, hEcover, hf, ?_, ?_, hescape⟩
  · intro q m K hK hKq
    obtain ⟨i, _hi, htarget, hinverse⟩ := exists_chosen_quotient_chart U hU O q
    rw [htarget] at hKq
    have hcoeff := quotientMetric_pullbackCoefficients_eqOn U hU O hO gChart hcompat B hgChart i
    have hderiv : EqOn
        (iteratedFDeriv ℝ m (gLimit.pullbackCoefficients
          (chartParametrization U hU (O.include i))))
        (iteratedFDeriv ℝ m (B i)) K := by
      intro x hx
      exact eqOn_iteratedFDeriv_of_isOpen (hU i) hcoeff m (hKq hx)
    simp only [hinverse, comp_chartParametrization_include U hU O]
    exact (hsourceJets i m K hK hKq).congr_right hderiv.symm
  · intro K hK epsilon hepsilon
    exact (htensor K {0} hK isCompact_singleton (subset_univ _) epsilon hepsilon).mono
      (fun k hk x hx v w hv hw => hk 0 (mem_singleton 0) x hx v w hv hw)

end PoincareMT.ChartDistance
