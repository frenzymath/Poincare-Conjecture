import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Covering
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Ellipticity
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Jets
import PoincareLib.Geometry.RicciFlow.Compactness.Coordinates.IndexedCovering

/-!
# Fixed-index normal covers of the terminal metrics

The finite centers and normalized charts form the existing normal-cover
structure, evaluated on a constant metric family. This is purely Riemannian
data and does not assert that the constant family solves Ricci flow.
Reference: Morgan--Tian Claim 11.5, p. 270, and Proposition 5.14, pp. 90-91.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

private theorem exists_surjective_fin_zero {alpha : Type*} [Fintype alpha]
    (a : alpha) {N : ℕ} (hN : Fintype.card alpha ≤ N) :
    ∃ f : Fin (N + 1) → alpha, f 0 = a ∧ Function.Surjective f := by
  classical
  let : Nonempty alpha := ⟨a⟩
  let e : alpha ↪ Fin N :=
    { toFun := fun x => ⟨(Fintype.equivFin alpha x).val,
        (Fintype.equivFin alpha x).isLt.trans_le hN⟩
      inj' := fun x y h => (Fintype.equivFin alpha).injective
        (Fin.ext (congrArg (fun z : Fin N => z.val) h)) }
  refine ⟨Fin.cases a (Function.invFun e), rfl, ?_⟩
  intro x
  exact ⟨(e x).succ, Function.leftInverse_invFun e.injective x⟩

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem eventually_nonempty_terminal_normalChartCover
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {A : ℝ} (hA : 0 < A) :
    ∃ R rho : ℝ, 0 < rho ∧ 2 * rho < R ∧ ∃ N : ℕ, ∀ᶠ k : ℕ in atTop,
      Nonempty (NormalChartCover (fun _ => S.normalizedTerminalMetric k)
        (S.base k).2 (-1) 1 A R rho (1 / 4) (9 / 4) N) := by
  classical
  obtain ⟨R, rho, hrho, hrhoR, hcharts⟩ :=
    H.eventually_uniform_terminal_elliptic_normal_charts P04 hbound hA
  obtain ⟨N, hcover⟩ := H.eventually_uniform_terminal_finset_cover P04 hbound hA
    (by positivity : 0 < rho / 4)
  refine ⟨R, rho, hrho, hrhoR, N + 1, ?_⟩
  filter_upwards [hcharts, hcover] with k hkcharts hkcover
  obtain ⟨K₀, hK₀, hcard, hcover₀⟩ := hkcover
  let K := insert (S.base k).2 K₀
  have hbase : (S.base k).2 ∈ K := Finset.mem_insert_self _ _
  have hK : (↑K : Set _) ⊆ S.baseBall k A := by
    intro p hp
    rcases Finset.mem_insert.mp hp with rfl | hp
    · exact S.base_mem_baseBall k hA
    · exact hK₀ hp
  have hcard' : K.card ≤ N + 1 :=
    (Finset.card_insert_le _ _).trans (Nat.add_le_add_right hcard 1)
  obtain ⟨f, hf0, hf⟩ := exists_surjective_fin_zero (⟨(S.base k).2, hbase⟩ : K)
    (by simpa only [Fintype.card_coe] using hcard')
  choose L Phi hsource htarget hzero hL hderiv hgeo hdist hcoeff using
    fun p : K => hkcharts p (hK p.property)
  let g := S.normalizedTerminalMetric k
  refine ⟨{
    centre := fun i => f i
    chart := fun i => Phi (f i)
    centre_zero := congrArg Subtype.val hf0
    centre_mem := fun i => ?_
    source := fun i => hsource (f i)
    target := fun i => htarget (f i)
    map_zero := fun i => hzero (f i)
    normalized := fun i => ⟨L (f i), hL (f i), hderiv (f i)⟩
    radial_geodesic := fun i => hgeo (f i)
    radial_distance := fun i => hdist (f i)
    coefficients := fun i _ _ => hcoeff (f i)
    distances := ?_
    compact_image := ?_
    cover := ?_ }⟩
  · rw [S.normalizedTerminalMetric_ball]
    exact hK (f i).property
  · intro i x hx y hy
    apply g.toReal_edist_bounds_of_normal_pullback_bounds (f i) (Phi (f i))
      (by positivity) (by linarith) (by norm_num) (by norm_num)
      (hsource (f i)) (htarget (f i)) (hdist (f i))
      (fun z hz v => hcoeff (f i) z ?_ v) hx hy
    exact Metric.closedBall_subset_closedBall (by linarith) (Metric.ball_subset_closedBall hz)
  · intro i
    apply (isCompact_closedBall (0 : EuclideanSpace ℝ (Fin 3)) (rho / 4)).image_of_continuousOn
    apply (Phi (f i)).contMDiffOn.continuousOn.mono
    rw [hsource (f i)]
    exact Metric.closedBall_subset_ball (by linarith)
  · intro x hx
    rw [S.normalizedTerminalMetric_ball] at hx
    obtain ⟨p, hp, hxp⟩ := mem_iUnion₂.mp (hcover₀ hx)
    let q : K := ⟨p, Finset.mem_insert_of_mem hp⟩
    obtain ⟨i, hi⟩ := hf q
    have hxtarget : x ∈ (Phi q).target := by
      rw [htarget q]
      exact hxp.trans_le (ENNReal.ofReal_le_ofReal (by linarith : rho / 4 ≤ R))
    have hwsource : (Phi q).symm x ∈ Metric.ball 0 R := by
      rw [← hsource q]
      exact (Phi q).map_target hxtarget
    have heq : Phi q ((Phi q).symm x) = x := (Phi q).right_inv hxtarget
    refine mem_iUnion.mpr ⟨i, ?_⟩
    rw [hi]
    refine ⟨(Phi q).symm x, ?_, heq⟩
    have hnorm := hdist q ((Phi q).symm x) hwsource
    rw [heq] at hnorm
    have hsmall : ENNReal.ofReal ‖(Phi q).symm x‖ < ENNReal.ofReal (rho / 4) := by
      rw [← hnorm]
      exact hxp
    simpa only [Metric.mem_closedBall, dist_zero_right] using
      (show ‖(Phi q).symm x‖ < rho / 4 from
        (ENNReal.ofReal_lt_ofReal_iff (by positivity)).mp hsmall).le

theorem eventually_terminal_normalChartCover_metric_jet_bound
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {A R rho : ℝ} {N : ℕ} (hA : 0 < A) (hrho : 0 < rho) (hrhoR : rho < R) (m : ℕ) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ᶠ k : ℕ in atTop,
      ∀ cover : NormalChartCover (fun _ => S.normalizedTerminalMetric k)
        (S.base k).2 (-1) 1 A R rho (1 / 4) (9 / 4) N,
        cover.HasMetricJetBound m B := by
  obtain ⟨B, hB, hjet⟩ :=
    H.eventually_uniform_terminal_normal_metric_jet_bound P04 hbound hA hrho hrhoR m
  refine ⟨B, hB, ?_⟩
  filter_upwards [hjet] with k hk cover i x hx
  obtain ⟨L, hL, hderiv⟩ := cover.normalized i
  apply hk (cover.centre i) _ L (cover.chart i) (cover.source i) (cover.target i)
    (cover.map_zero i) hL hderiv (cover.radial_geodesic i) x hx
  simpa only [S.normalizedTerminalMetric_ball] using cover.centre_mem i

end PoincareMT.M30CommonBlowupControls
