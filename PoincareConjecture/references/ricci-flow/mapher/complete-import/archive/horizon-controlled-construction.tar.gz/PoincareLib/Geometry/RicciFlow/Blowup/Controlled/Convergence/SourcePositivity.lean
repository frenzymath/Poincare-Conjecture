import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourceTerminal
import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Coordinates.TerminalPositivity

/-!
# Positive terminal coefficients of controlled source charts

The closed ellipticity bound and symmetry of the genuine retained source
metrics survive the terminal coefficient limit, with one positive lower
bound on the whole closed chart slab.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

private theorem retainedCoefficients_symmetric
    {a b : ℝ} {D : PointedFlowSequence 3 a b} (G : PointedGeometricConvergence D)
    (q : G.limitCarrier.carrier) (k : ℕ) (z : ℝ × EuclideanSpace ℝ (Fin 3))
    (v w : EuclideanSpace ℝ (Fin 3)) :
    G.spatialSpacetimeCoefficients q k z v w = G.spatialSpacetimeCoefficients q k z w v := by
  exact ((D.flow (G.subsequence k)).metricAt z.1).symm _ _ _

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

private theorem tendsto_bilinear_evaluation
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {f : ℕ → E →L[ℝ] E →L[ℝ] ℝ} {F : E →L[ℝ] E →L[ℝ] ℝ}
    (h : Tendsto f atTop (𝓝 F)) (v w : E) :
    Tendsto (fun k => f k v w) atTop (𝓝 (F v w)) :=
  ((ContinuousLinearMap.apply ℝ ℝ w).continuous.tendsto (F v)).comp
    (((ContinuousLinearMap.apply ℝ (E →L[ℝ] ℝ) v).continuous.tendsto F).comp h)

/-- Genuine coefficient convergence retains symmetry and uniform positive
lower and upper metric bounds on the entire closed terminal slab. -/
theorem source_coefficients_symmetric_elliptic
    (hB : 0 ≤ B) (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target)
    (F : ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3)
    (hconv : ∀ z ∈ Icc 0 (T / 2) ×ˢ K,
      Tendsto (fun k => G.spatialSpacetimeCoefficients q k z) atTop (𝓝 (F z))) :
    (∀ z ∈ Icc 0 (T / 2) ×ˢ K, ∀ v w, F z v w = F z w v) ∧
      ∃ a b : ℝ, 0 < a ∧ 0 < b ∧ ∀ z ∈ Icc 0 (T / 2) ×ˢ K, ∀ v,
        a * ‖v‖ ^ 2 ≤ F z v v ∧ F z v v ≤ b * ‖v‖ ^ 2 := by
  constructor
  · intro z hz v w
    have hvw := tendsto_bilinear_evaluation (hconv z hz) v w
    have hwv := tendsto_bilinear_evaluation (hconv z hz) w v
    have heq : (fun k => G.spatialSpacetimeCoefficients q k z v w) =
        (fun k => G.spatialSpacetimeCoefficients q k z w v) := by
      funext k
      exact retainedCoefficients_symmetric G q k z v w
    rw [heq] at hvw
    exact tendsto_nhds_unique hvw hwv
  · obtain ⟨a, b, ha, hb, hell⟩ := exists_eventually_reference_closed_ellipticity G hB q hK hKc
    refine ⟨a, b, ha, hb, ?_⟩
    intro z hz v
    have heval := tendsto_bilinear_evaluation (hconv z hz) v v
    constructor
    · apply ge_of_tendsto heval
      exact hell.mono fun k hk =>
        (hk (z.1 + (-T / 2)) ⟨by linarith [hz.1.1], by linarith [hz.1.2]⟩ z.2 hz.2 v).1
    · apply le_of_tendsto heval
      exact hell.mono fun k hk =>
        (hk (z.1 + (-T / 2)) ⟨by linarith [hz.1.1], by linarith [hz.1.2]⟩ z.2 hz.2 v).2

/-- The actual terminal source producer yields smooth positive symmetric
coefficients and all-order convergence, without a boundary certificate. -/
theorem exists_smooth_positive_terminal_source_coefficients
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier) {x₀ : EuclideanSpace ℝ (Fin 3)} {ρ : ℝ} (hρ : 0 < ρ)
    (hchart : Metric.closedBall x₀ ρ ⊆ (extChartAt (𝓡 3) q).target) :
    ∃ F : ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3,
      ContDiffOn ℝ ∞ F (Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ) ∧
      (∀ z ∈ Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ, ∀ v w, F z v w = F z w v) ∧
      (∃ a b : ℝ, 0 < a ∧ 0 < b ∧
        ∀ z ∈ Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ, ∀ v,
          a * ‖v‖ ^ 2 ≤ F z v v ∧ F z v v ≤ b * ‖v‖ ^ 2) ∧
      (∀ m, EqOn
        (iteratedFDeriv ℝ m (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
          (G.limitFlow.metricAt z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2))
        (iteratedFDerivWithin ℝ m F (Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ))
        (Ioo 0 (T / 2) ×ˢ Metric.ball x₀ ρ)) ∧
      ∀ m, TendstoUniformlyOn
        (fun k => iteratedFDerivWithin ℝ m (G.spatialSpacetimeCoefficients q k)
          (Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ))
        (iteratedFDerivWithin ℝ m F (Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ))
        atTop (Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ) := by
  obtain ⟨F, hF, hinterior, hconv⟩ := exists_smooth_terminal_source_coefficients
    G P04 hB hAr hcompact hcomplete q hρ hchart
  have hpoint : ∀ z ∈ Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ,
      Tendsto (fun k => G.spatialSpacetimeCoefficients q k z) atTop (𝓝 (F z)) := by
    intro z hz
    exact AncientCompactness.tendsto_of_compact_zero_jets _ F _
      (fun K _ hK => (hconv 0).mono hK) hz
  obtain ⟨hsymm, hell⟩ := source_coefficients_symmetric_elliptic
    G hB q (isCompact_closedBall x₀ ρ) hchart F hpoint
  exact ⟨F, hF, hsymm, hell, hinterior, hconv⟩

end PoincareMT.ControlledBlowupCompactness
