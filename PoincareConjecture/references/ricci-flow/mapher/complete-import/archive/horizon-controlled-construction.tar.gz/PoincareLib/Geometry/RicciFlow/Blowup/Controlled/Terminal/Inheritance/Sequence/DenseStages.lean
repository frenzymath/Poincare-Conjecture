import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.DenseSliceJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.SliceInvariants

/-!
# Smooth metric convergence along dense canonical stage slices

A fixed finite chart family is tested through an increasing derivative order.
Choosing each good time after these tests retains all metric jets on those
charts together with any additional terminal continuity conditions.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000
set_option synthInstance.maxHeartbeats 100000

open Set Filter Metric
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.M30CommonBlowupControls

open ControlledBlowupCylinder
local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem exists_canonical_stage_slices_with_metric_convergence
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (sigma : ℕ → ℕ) {A T B eta : ℝ} (hA : 0 < A) (hT : 0 < T)
    (cyl : ∀ k, ControlledBlowupCylinder S (sigma k) A T B eta)
    {M : Type v} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    (g : RiemannianMetric 3 M) {U : Set M} (hU : IsOpen U)
    (Phi : ∀ k, PartialDiffeomorph (𝓡 3) (𝓡 3) M (sourceBall S (sigma k) A) ∞)
    (hPhi : ∀ k, (Phi k).source = U)
    {ι : Type*} [Fintype ι] (q : ι → M) (K : ι → Set M)
    (hK : ∀ i, IsCompact (K i) ∧ K i ⊆ U ∩ (extChartAt (𝓡 3) (q i)).source)
    (hterminal : ∀ i m, TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m (((cyl k).ordinaryFlow hT).metric 0
        |>.pullbackCoefficients (Phi k ∘ (extChartAt (𝓡 3) (q i)).symm)))
      (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm))
      atTop ((extChartAt (𝓡 3) (q i)) '' K i))
    (P : ℕ → ℝ → Prop)
    (hP : ∀ k, ∀ᶠ s in 𝓝[Icc (-T) 0] 0, P k s) :
    ∃ (s : ℕ → ℝ) (hs : ∀ k, s k ∈ Icc (-T) 0),
      Tendsto s atTop (𝓝 0) ∧
      (∀ k, P k (s k) ∧
        (S.base (sigma k)).1 + s k / S.scale (sigma k) ∈ (S.flow (sigma k)).interval ∧
        generalizedSliceStrongCanonicalNeighborhoods (S.flow (sigma k)) epsilon C
          (4 * S.scale (sigma k)) ((S.base (sigma k)).1 + s k / S.scale (sigma k))) ∧
      ∀ i m, TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ m ((rescaledMetric
          ((S.flow (sigma k)).metric ((S.base (sigma k)).1 + s k / S.scale (sigma k)))
          (S.scale (sigma k)) (S.base_scalar_pos (sigma k))).pullbackCoefficients
            ((cyl k).stageSlicePartialDiffeomorph hA (s k) (hs k) (Phi k) ∘
              (extChartAt (𝓡 3) (q i)).symm)))
        (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm))
        atTop ((extChartAt (𝓡 3) (q i)) '' K i) := by
  classical
  let a := Fintype.equivFin ι
  let c := fun i : ι => extChartAt (𝓡 3) (q i)
  let V := fun i : ι => (c i).target ∩ (c i).symm ⁻¹' U
  let J := fun i : ι => c i '' K i
  have hV (i : ι) : IsOpen (V i) :=
    (continuousOn_extChartAt_symm (q i)).isOpen_inter_preimage
      (isOpen_extChartAt_target (q i)) hU
  have hJ (i : ι) : IsCompact (J i) := (hK i).1.image_of_continuousOn
    ((continuousOn_extChartAt (q i)).mono (fun _ hx => ((hK i).2 hx).2))
  have hJV (i : ι) : J i ⊆ V i := by
    rintro _ ⟨x, hx, rfl⟩
    refine ⟨(c i).map_source ((hK i).2 hx).2, ?_⟩
    change (c i).symm (c i x) ∈ U
    rw [(c i).left_inv ((hK i).2 hx).2]
    exact ((hK i).2 hx).1
  have hmap (k : ℕ) (i : ι) :
      ContMDiffOn (𝓡 3) (𝓡 3) ∞ (Phi k ∘ (c i).symm) (V i) :=
    (Phi k).contMDiffOn_toFun.comp
      ((contMDiffOn_extChartAt_symm (q i)).mono inter_subset_left)
      (fun _ hz => (hPhi k).symm ▸ hz.2)
  obtain ⟨s, hs, hs0, hselected⟩ := H.exists_canonical_slices_preserving_metric_jets_and_properties
    sigma (fun _ => A) (fun _ => T) (fun _ => B) (fun _ => eta) (fun _ => hT) cyl
    (fun _ => Fintype.card ι) id
    (fun _ i => V (a.symm i)) (fun _ i => J (a.symm i))
    (fun _ i => hV (a.symm i)) (fun _ i => hJ (a.symm i))
    (fun _ i => hJV (a.symm i))
    (fun k i => Phi k ∘ (c (a.symm i)).symm)
    (fun k i => hmap k (a.symm i)) P hP
  refine ⟨s, hs, hs0, fun k =>
    ⟨(hselected k).1, (hselected k).2.1, (hselected k).2.2.1⟩, ?_⟩
  have hsmall : Tendsto (fun k : ℕ => ((k : ℝ) + 1)⁻¹) atTop (𝓝 0) :=
    tendsto_inv_atTop_zero.comp
      (tendsto_atTop_add_const_right atTop 1 tendsto_natCast_atTop_atTop)
  intro i m
  rw [Metric.tendstoUniformlyOn_iff]
  intro d hd
  filter_upwards [Metric.tendstoUniformlyOn_iff.mp (hterminal i m) (d / 2) (by positivity),
    hsmall.eventually (eventually_lt_nhds (by positivity : (0 : ℝ) < d / 2)),
    eventually_ge_atTop m] with k hk hkd hkm z hz
  have herror := (hselected k).2.2.2 (a i) m hkm z (by simpa only [a.symm_apply_apply] using hz)
  have hdist : dist
      (iteratedFDeriv ℝ m (((cyl k).ordinaryFlow hT).metric 0
        |>.pullbackCoefficients (Phi k ∘ (c i).symm)) z)
      (iteratedFDeriv ℝ m ((rescaledMetric
        ((S.flow (sigma k)).metric ((S.base (sigma k)).1 + s k / S.scale (sigma k)))
        (S.scale (sigma k)) (S.base_scalar_pos (sigma k))).pullbackCoefficients
          ((cyl k).stageSlicePartialDiffeomorph hA (s k) (hs k) (Phi k) ∘ (c i).symm)) z)
      ≤ ((k : ℝ) + 1)⁻¹ := by
    have hmap' : ((cyl k).stageSlicePartialDiffeomorph hA (s k) (hs k) (Phi k) : M → _) =
        (cyl k).sliceMap (s k) (hs k) ∘ Phi k := rfl
    rw [hmap', Function.comp_assoc]
    simpa only [a.symm_apply_apply, dist_eq_norm, norm_sub_rev] using herror
  exact (dist_triangle _ _ _).trans_lt (add_lt_add (hk z hz) (hdist.trans_lt hkd)) |>.trans_le
    (by simpa only [add_halves] using le_rfl)

end PoincareMT.M30CommonBlowupControls
