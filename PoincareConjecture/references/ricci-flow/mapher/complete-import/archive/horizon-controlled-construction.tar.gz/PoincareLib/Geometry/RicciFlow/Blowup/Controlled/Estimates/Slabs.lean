import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Data
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.Worldlines.Uniqueness

/-!
# Noncollapse on controlled finite slabs

The surviving noncollapsed slab of the long hypothesis agrees with any
controlled cylinder through the same terminal points. A slightly longer slab
retains the closed left endpoint of the controlled cylinder.
Reference: Morgan--Tian Theorem 11.8, pp. 272-278.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.M30LongBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ} {T₀ : ℝ≥0∞}

/-- Noncollapse belongs to the actual trajectories, independently of which
compatible cylinder is used to represent them. -/
theorem eventually_noncollapsed_on_cylinder
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    {A T : ℝ} (hA : 0 < A) (hT : 0 < T) (hT₀ : ENNReal.ofReal T < T₀) :
    ∀ᶠ k : ℕ in atTop, ∀ (B eta : ℝ) (e : ControlledBlowupCylinder S k A T B eta),
      ∀ s hs, ∀ x ∈ S.baseBall k A,
        GeneralizedKappaNoncollapsedAt (S.flow k) (e.embedding.pointMap s hs x) kappa r₀ := by
  obtain ⟨T', hT'nonneg, hTT', hT'₀⟩ := ENNReal.lt_iff_exists_real_btwn.mp hT₀
  have hTT'real : T < T' := ENNReal.ofReal_lt_ofReal_iff'.mp hTT' |>.1
  have hT' : 0 < T' := hT.trans hTT'real
  filter_upwards [H.slabs T' hT' hT'₀ A hA] with k hk B eta e s hs x hx
  obtain ⟨d⟩ := hk
  have hs' : s ∈ Ioc (-T') 0 := ⟨by linarith [hs.1], hs.2⟩
  have hzero : (0 : ℝ) ∈ Icc (-T) 0 := ⟨by linarith, le_rfl⟩
  have hzero' : (0 : ℝ) ∈ Ioc (-T') 0 := ⟨by linarith, le_rfl⟩
  have heq := e.embedding.pointMap_eq_on_overlap d.embedding
    ordConnected_Icc ordConnected_Ioc hx hx hzero hzero'
    ((e.zero_identity hzero x hx).trans (d.zero_identity hzero' x hx).symm) s hs hs'
  rw [heq]
  exact d.noncollapsed s hs' x hx

end PoincareMT.M30LongBlowupControls
