import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Retained.Exhaustion
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Limit.TerminalJets

/-! # Canonical jets of the actual full-horizon generalized cylinders -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))
  (F₀ : RicciFlow 3 G.limitCarrier.carrier (Ioc (-tau 0 / 2) (tau 0 / 2)))
  (hF₀ : ∀ t ∈ Ioo (-tau 0 / 2) (tau 0 / 2), F₀.metric t = G.limitFlow.metricAt t)
  (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau ∪ {0}))
  (hmatch : ∀ t ∈ Ioc (-tau 0) 0, F.metric t = F₀.metric (t + tau 0 / 2))
  (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
  (htmono : StrictMono tau) (hB : ∀ j, 0 ≤ B j)
  {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
  (hjets : ∀ q r K, IsCompact K → K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target →
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ r (horizonSpacetimeCoefficients G q (sigma k)))
      (iteratedFDeriv ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)) atTop K)
  (heta : Tendsto eta atTop (𝓝 0))

local notation "theLimit" => liftedLimit (horizonLimit G F₀ hF₀ F hmatch P04 hAr hcompact
  hcomplete htmono.monotone hB hsigma hjets heta)

theorem horizonRetainedCylinder_coefficient_eq (k : ℕ)
    (q : (liftedSliceCarrier.{u} G.limitCarrier).carrier) (a b : Fin 3)
    (p : ℝ × EuclideanSpace ℝ (Fin 3)) (ht : p.1 ∈ Icc (-tau k) 0)
    (hp : p.2 ∈ (extChartAt (𝓡 3) q).target)
    (hx : (extChartAt (𝓡 3) q).symm p.2 ∈ retainedSpace G (sigma k)) :
    blowupPullbackCoefficient (L := theLimit) (horizonRetainedCylinder G hsigma k) q a b p =
      horizonSpacetimeCoefficients G q.down (sigma k) p
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b) := by
  rw [blowupPullbackCoefficient, dif_pos ht]
  exact horizonRetainedCylinder_chart_inner G hsigma htmono.monotone k p.1 ht q p.2 hp hx _ _

theorem eventually_horizonRetainedCylinder_jet_eq
    (q : (liftedSliceCarrier.{u} G.limitCarrier).carrier) (j r : ℕ)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKU : K ⊆ {p | p ∈ (horizonOpenTime tau ∪ {0}) ×ˢ (extChartAt (𝓡 3) q).target ∧
      (extChartAt (𝓡 3) q).symm p.2 ∈ retainedSpace G (sigma j)}) :
    ∀ᶠ k in atTop,
      K ⊆ Icc (-tau k) 0 ×ˢ (extChartAt (𝓡 3) q).target ∧
      ∀ a b : Fin 3, ∀ p ∈ K,
        iteratedFDerivWithin ℝ r
          (blowupPullbackCoefficient (L := theLimit) (horizonRetainedCylinder G hsigma k) q a b)
          (Icc (-tau k) 0 ×ˢ (extChartAt (𝓡 3) q).target) p =
        iteratedFDerivWithin ℝ r
          (fun z => horizonSpacetimeCoefficients G q.down (sigma k) z
            (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))
          ((horizonOpenTime tau ∪ {0}) ×ˢ (extChartAt (𝓡 3) q).target) p := by
  have hIt : Prod.fst '' K ⊆ horizonOpenTime tau ∪ {0} := by
    rintro _ ⟨p, hp, rfl⟩
    exact (hKU hp).1.1
  filter_upwards [eventually_ge_atTop j,
    horizon_window_interval_strict_cofinal htau htmono.monotone (hK.image continuous_fst) hIt]
      with k hkj htime
  have hkp (p) (hp : p ∈ K) : p.1 ∈ Ioc (-tau k) 0 := htime (mem_image_of_mem Prod.fst hp)
  refine ⟨fun p hp => ⟨Ioc_subset_Icc_self (hkp p hp), (hKU hp).1.2⟩, ?_⟩
  intro a b p hp
  let D := Icc (-tau k) 0 ×ˢ (extChartAt (𝓡 3) q).target
  let U := (horizonOpenTime tau ∪ {0}) ×ˢ (extChartAt (𝓡 3) q).target
  let W := (extChartAt (𝓡 3) q).target ∩
    (extChartAt (𝓡 3) q).symm ⁻¹' retainedSpace G (sigma k)
  have hWo : IsOpen W := (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
    (isOpen_extChartAt_target q) (retainedSpace_open G (sigma k))
  have hpW : p.2 ∈ W := ⟨(hKU hp).1.2, retainedSpace_monotone G (hsigma.monotone hkj) (hKU hp).2⟩
  have hnear : Prod.snd ⁻¹' W ∈ 𝓝 p := (hWo.preimage continuous_snd).mem_nhds hpW
  have heq : (blowupPullbackCoefficient (L := theLimit) (horizonRetainedCylinder G hsigma k) q a b)
      =ᶠ[𝓝[D] p] (fun z => horizonSpacetimeCoefficients G q.down (sigma k) z
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) := by
    filter_upwards [mem_nhdsWithin_of_mem_nhds hnear, self_mem_nhdsWithin] with z hz hzD
    exact horizonRetainedCylinder_coefficient_eq G F₀ hF₀ F hmatch P04 hAr hcompact hcomplete
      htmono hB hsigma hjets heta k q a b z hzD.1 hz.1 hz.2
  have hpD : p ∈ D := ⟨Ioc_subset_Icc_self (hkp p hp), (hKU hp).1.2⟩
  rw [heq.iteratedFDerivWithin_eq (heq.eq_of_nhdsWithin hpD) r]
  apply iteratedFDerivWithin_congr_set _ r
  filter_upwards [(isOpen_Ioi.preimage continuous_fst).mem_nhds (hkp p hp).1] with z hz
  apply propext
  constructor
  · intro hzD
    exact ⟨horizon_window_interval_subset htmono k hzD.1, hzD.2⟩
  · intro hzU
    refine ⟨⟨hz.le, ?_⟩, hzU.2⟩
    rcases hzU.1 with ht | ht
    · obtain ⟨i, hi⟩ := mem_iUnion.mp ht
      exact hi.2.le
    · exact (mem_singleton_iff.mp ht).le

end PoincareMT.ControlledBlowupCompactness
