import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Retained

/-!
# Metrics of the retained generalized embeddings

The generalized-cylinder metric is exactly the normalized ordinary source
metric in the retained M07 coordinates, including terminal time zero.
Source: Morgan--Tian, Theorem 11.8, pp. 274--279.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

open ControlledBlowupCylinder

theorem smallFlow_inner_eq_source_pullback
    {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}
    (e : ControlledBlowupCylinder S k A T B eta) (hA : 0 < A) (hT : 0 < T)
    (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (x : (componentCarrier S k hA).shrink.carrier) (v w : TangentSpace (𝓡 3) x) :
    ((e.smallFlow hA hT).metric s).inner x v w =
      e.embedding.pullbackInner s hs (smallSourceCoordinate S k hA x)
        (mfderiv (𝓡 3) (𝓡 3) (smallSourceCoordinate S k hA) x v)
        (mfderiv (𝓡 3) (𝓡 3) (smallSourceCoordinate S k hA) x w) := by
  let d := (Poincare.Manifold.shrinkDiffeomorph (𝓡 3) (componentCarrier S k hA).carrier).symm
  let f := (Subtype.val : (componentCarrier S k hA).carrier → sourceBall S k A)
  let j := (Subtype.val : sourceBall S k A → ((S.flow k).slice (S.base k).1).carrier)
  have hd : MDifferentiableAt (𝓡 3) (𝓡 3) d x :=
    d.contMDiff.contMDiffAt.mdifferentiableAt (by simp)
  have hf : MDifferentiableAt (𝓡 3) (𝓡 3) f (d x) :=
    (contMDiff_subtype_val (n := ∞) (d x)).mdifferentiableAt (by simp)
  have hj : MDifferentiableAt (𝓡 3) (𝓡 3) j (f (d x)) :=
    (contMDiff_subtype_val (n := ∞) (f (d x))).mdifferentiableAt (by simp)
  have hdf := mfderiv_comp x hf hd
  have hdfj := mfderiv_comp x hj (hf.comp x hd)
  change mfderiv (𝓡 3) (𝓡 3) (smallSourceCoordinate S k hA) x = _ at hdfj
  rw [hdf] at hdfj
  change ((e.ordinaryFlow hT).metric s).inner (f (d x))
    (mfderiv (𝓡 3) (𝓡 3) f (d x) (mfderiv (𝓡 3) (𝓡 3) d x v))
    (mfderiv (𝓡 3) (𝓡 3) f (d x) (mfderiv (𝓡 3) (𝓡 3) d x w)) = _
  rw [e.ordinaryFlow_inner hT s hs, hdfj]
  rfl

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

noncomputable def retainedSmallMap (k : ℕ) :
    (liftedSliceCarrier.{u} G.limitCarrier).carrier →
      (componentCarrier S (idx (G.subsequence k)) (hA (G.subsequence k))).shrink.carrier :=
  fun x => ((G.embedding k).toFun (0, x.down)).2

theorem retainedSmallMap_contMDiffAt (k : ℕ)
    {x : (liftedSliceCarrier.{u} G.limitCarrier).carrier}
    (hx : x.down ∈ G.exhaustion k) :
    ContMDiffAt (𝓡 3) (𝓡 3) ∞ (retainedSmallMap G k) x := by
  have ht : (0 : ℝ) ∈ Ioo (-T / 2) (T / 2) := ⟨by linarith [hT], by linarith [hT]⟩
  exact ((G.embedding k).spatialMap_contMDiffAt (G.exhaustion_open k) ht hx).comp x
    (Poincare.Manifold.uliftDiffeomorph (𝓡 3) G.limitCarrier.carrier).contMDiff.contMDiffAt

theorem retainedCylinder_pullbackInner (k : ℕ) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (x : (liftedSliceCarrier.{u} G.limitCarrier).carrier) (hx : x.down ∈ G.exhaustion k)
    (v w : TangentSpace (𝓡 3) x) :
    (retainedCylinder G k).pullbackInner s hs x v w =
      (((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).metric s).inner
        (retainedSmallMap G k x)
        (mfderiv (𝓡 3) (𝓡 3) (retainedSmallMap G k) x v)
        (mfderiv (𝓡 3) (𝓡 3) (retainedSmallMap G k) x w) := by
  let f := retainedSourceCoordinate G k
  have hfx : x ∈ f.source := by
    change x ∈ (retainedSourceCoordinate G k).source
    rwa [retainedSourceCoordinate_source]
  have h := (e (G.subsequence k)).embedding.rebasePartialSource_pullbackInner
    f.toOpenPartialHomeomorph (retainedSourceCoordinate_target_subset G k)
    f.contMDiffOn_toFun f.contMDiffOn_invFun (sourceBall S _ _).isOpen s hs x hfx v w
  change (retainedCylinder G k).pullbackInner s hs x v w = _ at h
  rw [h, smallFlow_inner_eq_source_pullback _ _ _ s hs]
  have hsmall := (retainedSmallMap_contMDiffAt G k hx).mdifferentiableAt (by simp)
  have hsource : MDifferentiableAt (𝓡 3) (𝓡 3)
      (smallSourceCoordinate S (idx (G.subsequence k)) (hA (G.subsequence k)))
      (retainedSmallMap G k x) :=
    (smallSourceCoordinate S (idx (G.subsequence k)) (hA (G.subsequence k))).mdifferentiableAt
      (by simp) (by rw [smallSourceCoordinate_source]; trivial)
  have hder := mfderiv_comp x hsource hsmall
  change mfderiv (𝓡 3) (𝓡 3) f.toOpenPartialHomeomorph x = _ at hder
  rw [hder]
  rfl

end PoincareMT.ControlledBlowupCompactness
