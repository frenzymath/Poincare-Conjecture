import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Component
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.NegativeCurvature
import PoincareLib.Geometry.RicciFlow.Pullback

/-!
# Controlled source flows on terminal neighborhoods

A terminal embedding whose image lies in a controlled ball pulls the actual
normalized cylinder back to its fixed domain. Its terminal tensor is exactly
the pullback of the normalized terminal metric. This realizes the local
backward flows used in Morgan--Tian, Claim 11.5, p. 270.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}
  {M : Type v} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]

def terminalBallMap (f : M → S.terminalComponent k)
    (hfball : ∀ x, (f x).val ∈ S.baseBall k A) : M → sourceBall S k A :=
  fun x => ⟨(f x).val, hfball x⟩

omit [IsManifold (𝓡 3) ∞ M] in
theorem terminalBallMap_isLocalDiffeomorph (f : M → S.terminalComponent k)
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hfball : ∀ x, (f x).val ∈ S.baseBall k A) :
    IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ (terminalBallMap f hfball) := by
  let h := terminalBallMap f hfball
  have hmap : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞
      ((Subtype.val : S.terminalComponent k → _) ∘ f) := fun x =>
    (hf x).comp (𝓡 3) _ (Poincare.isLocalDiffeomorph_opensSubtypeVal
      (𝓡 3) (S.terminalComponent k) (f x))
  have hcont : Continuous h :=
    (continuous_subtype_val.comp hf.contMDiff.continuous).subtype_mk _
  intro x
  have hi := Poincare.isLocalDiffeomorph_opensSubtypeVal
    (𝓡 3) (sourceBall S k A) (h x)
  apply ((hmap x).comp (𝓡 3) (sourceBall S k A)
    hi.localInverse_isLocalDiffeomorphAt).congr_of_eventuallyEq
  filter_upwards [hcont.continuousAt.tendsto.eventually hi.localInverse_eventuallyEq_left]
    with y hy
  exact hy.symm

def terminalPullbackFlow (e : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    (f : M → S.terminalComponent k)
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hfball : ∀ x, (f x).val ∈ S.baseBall k A) : RicciFlow 3 M (Icc (-T) 0) :=
  (e.ordinaryFlow hT).pullbackWithConnection (terminalBallMap f hfball)
    (terminalBallMap_isLocalDiffeomorph f hf hfball) (fun s =>
      ((e.ordinaryFlow hT).metric s |>.pullbackOfLocalDiffeomorph
        (terminalBallMap f hfball) (terminalBallMap_isLocalDiffeomorph f hf hfball)).leviCivitaData)

theorem terminalPullbackFlow_terminal_inner
    (e : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    (f : M → S.terminalComponent k)
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hfball : ∀ x, (f x).val ∈ S.baseBall k A)
    (x : M) (v w : TangentSpace (𝓡 3) x) :
    ((e.terminalPullbackFlow hT f hf hfball).metric 0).inner x v w =
      (S.terminalComponentMetric k).inner (f x)
        (mfderiv (𝓡 3) (𝓡 3) f x v) (mfderiv (𝓡 3) (𝓡 3) f x w) := by
  let h := terminalBallMap f hfball
  have hh := terminalBallMap_isLocalDiffeomorph f hf hfball
  change ((e.ordinaryFlow hT).metric 0).inner (h x)
    (mfderiv (𝓡 3) (𝓡 3) h x v) (mfderiv (𝓡 3) (𝓡 3) h x w) = _
  rw [e.ordinaryFlow_terminal_inner hT]
  change (S.normalizedTerminalMetric k).inner (f x).val
    ((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) (h x)).comp
      (mfderiv (𝓡 3) (𝓡 3) h x) v)
    ((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) (h x)).comp
      (mfderiv (𝓡 3) (𝓡 3) h x) w) =
    (S.normalizedTerminalMetric k).inner (f x).val
    ((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : S.terminalComponent k → _) (f x)).comp
      (mfderiv (𝓡 3) (𝓡 3) f x) v)
    ((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : S.terminalComponent k → _) (f x)).comp
      (mfderiv (𝓡 3) (𝓡 3) f x) w)
  rw [← mfderiv_comp x ((contMDiff_subtype_val (n := ∞)).mdifferentiable (by simp) (h x))
      (hh.contMDiff.mdifferentiable (by simp) x),
    ← mfderiv_comp x ((contMDiff_subtype_val (n := ∞)).mdifferentiable (by simp) (f x))
      (hf.contMDiff.mdifferentiable (by simp) x)]
  rfl

theorem terminalPullbackFlow_curvature_bound
    (e : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    (f : M → S.terminalComponent k)
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hfball : ∀ x, (f x).val ∈ S.baseBall k A)
    (s : ℝ) (hs : s ∈ Icc (-T) 0) (x : M) :
    |((e.terminalPullbackFlow hT f hf hfball).connection s).curvatureTensorNorm x| ≤ B := by
  rw [LeviCivitaData.curvatureTensorNorm_eq_of_local_isometry
    ((e.terminalPullbackFlow hT f hf hfball).connection s)
    ((e.ordinaryFlow hT).connection s) isOpen_univ
    (terminalBallMap_isLocalDiffeomorph f hf hfball).contMDiff.contMDiffOn
    (fun _ _ _ _ => rfl) (mem_univ x)]
  exact e.ordinaryFlow_curvature_bound hT s hs _

theorem terminalPullbackFlow_negativeCurvaturePart_le
    (e : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    (f : M → S.terminalComponent k)
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hfball : ∀ x, (f x).val ∈ S.baseBall k A)
    (s : ℝ) (hs : s ∈ Icc (-T) 0) (x : M) :
    ((e.terminalPullbackFlow hT f hf hfball).connection s).negativeCurvaturePart x ≤ eta := by
  rw [LeviCivitaData.negativeCurvaturePart_eq_of_local_isometry
    ((e.terminalPullbackFlow hT f hf hfball).connection s)
    ((e.ordinaryFlow hT).connection s) isOpen_univ
    (terminalBallMap_isLocalDiffeomorph f hf hfball).contMDiff.contMDiffOn
    (fun _ _ _ _ => rfl) (mem_univ x)]
  exact e.ordinaryFlow_negativeCurvaturePart_le hT s hs _

theorem terminalPullbackFlow_curvatureDerivativeNorm
    (e : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    (f : M → S.terminalComponent k)
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hfball : ∀ x, (f x).val ∈ S.baseBall k A)
    (s : ℝ) (m : ℕ) (x : M) :
    ((e.terminalPullbackFlow hT f hf hfball).connection s).curvatureDerivativeNorm m x =
      ((e.ordinaryFlow hT).connection s).curvatureDerivativeNorm m (terminalBallMap f hfball x) := by
  have hh := terminalBallMap_isLocalDiffeomorph f hf hfball
  apply LeviCivitaData.curvatureDerivativeNorm_eq_pullback
    ((e.terminalPullbackFlow hT f hf hfball).connection s)
    ((e.ordinaryFlow hT).connection s) isOpen_univ hh.contMDiff.contMDiffOn
  · intro y _
    exact ⟨hh.mfderivToContinuousLinearEquiv (by simp) y, rfl⟩
  · exact fun _ _ _ _ => rfl
  · exact mem_univ x

end PoincareMT.ControlledBlowupCylinder
