import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.AncientVolume.ScalarRatio.Annular.ClosedCompactness
import Mathlib.Topology.MetricSpace.UniformConvergence

/-!
# Smooth convergence through a finite terminal boundary

Compact convex coefficient domains retain their boundary under smooth
compactness. Uniform next-jet bounds make the selected source jets
equicontinuous, so the interior limit determines the boundary and yields
convergence along the full original sequence.

Reference: Morgan--Tian, Proposition 5.14, pp. 90--91.
-/

set_option autoImplicit false

open Set Filter Metric
open scoped Topology ContDiff

namespace PoincareMT.ControlledConvergence

variable {X Y : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
  [FiniteDimensional ℝ X] [NormedAddCommGroup Y] [NormedSpace ℝ Y]
  [FiniteDimensional ℝ Y]

omit [FiniteDimensional ℝ X] [FiniteDimensional ℝ Y] in
/-- The canonical within-domain jet has the same bound as the ordinary
interior jet, including every boundary point of the coefficient domain. -/
theorem norm_withinJet_le_of_interior_bound
    {Ω : Set X} (hclosed : IsClosed Ω) (hconvex : Convex ℝ Ω)
    (hne : (interior Ω).Nonempty) {f : X → Y} (hf : ContDiffOn ℝ ∞ f Ω)
    (m : ℕ) {B : ℝ} (hbound : ∀ x ∈ interior Ω, ‖iteratedFDeriv ℝ m f x‖ ≤ B)
    {x : X} (hx : x ∈ Ω) : ‖iteratedFDerivWithin ℝ m f Ω x‖ ≤ B := by
  have hunique := uniqueDiffOn_convex hconvex hne
  have hm : (m : ℕ∞ω) ≤ ∞ := WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤)
  have hclosure : closure (interior Ω) = Ω :=
    (hconvex.closure_interior_eq_closure_of_nonempty_interior hne).trans hclosed.closure_eq
  apply ContinuousWithinAt.closure_le (hclosure.symm ▸ hx)
    (((hf.continuousOn_iteratedFDerivWithin hm hunique) x hx).norm.mono interior_subset)
    continuousWithinAt_const
  intro y hy
  rw [iteratedFDerivWithin_eq_iteratedFDeriv hunique
    ((hf.contDiffAt (mem_interior_iff_mem_nhds.mp hy)).of_le hm) (interior_subset hy)]
  exact hbound y hy

/-- Eventual bounds and smoothness suffice to recover a smooth limit on the
whole closed coefficient domain, with no change to the source sequence. -/
theorem exists_smooth_limit_on_compact_convex_of_interior_jets
    {Ω : Set X} (hΩ : IsCompact Ω) (hconvex : Convex ℝ Ω)
    (hne : (interior Ω).Nonempty) (f : ℕ → X → Y)
    (hf : ∀ᶠ k : ℕ in atTop, ContDiffOn ℝ ∞ (f k) Ω)
    (g : (m : ℕ) → X → X [×m]→L[ℝ] Y)
    (hinterior : ∀ m K, IsCompact K → K ⊆ interior Ω →
      TendstoUniformlyOn (fun k => iteratedFDerivWithin ℝ m (f k) Ω) (g m) atTop K)
    (hbound : ∀ m : ℕ, ∃ B : ℝ, 0 ≤ B ∧ ∀ᶠ k : ℕ in atTop, ∀ x ∈ Ω,
      ‖iteratedFDerivWithin ℝ m (f k) Ω x‖ ≤ B) :
    ∃ F : X → Y, ContDiffOn ℝ ∞ F Ω ∧
      (∀ m, EqOn (g m) (iteratedFDerivWithin ℝ m F Ω) (interior Ω)) ∧
      ∀ m, TendstoUniformlyOn
        (fun k => iteratedFDerivWithin ℝ m (f k) Ω)
        (iteratedFDerivWithin ℝ m F Ω) atTop Ω := by
  have hunique := uniqueDiffOn_convex hconvex hne
  obtain ⟨N, hN⟩ := eventually_atTop.mp hf
  let f' := fun k => f (max k N)
  have hf' (k : ℕ) : ContDiffOn ℝ ∞ (f' k) Ω := hN _ (le_max_right k N)
  have heq : ∀ᶠ k : ℕ in atTop, f' k = f k :=
    (eventually_ge_atTop N).mono fun k hk => congrArg f (max_eq_left hk)
  have hbound' (m : ℕ) : ∃ B : ℝ, 0 ≤ B ∧ ∀ k x, x ∈ Ω →
      ‖iteratedFDerivWithin ℝ m (f' k) Ω x‖ ≤ B := by
    obtain ⟨B, hB, hevent⟩ := hbound m
    obtain ⟨M, hM⟩ := eventually_atTop.mp hevent
    have hfinite (k : Fin M) : ∃ C : ℝ, ∀ x ∈ Ω,
        ‖iteratedFDerivWithin ℝ m (f' k) Ω x‖ ≤ C :=
      hΩ.exists_bound_of_continuousOn
        ((hf' k).continuousOn_iteratedFDerivWithin
          (WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤)) hunique)
    choose C hC using hfinite
    let D := ∑ k : Fin M, max (C k) 0
    refine ⟨max B D, le_max_of_le_left hB, ?_⟩
    intro k x hx
    by_cases hk : M ≤ k
    · exact (hM (max k N) (hk.trans (le_max_left k N)) x hx).trans (le_max_left B D)
    · have hkM : k < M := lt_of_not_ge hk
      have hCD : C ⟨k, hkM⟩ ≤ D :=
        (le_max_left (C ⟨k, hkM⟩) 0).trans
          (Finset.single_le_sum (fun i _ => le_max_right (C i) 0)
            (Finset.mem_univ (⟨k, hkM⟩ : Fin M)))
      exact (hC ⟨k, hkM⟩ x hx).trans (hCD.trans (le_max_right B D))
  obtain ⟨σ, hσ, F, hF, hjets⟩ :=
    Poincare.AncientVolume.exists_smooth_subsequence_on_closed_convex
      hΩ.isClosed hconvex hne f' hf' (fun K _ hK m => by
        obtain ⟨B, hB, hboundB⟩ := hbound' m
        exact ⟨B, hB, fun k x hx => hboundB k x (hK hx)⟩)
  have hsame (m : ℕ) : EqOn (g m) (iteratedFDerivWithin ℝ m F Ω) (interior Ω) := by
    intro x hx
    have hinside := hinterior m {x} isCompact_singleton (singleton_subset_iff.mpr hx)
    have hinside' : TendstoUniformlyOn
        (fun k => iteratedFDerivWithin ℝ m (f' k) Ω) (g m) atTop {x} :=
      hinside.congr (heq.mono fun k hk y _ => by rw [hk])
    exact tendsto_nhds_unique
      ((hinside'.tendsto_at (mem_singleton x)).comp hσ.tendsto_atTop)
      ((hjets m {x} isCompact_singleton
        (singleton_subset_iff.mpr (interior_subset hx))).tendsto_at (mem_singleton x))
  refine ⟨F, hF, hsame, fun m => ?_⟩
  let u := fun k (x : Ω) => iteratedFDerivWithin ℝ m (f' k) Ω x
  let v := fun x : Ω => iteratedFDerivWithin ℝ m F Ω x
  let : CompactSpace Ω := isCompact_iff_compactSpace.mp hΩ
  obtain ⟨B, hB, hBbound⟩ := hbound' (m + 1)
  have hLip (k : ℕ) : LipschitzWith ⟨B, hB⟩ (u k) := by
    apply lipschitzWith_iff_dist_le_mul.mpr
    intro x y
    have hdiff := (hf' k).differentiableOn_iteratedFDerivWithin
      (ENat.natCast_lt_of_coe_top_le_withTop (N := (∞ : ℕ∞ω)) le_rfl m) hunique
    have hnorm : ‖u k x - u k y‖ ≤ B * ‖(x : X) - y‖ := by
      apply hconvex.norm_image_sub_le_of_norm_hasFDerivWithin_le
        (fun z hz => (hdiff z hz).hasFDerivWithinAt) (fun z hz => ?_) y.property x.property
      rw [norm_fderivWithin_iteratedFDerivWithin]
      exact hBbound k z hz
    change dist (u k x) (u k y) ≤ B * dist x y
    simpa only [dist_eq_norm, Subtype.dist_eq] using hnorm
  have hequi : Equicontinuous u :=
    (LipschitzWith.uniformEquicontinuous u ⟨B, hB⟩ hLip).equicontinuous
  have hv : Continuous v :=
    continuousOn_iff_continuous_domRestrict.mp
      (hF.continuousOn_iteratedFDerivWithin
        (WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤)) hunique)
  have hclosed := hequi.isClosed_setOfPred_tendsto (l := atTop) hv
  have hpoint (x : Ω) : Tendsto (fun k => u k x) atTop (𝓝 (v x)) := by
    apply closure_minimal (t := {x : Ω | Tendsto (fun k => u k x) atTop (𝓝 (v x))})
      (s := Subtype.val ⁻¹' interior Ω) ?_ hclosed ?_
    · intro y hy
      have hc := hinterior m {y.val} isCompact_singleton (singleton_subset_iff.mpr hy)
      have hc' : TendstoUniformlyOn
          (fun k => iteratedFDerivWithin ℝ m (f' k) Ω) (g m) atTop {y.val} :=
        hc.congr (heq.mono fun k hk z _ => by rw [hk])
      have hp := hc'.tendsto_at (mem_singleton y.val)
      rw [hsame m hy] at hp
      exact hp
    · rw [Topology.IsEmbedding.subtypeVal.closure_eq_preimage_closure_image,
        Subtype.image_preimage_coe, inter_eq_right.mpr interior_subset,
        hconvex.closure_interior_eq_closure_of_nonempty_interior hne, hΩ.isClosed.closure_eq]
      exact x.property
  have hu : TendstoUniformly u v atTop := by
    exact UniformFun.tendsto_iff_tendstoUniformly.mp
      ((hequi.tendsto_uniformFun_iff_pi atTop v).mpr (tendsto_pi_nhds.mpr hpoint))
  have hwhole : TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ m (f' k) Ω)
      (iteratedFDerivWithin ℝ m F Ω) atTop Ω := by
    exact tendstoUniformlyOn_iff_tendstoUniformly_comp_coe.mpr hu
  exact hwhole.congr (heq.mono fun k hk x _ => by rw [hk])

/-- Ordinary interior metric-jet estimates suffice for the boundary
producer. Smoothness within the source domain constructs the boundary jet
bounds, and its interior jets agree with the ordinary M07 derivatives. -/
theorem exists_smooth_limit_on_compact_convex_of_open_jets
    {Ω : Set X} (hΩ : IsCompact Ω) (hconvex : Convex ℝ Ω)
    (hne : (interior Ω).Nonempty) (f : ℕ → X → Y)
    (hf : ∀ᶠ k : ℕ in atTop, ContDiffOn ℝ ∞ (f k) Ω)
    (g : (m : ℕ) → X → X [×m]→L[ℝ] Y)
    (hinterior : ∀ m K, IsCompact K → K ⊆ interior Ω →
      TendstoUniformlyOn (fun k => iteratedFDeriv ℝ m (f k)) (g m) atTop K)
    (hbound : ∀ m : ℕ, ∃ B : ℝ, 0 ≤ B ∧ ∀ᶠ k : ℕ in atTop,
      ∀ x ∈ interior Ω, ‖iteratedFDeriv ℝ m (f k) x‖ ≤ B) :
    ∃ F : X → Y, ContDiffOn ℝ ∞ F Ω ∧
      (∀ m, EqOn (g m) (iteratedFDerivWithin ℝ m F Ω) (interior Ω)) ∧
      ∀ m, TendstoUniformlyOn
        (fun k => iteratedFDerivWithin ℝ m (f k) Ω)
        (iteratedFDerivWithin ℝ m F Ω) atTop Ω := by
  apply exists_smooth_limit_on_compact_convex_of_interior_jets hΩ hconvex hne f hf g
  · intro m K hK hKΩ
    apply (hinterior m K hK hKΩ).congr
    filter_upwards [hf] with k hk x hx
    symm
    exact iteratedFDerivWithin_eq_iteratedFDeriv (uniqueDiffOn_convex hconvex hne)
      ((hk.contDiffAt (mem_interior_iff_mem_nhds.mp (hKΩ hx))).of_le
        (WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤))) (interior_subset (hKΩ hx))
  · intro m
    obtain ⟨B, hB, hboundB⟩ := hbound m
    refine ⟨B, hB, ?_⟩
    filter_upwards [hf, hboundB] with k hk hBk x hx
    exact norm_withinJet_le_of_interior_bound hΩ.isClosed hconvex hne hk m hBk hx

/-- A finite closed time slab preserves every within-domain jet, including
its terminal time, on the original source sequence and spatial chart. -/
theorem exists_smooth_terminal_limit_on_closed_slab
    {a b ρ : ℝ} (hab : a < b) {x₀ : X} (hρ : 0 < ρ)
    (f : ℕ → ℝ × X → Y)
    (hf : ∀ᶠ k : ℕ in atTop,
      ContDiffOn ℝ ∞ (f k) (Icc a b ×ˢ closedBall x₀ ρ))
    (g : (m : ℕ) → ℝ × X → (ℝ × X) [×m]→L[ℝ] Y)
    (hinterior : ∀ m K, IsCompact K → K ⊆ Ioo a b ×ˢ ball x₀ ρ →
      TendstoUniformlyOn
        (fun k => iteratedFDerivWithin ℝ m (f k) (Icc a b ×ˢ closedBall x₀ ρ))
        (g m) atTop K)
    (hbound : ∀ m : ℕ, ∃ B : ℝ, 0 ≤ B ∧ ∀ᶠ k : ℕ in atTop,
      ∀ z ∈ Icc a b ×ˢ closedBall x₀ ρ,
        ‖iteratedFDerivWithin ℝ m (f k) (Icc a b ×ˢ closedBall x₀ ρ) z‖ ≤ B) :
    ∃ F : ℝ × X → Y, ContDiffOn ℝ ∞ F (Icc a b ×ˢ closedBall x₀ ρ) ∧
      (∀ m, EqOn (g m) (iteratedFDerivWithin ℝ m F (Icc a b ×ˢ closedBall x₀ ρ))
        (Ioo a b ×ˢ ball x₀ ρ)) ∧
      ∀ m, TendstoUniformlyOn
        (fun k => iteratedFDerivWithin ℝ m (f k) (Icc a b ×ˢ closedBall x₀ ρ))
        (iteratedFDerivWithin ℝ m F (Icc a b ×ˢ closedBall x₀ ρ)) atTop
        (Icc a b ×ˢ closedBall x₀ ρ) := by
  have hint : interior (Icc a b ×ˢ closedBall x₀ ρ) = Ioo a b ×ˢ ball x₀ ρ := by
    rw [interior_prod_eq, interior_Icc, interior_closedBall x₀ hρ.ne']
  have hne : (interior (Icc a b ×ˢ closedBall x₀ ρ)).Nonempty := by
    rw [hint]
    exact ⟨((a + b) / 2, x₀), ⟨by constructor <;> linarith, mem_ball_self hρ⟩⟩
  have h := exists_smooth_limit_on_compact_convex_of_interior_jets
    (isCompact_Icc.prod (isCompact_closedBall x₀ ρ))
    ((convex_Icc a b).prod (convex_closedBall x₀ ρ)) hne f hf g
    (fun m K hK hsub => hinterior m K hK (by simpa only [hint] using hsub)) hbound
  simpa only [hint] using h

end PoincareMT.ControlledConvergence
