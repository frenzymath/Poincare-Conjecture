import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.IndexedCover
import PoincareLib.Topology.Sequences.Diagonal

/-!
# A common diagonal of terminal chart covers and jets

One subsequence retains the finite covers at every spatial stage, together
with all metric-jet bounds through that stage. Each derivative order keeps
its own eventual tail before the diagonal is chosen.
Reference: Morgan--Tian Claim 11.5, p. 270, and Proposition 5.14, pp. 90-91.
-/

set_option autoImplicit false
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem exists_diagonal_terminal_normalChartCovers_with_metric_jets
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S) :
    ∃ sigma : ℕ → ℕ, StrictMono sigma ∧
      ∃ R rho : ℕ → ℝ, ∃ N : ℕ → ℕ, ∃ B : ℕ → ℕ → ℝ,
        (∀ j, 0 < rho j ∧ 2 * rho j < R j) ∧ (∀ j m, 0 ≤ B j m) ∧
        ∀ k j, j ≤ k →
          ∃ cover : NormalChartCover (fun _ => S.normalizedTerminalMetric (sigma k))
            (S.base (sigma k)).2 (-1) 1 ((j : ℝ) + 1) (R j) (rho j) (1 / 4) (9 / 4) (N j),
            ∀ m ≤ j, cover.HasMetricJetBound m (B j m) := by
  classical
  choose R rho hrho hrhoR N hcover using fun j : ℕ =>
    H.eventually_nonempty_terminal_normalChartCover P04 hbound
      (by positivity : 0 < (j : ℝ) + 1)
  have hjetData (j m : ℕ) := H.eventually_terminal_normalChartCover_metric_jet_bound
    P04 hbound (N := N j) (R := R j) (rho := rho j)
    (by positivity : 0 < (j : ℝ) + 1) (hrho j)
    (by linarith [hrho j, hrhoR j]) m
  choose B hB hjet using hjetData
  let Q (j k : ℕ) : Prop :=
    ∃ cover : NormalChartCover (fun _ => S.normalizedTerminalMetric k)
      (S.base k).2 (-1) 1 ((j : ℝ) + 1) (R j) (rho j) (1 / 4) (9 / 4) (N j),
      ∀ m ≤ j, cover.HasMetricJetBound m (B j m)
  have hQ (j : ℕ) : ∀ᶠ k : ℕ in atTop, Q j k := by
    filter_upwards [hcover j, (eventually_all_finite (Set.finite_Iic j)).mpr
      (fun m _ => hjet j m)] with k hk hkjets
    obtain ⟨cover⟩ := hk
    exact ⟨cover, fun m hm => hkjets m hm cover⟩
  obtain ⟨sigma, hsigma, hselected⟩ := Poincare.exists_strictMono_forall_le_of_eventually hQ
  exact ⟨sigma, hsigma, R, rho, N, B, fun j => ⟨hrho j, hrhoR j⟩,
    hB, hselected⟩

end PoincareMT.M30CommonBlowupControls
