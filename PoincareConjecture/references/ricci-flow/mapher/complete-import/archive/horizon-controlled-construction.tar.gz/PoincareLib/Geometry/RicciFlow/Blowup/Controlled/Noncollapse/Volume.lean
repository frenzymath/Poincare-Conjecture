import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Metric.Coverage
import PoincareLib.Geometry.RicciFlow.Compactness.Convergence.Volume.Convergence
import PoincareLib.Geometry.RicciFlow.AncientKappa.Asymptotic.Compactness.Calibration

/-!
# Ball-volume convergence in generalized blow-up limits

The normalized source metrics and actual cylinder embeddings have two-sided
volume comparison at every retained time, including time zero. Completeness
of the limit makes its ball volumes continuous in positive radius, so the
comparison converges to equality without completeness of source slices.

References: Kleiner--Lott, Corollary 44.1, pp. 2682--2683, and Appendix E,
pp. 2848--2849; Morgan--Tian, Theorem 11.8, pp. 272--278.
-/

noncomputable section

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter MeasureTheory
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.measurableSpace FlowCarrier.borelSpace
  FlowCarrier.t3Space FlowCarrier.secondCountable

variable {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
  (G : GeneralizedBlowupConvergence S J.domain)

/-- Volume of the normalized source ball centered at the actual image point.
The value before the time is retained is irrelevant to convergence. -/
def normalizedSourceBallVolume (k : ℕ) (t : ℝ) (p : G.limit.carrier.carrier) (r : ℝ) : ℝ≥0∞ :=
  if ht : t ∈ Icc (-G.exhaustion.time k) 0 then
    (G.normalizedSourceMetric k t).volumeMeasure
      ((G.normalizedSourceMetric k t).ball ((G.embedding k).forward t ht p) r)
  else 0

/-- Arbitrarily small radius and density distortion bounds the actual source
ball volume from both sides at every limit point. -/
theorem eventually_normalizedSourceBallVolume_bounds
    {t r C : ℝ} (ht : t ∈ J.domain) (ht0 : t ≤ 0)
    (p : G.limit.carrier.carrier) (hr : 0 < r) (hC : 1 < C) :
    ∀ᶠ k in atTop,
      G.normalizedSourceBallVolume k t p r ≤
        ENNReal.ofReal C ^ 3 * (G.limit.flow.metric t).volumeMeasure
          ((G.limit.flow.metric t).ball p (C * r)) ∧
      (G.limit.flow.metric t).volumeMeasure ((G.limit.flow.metric t).ball p (r / C)) ≤
        ENNReal.ofReal C ^ 3 * G.normalizedSourceBallVolume k t p r := by
  let g := G.limit.flow.metric t
  let : EMetricSpace G.limit.carrier.carrier := G.limit.carrier.metricEMetricSpace g
  let R := C * r + 1
  let V := g.ball p R
  have hCp : 0 < C := zero_lt_one.trans hC
  have hcompact : IsCompact (closure V) :=
    g.isCompact_closure_ball_of_metricComplete (G.limit.complete t ht) p R
  have hball (s : ℝ) : IsOpen (g.ball p s) :=
    isOpen_lt (continuous_const.edist continuous_id) continuous_const
  have hV : IsOpen V := hball R
  have hsingle : ({t} : Set ℝ) ⊆ J.domain := singleton_subset_iff.mpr ht
  have hsingle0 : ({t} : Set ℝ) ⊆ Iic 0 := singleton_subset_iff.mpr ht0
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset hcompact
  filter_upwards [G.eventually_normalized_tangentNorm_bounds
      (isCompact_singleton.prod hcompact) (fun _ hz => hsingle hz.1) hC,
    G.eventually_source_ball_subset_slice_image_ball isCompact_singleton hsingle hsingle0 p hr hC,
    G.exhaustion.time_cofinal {t} isCompact_singleton hsingle,
    eventually_ge_atTop j] with k hk hcover htime hjk
  have htk : t ∈ Icc (-G.exhaustion.time k) 0 := htime (mem_singleton t)
  simp only [normalizedSourceBallVolume, dif_pos htk]
  let h := G.normalizedSourceMetric k t
  let e := (G.embedding k).sliceHomeomorph (G.exhaustion.space_open k) t htk
  have hVe : V ⊆ e.source := subset_closure.trans (hj.trans (G.exhaustion.space_increasing hjk))
  have he : ∀ x ∈ e.source, ContMDiffAt (𝓡 3) (𝓡 3) ∞ e x :=
    fun x hx => ((G.embedding k).forward_smooth t htk x hx).contMDiffAt
      (e.open_source.mem_nhds hx)
  have hei : ∀ y ∈ e.target, ContMDiffAt (𝓡 3) (𝓡 3) ∞ e.symm y :=
    fun y hy => ((G.embedding k).inverse_smooth t htk y hy).contMDiffAt
      (e.open_target.mem_nhds hy)
  have hed : e.MDifferentiable (𝓡 3) (𝓡 3) :=
    ⟨fun x hx => (he x hx).mdifferentiableAt (by simp) |>.mdifferentiableWithinAt,
      fun y hy => (hei y hy).mdifferentiableAt (by simp) |>.mdifferentiableWithinAt⟩
  have hf : ∀ x ∈ V, ∀ v : TangentSpace (𝓡 3) x,
      h.tangentNorm (e x) (mfderiv (𝓡 3) (𝓡 3) e x v) ≤ C * g.tangentNorm x v :=
    fun x hx v => (hk (t, x) ⟨mem_singleton t, subset_closure hx⟩ htk v).1
  have hb : ∀ x ∈ V, ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ C * h.tangentNorm (e x) (mfderiv (𝓡 3) (𝓡 3) e x v) :=
    fun x hx v => (hk (t, x) ⟨mem_singleton t, subset_closure hx⟩ htk v).2
  have hlarge : g.ball p (C * r) ⊆ V := fun x hx =>
    hx.trans_le (ENNReal.ofReal_le_ofReal (by dsimp [R]; linarith))
  have hsmall : g.ball p (r / C) ⊆ V := by
    intro x hx
    apply hx.trans_le (ENNReal.ofReal_le_ofReal ?_)
    have hdiv : r / C ≤ r := div_le_self hr.le hC.le
    have hmul : r ≤ C * r := by nlinarith
    dsimp [R]
    linarith
  constructor
  · apply (measure_mono (hcover t (mem_singleton t) htk)).trans
    exact g.volumeMeasure_image_le_of_tangentNorm_le h e hV hVe
      (fun x hx => (he x hx).of_le (by simp) |>.contMDiffWithinAt) hCp hf
      (hball (C * r)).measurableSet hlarge
  · have himage : IsOpen (e '' g.ball p (r / C)) :=
      e.isOpen_image_of_subset_source (hball (r / C)) (hsmall.trans hVe)
    have hinv := g.inverse_tangentNorm_le_of_le h e hed hVe hb
    have hvol := h.volumeMeasure_image_le_of_tangentNorm_le g e.symm
      (e.isOpen_image_of_subset_source hV hVe)
      (by rintro _ ⟨x, hx, rfl⟩; exact e.map_source (hVe hx))
      (fun y hy => (hei y hy).of_le (by simp) |>.contMDiffWithinAt) hCp hinv
      himage.measurableSet (image_mono hsmall)
    have hback : e.symm '' (e '' g.ball p (r / C)) = g.ball p (r / C) := by
      rw [image_image]
      exact Set.EqOn.image_eq_self (fun x hx => e.left_inv (hVe (hsmall hx)))
    rw [hback] at hvol
    apply hvol.trans (mul_le_mul' le_rfl (measure_mono ?_))
    have hi := g.image_ball_subset_ball_of_tangentNorm_le h e p hCp
      (hsmall.trans hVe) (fun x hx => (he x hx).of_le (by simp))
      (fun x hx => hf x (hsmall hx))
    change e '' g.ball p (r / C) ⊆ h.ball (e p) r
    simpa only [mul_div_cancel₀ _ hCp.ne'] using hi

/-- Normalized source ball volumes converge to the actual calibrated limit
ball volume, including the terminal time. -/
theorem tendsto_normalizedSourceBallVolume
    {t r : ℝ} (ht : t ∈ J.domain) (ht0 : t ≤ 0)
    (p : G.limit.carrier.carrier) (hr : 0 < r) :
    Tendsto (fun k => G.normalizedSourceBallVolume k t p r) atTop
      (𝓝 (calibratedMetricVolume (G.limit.flow.metric t) ((G.limit.flow.metric t).ball p r))) := by
  rw [calibratedMetricVolume_eq_volumeMeasure]
  apply Poincare.tendsto_of_ball_volume_radius_squeeze (r := r)
    (V := fun ρ => (G.limit.flow.metric t).volumeMeasure ((G.limit.flow.metric t).ball p ρ)) 3
  · exact (G.limit.flow.metric t).continuousAt_ball_volume_of_metricComplete
      (G.limit.complete t ht) p hr
  · intro C hC
    exact (G.eventually_normalizedSourceBallVolume_bounds ht ht0 p hr hC).mono (fun _ h => h.1)
  · intro C hC
    exact (G.eventually_normalizedSourceBallVolume_bounds ht ht0 p hr hC).mono (fun _ h => h.2)

end PoincareMT.GeneralizedBlowupConvergence
