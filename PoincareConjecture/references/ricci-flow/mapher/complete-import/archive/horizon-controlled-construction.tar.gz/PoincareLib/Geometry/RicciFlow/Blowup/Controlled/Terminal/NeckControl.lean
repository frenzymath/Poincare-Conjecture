import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Positive

/-!
# Scalar bounds from control by actual neck centers

For the positive-curvature branch, transferring the end neck of a cap and
its scalar ratio suffices. No limit cap certificate is required.

Reference: Morgan--Tian, Claim 11.7, p. 271.
-/

set_option autoImplicit false

open Set
open scoped Manifold ContDiff

universe u

namespace PoincareMT.RiemannianMetric

theorem exists_universal_neck_control_scalar_bound_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ < 1 / 2 ∧
      ∀ (M : Type u) [TopologicalSpace M] [T3Space M]
        [ConnectedSpace M] [Nonempty M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
        [IsManifold (𝓡 3) ∞ M] [MeasurableSpace M] [BorelSpace M],
      ∀ (g : RiemannianMetric 3 M) (D : LeviCivitaData g),
        MetricComplete g → D.StrictlyPositiveSectionalCurvature →
      ∀ epsilon C cutoff : ℝ, 0 < epsilon → epsilon ≤ epsilon₀ → 0 ≤ C →
        (∀ x : M, cutoff < D.scalarCurvature x →
          ∃ N : EpsilonNeck g, N.epsilon = epsilon ∧
            D.scalarCurvature x ≤ C * D.scalarCurvature N.center) →
        ∃ B : ℝ, 0 < B ∧ ∀ x : M, D.scalarCurvature x ≤ B := by
  obtain ⟨epsilon₀, hpos, hhalf, hscale⟩ := exists_universal_neck_scale_lower_bound.{u}
  refine ⟨epsilon₀, hpos, hhalf, ?_⟩
  intro M _ _ _ _ _ _ _ _ g D hcomplete hpositive epsilon C cutoff hepsilon hsmall hC hcontrol
  obtain ⟨rho, hrho, hneck⟩ :=
    hscale M g D hcomplete hpositive epsilon hepsilon hsmall
  refine ⟨max 1 (max cutoff (C * (1 / rho ^ 2))),
    lt_of_lt_of_le zero_lt_one (le_max_left _ _), ?_⟩
  intro x
  by_cases hx : cutoff < D.scalarCurvature x
  · obtain ⟨N, heq, hbound⟩ := hcontrol x hx
    have hcenter := N.scalar_center_le_of_scale_lower D hrho (hneck N heq)
    exact (hbound.trans (mul_le_mul_of_nonneg_left hcenter hC)).trans
      ((le_max_right _ _).trans (le_max_right _ _))
  · exact (le_of_not_gt hx).trans ((le_max_left _ _).trans (le_max_right _ _))

end PoincareMT.RiemannianMetric
