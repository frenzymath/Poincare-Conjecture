import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Charts
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Derivatives
import PoincareLib.Geometry.Riemannian.Coordinates.Exponential.JetBounds.CurvatureNaturality
import PoincareLib.Geometry.Riemannian.Coordinates.Transitions

/-!
# Curvature derivatives of the normalized terminal metrics

The terminal subtype inclusion is a local isometry. Transporting the actual
Shi estimates on the controlled cylinders bounds every curvature derivative
on each fixed terminal ball, without choosing a common backward interval.
Reference: Morgan--Tian Corollary 11.4 and Claim 11.5, pp. 269-270.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

theorem ordinaryFlow_terminal_curvatureDerivativeNorm
    {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}
    (e : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    (m : ℕ) (x : sourceBall S k A) :
    ((e.ordinaryFlow hT).connection 0).curvatureDerivativeNorm m x =
      (S.normalizedTerminalConnection k).curvatureDerivativeNorm m x.val := by
  apply LeviCivitaData.curvatureDerivativeNorm_eq_pullback
    ((e.ordinaryFlow hT).connection 0) (S.normalizedTerminalConnection k)
    (f := Subtype.val) isOpen_univ contMDiff_subtype_val.contMDiffOn
  · intro y _
    let : FiniteDimensional ℝ (TangentSpace (𝓡 3) y) := by
      unfold TangentSpace
      infer_instance
    let df : TangentSpace (𝓡 3) y →L[ℝ] TangentSpace (𝓡 3) y.val :=
      mfderiv (𝓡 3) (𝓡 3)
        (Subtype.val : sourceBall S k A → ((S.flow k).slice (S.base k).1).carrier) y
    have hbij : Function.Bijective df :=
      ((e.ordinaryFlow hT).metric 0).mfderiv_bijective_of_pullback_eq
      (S.normalizedTerminalMetric k) y
      (fun v w => (e.ordinaryFlow_terminal_inner hT y v w).symm)
    refine ⟨(LinearEquiv.ofBijective df.toLinearMap hbij).toContinuousLinearEquiv, ?_⟩
    ext v
    rfl
  · intro y _ v w
    exact e.ordinaryFlow_terminal_inner hT y v w
  · exact mem_univ x

end PoincareMT.ControlledBlowupCylinder

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

/-- Each derivative order has its own uniform eventual bound on a fixed ball. -/
theorem eventually_normalized_terminal_curvatureDerivative_bound
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    (A : ℝ) (hA : 0 < A) (m : ℕ) :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ k : ℕ in atTop, ∀ x ∈ S.baseBall k A,
      (S.normalizedTerminalConnection k).curvatureDerivativeNorm m x ≤ D := by
  obtain ⟨T, B, hT, hB, hcyl⟩ :=
    H.eventually_controlled_cylinders_on_fixed_ball P04 hbound (A + 1) (by linarith)
  obtain ⟨D, hD, hderiv⟩ := ControlledBlowupCylinder.exists_uniform_curvatureDerivative_bound
    P04 hA (by linarith : A < A + 1) hT hB.le m
  refine ⟨D, hD, ?_⟩
  filter_upwards [hcyl 1 zero_lt_one, H.balls_compact (A + 1) (by linarith)]
    with k hk hcompact x hx
  obtain ⟨e⟩ := hk
  have hx' : x ∈ S.baseBall k (A + 1) :=
    S.closure_baseBall_subset k hA (by linarith) (subset_closure hx)
  have h := hderiv S k 1 e hcompact 0 ⟨by linarith, le_rfl⟩ ⟨x, hx'⟩ hx
  rwa [e.ordinaryFlow_terminal_curvatureDerivativeNorm] at h

end PoincareMT.M30CommonBlowupControls
