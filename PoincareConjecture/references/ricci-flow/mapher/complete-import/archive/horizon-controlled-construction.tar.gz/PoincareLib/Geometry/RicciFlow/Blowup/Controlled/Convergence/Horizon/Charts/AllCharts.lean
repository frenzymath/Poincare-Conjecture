import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.Carrier
import PoincareLib.Analysis.Calculus.SmoothCompactness.EventualUniqueness
import PoincareLib.Geometry.RicciFlow.AncientKappa.Asymptotic.Compactness.Coordinates.BilinearConvergence

/-! # Full-horizon convergence in every chart of the retained carrier -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

theorem tendsto_horizon_coefficient_of_chart_cover
    (q : ℕ → G.limitCarrier.carrier)
    (hcover : ∀ x : G.limitCarrier.carrier, ∃ i, x ∈ (extChartAt (𝓡 3) (q i)).source)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau))
    (hpoint : ∀ i z, z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target →
      Tendsto (fun k => horizonSpacetimeCoefficients G (q i) (sigma k) z) atTop
        (𝓝 ((F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm z.2)))
    (p : G.limitCarrier.carrier) {t : ℝ} (ht : t ∈ horizonOpenTime tau)
    {x : EuclideanSpace ℝ (Fin 3)} (hx : x ∈ (extChartAt (𝓡 3) p).target)
    (v w : EuclideanSpace ℝ (Fin 3)) :
    Tendsto (fun k => horizonSpacetimeCoefficients G p (sigma k) (t, x) v w) atTop
      (𝓝 ((F.metric t).pullbackCoefficients (extChartAt (𝓡 3) p).symm x v w)) := by
  let y := (extChartAt (𝓡 3) p).symm x
  obtain ⟨i, hi⟩ := hcover y
  let c := extChartAt (𝓡 3) (q i)
  let z := c y
  have hz : z ∈ c.target := c.map_source hi
  have hxy : y = c.symm z := (c.left_inv hi).symm
  have hinv := isInvertible_mfderivWithin_extChartAt_symm hz
  simp only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] at hinv
  obtain ⟨a, ha⟩ := hinv.surjective (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) p).symm x v)
  obtain ⟨b, hb⟩ := hinv.surjective (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) p).symm x w)
  have heval : Continuous (fun D : SpacetimeBounds.MetricCoefficient 3 => D a b) :=
    (continuous_id.clm_apply continuous_const).clm_apply continuous_const
  have hc := (heval.tendsto _).comp (hpoint i (t, z) ⟨ht, hz⟩)
  have htarg : (F.metric t).pullbackCoefficients c.symm z a b =
      (F.metric t).pullbackCoefficients (extChartAt (𝓡 3) p).symm x v w := by
    change (F.metric t).inner (c.symm z) (mfderiv (𝓡 3) (𝓡 3) c.symm z a)
      (mfderiv (𝓡 3) (𝓡 3) c.symm z b) = _
    rw [ha, hb, ← hxy]
    rfl
  rw [htarg] at hc
  apply hc.congr'
  exact (hsigma.tendsto_atTop.eventually
    (eventually_horizonSpacetimeCoefficients_compatible G p (q i) hx hz hxy v w a b ha.symm hb.symm)).mono
      fun k hk => (hk t).symm

theorem tendsto_horizon_bilinear_coefficient_of_chart_cover
    (q : ℕ → G.limitCarrier.carrier)
    (hcover : ∀ x : G.limitCarrier.carrier, ∃ i, x ∈ (extChartAt (𝓡 3) (q i)).source)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau))
    (hpoint : ∀ i z, z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target →
      Tendsto (fun k => horizonSpacetimeCoefficients G (q i) (sigma k) z) atTop
        (𝓝 ((F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm z.2)))
    (p : G.limitCarrier.carrier) {t : ℝ} (ht : t ∈ horizonOpenTime tau)
    {x : EuclideanSpace ℝ (Fin 3)} (hx : x ∈ (extChartAt (𝓡 3) p).target) :
    Tendsto (fun k => horizonSpacetimeCoefficients G p (sigma k) (t, x)) atTop
      (𝓝 ((F.metric t).pullbackCoefficients (extChartAt (𝓡 3) p).symm x)) := by
  have hentry (a b : Fin 3) := tendsto_horizon_coefficient_of_chart_cover G q hcover hsigma F hpoint
    p ht hx (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)
  have he := Poincare.Analysis.Calculus.tendstoUniformlyOn_bilinear_of_basis_entries
    (K := ({()} : Set Unit)) (A := fun k _ => horizonSpacetimeCoefficients G p (sigma k) (t, x))
    (B := fun _ => (F.metric t).pullbackCoefficients (extChartAt (𝓡 3) p).symm x)
    (fun a b => by
      apply Metric.tendstoUniformlyOn_iff.mpr
      intro epsilon hepsilon
      filter_upwards [Metric.tendsto_nhds.mp (hentry a b) epsilon hepsilon] with k hk u hu
      simpa only [dist_comm] using hk)
  exact he.tendsto_at (mem_singleton ())

theorem tendstoUniformlyOn_horizon_jets_of_chart_cover
    (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (htmono : StrictMono tau) (hB : ∀ j, 0 ≤ B j)
    (q : ℕ → G.limitCarrier.carrier)
    (hcover : ∀ x : G.limitCarrier.carrier, ∃ i, x ∈ (extChartAt (𝓡 3) (q i)).source)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau))
    (hpoint : ∀ i z, z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target →
      Tendsto (fun k => horizonSpacetimeCoefficients G (q i) (sigma k) z) atTop
        (𝓝 ((F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm z.2)))
    (p : G.limitCarrier.carrier) (m : ℕ)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKsub : K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) p).target) :
    TendstoUniformlyOn (fun k => iteratedFDeriv ℝ m (horizonSpacetimeCoefficients G p (sigma k)))
      (iteratedFDeriv ℝ m (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) p).symm z.2)) atTop K := by
  apply Poincare.Analysis.Calculus.tendstoUniformlyOn_iteratedFDeriv_of_locallyEventuallyContDiff
    ((horizonOpenTime_isOpen tau).prod (isOpen_extChartAt_target p))
    (fun z hz => tendsto_horizon_bilinear_coefficient_of_chart_cover G q hcover hsigma F hpoint p hz.1 hz.2)
    (fun A hA hAsub => hsigma.tendsto_atTop.eventually
      (horizonSpacetimeCoefficients_locallyEventuallyContDiff G htmono.monotone p A hA hAsub))
    (fun A hA hAsub r => ?_) m hK hKsub
  obtain ⟨C, hC⟩ := horizonSpacetimeCoefficients_eventuallyBoundedJets G P04 hAr hcompact hcomplete
    htmono hB p hA hAsub r
  exact ⟨C, hsigma.tendsto_atTop.eventually hC⟩

end PoincareMT.ControlledBlowupCompactness
