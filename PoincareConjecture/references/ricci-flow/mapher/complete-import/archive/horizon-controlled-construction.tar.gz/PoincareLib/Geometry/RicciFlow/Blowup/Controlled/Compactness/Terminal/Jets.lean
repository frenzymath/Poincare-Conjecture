import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Derivatives
import PoincareLib.Geometry.Riemannian.Coordinates.Exponential.JetBounds.FiniteOrder.Pullback
import PoincareLib.Geometry.Riemannian.Coordinates.Exponential.JetBounds.PrecompactGauss

/-!
# Uniform terminal metric jets in normal coordinates

The actual terminal curvature derivatives bound every metric jet in any of
the retained normalized exponential charts. Only finitely many derivative
orders are needed for a fixed jet, so the eventual bounds need no uniform tail
over all orders.
Reference: Morgan--Tian Claim 11.5, p. 270, and Proposition 5.14, pp. 90-91.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem eventually_uniform_terminal_normal_metric_jet_bound
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {A rho R : ℝ} (hA : 0 < A) (hrho : 0 < rho) (hrhoR : rho < R) (m : ℕ) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ᶠ k : ℕ in atTop,
      ∀ p ∈ S.baseBall k A,
      ∀ L : EuclideanSpace ℝ (Fin 3) ≃L[ℝ] EuclideanSpace ℝ (Fin 3),
      ∀ Phi : PartialDiffeomorph (𝓡 3) (𝓡 3)
          (EuclideanSpace ℝ (Fin 3)) ((S.flow k).slice (S.base k).1).carrier ∞,
        Phi.source = Metric.ball 0 R →
        Phi.target = (S.normalizedTerminalMetric k).ball p R → Phi 0 = p →
        (∀ v w, (S.normalizedTerminalMetric k).pullbackCoefficients
          (extChartAt (𝓡 3) p).symm (extChartAt (𝓡 3) p p) (L v) (L w) = inner ℝ v w) →
        HasFDerivAt (fun w => extChartAt (𝓡 3) p (Phi w)) L.toContinuousLinearMap 0 →
        (∀ w ∈ Metric.ball 0 R, (S.normalizedTerminalMetric k).IsGeodesicOn
          (fun t => Phi (t • w)) {t : ℝ | t • w ∈ Metric.ball 0 R}) →
        ∀ x ∈ Metric.closedBall 0 rho,
          ‖iteratedFDeriv ℝ m ((S.normalizedTerminalMetric k).pullbackCoefficients Phi) x‖ ≤ B := by
  have hR : 0 < R := hrho.trans hrhoR
  choose D hD hcurv using fun l =>
    H.eventually_normalized_terminal_curvatureDerivative_bound P04 hbound
      (A + R) (by positivity) l
  obtain ⟨B, hB, hjet⟩ := CoordinateExponential.exists_uniform_pullback_metric_jet_bound
    3 m hrho hrhoR D (fun l => (hD l).le)
  refine ⟨B, hB, ?_⟩
  filter_upwards [(eventually_all_finite (Set.finite_Iic m)).mpr
    (fun l _ => hcurv l)] with k hk
  intro p hp L Phi hsource htarget hzero hL hderiv hgeo
  let g := S.normalizedTerminalMetric k
  let : Bundle.RiemannianBundle
      (TangentSpace (𝓡 3) : ((S.flow k).slice (S.base k).1).carrier → Type _) :=
    ⟨g.toRiemannianMetric⟩
  have he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ Phi (Metric.ball 0 R) := by
    simpa only [hsource] using Phi.contMDiffOn
  have hnorm := g.pullbackCoefficients_zero_of_orthonormal p
    (he.contMDiffAt (Metric.isOpen_ball.mem_nhds (Metric.mem_ball_self hR)))
    hzero hderiv hL
  apply hjet g (S.normalizedTerminalConnection k) Phi he
  · intro x hx
    exact ⟨(Phi.isLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞
      (hsource.symm ▸ hx)).mfderivToContinuousLinearEquiv (by simp), rfl⟩
  · exact hnorm
  · exact CoordinateExponential.gauss_identity_of_radial_family g he hgeo
      (fun v hv t ht =>
        g.tangentNorm_radial_of_normalized_exponential p L hzero hL hderiv hgeo hv ht)
  · intro l hl x hx
    apply hk l hl (Phi x)
    have hxp : Phi x ∈ g.ball p R := by
      rw [← htarget]
      exact Phi.map_source (hsource.symm ▸ hx)
    rw [← S.normalizedTerminalMetric_ball] at hp ⊢
    change g.edist (S.base k).2 (Phi x) < ENNReal.ofReal (A + R)
    rw [ENNReal.ofReal_add hA.le hR.le]
    exact Manifold.riemannianEDist_triangle.trans_lt (ENNReal.add_lt_add hp hxp)

end PoincareMT.M30CommonBlowupControls
