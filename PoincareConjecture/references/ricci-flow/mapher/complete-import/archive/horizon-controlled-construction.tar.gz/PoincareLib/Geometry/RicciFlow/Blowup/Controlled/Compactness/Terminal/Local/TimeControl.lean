import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.TerminalMetric
import PoincareLib.Geometry.RicciFlow.Curvature.Theory
import Mathlib.Topology.UniformSpace.HeineCantor

/-!
# Uniform terminal time control on actual source stages

Scalar continuity is uniform on any compact comparison stage. The cylinder
curvature bound gives a uniform metric comparison near zero without choosing
coordinate frames or a compact set in the tangent bundle.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.RicciFlow

theorem tendstoUniformlyOn_scalar_at_terminal
    (P04 : RicciFlowCurvatureTheory.{u})
    {M : Type u} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {N : Type v} [TopologicalSpace N] {K : Set N} (hK : IsCompact K)
    (f : N → M) (hf : ContinuousOn f K)
    {T : ℝ} (hT : 0 < T) (F : RicciFlow 3 M (Icc (-T) 0)) :
    TendstoUniformlyOn (fun s x => (F.connection s).scalarCurvature (f x))
      (fun x => (F.connection 0).scalarCurvature (f x)) (𝓝[Icc (-T) 0] 0) K := by
  have hmap : ContinuousOn (fun z : ℝ × N => (z.1, f z.2)) (Icc (-T) 0 ×ˢ K) :=
    continuous_fst.continuousOn.prodMk
      (hf.comp continuous_snd.continuousOn fun _ hz => hz.2)
  have hscalar := P04.scalar_regular 3 M (Icc (-T) 0) F
  have hc : ContinuousOn (fun z : ℝ × M => (F.connection z.1).scalarCurvature z.2)
      (Icc (-T) 0 ×ˢ (univ : Set M)) := hscalar.continuousOn
  have hcont : ContinuousOn
      (fun z : ℝ × N => (F.connection z.1).scalarCurvature (f z.2)) (Icc (-T) 0 ×ˢ K) :=
    ContinuousOn.comp (g := fun z : ℝ × M => (F.connection z.1).scalarCurvature z.2)
      (f := fun z : ℝ × N => (z.1, f z.2)) hc hmap
      (fun z hz => ⟨hz.1, mem_univ _⟩)
  apply Metric.tendstoUniformlyOn_iff.mpr
  intro delta hdelta
  obtain ⟨V, hV, hbound⟩ := hK.mem_uniformity_of_prod
    (f := fun (s : ℝ) (x : N) => (F.connection s).scalarCurvature (f x)) hcont
    (show (0 : ℝ) ∈ Icc (-T) 0 from ⟨by linarith, le_rfl⟩)
    (Metric.dist_mem_uniformity hdelta)
  exact Filter.mem_of_superset hV fun s hs x hx => by
    simpa only [Set.mem_setOf_eq, dist_comm] using hbound s hs x hx

end PoincareMT.RicciFlow

namespace PoincareMT.ControlledTerminal

theorem tangentNorm_lower_of_unit_tensor_error
    {M : Type u} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {N : Type v} [TopologicalSpace N]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) N] [IsManifold (𝓡 3) ∞ N]
    (g : RiemannianMetric 3 M) (h : RiemannianMetric 3 N) (f : M → N) (x : M)
    (herror : ∀ u w : TangentSpace (𝓡 3) x,
      g.tangentNorm x u ≤ 1 → g.tangentNorm x w ≤ 1 →
      |h.inner (f x) (mfderiv (𝓡 3) (𝓡 3) f x u) (mfderiv (𝓡 3) (𝓡 3) f x w) -
        g.inner x u w| < 1 / 2)
    (v : TangentSpace (𝓡 3) x) :
    g.tangentNorm x v ≤ (3 / 2 : ℝ) * h.tangentNorm (f x) (mfderiv (𝓡 3) (𝓡 3) f x v) := by
  by_cases hv : v = 0
  · subst v
    simp [RiemannianMetric.tangentNorm]
  let a := g.tangentNorm x v
  have ha : 0 < a := Real.sqrt_pos.mpr (g.pos x v hv)
  have ha2 : a ^ 2 = g.inner x v v := Real.sq_sqrt (g.pos x v hv).le
  have hinv : a⁻¹ ^ 2 * a ^ 2 = 1 := by field_simp
  let u : TangentSpace (𝓡 3) x := a⁻¹ • v
  have hu : g.tangentNorm x u = 1 := by
    change Real.sqrt _ = 1
    simp only [u, map_smul, smul_apply, smul_eq_mul]
    rw [show a⁻¹ * (a⁻¹ * g.inner x v v) = 1 by rw [← ha2]; nlinarith [hinv]]
    exact Real.sqrt_one
  have hlow := (abs_lt.mp (herror u u hu.le hu.le)).1
  simp only [u, map_smul, smul_apply, smul_eq_mul] at hlow
  have hmul := mul_lt_mul_of_pos_right hlow (sq_pos_of_pos ha)
  have hscale (b c : ℝ) : (a⁻¹ * (a⁻¹ * b) - a⁻¹ * (a⁻¹ * c)) * a ^ 2 = b - c := by
    rw [show (a⁻¹ * (a⁻¹ * b) - a⁻¹ * (a⁻¹ * c)) * a ^ 2 =
      (a⁻¹ ^ 2 * a ^ 2) * (b - c) by ring, hinv, one_mul]
  rw [hscale, ha2] at hmul
  have hq : g.inner x v v ≤ (3 / 2 : ℝ) ^ 2 *
      h.inner (f x) (mfderiv (𝓡 3) (𝓡 3) f x v) (mfderiv (𝓡 3) (𝓡 3) f x v) := by
    nlinarith [g.pos x v hv]
  change Real.sqrt _ ≤ (3 / 2 : ℝ) * Real.sqrt _
  rw [← Real.sqrt_sq (by norm_num : (0 : ℝ) ≤ 3 / 2), ← Real.sqrt_mul (sq_nonneg (3 / 2 : ℝ))]
  exact Real.sqrt_le_sqrt hq

end PoincareMT.ControlledTerminal

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

theorem eventually_terminal_tangentNorm_le
    (cyl : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T) :
    ∀ᶠ s in 𝓝[Icc (-T) 0] 0, ∀ x : sourceBall S k A, ∀ v : TangentSpace (𝓡 3) x,
      ((cyl.ordinaryFlow hT).metric 0).tangentNorm x v ≤
        (4 / 3 : ℝ) * ((cyl.ordinaryFlow hT).metric s).tangentNorm x v := by
  have hcont : Continuous (fun s : ℝ => Real.exp (3 * B * |s|)) := by fun_prop
  have hexp : ∀ᶠ s in 𝓝 (0 : ℝ), Real.exp (3 * B * |s|) < 4 / 3 :=
    hcont.continuousAt (gt_mem_nhds (by norm_num : Real.exp (3 * B * |(0 : ℝ)|) < 4 / 3))
  filter_upwards [self_mem_nhdsWithin, hexp.filter_mono nhdsWithin_le_nhds] with s hs he x v
  have hzero : (0 : ℝ) ∈ Icc (-T) 0 := ⟨by linarith, le_rfl⟩
  have hc := cyl.ordinaryFlow_tangentNorm_le hT x v hs hzero
  rw [zero_sub, abs_neg] at hc
  exact hc.trans (mul_le_mul_of_nonneg_right he.le (Real.sqrt_nonneg _))

theorem eventually_pullback_tangentNorm_lower
    (cyl : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    {M : Type v} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    (g : RiemannianMetric 3 M) (f : M → sourceBall S k A) {K : Set M}
    (hterminal : ∀ x ∈ K, ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ (3 / 2 : ℝ) * ((cyl.ordinaryFlow hT).metric 0).tangentNorm
        (f x) (mfderiv (𝓡 3) (𝓡 3) f x v)) :
    ∀ᶠ s in 𝓝[Icc (-T) 0] 0, ∀ x ∈ K, ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ 2 * ((cyl.ordinaryFlow hT).metric s).tangentNorm
        (f x) (mfderiv (𝓡 3) (𝓡 3) f x v) := by
  filter_upwards [cyl.eventually_terminal_tangentNorm_le hT] with s hs x hx v
  have htime := hs (f x) (mfderiv (𝓡 3) (𝓡 3) f x v)
  have href := hterminal x hx v
  linarith

end PoincareMT.ControlledBlowupCylinder
