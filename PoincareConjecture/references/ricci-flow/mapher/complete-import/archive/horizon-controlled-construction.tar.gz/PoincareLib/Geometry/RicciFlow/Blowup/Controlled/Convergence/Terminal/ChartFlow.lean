import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.FlowRealization

/-!
# Finite closed-slab flow limits in actual partial charts
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold

/-- Restrict the genuine retained charts after one exhaustion threshold and
realize their closed-slab coefficient limit as a Ricci flow. -/
theorem exists_flow_of_eventual_partial_chart_coefficients
    {n : ℕ} {a b : ℝ} (hab : a < b) (C : ℕ → FlowCarrier n)
    {x₀ : EuclideanSpace ℝ (Fin n)} {ρ : ℝ} (hρ : 0 < ρ)
    (Fseq : ∀ k, RicciFlow n (C k).carrier (Icc a b))
    (Φ : ∀ k, PartialDiffeomorph (𝓡 n) (𝓡 n)
      (EuclideanSpace ℝ (Fin n)) (C k).carrier ∞)
    (hsource : ∀ᶠ k : ℕ in atTop, closedBall x₀ ρ ⊆ (Φ k).source)
    (U : Opens (EuclideanSpace ℝ (Fin n)))
    (hU : (U : Set (EuclideanSpace ℝ (Fin n))) ⊆ ball x₀ ρ)
    (B : ℝ × EuclideanSpace ℝ (Fin n) →
      EuclideanSpace ℝ (Fin n) →L[ℝ] EuclideanSpace ℝ (Fin n) →L[ℝ] ℝ)
    (hB : ContDiffOn ℝ ∞ B (Icc a b ×ˢ closedBall x₀ ρ))
    (hsymm : ∀ t ∈ Icc a b, ∀ x ∈ U, ∀ v w, B (t, x) v w = B (t, x) w v)
    (hlower : ∀ t ∈ Icc a b, ∀ x ∈ U, ∃ c : ℝ, 0 < c ∧
      ∀ v, c * ‖v‖ ^ 2 ≤ B (t, x) v v)
    (hjet : ∀ r, TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r
        (fun z : ℝ × EuclideanSpace ℝ (Fin n) =>
          ((Fseq k).metric z.1).pullbackCoefficients (Φ k) z.2)
        (Icc a b ×ˢ closedBall x₀ ρ))
      (iteratedFDerivWithin ℝ r B (Icc a b ×ˢ closedBall x₀ ρ)) atTop
      (Icc a b ×ˢ closedBall x₀ ρ)) :
    ∃ F : RicciFlow n U (Icc a b), ∀ t ∈ Icc a b,
      ∀ (x : U) (v w : TangentSpace (𝓡 n) x), (F.metric t).inner x v w = B (t, x) v w := by
  obtain ⟨N, hN⟩ := eventually_atTop.mp hsource
  have hUΦ (k : ℕ) : (U : Set (EuclideanSpace ℝ (Fin n))) ⊆
      (Φ (max k N)).source :=
    (hU.trans ball_subset_closedBall).trans (hN _ (le_max_right k N))
  let Fchart (k : ℕ) :=
    (Fseq (max k N)).pullbackToPartialChart (Φ (max k N)) U (hUΦ k)
  apply exists_flow_of_closed_slab_coefficients hab hρ U hU Fchart
    (fun k z => ((Fseq (max k N)).metric z.1).pullbackCoefficients
      (Φ (max k N)) z.2) B ?_ hB ?_ hsymm hlower ?_
  · intro k
    exact ((Fseq (max k N)).contDiffOn_pullbackCoefficients_within
      (Φ (max k N)).open_source (Φ (max k N)).contMDiffOn_toFun).mono
        (prod_mono subset_rfl (hN _ (le_max_right k N)))
  · intro k t _ x v w
    exact RicciFlow.pullbackToPartialChart_inner (Fseq (max k N))
      (Φ (max k N)) U (hUΦ k) t x v w
  · intro r
    apply (hjet r).congr
    filter_upwards [eventually_ge_atTop N] with k hk z _
    rw [max_eq_left hk]

end PoincareMT.ControlledConvergence
