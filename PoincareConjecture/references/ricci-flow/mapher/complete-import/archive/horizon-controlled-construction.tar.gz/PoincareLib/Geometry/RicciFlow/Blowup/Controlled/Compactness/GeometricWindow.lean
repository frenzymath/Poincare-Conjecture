import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.FiniteWindow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Predecessors
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Data
import PoincareLib.Topology.Sequences.Diagonal

/-!
# Finite interior limits from the accepted geometric controls

The chosen source index satisfies the actual cylinder, compact-ball, and
terminal-volume premises. M07 is then applied to the normalized Type-0
sequence, giving a complete interior limit with the original uniform bound.
Source: Morgan--Tian, Theorem 5.15, p. 92, and Theorem 11.8, pp. 274--279.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

def expandingRadius (i : ℕ) : ℝ := (i : ℝ) + 1

theorem expandingRadius_pos (i : ℕ) : 0 < expandingRadius i := by
  unfold expandingRadius
  positivity

/-- The frozen geometric controls supply an actual complete pointed limit on
every finite interior window, using only the frozen M07 predecessor service. -/
theorem exists_finite_window_limit_with_compact_balls
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀) {T : ℝ} (hT : 0 < T)
    (horizon : ENNReal.ofReal T < T₀) :
    ∃ B : ℝ, 0 ≤ B ∧ ∃ idx : ℕ → ℕ, StrictMono idx ∧
      ∃ e : ∀ i, ControlledBlowupCylinder S (idx i) (expandingRadius i) T B
        ((expandingRadius i)⁻¹),
      (∀ i, IsCompact (closure (S.baseBall (idx i) (expandingRadius i)))) ∧
      ∃ G : PointedGeometricConvergence
        (interiorSequence S idx expandingRadius (fun i => (expandingRadius i)⁻¹)
          T B expandingRadius_pos hT e),
        (∀ t ∈ Ioo (-T / 2) (T / 2),
          G.limitCarrier.metricComplete (G.limitFlow.metricAt t)) ∧
        ∀ t ∈ Ioo (-T / 2) (T / 2), ∀ x : G.limitCarrier.carrier,
          (G.limitFlow.flow.connection t).curvatureTensorNorm x ≤ B := by
  classical
  obtain ⟨B, hB, hcyl⟩ := H.cylinders T hT horizon
  obtain ⟨rho, v, hrho, hv, hvolume⟩ := H.terminal_volume
  have hevent (i : ℕ) : ∀ᶠ k in atTop,
      IsCompact (closure (S.baseBall k (expandingRadius i))) ∧
      Nonempty (ControlledBlowupCylinder S k (expandingRadius i) T B
        ((expandingRadius i)⁻¹)) ∧
      ENNReal.ofReal (v / Real.sqrt (S.scale k) ^ 3) ≤
        calibratedMetricVolume ((S.flow k).metric (S.base k).1) (S.baseBall k rho) :=
    (H.balls_compact _ (expandingRadius_pos i)).and
      ((hcyl _ (expandingRadius_pos i) _ (inv_pos.mpr (expandingRadius_pos i))).and hvolume)
  obtain ⟨idx, hidx, hselect⟩ := Poincare.exists_strictMono_forall_le_of_eventually hevent
  let e (i : ℕ) := Classical.choice (hselect i i le_rfl).2.1
  have hAr : Tendsto expandingRadius atTop atTop := by
    exact tendsto_atTop_add_const_right atTop 1 tendsto_natCast_atTop_atTop
  obtain ⟨K, hK⟩ := exists_pointedCompactnessHypotheses S idx expandingRadius
    (fun i => (expandingRadius i)⁻¹) expandingRadius_pos hT hB e hAr
    (fun i => (hselect i i le_rfl).1) hrho hv
    (Eventually.of_forall (fun i => (hselect i i le_rfl).2.2))
  obtain ⟨L⟩ := P.m07 K
  have hlimit : ∃ G : PointedGeometricConvergence K.sequence,
      ∀ t ∈ Ioo (-T / 2) (T / 2),
        G.limitCarrier.metricComplete (G.limitFlow.metricAt t) :=
    ⟨L.geometric_limit, L.complete_interior⟩
  rw [hK] at hlimit
  obtain ⟨G, hcomplete⟩ := hlimit
  refine ⟨B, hB, idx, hidx, e, (fun i => (hselect i i le_rfl).1), G, hcomplete, ?_⟩
  apply G.curvatureTensorNorm_le_of_uniform_ball_bound
    ⟨by linarith, by linarith⟩
  intro r _
  refine Eventually.of_forall (fun i t ht x _ => ?_)
  exact (le_abs_self _).trans ((e i).smallFlow_curvature_bound
    (expandingRadius_pos i) hT (t + (-T / 2))
      ⟨by linarith [ht.1], by linarith [ht.2]⟩ x)

theorem exists_finite_window_limit
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀) {T : ℝ} (hT : 0 < T)
    (horizon : ENNReal.ofReal T < T₀) :
    ∃ B : ℝ, 0 ≤ B ∧ ∃ idx : ℕ → ℕ, StrictMono idx ∧
      ∃ e : ∀ i, ControlledBlowupCylinder S (idx i) (expandingRadius i) T B
        ((expandingRadius i)⁻¹),
      ∃ G : PointedGeometricConvergence
        (interiorSequence S idx expandingRadius (fun i => (expandingRadius i)⁻¹)
          T B expandingRadius_pos hT e),
        (∀ t ∈ Ioo (-T / 2) (T / 2),
          G.limitCarrier.metricComplete (G.limitFlow.metricAt t)) ∧
        ∀ t ∈ Ioo (-T / 2) (T / 2), ∀ x : G.limitCarrier.carrier,
          (G.limitFlow.flow.connection t).curvatureTensorNorm x ≤ B := by
  obtain ⟨B, hB, idx, hidx, e, _, G, hcomplete, hbound⟩ :=
    exists_finite_window_limit_with_compact_balls P H hT horizon
  exact ⟨B, hB, idx, hidx, e, G, hcomplete, hbound⟩

end PoincareMT.ControlledBlowupCompactness
