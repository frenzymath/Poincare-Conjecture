import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Curvature.Static
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.JetSlices

/-!
# Curvature inherited by local closed-slab flows

Spatial slicing of the actual closed-slab metric jets preserves scalar and
curvature-norm convergence through both time endpoints. A vanishing negative
curvature error gives nonnegative curvature operator for the local limit.
Source: Morgan--Tian, Claim 11.5, p. 270.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledTerminal

private theorem pullbackCoefficients_openChart
    (U : Opens (EuclideanSpace ℝ (Fin 3)))
    (g : RiemannianMetric 3 U) (p x : U) :
    g.pullbackCoefficients (extChartAt (𝓡 3) p).symm (x : EuclideanSpace ℝ (Fin 3)) =
      g.inner x := by
  have hd := mfderivWithin_range_extChartAt_symm (I := 𝓡 3) (x := x)
  rw [ModelWithCorners.range_eq_univ, mfderivWithin_univ] at hd
  have hc : extChartAt (𝓡 3) p = extChartAt (𝓡 3) x := by
    simp [extChartAt, Opens.chartAt_eq]
  rw [hc]
  ext v w
  change g.inner ((extChartAt (𝓡 3) x).symm x)
    (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) x).symm x v)
    (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) x).symm x w) = g.inner x v w
  have hx : (extChartAt (𝓡 3) x).symm (x : EuclideanSpace ℝ (Fin 3)) = x :=
    (extChartAt (𝓡 3) x).left_inv (mem_extChartAt_source x)
  change mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) x).symm
    (x : EuclideanSpace ℝ (Fin 3)) = ContinuousLinearMap.id ℝ _ at hd
  rw [hd, hx]
  rfl

private theorem iteratedFDeriv_openChart_bilinear_eq
    (U : Opens (EuclideanSpace ℝ (Fin 3))) (g : RiemannianMetric 3 U)
    (B : EuclideanSpace ℝ (Fin 3) →
      EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ)
    (hcoeff : ∀ (x : U) v w, g.inner x v w = B x v w)
    (q : U) {x : EuclideanSpace ℝ (Fin 3)} (hx : x ∈ U) (r : ℕ) :
    iteratedFDeriv ℝ r (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm) x =
      iteratedFDeriv ℝ r B x := by
  have heq : g.pullbackCoefficients (extChartAt (𝓡 3) q).symm =ᶠ[𝓝 x] B := by
    filter_upwards [U.isOpen.mem_nhds hx] with y hy
    rw [pullbackCoefficients_openChart U g q ⟨y, hy⟩]
    ext v w
    exact hcoeff ⟨y, hy⟩ v w
  exact (heq.iteratedFDeriv ℝ r).self_of_nhds

section ClosedSlab

variable {a b : ℝ} (hab : a < b)
  {x₀ : EuclideanSpace ℝ (Fin 3)} {rho : ℝ} (hrho : 0 < rho)
  (U : Opens (EuclideanSpace ℝ (Fin 3)))
  (hU : (U : Set (EuclideanSpace ℝ (Fin 3))) ⊆ ball x₀ rho)
  (Fseq : ℕ → RicciFlow 3 U (Icc a b)) (F : RicciFlow 3 U (Icc a b))
  (Bseq : ℕ → ℝ × EuclideanSpace ℝ (Fin 3) →
    EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ)
  (B : ℝ × EuclideanSpace ℝ (Fin 3) →
    EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ)
  (hseq : ∀ k, ContDiffOn ℝ ∞ (Bseq k) (Icc a b ×ˢ closedBall x₀ rho))
  (hB : ContDiffOn ℝ ∞ B (Icc a b ×ˢ closedBall x₀ rho))
  (hcoeff : ∀ k t, t ∈ Icc a b → ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
    ((Fseq k).metric t).inner x v w = Bseq k (t, x) v w)
  (hF : ∀ t ∈ Icc a b, ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
    (F.metric t).inner x v w = B (t, x) v w)
  (hjet : ∀ r, TendstoUniformlyOn
    (fun k => iteratedFDerivWithin ℝ r (Bseq k) (Icc a b ×ˢ closedBall x₀ rho))
    (iteratedFDerivWithin ℝ r B (Icc a b ×ˢ closedBall x₀ rho)) atTop
    (Icc a b ×ˢ closedBall x₀ rho))

include hab hrho hU hseq hB hcoeff hF hjet in
theorem tendstoUniformlyOn_local_spatial_metric_jets
    (t : ℝ) (ht : t ∈ Icc a b) (q : U) (r : ℕ)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (_hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) :
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ r (((Fseq k).metric t).pullbackCoefficients
        (extChartAt (𝓡 3) q).symm))
      (iteratedFDeriv ℝ r ((F.metric t).pullbackCoefficients (extChartAt (𝓡 3) q).symm))
      atTop K := by
  let E := EuclideanSpace ℝ (Fin 3)
  let V := E →L[ℝ] E →L[ℝ] ℝ
  have hKU : K ⊆ U := by
    intro x hx
    have hc := (extChartAt (𝓡 3) q).right_inv (hKc hx)
    change (((extChartAt (𝓡 3) q).symm x : U) : E) = x at hc
    exact hc ▸ ((extChartAt (𝓡 3) q).symm x).property
  let P := ContinuousMultilinearMap.compContinuousLinearMapL
    (𝕜 := ℝ) (F := V) (fun _ : Fin r => ContinuousLinearMap.inr ℝ ℝ E)
  have hh := (P.uniformContinuous.comp_tendstoUniformlyOn (hjet r)).comp
    (fun x : E => (t, x))
  have hu : TendstoUniformlyOn
      (fun k x => P (iteratedFDerivWithin ℝ r (Bseq k)
        (Icc a b ×ˢ closedBall x₀ rho) (t, x)))
      (fun x => P (iteratedFDerivWithin ℝ r B
        (Icc a b ×ˢ closedBall x₀ rho) (t, x))) atTop K :=
    hh.mono fun x hx => ⟨ht, ball_subset_closedBall (hU (hKU hx))⟩
  apply Metric.tendstoUniformlyOn_iff.mpr
  intro epsilon hepsilon
  filter_upwards [Metric.tendstoUniformlyOn_iff.mp hu epsilon hepsilon] with k hk x hx
  rw [iteratedFDeriv_openChart_bilinear_eq U ((Fseq k).metric t) (fun y => Bseq k (t, y))
      (hcoeff k t ht) q (hKU hx),
    iteratedFDeriv_openChart_bilinear_eq U (F.metric t) (fun y => B (t, y)) (hF t ht) q (hKU hx),
    ControlledConvergence.iteratedFDeriv_spatial_slice_of_closed_slab hab hrho _ (hseq k) ht (hU (hKU hx)),
    ControlledConvergence.iteratedFDeriv_spatial_slice_of_closed_slab hab hrho _ hB ht (hU (hKU hx))]
  exact hk x hx

include hab hrho hU hseq hB hcoeff hF hjet in
theorem curvature_of_local_closed_slab_jets
    (t : ℝ) (ht : t ∈ Icc a b) (x : U) :
    Tendsto (fun k => ((Fseq k).connection t).scalarCurvature x) atTop
        (𝓝 ((F.connection t).scalarCurvature x)) ∧
      Tendsto (fun k => ((Fseq k).connection t).curvatureTensorNorm x) atTop
        (𝓝 ((F.connection t).curvatureTensorNorm x)) ∧
      ∀ eta : ℕ → ℝ, Tendsto eta atTop (𝓝 0) →
        (∀ᶠ k in atTop, ((Fseq k).connection t).negativeCurvaturePart x ≤ eta k) →
        (F.connection t).NonnegativeCurvatureOperator x := by
  have hid : ∀ k : ℕ, IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (id : U → U) univ :=
    fun _ x => (Diffeomorph.refl (𝓡 3) U ∞).isLocalDiffeomorph x
  have hcover : (⋃ _ : ℕ, (univ : Set U)) = univ := iUnion_const univ
  have hc (q : U) (r : ℕ) (K : Set (EuclideanSpace ℝ (Fin 3)))
      (hK : IsCompact K) (hKc : K ⊆ (extChartAt (𝓡 3) q).target) :
      TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ r (((Fseq k).metric t).pullbackCoefficients
          (id ∘ (extChartAt (𝓡 3) q).symm)))
        (iteratedFDeriv ℝ r ((F.metric t).pullbackCoefficients (extChartAt (𝓡 3) q).symm))
        atTop K := by
    simpa only [Function.id_comp] using tendstoUniformlyOn_local_spatial_metric_jets
      hab hrho U hU Fseq F Bseq B hseq hB hcoeff hF hjet t ht q r hK hKc
  have hcurv := tendsto_curvature (F.connection t) (fun k => (Fseq k).connection t)
    (fun _ => univ) (fun _ => isOpen_univ) (fun _ _ _ => Subset.rfl) hcover
    (fun _ => id) hid hc x
  refine ⟨hcurv.1, hcurv.2, ?_⟩
  intro eta heta hnegative
  exact nonnegativeCurvatureOperator_of_spatial_metric_jets
    (F.connection t) (fun k => (Fseq k).connection t)
    (fun _ => univ) (fun _ => isOpen_univ) (fun _ _ _ => Subset.rfl) hcover
    (fun _ => id) hid hc x heta hnegative

include hab hrho hU hseq hB hcoeff hF hjet in
theorem nonnegativeCurvatureOperator_of_local_closed_slab_jets
    {eta : ℕ → ℝ} (heta : Tendsto eta atTop (𝓝 0))
    (hnegative : ∀ᶠ k in atTop, ∀ t ∈ Icc a b, ∀ x : U,
      ((Fseq k).connection t).negativeCurvaturePart x ≤ eta k) :
    ∀ t ∈ Icc a b, ∀ x : U, (F.connection t).NonnegativeCurvatureOperator x := by
  intro t ht x
  exact (curvature_of_local_closed_slab_jets hab hrho U hU Fseq F Bseq B hseq hB hcoeff hF hjet
    t ht x).2.2 eta heta (hnegative.mono fun _ hk => hk t ht x)

end ClosedSlab

end PoincareMT.ControlledTerminal
