import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.ControlledCylinder
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.NeckTransfer
import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Coordinates.PartialCharts

/-!
# Actual earlier-slice comparison maps

A controlled cylinder transports each terminal source ball diffeomorphically
onto its earlier image. Composing with a captured terminal stage keeps the
exact stage domain and identifies its normalized metric coefficients with
the ordinary cylinder flow.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

def sliceMap (cyl : ControlledBlowupCylinder S k A T B eta)
    (s : ℝ) (hs : s ∈ Icc (-T) 0) :
    sourceBall S k A → ((S.flow k).slice ((S.base k).1 + s / S.scale k)).carrier :=
  cyl.embedding.forward s hs ∘ Subtype.val

theorem sliceMap_isLocalDiffeomorph
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (s : ℝ) (hs : s ∈ Icc (-T) 0) :
    IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ (cyl.sliceMap s hs) := by
  let e := cyl.embedding.sliceHomeomorph (sourceBall S k A).isOpen s hs
  let d : PartialDiffeomorph (𝓡 3) (𝓡 3)
      ((S.flow k).slice (S.base k).1).carrier
      ((S.flow k).slice ((S.base k).1 + s / S.scale k)).carrier ∞ :=
    { toPartialEquiv := e.toPartialEquiv
      open_source := e.open_source
      open_target := e.open_target
      contMDiffOn_toFun := cyl.embedding.forward_smooth s hs
      contMDiffOn_invFun := cyl.embedding.inverse_smooth s hs }
  intro x
  exact (Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 3) (sourceBall S k A) x).comp
    (𝓡 3) _ (d.isLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞ x.property)

theorem sliceMap_injective
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (s : ℝ) (hs : s ∈ Icc (-T) 0) : Function.Injective (cyl.sliceMap s hs) := by
  intro x y hxy
  apply Subtype.ext
  have heq := congrArg (cyl.embedding.inverse s hs) hxy
  simpa only [sliceMap, Function.comp_apply,
    cyl.embedding.left_inverse s hs x.property,
    cyl.embedding.left_inverse s hs y.property] using heq

def slicePartialDiffeomorph (cyl : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (s : ℝ) (hs : s ∈ Icc (-T) 0) :
    PartialDiffeomorph (𝓡 3) (𝓡 3) (sourceBall S k A)
      ((S.flow k).slice ((S.base k).1 + s / S.scale k)).carrier ∞ := by
  letI : Nonempty (sourceBall S k A) := ⟨⟨(S.base k).2, base_mem_sourceBall hA⟩⟩
  exact AncientCompactness.partialDiffeomorphOfInjOn isOpen_univ
    (cyl.sliceMap s hs) (cyl.sliceMap_injective s hs).injOn
    (fun x => cyl.sliceMap_isLocalDiffeomorph s hs x)

@[simp] theorem slicePartialDiffeomorph_source
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (s : ℝ) (hs : s ∈ Icc (-T) 0) :
    (cyl.slicePartialDiffeomorph hA s hs).source = univ := rfl

variable {M : Type v} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]

def stageSlicePartialDiffeomorph (cyl : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (Phi : PartialDiffeomorph (𝓡 3) (𝓡 3) M (sourceBall S k A) ∞) :
    PartialDiffeomorph (𝓡 3) (𝓡 3) M
      ((S.flow k).slice ((S.base k).1 + s / S.scale k)).carrier ∞ :=
  Phi.trans (cyl.slicePartialDiffeomorph hA s hs)

omit [IsManifold (𝓡 3) ∞ M] in
@[simp] theorem stageSlicePartialDiffeomorph_source
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (Phi : PartialDiffeomorph (𝓡 3) (𝓡 3) M (sourceBall S k A) ∞) :
    (cyl.stageSlicePartialDiffeomorph hA s hs Phi).source = Phi.source := by
  change Phi.source ∩ Phi ⁻¹' univ = Phi.source
  simp only [preimage_univ, inter_univ]

theorem sliceMap_pullback_inner
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (x : sourceBall S k A) (v w : TangentSpace (𝓡 3) x) :
    (rescaledMetric ((S.flow k).metric ((S.base k).1 + s / S.scale k))
      (S.scale k) (S.base_scalar_pos k)).inner (cyl.sliceMap s hs x)
        (mfderiv (𝓡 3) (𝓡 3) (cyl.sliceMap s hs) x v)
        (mfderiv (𝓡 3) (𝓡 3) (cyl.sliceMap s hs) x w) =
      ((cyl.ordinaryFlow hT).metric s).inner x v w := by
  rw [cyl.ordinaryFlow_inner hT s hs]
  have hd := ((cyl.embedding.forward_smooth s hs).contMDiffAt
    ((sourceBall S k A).isOpen.mem_nhds x.property)).mdifferentiableAt (by simp)
  have hi : MDifferentiableAt (𝓡 3) (𝓡 3)
      (Subtype.val : sourceBall S k A → _) x :=
    (contMDiff_subtype_val (n := ∞)).mdifferentiable (by simp) x
  simp only [sliceMap, mfderiv_comp x hd hi]
  rfl

theorem sliceMap_pullback_coefficients
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (phi : EuclideanSpace ℝ (Fin 3) → sourceBall S k A)
    {z : EuclideanSpace ℝ (Fin 3)} (hphi : MDifferentiableAt (𝓡 3) (𝓡 3) phi z) :
    (rescaledMetric ((S.flow k).metric ((S.base k).1 + s / S.scale k))
      (S.scale k) (S.base_scalar_pos k)).pullbackCoefficients
        (cyl.sliceMap s hs ∘ phi) z =
      ((cyl.ordinaryFlow hT).metric s).pullbackCoefficients phi z := by
  have hd := (cyl.sliceMap_isLocalDiffeomorph s hs (phi z)).mdifferentiableAt (by simp)
  ext v w
  change (rescaledMetric ((S.flow k).metric ((S.base k).1 + s / S.scale k))
      (S.scale k) (S.base_scalar_pos k)).inner _
    (mfderiv (𝓡 3) (𝓡 3) (cyl.sliceMap s hs ∘ phi) z v)
    (mfderiv (𝓡 3) (𝓡 3) (cyl.sliceMap s hs ∘ phi) z w) = _
  rw [mfderiv_comp z hd hphi]
  exact cyl.sliceMap_pullback_inner hT s hs (phi z)
    (mfderiv (𝓡 3) (𝓡 3) phi z v) (mfderiv (𝓡 3) (𝓡 3) phi z w)

theorem sliceMap_pullback_metric_jet
    (cyl : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (phi : EuclideanSpace ℝ (Fin 3) → sourceBall S k A)
    {V : Set (EuclideanSpace ℝ (Fin 3))} (hV : IsOpen V)
    (hphi : ContMDiffOn (𝓡 3) (𝓡 3) ∞ phi V)
    {z : EuclideanSpace ℝ (Fin 3)} (hz : z ∈ V) (m : ℕ) :
    iteratedFDeriv ℝ m ((rescaledMetric
      ((S.flow k).metric ((S.base k).1 + s / S.scale k))
      (S.scale k) (S.base_scalar_pos k)).pullbackCoefficients (cyl.sliceMap s hs ∘ phi)) z =
      iteratedFDeriv ℝ m (((cyl.ordinaryFlow hT).metric s).pullbackCoefficients phi) z := by
  have heq : (rescaledMetric ((S.flow k).metric ((S.base k).1 + s / S.scale k))
      (S.scale k) (S.base_scalar_pos k)).pullbackCoefficients (cyl.sliceMap s hs ∘ phi)
      =ᶠ[𝓝 z] ((cyl.ordinaryFlow hT).metric s).pullbackCoefficients phi := by
    filter_upwards [hV.mem_nhds hz] with y hy
    exact cyl.sliceMap_pullback_coefficients hT s hs phi
      ((hphi.contMDiffAt (hV.mem_nhds hy)).mdifferentiableAt (by simp))
  exact (heq.iteratedFDeriv ℝ m).self_of_nhds

end PoincareMT.ControlledBlowupCylinder
