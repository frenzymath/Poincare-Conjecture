import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Necks.Capture
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Necks.Convergence
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.MetricJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.TimeControl
import PoincareLib.Geometry.Riemannian.Connection.Uniqueness
import Mathlib.Topology.Order.IsLUB

/-! # Weak neck covers at the closed backward endpoint -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1600000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupBoundary

theorem neck_cover_at_left_endpoint
    {M : Type u} [TopologicalSpace M] [T2Space M] [T3Space M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    [MeasurableSpace M] [BorelSpace M]
    (P04 : RicciFlowCurvatureTheory.{u}) {T : ℝ} (hT : 0 < T)
    (F : RicciFlow 3 M (Icc (-T) 0))
    (hcomplete : MetricComplete (F.metric (-T)))
    (hnonnegative : ∀ t ∈ Icc (-T) 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    {delta epsilon C cutoff : ℝ}
    (hdelta : 0 < delta) (hsmall : delta < 1 / 200)
    (haccuracy : delta < epsilon) (hepsilon : epsilon < 1 / 2)
    (hC : 0 < C) (hcutoff : 0 ≤ cutoff)
    (hcover : ∀ t ∈ Ioc (-T) 0, ∀ x : M,
      cutoff < (F.connection t).scalarCurvature x →
      ∃ N : EpsilonNeck (F.metric t), N.epsilon = delta ∧
        (F.metric t).edist x N.center ≤
          ENNReal.ofReal (C * (F.connection t).scalarCurvature x ^ (-1 / 2 : ℝ)) ∧
        (F.connection t).scalarCurvature x ≤ C * (F.connection t).scalarCurvature N.center) :
    ∀ x : M, (F.connection (-T)).scalarCurvature x ≤ cutoff ∨
      ∃ N : EpsilonNeck (F.metric (-T)), N.epsilon = epsilon ∧
        N.connection = F.connection (-T) ∧
        (F.connection (-T)).scalarCurvature x ≤
          (2 * C) * (F.connection (-T)).scalarCurvature N.center := by
  classical
  intro x
  by_cases hx : (F.connection (-T)).scalarCurvature x ≤ cutoff
  · exact Or.inl hx
  right
  have hxhigh : cutoff < (F.connection (-T)).scalarCurvature x := lt_of_not_ge hx
  have hxpos : 0 < (F.connection (-T)).scalarCurvature x := hcutoff.trans_lt hxhigh
  let g := F.metric (-T)
  let l := (F.connection (-T)).scalarCurvature x / 2
  have hl : 0 < l := by dsimp [l]; positivity
  let A := C * l ^ (-1 / 2 : ℝ)
  let r := A + (2 * Real.pi + 2 * delta⁻¹) * (l / C) ^ (-1 / 2 : ℝ) + 1
  have hA : 0 ≤ A := by dsimp [A]; positivity
  have hr : 0 < r := by dsimp [r]; positivity [Real.pi_pos]
  let K := closure (g.ball x (2 * r))
  let K' := closure (g.ball x (2 * r + 1))
  have hK : IsCompact K := g.isCompact_closure_ball_of_metricComplete hcomplete x (2 * r)
  have hK' : IsCompact K' := g.isCompact_closure_ball_of_metricComplete hcomplete x (2 * r + 1)
  have hxK : x ∈ K := by
    letI : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
      ⟨g.toRiemannianMetric⟩
    apply subset_closure
    change g.edist x x < ENNReal.ofReal (2 * r)
    rw [show g.edist x x = 0 from Manifold.riemannianEDist_self]
    exact ENNReal.ofReal_pos.mpr (by positivity)
  have hleft : -T ∈ Icc (-T) (0 : ℝ) := ⟨le_rfl, by linarith⟩
  obtain ⟨times, _, htimes, htendsto⟩ := exists_seq_strictAnti_tendsto' (by linarith : -T < (0 : ℝ))
  have htclosed : Tendsto times atTop (𝓝[Icc (-T) 0] (-T)) :=
    tendsto_nhdsWithin_iff.mpr ⟨htendsto, Eventually.of_forall fun k =>
      ⟨(htimes k).1.le, (htimes k).2.le⟩⟩
  have hscalar := (F.tendstoUniformlyOn_scalar_at_included_time P04 isCompact_singleton hleft).tendsto_at
    (mem_singleton x)
  have hpoint : Tendsto (fun k => (F.connection (times k)).scalarCurvature x)
      atTop (𝓝 ((F.connection (-T)).scalarCurvature x)) := hscalar.comp htclosed
  have hhigh : ∀ᶠ k in atTop, cutoff < (F.connection (times k)).scalarCurvature x :=
    hpoint.eventually (Ioi_mem_nhds hxhigh)
  have hlow : ∀ᶠ k in atTop, l ≤ (F.connection (times k)).scalarCurvature x :=
    (hpoint.eventually (Ioi_mem_nhds (by dsimp [l]; linarith))).mono fun _ h => h.le
  have hnorm := htclosed.eventually (F.eventually_tangentNorm_le_twice_at_included_time P04
    isCompact_Icc (convex_Icc _ _) hnonnegative hK' hleft)
  obtain ⟨a, ha⟩ := eventually_atTop.mp (hhigh.and (hlow.and hnorm))
  let s := fun k : ℕ => times (k + a)
  have hsclosed : Tendsto s atTop (𝓝[Icc (-T) 0] (-T)) := htclosed.comp (tendsto_add_atTop_nat a)
  have hs (k : ℕ) : s k ∈ Ioc (-T) 0 := ⟨(htimes (k + a)).1, (htimes (k + a)).2.le⟩
  have hselected (k : ℕ) := ha (k + a) (Nat.le_add_left a k)
  have hex (k : ℕ) := hcover (s k) (hs k) x (hselected k).1
  choose N hNe hNd hNr using hex
  have hscalarEq (k : ℕ) (y : M) :
      (N k).connection.scalarCurvature y = (F.connection (s k)).scalarCurvature y :=
    (N k).connection.scalarCurvature_eq (F.connection (s k)) y
  have hcenterLower (k : ℕ) : l / C ≤ (N k).connection.scalarCurvature (N k).center := by
    rw [hscalarEq]
    apply (div_le_iff₀ hC).mpr
    nlinarith [(hselected k).2.1, hNr k]
  have hcapture (k : ℕ) : (N k).carrier ⊆ K := by
    apply neck_carrier_subset_fixed_ball_of_center_control g (F.metric (s k)) hcomplete
      (N k) x (div_pos hl hC) hA hr (hcenterLower k)
    · apply (hNd k).trans
      apply ENNReal.ofReal_le_ofReal
      exact mul_le_mul_of_nonneg_left
        (Real.rpow_le_rpow_of_nonpos hl (hselected k).2.1 (by norm_num)) hC.le
    · dsimp only [r]
      rw [hNe k]
    · exact (hselected k).2.2
  obtain ⟨B, hB, hbound⟩ := F.exists_scalar_upper_bound_on_compact P04 isCompact_Icc hK
  have hcenterBounds (k : ℕ) : l / C ≤ (N k).connection.scalarCurvature (N k).center ∧
      (N k).connection.scalarCurvature (N k).center ≤ B := by
    refine ⟨hcenterLower k, ?_⟩
    rw [hscalarEq]
    exact hbound (s k) (Ioc_subset_Icc_self (hs k)) (N k).center
      (hcapture k ((N k).central_sphere_subset (N k).center_on_central_sphere))
  have hjets (q : M) (W : Set (EuclideanSpace ℝ (Fin 3))) (hW : IsCompact W)
      (hWc : W ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) : TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((F.metric (s k)).parametrizedCoefficients (extChartAt (𝓡 3) q).symm))
      (iteratedFDeriv ℝ m (g.parametrizedCoefficients (extChartAt (𝓡 3) q).symm)) atTop W := by
    let J : SpacetimeInterval := ⟨Icc (-T) 0, ordConnected_Icc,
      ⟨-T, hleft, 0, ⟨by linarith, le_rfl⟩, by linarith⟩⟩
    have hc := F.tendstoUniformlyOn_spatialMetricJets_of_compact_interval (J := J)
      isCompact_Icc (isOpen_extChartAt_target q) hW hWc (extChartAt (𝓡 3) q).symm
      (contMDiffOn_extChartAt_symm (n := ∞) q) hleft m
    exact fun V hV => hsclosed.eventually (hc V hV)
  have hscalarconv : TendstoUniformlyOn (fun k y => (N k).connection.scalarCurvature y)
      (F.connection (-T)).scalarCurvature atTop K := by
    have hc := F.tendstoUniformlyOn_scalar_at_included_time P04 hK hleft
    have ht : TendstoUniformlyOn (fun k y => (F.connection (s k)).scalarCurvature y)
        (F.connection (-T)).scalarCurvature atTop K := fun V hV => hsclosed.eventually (hc V hV)
    exact ht.congr (Eventually.of_forall fun k y _ => (hscalarEq k y).symm)
  exact exists_neck_of_captured_metric_convergence g (F.connection (-T))
    (fun k => F.metric (s k)) (fun k => (N k).connection) N hK hcapture x hxK hxpos
    hdelta hsmall haccuracy hepsilon (div_pos hl hC) hB hC hNe (fun _ => rfl) hcenterBounds
    (fun k => by simpa only [hscalarEq] using hNr k) hjets hscalarconv

end PoincareMT.ControlledBlowupBoundary
