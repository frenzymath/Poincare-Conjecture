import PoincareLib.Geometry.RicciFlow.Soliton.ThreeDimensional.Splitting.Rank
import PoincareLib.Geometry.RicciFlow.Soliton.ThreeDimensional.Splitting.LocalParallel

/-!
# Local parallel lines on finite partial-flow limits

A terminal null sectional plane on a nonnegative finite Ricci-flow slab
forces a Ricci-null line. The terminal one-sided derivative sign supplies
the reaction inequality, and spatial nullity propagation constructs local
unit parallel sections everywhere on a connected nonflat terminal slice.
Neither completeness nor a global curvature bound is used.

Reference: Morgan--Tian, Corollary 4.20 and Claim 11.7, p. 271.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.RicciFlow

theorem curvatureReaction_nonpos_on_closed_slab_terminal_null_plane
    {n : ℕ} {M : Type u} [TopologicalSpace M] [T2Space M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    (hC : RicciFlowCurvatureTheory.{u}) {a b : ℝ} (hab : a < b)
    (F : RicciFlow n M (Icc a b))
    (hsec : ∀ t ∈ Icc a b, (F.connection t).NonnegativeSectionalCurvature)
    (x : M) (v w : TangentSpace (𝓡 n) x)
    (hzero : (F.connection b).curvatureTensor x v w v w = 0) :
    (F.connection b).curvatureReaction x v w v w ≤ 0 := by
  have hb : b ∈ Icc a b := ⟨hab.le, le_rfl⟩
  have hlap := (F.connection b).tensorLaplacian_nonneg_on_null_plane
    (hC.tensor_calculus n M (F.metric b) (F.connection b)) (hsec b hb) x v w hzero
  have hd := hC.curvature_evolution n M (Icc a b) F b hb x v w v w
  have hmin : IsLocalMinOn (fun t => (F.connection t).curvatureTensor x v w v w)
      (Icc a b) b := by
    rw [IsLocalMinOn]
    filter_upwards [self_mem_nhdsWithin] with t ht
    simpa only [hzero] using hsec t ht x v w
  have hcone : a - b ∈ posTangentConeAt (Icc a b) b :=
    sub_mem_posTangentConeAt_of_segment_subset
      ((convex_Icc a b).segment_subset hb ⟨le_rfl, hab.le⟩)
  have hsign := hmin.hasFDerivWithinAt_nonneg hd.hasFDerivWithinAt hcone
  simp only [ContinuousLinearMap.toSpanSingleton_apply, smul_eq_mul] at hsign
  nlinarith

variable {M : Type u} [TopologicalSpace M] [T2Space M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
  {a b : ℝ}

/-- A finite backward lifetime already suffices to turn a terminal null
sectional plane into a nonzero Ricci-null vector. -/
theorem exists_ricci_null_vector_of_closed_slab_terminal_null_plane
    (hC : RicciFlowCurvatureTheory.{u}) (hab : a < b)
    (F : RicciFlow 3 M (Icc a b))
    (hsec : ∀ t ∈ Icc a b, (F.connection t).NonnegativeSectionalCurvature)
    (x : M) (v w : TangentSpace (𝓡 3) x)
    (hv : (F.metric b).inner x v v = 1)
    (hw : (F.metric b).inner x w w = 1)
    (hvw : (F.metric b).inner x v w = 0)
    (hzero : (F.connection b).curvatureTensor x v w v w = 0) :
    ∃ z : TangentSpace (𝓡 3) x, z ≠ 0 ∧ ∀ u, (F.connection b).ricci x z u = 0 := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
    ⟨(F.metric b).toRiemannianMetric⟩
  let : FiniteDimensional ℝ (TangentSpace (𝓡 3) x) := by
    unfold TangentSpace
    infer_instance
  have hvw' : inner ℝ v w = 0 := hvw
  have hwv : inner ℝ w v = 0 := by rw [real_inner_comm, hvw']
  have hframe : Orthonormal ℝ (({1, 2} : Set (Fin 3)).domRestrict ![0, v, w]) := by
    apply orthonormal_iff_ite.mpr
    rintro ⟨i, hi⟩ ⟨j, hj⟩
    have hi' : i = 1 ∨ i = 2 := by simpa only [mem_insert_iff, mem_singleton_iff] using hi
    have hj' : j = 1 ∨ j = 2 := by simpa only [mem_insert_iff, mem_singleton_iff] using hj
    rcases hi' with rfl | rfl <;> rcases hj' with rfl | rfl
    · change inner ℝ v v = 1
      exact hv
    · simpa using hvw'
    · simpa using hwv
    · change inner ℝ w w = 1
      exact hw
  obtain ⟨e, he⟩ := hframe.exists_orthonormalBasis_extension_of_card_eq
    (show Module.finrank ℝ (TangentSpace (𝓡 3) x) = Fintype.card (Fin 3) from
      finrank_euclideanSpace_fin)
  have he1 : e 1 = v := by simpa using he 1 (by simp)
  have he2 : e 2 = w := by simpa using he 2 (by simp)
  apply (F.connection b).exists_ricci_null_vector_of_null_frame_plane
    (hC.tensor_calculus 3 M (F.metric b) (F.connection b)) x
    (hsec b ⟨hab.le, le_rfl⟩ x) e
  · simpa only [he1, he2] using hzero
  · simpa only [he1, he2] using
      F.curvatureReaction_nonpos_on_closed_slab_terminal_null_plane hC hab hsec x v w hzero

variable [ConnectedSpace M]

theorem ricciNullity_eq_one_of_closed_slab_terminal_null_plane
    (hC : RicciFlowCurvatureTheory.{u}) (hab : a < b)
    (F : RicciFlow 3 M (Icc a b))
    (hoperator : ∀ t ∈ Icc a b, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    (hnonflat : ∃ p, (F.connection b).curvatureTensorNorm p ≠ 0)
    (x : M) (v w : TangentSpace (𝓡 3) x)
    (hv : (F.metric b).inner x v v = 1)
    (hw : (F.metric b).inner x w w = 1)
    (hvw : (F.metric b).inner x v w = 0)
    (hzero : (F.connection b).curvatureTensor x v w v w = 0) :
    ∀ y : M, Splitting.ricciNullity (F.connection b) y = 1 := by
  have hb : b ∈ Icc a b := ⟨hab.le, le_rfl⟩
  have hsec (t : ℝ) (ht : t ∈ Icc a b) :
      (F.connection t).NonnegativeSectionalCurvature := fun y u z =>
    (F.connection t).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
      y (hoperator t ht y) u z
  obtain ⟨p, hp⟩ := hnonflat
  have hupper := (F.connection b).ricciNullity_le_one_of_nonflat
    (hC.tensor_calculus 3 M (F.metric b) (F.connection b)) p (hoperator b hb p) hp
  obtain ⟨z, hz, hzn⟩ := F.exists_ricci_null_vector_of_closed_slab_terminal_null_plane
    hC hab hsec x v w hv hw hvw hzero
  have hpos : 0 < Splitting.ricciNullity (F.connection b) x := by
    apply Module.finrank_pos_iff_exists_ne_zero.mpr
    refine ⟨⟨z, (Splitting.mem_ricciKernel _ _ _).mpr hzn⟩, ?_⟩
    intro heq
    exact hz (congrArg Subtype.val heq)
  intro y
  have hyp := Splitting.ricciNullity_eq_on_positive_slice hC hab F hsec
    (show b ∈ Ioc a b from ⟨hab, le_rfl⟩) y p
  have hyx := Splitting.ricciNullity_eq_on_positive_slice hC hab F hsec
    (show b ∈ Ioc a b from ⟨hab, le_rfl⟩) y x
  omega

/-- The local parallel line for a partial-flow limit is produced from an
actual null sectional plane, not supplied as a splitting certificate. -/
theorem exists_local_parallel_unit_field_of_closed_slab_terminal_null_plane
    (hC : RicciFlowCurvatureTheory.{u}) (hab : a < b)
    (F : RicciFlow 3 M (Icc a b))
    (hoperator : ∀ t ∈ Icc a b, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    (hnonflat : ∃ p, (F.connection b).curvatureTensorNorm p ≠ 0)
    (x : M) (v w : TangentSpace (𝓡 3) x)
    (hv : (F.metric b).inner x v v = 1)
    (hw : (F.metric b).inner x w w = 1)
    (hvw : (F.metric b).inner x v w = 0)
    (hzero : (F.connection b).curvatureTensor x v w v w = 0) (p : M) :
    ∃ (U : Set M) (V : (y : M) → TangentSpace (𝓡 3) y),
      IsOpen U ∧ p ∈ U ∧
      ContMDiffOn (𝓡 3) ((𝓡 3).prod (𝓡 3)) ∞ (T% V) U ∧
      ∀ y ∈ U, (F.metric b).inner y (V y) (V y) = 1 ∧
        (∀ z, (F.connection b).ricci y (V y) z = 0) ∧
        ∀ z, (F.connection b).connection V y z = 0 := by
  apply Splitting.exists_local_parallel_unit_ricci_null_section hC hab F
    (fun t ht y u z =>
      (F.connection t).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
        y (hoperator t ht y) u z)
  exact F.ricciNullity_eq_one_of_closed_slab_terminal_null_plane hC hab hoperator hnonflat
    x v w hv hw hvw hzero

end PoincareMT.RicciFlow
