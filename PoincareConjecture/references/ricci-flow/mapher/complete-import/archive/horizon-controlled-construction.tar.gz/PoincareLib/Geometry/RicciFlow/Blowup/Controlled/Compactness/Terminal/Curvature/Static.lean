import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Curvature.Moving
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Completeness

/-!
# Curvature of the static terminal metric extraction

The extracted spatial metric jets determine curvature along the actual
source embeddings, including when the limit point varies in a compact set.
Source: Morgan--Tian, Section 5.1, pp. 85--89.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledTerminal

private theorem exists_pullback_realization
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {g : RiemannianMetric 3 M} (D : LeviCivitaData g)
    (phi : EuclideanSpace ℝ (Fin 3) → M) (x : EuclideanSpace ℝ (Fin 3))
    (hphi : ∀ᶠ y in 𝓝 x, ContMDiffAt (𝓡 3) (𝓡 3) ∞ phi y ∧
      Function.Injective (mfderiv (𝓡 3) (𝓡 3) phi y)) :
    ∃ gd : Σ h : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3)), LeviCivitaData h,
      (gd.1.euclideanCoefficients =ᶠ[𝓝 x] g.pullbackCoefficients phi) ∧
      gd.2.scalarCurvature x = D.scalarCurvature (phi x) ∧
      gd.2.curvatureTensorNorm x = D.curvatureTensorNorm (phi x) ∧
      (gd.2.NonnegativeCurvatureOperator x ↔ D.NonnegativeCurvatureOperator (phi x)) := by
  obtain ⟨V, hVphi, hVo, hxV⟩ := mem_nhds_iff.mp hphi
  obtain ⟨h, Dh, W, hWo, hxW, hWV, heq⟩ := RiemannianMetric.exists_local_realization hVo hxV
    (g.pullbackCoefficients phi)
    (fun y hy => (g.contDiffAt_pullbackCoefficients (hVphi hy).1).contDiffWithinAt)
    (fun y _ v w => g.symm _ _ _) (by
      intro y hy v hv
      apply g.pos (phi y)
      intro hz
      apply hv
      apply (hVphi hy).2
      rw [map_zero]
      convert! hz using 1)
  have hmap : ContMDiffOn (𝓡 3) (𝓡 3) ∞ phi W :=
    fun y hy => (hVphi (hWV hy)).1.contMDiffWithinAt
  have hmetric : ∀ y ∈ W, ∀ v w : TangentSpace (𝓡 3) y,
      h.inner y v w = g.inner (phi y)
        (mfderiv (𝓡 3) (𝓡 3) phi y v) (mfderiv (𝓡 3) (𝓡 3) phi y w) :=
    fun y hy v w => congrArg (fun B => B v w) (heq y hy)
  exact ⟨⟨h, Dh⟩, Filter.Eventually.mono (hWo.mem_nhds hxW) heq,
    Dh.scalarCurvature_eq_of_local_isometry D hWo hmap hmetric hxW,
    Dh.curvatureTensorNorm_eq_of_local_isometry D hWo hmap hmetric hxW,
    Dh.nonnegativeCurvatureOperator_iff_of_local_isometry D hWo hmap hmetric hxW⟩

private theorem chart_inverse_regular
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    (q : M) {z : EuclideanSpace ℝ (Fin 3)} (hz : z ∈ (extChartAt (𝓡 3) q).target) :
    ContMDiffAt (𝓡 3) (𝓡 3) ∞ (extChartAt (𝓡 3) q).symm z ∧
      Function.Injective (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z) := by
  refine ⟨(contMDiffWithinAt_extChartAt_symm_target (n := ∞) q hz).contMDiffAt
    (extChartAt_target_mem_nhds' hz), ?_⟩
  have hi : (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z).IsInvertible := by
    simpa only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] using
      isInvertible_mfderivWithin_extChartAt_symm hz
  exact hi.injective

section Sequence

variable {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
  {N : ℕ → Type*} [∀ k, TopologicalSpace (N k)]
  [∀ k, ChartedSpace (EuclideanSpace ℝ (Fin 3)) (N k)]
  [∀ k, IsManifold (𝓡 3) ∞ (N k)]
  {g : RiemannianMetric 3 M} (D : LeviCivitaData g)
  {gs : ∀ k, RiemannianMetric 3 (N k)} (Ds : ∀ k, LeviCivitaData (gs k))
  (E : ℕ → Set M) (hE : ∀ j, IsOpen (E j)) (hmono : Monotone E)
  (hcover : ⋃ j, E j = univ) (f : ∀ k, M → N k)
  (hf : ∀ k, IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k))
  (hconv : ∀ q m K, IsCompact K → K ⊆ (extChartAt (𝓡 3) q).target →
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((gs k).pullbackCoefficients
        (f k ∘ (extChartAt (𝓡 3) q).symm)))
      (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm)) atTop K)

include hE hmono hcover hf in
omit [∀ k, IsManifold (𝓡 3) ∞ (N k)] in
private theorem eventually_coordinate_regular (q : M)
    {p : EuclideanSpace ℝ (Fin 3)} (hp : p ∈ (extChartAt (𝓡 3) q).target) :
    ∀ᶠ z : ℕ × EuclideanSpace ℝ (Fin 3) in atTop ×ˢ 𝓝 p,
      ∀ᶠ y in 𝓝 z.2,
        ContMDiffAt (𝓡 3) (𝓡 3) ∞ (f z.1 ∘ (extChartAt (𝓡 3) q).symm) y ∧
          Function.Injective (mfderiv (𝓡 3) (𝓡 3)
            (f z.1 ∘ (extChartAt (𝓡 3) q).symm) y) := by
  let c := extChartAt (𝓡 3) q
  obtain ⟨j, hj⟩ := mem_iUnion.mp (by rw [hcover]; exact mem_univ (c.symm p))
  let U := c.target ∩ c.symm ⁻¹' E j
  have hU : IsOpen U :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
      (isOpen_extChartAt_target q) (hE j)
  filter_upwards [(eventually_ge_atTop j).prod_mk (hU.mem_nhds ⟨hp, hj⟩)] with z hz
  filter_upwards [hU.mem_nhds hz.2] with y hy
  have hc := chart_inverse_regular q hy.1
  have hfk := hf z.1 ⟨c.symm y, hmono hz.1 hy.2⟩
  refine ⟨hfk.contMDiffAt.comp y hc.1, ?_⟩
  have hd : mfderiv (𝓡 3) (𝓡 3) (f z.1 ∘ (extChartAt (𝓡 3) q).symm) y =
      (mfderiv (𝓡 3) (𝓡 3) (f z.1) ((extChartAt (𝓡 3) q).symm y)).comp
        (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm y) :=
    mfderiv_comp y (hfk.contMDiffAt.mdifferentiableAt (by simp))
      (hc.1.mdifferentiableAt (by simp))
  rw [hd]
  exact (hfk.mfderivToContinuousLinearEquiv (by simp)).injective.comp hc.2

include hconv in
private theorem tendsto_coordinate_metric_jet_prod (q : M) (r : ℕ)
    {p : EuclideanSpace ℝ (Fin 3)} (hp : p ∈ (extChartAt (𝓡 3) q).target) :
    Tendsto (fun z : ℕ × EuclideanSpace ℝ (Fin 3) =>
      iteratedFDeriv ℝ r ((gs z.1).pullbackCoefficients
        (f z.1 ∘ (extChartAt (𝓡 3) q).symm)) z.2)
      (atTop ×ˢ 𝓝 p)
      (𝓝 (iteratedFDeriv ℝ r (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm) p)) := by
  obtain ⟨K, hK, hpK, hKsub⟩ := exists_compact_between isCompact_singleton
    (isOpen_extChartAt_target q) (singleton_subset_iff.mpr hp)
  have hKn : K ∈ 𝓝 p := mem_of_superset
    (isOpen_interior.mem_nhds (hpK (mem_singleton p))) interior_subset
  have hu : TendstoUniformlyOn
      (fun z : ℕ × EuclideanSpace ℝ (Fin 3) => iteratedFDeriv ℝ r
        ((gs z.1).pullbackCoefficients (f z.1 ∘ (extChartAt (𝓡 3) q).symm)))
      (iteratedFDeriv ℝ r (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm))
      (atTop ×ˢ 𝓝 p) K := fun V hV => tendsto_fst.eventually (hconv q r K hK hKsub V hV)
  apply hu.tendsto_comp
    ((g.contDiffAt_pullbackCoefficients (chart_inverse_regular q hp).1).continuousAt_iteratedFDeriv
      (by exact_mod_cast le_top : (r : ℕ∞ω) ≤ ∞)).continuousWithinAt
  rw [nhdsWithin_eq_nhds.mpr hKn]
  exact tendsto_snd

include hE hmono hcover hf hconv in
theorem tendsto_coordinate_curvature_prod (q : M)
    {p : EuclideanSpace ℝ (Fin 3)} (hp : p ∈ (extChartAt (𝓡 3) q).target) :
    Tendsto (fun z : ℕ × EuclideanSpace ℝ (Fin 3) =>
      (Ds z.1).scalarCurvature (f z.1 ((extChartAt (𝓡 3) q).symm z.2)))
      (atTop ×ˢ 𝓝 p) (𝓝 (D.scalarCurvature ((extChartAt (𝓡 3) q).symm p))) ∧
    Tendsto (fun z : ℕ × EuclideanSpace ℝ (Fin 3) =>
      (Ds z.1).curvatureTensorNorm (f z.1 ((extChartAt (𝓡 3) q).symm z.2)))
      (atTop ×ˢ 𝓝 p) (𝓝 (D.curvatureTensorNorm ((extChartAt (𝓡 3) q).symm p))) := by
  obtain ⟨gd, heq, hscalar, hnorm, _hpos⟩ := exists_pullback_realization D
    (extChartAt (𝓡 3) q).symm p
    (Filter.Eventually.mono (extChartAt_target_mem_nhds' hp) fun y hy => chart_inverse_regular q hy)
  have hjets (r : ℕ) (_hr : r ≤ 2) :
      Tendsto (fun z : ℕ × EuclideanSpace ℝ (Fin 3) =>
        iteratedFDeriv ℝ r ((gs z.1).pullbackCoefficients
          (f z.1 ∘ (extChartAt (𝓡 3) q).symm)) z.2)
        (atTop ×ˢ 𝓝 p) (𝓝 (iteratedFDeriv ℝ r gd.1.euclideanCoefficients p)) := by
    rw [(heq.iteratedFDeriv ℝ r).self_of_nhds]
    exact tendsto_coordinate_metric_jet_prod f hconv q r hp
  have hh := curvature_of_moving_pullback_jets
    (fun z : ℕ × EuclideanSpace ℝ (Fin 3) => Ds z.1)
    (fun z => f z.1 ∘ (extChartAt (𝓡 3) q).symm) gd.2 Prod.snd p
    (eventually_coordinate_regular E hE hmono hcover f hf q hp) hjets
  rw [hscalar, hnorm] at hh
  exact ⟨hh.1, hh.2.1⟩

include hE hmono hcover hf hconv in
theorem tendsto_curvature_prod (x : M) :
    Tendsto (fun z : ℕ × M => (Ds z.1).scalarCurvature (f z.1 z.2))
      (atTop ×ˢ 𝓝 x) (𝓝 (D.scalarCurvature x)) ∧
    Tendsto (fun z : ℕ × M => (Ds z.1).curvatureTensorNorm (f z.1 z.2))
      (atTop ×ˢ 𝓝 x) (𝓝 (D.curvatureTensorNorm x)) := by
  let c := extChartAt (𝓡 3) x
  have hx : x ∈ c.source := mem_extChartAt_source x
  have hh := tendsto_coordinate_curvature_prod D Ds E hE hmono hcover f hf hconv x (c.map_source hx)
  have ht : Tendsto (fun z : ℕ × M => (z.1, c z.2))
      (atTop ×ˢ 𝓝 x) (atTop ×ˢ 𝓝 (c x)) :=
    tendsto_id.prodMap (continuousAt_extChartAt x).tendsto
  have hs := hh.1.comp ht
  have hn := hh.2.comp ht
  change Tendsto (fun z : ℕ × M => (Ds z.1).scalarCurvature (f z.1 (c.symm (c z.2))))
    (atTop ×ˢ 𝓝 x) (𝓝 (D.scalarCurvature (c.symm (c x)))) at hs
  change Tendsto (fun z : ℕ × M => (Ds z.1).curvatureTensorNorm (f z.1 (c.symm (c z.2))))
    (atTop ×ˢ 𝓝 x) (𝓝 (D.curvatureTensorNorm (c.symm (c x)))) at hn
  rw [c.left_inv hx] at hs hn
  refine ⟨hs.congr' ?_, hn.congr' ?_⟩ <;>
    filter_upwards [tendsto_snd.eventually (extChartAt_source_mem_nhds (I := 𝓡 3) x)] with z hz <;>
    rw [c.left_inv hz]

include hE hmono hcover hf hconv in
theorem tendsto_curvature (x : M) :
    Tendsto (fun k => (Ds k).scalarCurvature (f k x)) atTop (𝓝 (D.scalarCurvature x)) ∧
    Tendsto (fun k => (Ds k).curvatureTensorNorm (f k x)) atTop
      (𝓝 (D.curvatureTensorNorm x)) := by
  have ht : Tendsto (fun k : ℕ => (k, x)) atTop (atTop ×ˢ 𝓝 x) :=
    tendsto_id.prodMk tendsto_const_nhds
  have hh := tendsto_curvature_prod D Ds E hE hmono hcover f hf hconv x
  constructor
  · simpa only [Function.comp_def] using hh.1.comp ht
  · simpa only [Function.comp_def] using hh.2.comp ht

include hE hmono hcover hf hconv in
theorem tendstoUniformlyOn_scalarCurvature {K : Set M} (hK : IsCompact K) :
    TendstoUniformlyOn (fun k x => (Ds k).scalarCurvature (f k x)) D.scalarCurvature atTop K := by
  classical
  apply Metric.tendstoUniformlyOn_iff.mpr
  intro epsilon hepsilon
  have hlocal (x : M) : ∃ U ∈ 𝓝 x, ∀ᶠ k in atTop,
      ∀ y ∈ U, |(Ds k).scalarCurvature (f k y) - D.scalarCurvature y| < epsilon := by
    have hd := (tendsto_curvature_prod D Ds E hE hmono hcover f hf hconv x).1.sub
      (D.continuous_scalarCurvature.continuousAt.tendsto.comp tendsto_snd)
    have hd' := hd.abs
    simp only [sub_self, abs_zero] at hd'
    obtain ⟨P, hP, Q, hQ, hPQ⟩ := eventually_prod_iff.mp
      (hd'.eventually (Iio_mem_nhds hepsilon))
    exact ⟨{y | Q y}, hQ, hP.mono fun k hk y hy => hPQ hk hy⟩
  choose U hU hb using fun x : K => hlocal x.val
  obtain ⟨s, hs⟩ := hK.elim_nhds_subcover' (fun x hx => U ⟨x, hx⟩)
    (fun x hx => hU ⟨x, hx⟩)
  filter_upwards [s.eventually_all.mpr (fun x _ => hb x)] with k hk x hx
  obtain ⟨y, hy, hxy⟩ := mem_iUnion₂.mp (hs hx)
  simpa only [Real.dist_eq, abs_sub_comm] using hk y hy x hxy

include hE hmono hcover hf hconv in
theorem nonnegativeCurvatureOperator_of_spatial_metric_jets
    (x : M) {eta : ℕ → ℝ} (heta : Tendsto eta atTop (𝓝 0))
    (hneg : ∀ᶠ k in atTop, (Ds k).negativeCurvaturePart (f k x) ≤ eta k) :
    D.NonnegativeCurvatureOperator x := by
  let c := extChartAt (𝓡 3) x
  let p := c x
  have hp : p ∈ c.target := c.map_source (mem_extChartAt_source x)
  have hcx : c.symm p = x := c.left_inv (mem_extChartAt_source x)
  obtain ⟨gd, heq, _hscalar, _hnorm, hpos⟩ := exists_pullback_realization D c.symm p
    (Filter.Eventually.mono (extChartAt_target_mem_nhds' hp) fun y hy => chart_inverse_regular x hy)
  have ht : Tendsto (fun k : ℕ => (k, p)) atTop (atTop ×ˢ 𝓝 p) :=
    tendsto_id.prodMk tendsto_const_nhds
  have hreg := ht.eventually (eventually_coordinate_regular E hE hmono hcover f hf x hp)
  have hjets (r : ℕ) (_hr : r ≤ 2) :
      Tendsto (fun k => iteratedFDeriv ℝ r ((gs k).pullbackCoefficients (f k ∘ c.symm)) p)
        atTop (𝓝 (iteratedFDeriv ℝ r gd.1.euclideanCoefficients p)) := by
    rw [(heq.iteratedFDeriv ℝ r).self_of_nhds]
    exact (hconv x r {p} isCompact_singleton (singleton_subset_iff.mpr hp)).tendsto_at (mem_singleton p)
  have hh := curvature_of_moving_pullback_jets Ds (fun k => f k ∘ c.symm) gd.2
    (fun _ => p) p hreg hjets
  have hlim := hh.2.2 eta heta (by simpa only [Function.comp_apply, hcx] using hneg)
  simpa only [hcx] using hpos.mp hlim

end Sequence

end PoincareMT.ControlledTerminal
