import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Charts
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Cylinders
import PoincareLib.Geometry.Manifold.InverseFunction.LocalDiffeomorph

/-!
# Captured compact terminal stages

The retained terminal embeddings give partial diffeomorphisms on each fixed
precompact stage into a common controlled source ball. This keeps connected
domains containing both the basepoint and a selected high-curvature point.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.ControlledTerminal

open ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A : ℝ}
  {M : Type v} [TopologicalSpace M] [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
  [IsManifold (𝓡 3) ∞ M]

def terminalStageBallMap (hA : 0 < A) {U : Set M}
    (f : M → S.terminalComponent k)
    (hball : ∀ x ∈ U, (f x).val ∈ S.baseBall k A) (x : M) : sourceBall S k A := by
  classical
  exact if hx : x ∈ U then ⟨(f x).val, hball x hx⟩
    else ⟨(S.base k).2, base_mem_sourceBall hA⟩

omit [TopologicalSpace M] [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
    [IsManifold (𝓡 3) ∞ M] in
theorem terminalStageBallMap_val (hA : 0 < A) {U : Set M}
    (f : M → S.terminalComponent k)
    (hball : ∀ x ∈ U, (f x).val ∈ S.baseBall k A)
    {x : M} (hx : x ∈ U) : (terminalStageBallMap hA f hball x).val = (f x).val := by
  simp only [terminalStageBallMap, dif_pos hx]

omit [IsManifold (𝓡 3) ∞ M] in
theorem terminalStageBallMap_isLocalDiffeomorphOn (hA : 0 < A) {U : Set M}
    (f : M → S.terminalComponent k)
    (hball : ∀ x ∈ U, (f x).val ∈ S.baseBall k A)
    (hU : IsOpen U) (hf : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ f U) :
    IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (terminalStageBallMap hA f hball) U := by
  intro x
  let b := terminalStageBallMap hA f hball
  have hraw := (hf x).comp (𝓡 3) _
    (Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 3) (S.terminalComponent k) (f x))
  have hi := Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 3) (sourceBall S k A) (b x)
  have hval : (b x).val = (f x).val := terminalStageBallMap_val hA f hball x.property
  have hinv : IsLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞ hi.localInverse (f x).val := by
    rw [← hval]
    exact hi.localInverse_isLocalDiffeomorphAt
  apply (hraw.comp (𝓡 3) _ hinv).congr_of_eventuallyEq
  have hright : ∀ᶠ y in 𝓝 ((f x).val), (hi.localInverse y).val = y := by
    rw [← hval]
    exact hi.localInverse_eventuallyEq_right
  filter_upwards [hU.mem_nhds x.property, hraw.contMDiffAt.continuousAt.tendsto.eventually hright]
    with y hy hyeq
  exact Subtype.ext ((terminalStageBallMap_val hA f hball hy).trans hyeq.symm)

def terminalStagePartialDiffeomorph [Nonempty M]
    (hA : 0 < A) {U : Set M} (f : M → S.terminalComponent k)
    (hball : ∀ x ∈ U, (f x).val ∈ S.baseBall k A)
    (hU : IsOpen U) (hf : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ f U)
    (hinj : InjOn f U) : PartialDiffeomorph (𝓡 3) (𝓡 3) M (sourceBall S k A) ∞ :=
  AncientCompactness.partialDiffeomorphOfInjOn hU (terminalStageBallMap hA f hball)
    (by
      intro x hx y hy hxy
      apply hinj hx hy
      apply Subtype.ext
      simpa only [terminalStageBallMap_val hA f hball hx,
        terminalStageBallMap_val hA f hball hy] using congrArg Subtype.val hxy)
    (terminalStageBallMap_isLocalDiffeomorphOn hA f hball hU hf)

theorem terminalStageBallMap_terminal_coefficients
    (hA : 0 < A) {U : Set M} (f : M → S.terminalComponent k)
    (hball : ∀ x ∈ U, (f x).val ∈ S.baseBall k A)
    (hU : IsOpen U) (hf : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ f U)
    {T B eta : ℝ} (cyl : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    (q : M) {z : EuclideanSpace ℝ (Fin 3)}
    (hz : z ∈ (extChartAt (𝓡 3) q).target)
    (hzU : (extChartAt (𝓡 3) q).symm z ∈ U) :
    ((cyl.ordinaryFlow hT).metric 0).pullbackCoefficients
        (terminalStageBallMap hA f hball ∘ (extChartAt (𝓡 3) q).symm) z =
      (S.terminalComponentMetric k).pullbackCoefficients
        (f ∘ (extChartAt (𝓡 3) q).symm) z := by
  let c := extChartAt (𝓡 3) q
  let W := c.target ∩ c.symm ⁻¹' U
  have hW : IsOpen W := (continuousOn_extChartAt_symm q).isOpen_inter_preimage
    (isOpen_extChartAt_target q) hU
  have hzW : z ∈ W := ⟨hz, hzU⟩
  let phi := f ∘ c.symm
  have hphi : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ phi W := by
    have hc : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ c.symm c.target := by
      apply Poincare.isLocalDiffeomorphOn_of_contMDiffOn_bijective_mfderiv
        (isOpen_extChartAt_target q) (contMDiffOn_extChartAt_symm q)
      intro x hx
      have hi : (mfderiv (𝓡 3) (𝓡 3) c.symm x).IsInvertible := by
        simpa only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] using
          isInvertible_mfderivWithin_extChartAt_symm (I := 𝓡 3) hx
      exact hi.bijective
    intro x
    exact (hc ⟨x, x.property.1⟩).comp (𝓡 3) _ (hf ⟨c.symm x, x.property.2⟩)
  have hball' : ∀ x ∈ W, (phi x).val ∈ S.baseBall k A := fun x hx => hball _ hx.2
  have heq : terminalStageBallMap hA f hball ∘ c.symm =ᶠ[𝓝 z]
      terminalBallParametrization hA phi hball' := by
    filter_upwards [hW.mem_nhds hzW] with x hx
    apply Subtype.ext
    exact (terminalStageBallMap_val hA f hball hx.2).trans
      (terminalBallParametrization_val hA phi hball' hx).symm
  trans ((cyl.ordinaryFlow hT).metric 0).pullbackCoefficients
      (terminalBallParametrization hA phi hball') z
  · ext v w
    change ((cyl.ordinaryFlow hT).metric 0).inner _
      (mfderiv (𝓡 3) (𝓡 3) (terminalStageBallMap hA f hball ∘ c.symm) z v)
      (mfderiv (𝓡 3) (𝓡 3) (terminalStageBallMap hA f hball ∘ c.symm) z w) = _
    rw [heq.mfderiv_eq, heq.self_of_nhds]
    rfl
  · exact terminalBallParametrization_terminal_coefficients hA phi hball' hW hphi cyl hT hzW

theorem eventually_captured_terminal_stage [Nonempty M]
    (sigma : ℕ → ℕ) (E : ℕ → Set M) (hE : ∀ j, IsOpen (E j))
    (hmono : Monotone E) (hcover : ⋃ j, E j = univ)
    (f : ∀ k, M → S.terminalComponent (sigma k))
    (hemb : ∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x))
    (hlocal : ∀ k, IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k))
    (himage : ∀ K : Set M, IsCompact K → ∃ R : ℝ, 0 < R ∧
      ∀ᶠ k in atTop, ∀ x ∈ K, (f k x).val ∈ S.baseBall (sigma k) R)
    {U : Set M} (hU : IsOpen U) (hUc : IsCompact (closure U)) :
    ∃ R : ℝ, 0 < R ∧ ∀ A : ℝ, R ≤ A → ∀ᶠ k in atTop,
      ∃ Phi : PartialDiffeomorph (𝓡 3) (𝓡 3) M (sourceBall S (sigma k) A) ∞,
        Phi.source = U ∧
        (∀ x ∈ U, (Phi x).val = (f k x).val) ∧
        ∀ T B eta (cyl : ControlledBlowupCylinder S (sigma k) A T B eta)
          (hT : 0 < T) q z, z ∈ (extChartAt (𝓡 3) q).target →
            (extChartAt (𝓡 3) q).symm z ∈ U →
            ((cyl.ordinaryFlow hT).metric 0).pullbackCoefficients
                (Phi ∘ (extChartAt (𝓡 3) q).symm) z =
              (S.terminalComponentMetric (sigma k)).pullbackCoefficients
                (f k ∘ (extChartAt (𝓡 3) q).symm) z := by
  obtain ⟨j, hj⟩ := hUc.elim_directed_cover E hE
    (by rw [hcover]; exact subset_univ _) hmono.directed_le
  obtain ⟨R, hR, hRimage⟩ := himage (closure U) hUc
  refine ⟨R, hR, fun A hRA => ?_⟩
  have hA : 0 < A := hR.trans_le hRA
  filter_upwards [hRimage, eventually_ge_atTop j] with k hk hjk
  have hUE : U ⊆ E k := fun x hx => hmono hjk (hj (subset_closure hx))
  have hball : ∀ x ∈ U, (f k x).val ∈ S.baseBall (sigma k) A := by
    intro x hx
    have hh := hk x (subset_closure hx)
    rw [← S.normalizedTerminalMetric_ball] at hh ⊢
    exact hh.trans_le (ENNReal.ofReal_le_ofReal hRA)
  have hf : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) U :=
    fun x => hlocal k ⟨x, hUE x.property⟩
  have hi : InjOn (f k) U := by
    intro x hx y hy hxy
    exact congrArg Subtype.val ((hemb k).injective
      (a₁ := ⟨x, hUE hx⟩) (a₂ := ⟨y, hUE hy⟩) hxy)
  let Phi := terminalStagePartialDiffeomorph hA (f k) hball hU hf hi
  refine ⟨Phi, rfl, fun x hx => terminalStageBallMap_val hA (f k) hball hx, ?_⟩
  intro T B eta cyl hT q z hz hzU
  exact terminalStageBallMap_terminal_coefficients hA (f k) hball hU hf cyl hT q hz hzU

end PoincareMT.ControlledTerminal
