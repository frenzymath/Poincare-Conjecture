import PoincareLib.Geometry.RicciFlow.Surgery.Singular.RegularLimit.Canonical.ComponentCapture
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.RegularLimit.Canonical.RoundComparison.Component

/-!
# Scalar control from canonical component alternatives

A connected comparison domain keeps the basepoint and selected point in
the same source component. The original component scalar ratios then pass
to the limit using scalar convergence at those two points.

Reference: Morgan--Tian, Claim 11.6 and Definition 9.75, pp. 270 and 231.
-/

set_option autoImplicit false

open Set Filter
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.ControlledTerminal

private theorem image_subset_component_of_mem
    {Y : Type u} {X : Type v} [TopologicalSpace Y] [TopologicalSpace X]
    {f : Y → X} {U : Set Y} (hU : IsPreconnected U) (hf : ContinuousOn f U)
    {x : Y} (hx : x ∈ U) {p : X} (hp : f x ∈ connectedComponent p) :
    f '' U ⊆ connectedComponent p := by
  rw [connectedComponent_eq hp]
  exact (hU.image f hf).subset_connectedComponent (mem_image_of_mem f hx)

theorem scalar_le_of_component_alternative_on_connected_image
    {Y : Type u} [TopologicalSpace Y]
    {X : Type v} [TopologicalSpace X]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) X] [IsManifold (𝓡 3) ∞ X]
    {g : RiemannianMetric 3 X} (D : LeviCivitaData g)
    {f : Y → X} {U : Set Y} (hU : IsPreconnected U) (hf : ContinuousOn f U)
    {p x : Y} (hp : p ∈ U) (hx : x ∈ U)
    {epsilon C : ℝ}
    (hepsilon : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold)
    (hbase : 0 ≤ D.scalarCurvature (f p))
    (hcomponent : (∃ N : SingularCComponent g D C, f x ∈ N.carrier) ∨
      ∃ N : SingularRoundComponent g epsilon, f x ∈ N.carrier) :
    D.scalarCurvature (f x) ≤ max (C / 6) 2 * D.scalarCurvature (f p) := by
  rcases hcomponent with ⟨N, hxN⟩ | ⟨N, hxN⟩
  · have hpN : f p ∈ N.carrier := by
      rw [N.component_eq] at hxN ⊢
      exact image_subset_component_of_mem hU hf hx hxN (mem_image_of_mem f hp)
    exact (N.scalar_le_constant_div_six_mul hpN hxN).trans
      (mul_le_mul_of_nonneg_right (le_max_left _ _) hbase)
  · have hpN : f p ∈ N.carrier := by
      rw [N.component_eq] at hxN ⊢
      exact image_subset_component_of_mem hU hf hx hxN (mem_image_of_mem f hp)
    exact (N.scalar_le_two_mul D hepsilon hpN hxN).trans
      (mul_le_mul_of_nonneg_right (le_max_right _ _) hbase)

theorem scalar_limit_le_of_frequent_component_alternative
    {Y : Type u} [TopologicalSpace Y]
    {X : ℕ → Type v} [∀ k, TopologicalSpace (X k)]
    [∀ k, ChartedSpace (EuclideanSpace ℝ (Fin 3)) (X k)]
    [∀ k, IsManifold (𝓡 3) ∞ (X k)]
    (g : ∀ k, RiemannianMetric 3 (X k)) (D : ∀ k, LeviCivitaData (g k))
    (f : ∀ k, Y → X k) {U : Set Y} (hU : IsPreconnected U)
    (hf : ∀ᶠ k in atTop, ContinuousOn (f k) U)
    {p x : Y} (hp : p ∈ U) (hx : x ∈ U)
    {epsilon C R : ℝ}
    (hepsilon : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold)
    (hbase : Tendsto (fun k => (D k).scalarCurvature (f k p)) atTop (𝓝 1))
    (hscalar : Tendsto (fun k => (D k).scalarCurvature (f k x)) atTop (𝓝 R))
    (hcomponent : ∃ᶠ k in atTop,
      (∃ N : SingularCComponent (g k) (D k) C, f k x ∈ N.carrier) ∨
      ∃ N : SingularRoundComponent (g k) epsilon, f k x ∈ N.carrier) :
    R ≤ max (C / 6) 2 := by
  have hpositive : ∀ᶠ k in atTop, 0 ≤ (D k).scalarCurvature (f k p) :=
    (hbase.eventually (eventually_gt_nhds zero_lt_one)).mono fun _ hk => hk.le
  have hbound : ∃ᶠ k in atTop, (D k).scalarCurvature (f k x) ≤
      max (C / 6) 2 * (D k).scalarCurvature (f k p) := by
    apply ((hcomponent.and_eventually hf).and_eventually hpositive).mono
    rintro k ⟨⟨hk, hfk⟩, hpk⟩
    exact scalar_le_of_component_alternative_on_connected_image
      (D k) hU hfk hp hx hepsilon hpk hk
  simpa only [mul_one] using le_of_tendsto_of_tendsto_of_frequently hscalar
    (tendsto_const_nhds.mul hbase) hbound

theorem normalized_scalar_limit_le_of_frequent_component_alternative
    {Y : Type u} [TopologicalSpace Y]
    {X : ℕ → Type v} [∀ k, TopologicalSpace (X k)]
    [∀ k, ChartedSpace (EuclideanSpace ℝ (Fin 3)) (X k)]
    [∀ k, IsManifold (𝓡 3) ∞ (X k)]
    (g : ∀ k, RiemannianMetric 3 (X k)) (D : ∀ k, LeviCivitaData (g k))
    (f : ∀ k, Y → X k) (scale : ℕ → ℝ) (hscale : ∀ k, 0 < scale k)
    {U : Set Y} (hU : IsPreconnected U)
    (hf : ∀ᶠ k in atTop, ContinuousOn (f k) U)
    {p x : Y} (hp : p ∈ U) (hx : x ∈ U)
    {epsilon C R : ℝ}
    (hepsilon : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold)
    (hbase : Tendsto (fun k => (scale k)⁻¹ * (D k).scalarCurvature (f k p)) atTop (𝓝 1))
    (hscalar : Tendsto (fun k => (scale k)⁻¹ * (D k).scalarCurvature (f k x)) atTop (𝓝 R))
    (hcomponent : ∃ᶠ k in atTop,
      (∃ N : SingularCComponent (g k) (D k) C, f k x ∈ N.carrier) ∨
      ∃ N : SingularRoundComponent (g k) epsilon, f k x ∈ N.carrier) :
    R ≤ max (C / 6) 2 := by
  have hpositive : ∀ᶠ k in atTop, 0 ≤ (D k).scalarCurvature (f k p) := by
    filter_upwards [hbase.eventually (eventually_gt_nhds zero_lt_one)] with k hk
    exact ((mul_pos_iff_of_pos_left (inv_pos.mpr (hscale k))).mp hk).le
  have hbound : ∃ᶠ k in atTop, (scale k)⁻¹ * (D k).scalarCurvature (f k x) ≤
      max (C / 6) 2 * ((scale k)⁻¹ * (D k).scalarCurvature (f k p)) := by
    apply ((hcomponent.and_eventually hf).and_eventually hpositive).mono
    rintro k ⟨⟨hk, hfk⟩, hpk⟩
    have hh := mul_le_mul_of_nonneg_left
      (scalar_le_of_component_alternative_on_connected_image
        (D k) hU hfk hp hx hepsilon hpk hk) (inv_pos.mpr (hscale k)).le
    simpa only [mul_left_comm] using hh
  simpa only [mul_one] using le_of_tendsto_of_tendsto_of_frequently hscalar
    (tendsto_const_nhds.mul hbase) hbound

end PoincareMT.ControlledTerminal
