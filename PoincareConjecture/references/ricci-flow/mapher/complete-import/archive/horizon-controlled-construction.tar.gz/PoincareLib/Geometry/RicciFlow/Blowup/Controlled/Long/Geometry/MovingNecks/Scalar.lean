import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.MovingNecks.Separation
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.PathAvoidance
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Geometry.NeckCurvature

/-!
# Scalar control when neck centers approach a fixed reference point

Curvature controls both center displacement and neck scale. Large scalar
curvature would trap the actual separating sphere in a neighborhood avoided
by one fixed path, contradicting the large-triangle geometry.
Reference: Morgan--Tian, Claims 11.13--11.14, pp. 276--277.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledLongGeometry

theorem mul_inverse_sqrt_lt_of_sq_lt {K r R : ℝ} (hK : 0 < K) (hr : 0 < r)
    (hR : (K / r) ^ 2 < R) : K * R ^ (-1 / 2 : ℝ) < r := by
  have hRpos : 0 < R := (sq_nonneg _).trans_lt hR
  have hsqrt : K / r < Real.sqrt R := by
    have hh := Real.sqrt_lt_sqrt (sq_nonneg _) hR
    simpa only [Real.sqrt_sq (div_pos hK hr).le] using hh
  rw [neg_div, Real.rpow_neg hRpos.le, ← Real.sqrt_eq_rpow, ← div_eq_mul_inv]
  apply (div_lt_iff₀ (Real.sqrt_pos.mpr hRpos)).mpr
  have hh := (div_lt_iff₀ hr).mp hsqrt
  nlinarith

theorem exists_scalar_cutoff_for_necks_with_controlled_center
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    [MeasurableSpace M] [BorelSpace M] [T2Space M] [T3Space M] [ConnectedSpace M]
    (g₀ : RiemannianMetric 3 M) {p y z : M} (hpy : p ≠ y) (hzy : z ≠ y)
    {epsilon d K : ℝ} (hepsilon : 0 < epsilon)
    (hsmall : epsilon ≤ 1 / (400 * Real.pi)) (hd : 0 < d) (hK : 0 < K) :
    ∃ cutoff : ℝ, 0 < cutoff ∧
      ∀ (g : RiemannianMetric 3 M) (D : LeviCivitaData g),
        MetricComplete g → D.NonnegativeSectionalCurvature →
        (∀ x : M, (g₀.edist y x).toReal ≤ (g.edist y x).toReal) →
        d ≤ (g.edist y p).toReal → d ≤ (g.edist y z).toReal →
        (g.edist y p).toReal ≤ 9 * d / 8 → (g.edist y z).toReal ≤ 9 * d / 8 →
        d ≤ (g.edist p z).toReal → ∀ N : EpsilonNeck g, N.epsilon = epsilon →
        (g.edist y N.center).toReal ≤ K * D.scalarCurvature y ^ (-1 / 2 : ℝ) →
        D.scalarCurvature y ≤ K * D.scalarCurvature N.center →
        D.scalarCurvature y ≤ cutoff := by
  obtain ⟨r, hr, hsep⟩ := exists_central_sphere_separating_radius g₀ y
  obtain ⟨rho, hrho, gamma, hgamma⟩ := exists_path_with_positive_distance
    (n := 1) g₀ hpy hzy
  let tau := min (d / 8) (min r rho / 3)
  have htau : 0 < tau := lt_min (by positivity) (div_pos (lt_min hr hrho) (by norm_num))
  have htaud : tau ≤ d / 8 := min_le_left _ _
  have htaur : 2 * tau ≤ r := by
    have hh := min_le_right (d / 8) (min r rho / 3)
    have hh' := min_le_left r rho
    dsimp [tau]
    linarith
  have htaurho : 2 * tau ≤ rho := by
    have hh := min_le_right (d / 8) (min r rho / 3)
    have hh' := min_le_right r rho
    dsimp [tau]
    linarith
  let B := 2 * Real.pi + 2 * epsilon⁻¹
  have hB : 0 < B := by dsimp [B]; positivity
  let cutoff := max ((K / tau) ^ 2) (K * (B / tau) ^ 2) + 1
  have hcutoff : 0 < cutoff := by
    have hh := (sq_nonneg (K / tau)).trans (le_max_left _ (K * (B / tau) ^ 2))
    dsimp [cutoff]
    linarith
  refine ⟨cutoff, hcutoff, ?_⟩
  intro g D hcomplete hsec hdist ha hb ha' hb' hfar N heq hcenter hscalar
  by_contra hn
  have hlarge : cutoff < D.scalarCurvature y := lt_of_not_ge hn
  have hlarge₁ : (K / tau) ^ 2 < D.scalarCurvature y := by
    have hh := le_max_left ((K / tau) ^ 2) (K * (B / tau) ^ 2)
    dsimp [cutoff] at hlarge
    linarith
  have hlarge₂ : K * (B / tau) ^ 2 < D.scalarCurvature y := by
    have hh := le_max_right ((K / tau) ^ 2) (K * (B / tau) ^ 2)
    dsimp [cutoff] at hlarge
    linarith
  have hcenterSmall : (g.edist y N.center).toReal < tau :=
    hcenter.trans_lt (mul_inverse_sqrt_lt_of_sq_lt hK htau hlarge₁)
  have hscale : B * N.scale < tau :=
    N.scale_mul_lt_of_scalar_center_gt D hB htau
      (lt_of_mul_lt_mul_left (hlarge₂.trans_le hscalar) hK.le)
  have hscale' : 2 * Real.pi * N.scale < tau := by
    apply lt_of_le_of_lt _ hscale
    apply mul_le_mul_of_nonneg_right _ N.scale_pos.le
    dsimp [B]
    have hi := inv_pos.mpr hepsilon
    linarith
  have hsphere : ∀ x ∈ N.central_sphere, (g₀.edist y x).toReal < 2 * tau := by
    intro x hx
    have hdiam := ENNReal.toReal_mono ENNReal.ofReal_ne_top
      (N.edist_central_sphere_le_two_pi_mul_scale N.center_on_central_sphere hx)
    rw [ENNReal.toReal_ofReal
      (mul_nonneg (mul_nonneg (by norm_num) Real.pi_pos.le) N.scale_pos.le)] at hdiam
    have htriangle := g.toReal_edist_triangle y N.center x
    have hh := hdist x
    linarith
  have hseparating : N.IsSeparating := hsep g N
    (fun x hx => (hsphere x hx).trans_le htaur)
  have hcomm : g.edist N.center y = g.edist y N.center := by
    let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
      ⟨g.toRiemannianMetric⟩
    exact Manifold.riemannianEDist_comm
  have hlowp := g.toReal_edist_triangle y N.center p
  have hlowz := g.toReal_edist_triangle y N.center z
  have hupp := g.toReal_edist_triangle N.center y p
  have hupz := g.toReal_edist_triangle N.center y z
  rw [hcomm] at hupp hupz
  have hsize : (2 * Real.pi + 2 * N.epsilon⁻¹) * N.scale < 7 * d / 8 := by
    rw [heq]
    change B * N.scale < 7 * d / 8
    linarith
  obtain ⟨s, hs⟩ := N.every_path_meets_central_sphere_of_endpoint_distances D
    hcomplete hsec hseparating (heq.trans_le hsmall)
    (show 0 < 7 * d / 8 by positivity)
    (by linarith : 7 * d / 8 ≤ (g.edist N.center p).toReal)
    (by linarith : 7 * d / 8 ≤ (g.edist N.center z).toReal)
    (by linarith : (g.edist N.center p).toReal ≤ 3 * (7 * d / 8) / 2)
    (by linarith : (g.edist N.center z).toReal ≤ 3 * (7 * d / 8) / 2)
    (by linarith : 7 * d / 8 ≤ (g.edist p z).toReal) hsize gamma
  exact (not_lt_of_ge (hgamma s)) ((hsphere (gamma s) hs).trans_le htaurho)

end PoincareMT.ControlledLongGeometry
