import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Ancient.Compact.Stability.Neck.Jets.Pullback

/-!
# Uniform normalization of varying finite metric jets

Small unnormalized metric errors and small errors in the scalar at the neck
center give small normalized errors. The reference jets and original scalar
factors need only be bounded uniformly; the local coordinate maps may vary.

Reference: Morgan--Tian, Claim 11.6 and Proposition 9.79(3).
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Filter
open scoped ContDiff Topology

namespace PoincareMT.TerminalNeck

theorem eventually_small_normalized_jet_errors
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {ι : Type*} (a b : ℕ → ι → E → F) (q Q : ℕ → ι → ℝ)
    (x : ι → E) (m : ℕ) {B u : ℝ} (hB : 0 ≤ B) (hu : 0 ≤ u)
    (hsmooth : ∀ᶠ k in atTop, ∀ i,
      ContDiffAt ℝ ∞ (a k i) (x i) ∧ ContDiffAt ℝ ∞ (b k i) (x i))
    (hsource : ∀ᶠ k in atTop, ∀ i j, j ≤ m →
      ‖iteratedFDeriv ℝ j (a k i) (x i)‖ ≤ B)
    (hscalar : ∀ᶠ k in atTop, ∀ i, |q k i| ≤ u)
    (herror : ∀ δ : ℝ, 0 < δ → ∀ᶠ k in atTop, ∀ i j, j ≤ m →
      ‖iteratedFDeriv ℝ j (fun y => b k i y - a k i y) (x i)‖ ≤ δ)
    (hgap : ∀ δ : ℝ, 0 < δ → ∀ᶠ k in atTop, ∀ i, |Q k i - q k i| ≤ δ)
    {η : ℝ} (hη : 0 < η) :
    ∀ᶠ k in atTop, ∀ i j, j ≤ m →
      ‖iteratedFDeriv ℝ j (fun y => Q k i • b k i y - q k i • a k i y) (x i)‖ ≤ η := by
  let δ := min 1 (η / (u + B + 2))
  have hden : 0 < u + B + 2 := by positivity
  have hδ : 0 < δ := lt_min zero_lt_one (div_pos hη hden)
  have hδone : δ ≤ 1 := min_le_left _ _
  have hδη : δ * (u + B + 2) ≤ η :=
    (le_div_iff₀ hden).mp (min_le_right _ _)
  filter_upwards [hsmooth, hsource, hscalar, herror δ hδ, hgap δ hδ]
    with k hks hka hkq hke hkg i j hj
  have hQ : |Q k i| ≤ u + 1 := by
    calc
      |Q k i| = |(Q k i - q k i) + q k i| := by congr 1; ring
      _ ≤ |Q k i - q k i| + |q k i| := abs_add_le _ _
      _ ≤ 1 + u := add_le_add ((hkg i).trans hδone) (hkq i)
      _ = u + 1 := by ring
  have ha := (hks i).1
  have hb := (hks i).2
  have heq : iteratedFDeriv ℝ j
      (fun y => Q k i • b k i y - q k i • a k i y) (x i) =
      Q k i • iteratedFDeriv ℝ j (fun y => b k i y - a k i y) (x i) +
        (Q k i - q k i) • iteratedFDeriv ℝ j (a k i) (x i) := by
    rw [fun_iteratedFDeriv_sub_apply
      ((hb.const_smul (Q k i)).of_le (by exact_mod_cast le_top))
      ((ha.const_smul (q k i)).of_le (by exact_mod_cast le_top)),
      iteratedFDeriv_const_smul_apply' (hb.of_le (by exact_mod_cast le_top)),
      iteratedFDeriv_const_smul_apply' (ha.of_le (by exact_mod_cast le_top)),
      fun_iteratedFDeriv_sub_apply
        (hb.of_le (by exact_mod_cast le_top)) (ha.of_le (by exact_mod_cast le_top))]
    module
  rw [heq]
  have hnorm := norm_add_le
    (Q k i • iteratedFDeriv ℝ j (fun y => b k i y - a k i y) (x i))
    ((Q k i - q k i) • iteratedFDeriv ℝ j (a k i) (x i))
  rw [norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs] at hnorm
  have hfirst := mul_le_mul hQ (hke i j hj) (norm_nonneg _) (by positivity : 0 ≤ u + 1)
  have hsecond := mul_le_mul (hkg i) (hka i j hj) (norm_nonneg _) hδ.le
  exact hnorm.trans ((add_le_add hfirst hsecond).trans (by nlinarith [hδ.le]))

end PoincareMT.TerminalNeck
