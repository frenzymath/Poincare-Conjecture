import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Sequence.DenseStages
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.TimeControl

/-!
# Canonical stage slices retaining scalar and metric control

The actual dense good slices are chosen after both compact scalar continuity
and the cylinder metric comparison. Their comparison maps retain the metric
jets, compact scalar convergence, and the differential lower bound needed
to capture full canonical neighborhoods.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000
set_option synthInstance.maxHeartbeats 100000

open Set Filter Metric
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.M30CommonBlowupControls

open ControlledBlowupCylinder
local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem exists_canonical_stage_slices_with_scalar_and_metric_control
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u})
    (sigma : ℕ → ℕ) {A T B eta : ℝ} (hA : 0 < A) (hT : 0 < T)
    (cyl : ∀ k, ControlledBlowupCylinder S (sigma k) A T B eta)
    {M : Type v} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    (g : RiemannianMetric 3 M) (D : LeviCivitaData g) {U : Set M} (hU : IsOpen U)
    (Phi : ∀ k, PartialDiffeomorph (𝓡 3) (𝓡 3) M (sourceBall S (sigma k) A) ∞)
    (hPhi : ∀ k, (Phi k).source = U)
    {K₀ : Set M} (hK₀ : IsCompact K₀) (hK₀U : K₀ ⊆ U)
    (hscalar0 : TendstoUniformlyOn
      (fun k y => (((cyl k).ordinaryFlow hT).connection 0).scalarCurvature (Phi k y))
      D.scalarCurvature atTop K₀)
    (hlower0 : ∀ k y, y ∈ K₀ → ∀ w : TangentSpace (𝓡 3) y,
      g.tangentNorm y w ≤ (3 / 2 : ℝ) * (((cyl k).ordinaryFlow hT).metric 0).tangentNorm
        (Phi k y) (mfderiv (𝓡 3) (𝓡 3) (Phi k) y w))
    {ι : Type*} [Fintype ι] (q : ι → M) (K : ι → Set M)
    (hK : ∀ i, IsCompact (K i) ∧ K i ⊆ U ∩ (extChartAt (𝓡 3) (q i)).source)
    (hterminal : ∀ i m, TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m (((cyl k).ordinaryFlow hT).metric 0
        |>.pullbackCoefficients (Phi k ∘ (extChartAt (𝓡 3) (q i)).symm)))
      (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm))
      atTop ((extChartAt (𝓡 3) (q i)) '' K i)) :
    ∃ (s : ℕ → ℝ) (hs : ∀ k, s k ∈ Icc (-T) 0),
      let t := fun k => (S.base (sigma k)).1 + s k / S.scale (sigma k)
      let h := fun k => rescaledMetric ((S.flow (sigma k)).metric (t k))
        (S.scale (sigma k)) (S.base_scalar_pos (sigma k))
      let Ds := fun k => rescaledMetric_connection ((S.flow (sigma k)).metric (t k))
        ((S.flow (sigma k)).connection (t k)) (S.scale (sigma k)) (S.base_scalar_pos (sigma k))
      let e := fun k => (cyl k).stageSlicePartialDiffeomorph hA (s k) (hs k) (Phi k)
      Tendsto s atTop (𝓝 0) ∧
      (∀ k, (e k).source = U) ∧
      (∀ k, t k ∈ (S.flow (sigma k)).interval ∧
        generalizedSliceStrongCanonicalNeighborhoods (S.flow (sigma k)) epsilon C
          (4 * S.scale (sigma k)) (t k)) ∧
      (∀ i m, TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ m ((h k).pullbackCoefficients
          (e k ∘ (extChartAt (𝓡 3) (q i)).symm)))
        (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm))
        atTop ((extChartAt (𝓡 3) (q i)) '' K i)) ∧
      TendstoUniformlyOn (fun k y => (Ds k).scalarCurvature (e k y))
        D.scalarCurvature atTop K₀ ∧
      ∀ k y, y ∈ K₀ → ∀ w : TangentSpace (𝓡 3) y,
        g.tangentNorm y w ≤ 2 * (h k).tangentNorm (e k y)
          (mfderiv (𝓡 3) (𝓡 3) (e k) y w) := by
  let P := fun k s =>
    (∀ y ∈ K₀,
      |(((cyl k).ordinaryFlow hT).connection s).scalarCurvature (Phi k y) -
        (((cyl k).ordinaryFlow hT).connection 0).scalarCurvature (Phi k y)| ≤
          ((k : ℝ) + 1)⁻¹) ∧
    ∀ y ∈ K₀, ∀ w : TangentSpace (𝓡 3) y,
      g.tangentNorm y w ≤ 2 * (((cyl k).ordinaryFlow hT).metric s).tangentNorm
        (Phi k y) (mfderiv (𝓡 3) (𝓡 3) (Phi k) y w)
  have hP (k : ℕ) : ∀ᶠ s in 𝓝[Icc (-T) 0] 0, P k s := by
    have hcont : ContinuousOn (Phi k) K₀ := (Phi k).contMDiffOn_toFun.continuousOn.mono
      (fun y hy => (hPhi k).symm ▸ hK₀U hy)
    have htime := RicciFlow.tendstoUniformlyOn_scalar_at_terminal P04 hK₀ (Phi k) hcont
      hT ((cyl k).ordinaryFlow hT)
    have hscalar := Metric.tendstoUniformlyOn_iff.mp htime (((k : ℝ) + 1)⁻¹) (by positivity)
    filter_upwards [hscalar, (cyl k).eventually_pullback_tangentNorm_lower hT g (Phi k)
      (hlower0 k)] with s hs hlower
    refine ⟨fun y hy => ?_, hlower⟩
    simpa only [Real.dist_eq, abs_sub_comm] using (hs y hy).le
  obtain ⟨s, hs, hs0, hselect, hjets⟩ := H.exists_canonical_stage_slices_with_metric_convergence
    sigma hA hT cyl g hU Phi hPhi q K hK hterminal P hP
  let t := fun k => (S.base (sigma k)).1 + s k / S.scale (sigma k)
  let h := fun k => rescaledMetric ((S.flow (sigma k)).metric (t k))
    (S.scale (sigma k)) (S.base_scalar_pos (sigma k))
  let Ds := fun k => rescaledMetric_connection ((S.flow (sigma k)).metric (t k))
    ((S.flow (sigma k)).connection (t k)) (S.scale (sigma k)) (S.base_scalar_pos (sigma k))
  let e := fun k => (cyl k).stageSlicePartialDiffeomorph hA (s k) (hs k) (Phi k)
  have hscalar (k : ℕ) (y : M) : (Ds k).scalarCurvature (e k y) =
      (((cyl k).ordinaryFlow hT).connection (s k)).scalarCurvature (Phi k y) :=
    (cyl k).sliceMap_scalarCurvature hT (s k) (hs k) (Ds k) (Phi k y)
  refine ⟨s, hs, hs0, fun k => by simp only [stageSlicePartialDiffeomorph_source, hPhi],
    fun k => (hselect k).2, hjets, ?_, ?_⟩
  · have hsmall : Tendsto (fun k : ℕ => ((k : ℝ) + 1)⁻¹) atTop (𝓝 0) :=
      tendsto_inv_atTop_zero.comp
        (tendsto_atTop_add_const_right atTop 1 tendsto_natCast_atTop_atTop)
    rw [Metric.tendstoUniformlyOn_iff]
    intro d hd
    filter_upwards [Metric.tendstoUniformlyOn_iff.mp hscalar0 (d / 2) (by positivity),
      hsmall.eventually (eventually_lt_nhds (by positivity : (0 : ℝ) < d / 2))]
      with k hk hkd y hy
    change dist (D.scalarCurvature y) ((Ds k).scalarCurvature (e k y)) < d
    rw [hscalar k y]
    have htime : dist
        ((((cyl k).ordinaryFlow hT).connection 0).scalarCurvature (Phi k y))
        ((((cyl k).ordinaryFlow hT).connection (s k)).scalarCurvature (Phi k y)) < d / 2 := by
      rw [Real.dist_eq, abs_sub_comm]
      exact ((hselect k).1.1 y hy).trans_lt hkd
    exact (dist_triangle _ _ _).trans_lt (by linarith [hk y hy, htime])
  · intro k y hy w
    change g.tangentNorm y w ≤ 2 * (h k).tangentNorm (e k y)
      (mfderiv (𝓡 3) (𝓡 3) (e k) y w)
    rw [(cyl k).stageSlicePartialDiffeomorph_tangentNorm hA hT (s k) (hs k) (Phi k)
      ((hPhi k).symm ▸ hK₀U hy) w]
    exact (hselect k).1.2 y hy w

end PoincareMT.M30CommonBlowupControls
