import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Geometry
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Completeness
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.BackwardFlow

/-! # Complete finite boundary metrics from actual local extensions -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledBlowupBoundary

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space

/-- Actual local extensions determine a complete nonnegatively curved
boundary metric on the existing carrier, and local backward flows ending
at that metric. The completeness conclusion is proved from metric order. -/
theorem exists_complete_boundary_metric
    {n : ℕ} (C : FlowCarrier n) (p : C.carrier)
    {ι : Type*} {U : ι → Type*} [∀ i, TopologicalSpace (U i)]
    [∀ i, ChartedSpace (EuclideanSpace ℝ (Fin n)) (U i)]
    [∀ i, IsManifold (𝓡 n) ∞ (U i)]
    {T : ℝ} (hT : 0 < T) (V : ι → ℝ) (hV : ∀ i, T < V i)
    (F : ∀ i, RicciFlow n (U i) (Icc (-V i) 0))
    (g : ℝ → C.metric) (hcomplete : C.metricComplete (g 0))
    (q : ∀ i, U i → C.carrier)
    (hq : ∀ i, IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (q i))
    (hcover : ∀ y, ∃ i x, q i x = y)
    (hpres : ∀ i, ∀ t ∈ Ioc (-T) 0, ∀ (x : U i) (a b : TangentSpace (𝓡 n) x),
      ((F i).metric t).inner x a b = (g t).inner (q i x)
        (mfderiv (𝓡 n) (𝓡 n) (q i) x a) (mfderiv (𝓡 n) (𝓡 n) (q i) x b))
    (hnonnegative : ∀ i, ∀ t ∈ Icc (-V i) 0, ∀ x,
      ((F i).connection t).NonnegativeCurvatureOperator x) :
    ∃ gBoundary : C.metric,
      C.metricComplete gBoundary ∧
      (∀ y, gBoundary.leviCivitaData.NonnegativeCurvatureOperator y) ∧
      (∀ y v, (g 0).inner y v v ≤ gBoundary.inner y v v) ∧
      (∀ i (x : U i) (a b : TangentSpace (𝓡 n) x),
        ((F i).metric (-T)).inner x a b = gBoundary.inner (q i x)
          (mfderiv (𝓡 n) (𝓡 n) (q i) x a) (mfderiv (𝓡 n) (𝓡 n) (q i) x b)) ∧
      ∀ i, ∃ d : ℝ, 0 < d ∧ ∃ H : RicciFlow n (U i) (Icc (-d) 0),
        (∀ t ∈ Icc (-d) 0, ∀ x, (H.connection t).NonnegativeCurvatureOperator x) ∧
        ∀ (x : U i) (a b : TangentSpace (𝓡 n) x),
          (H.metric 0).inner x a b = gBoundary.inner (q i x)
            (mfderiv (𝓡 n) (𝓡 n) (q i) x a) (mfderiv (𝓡 n) (𝓡 n) (q i) x b) := by
  obtain ⟨gBoundary, hBoundary⟩ := exists_boundary_metric hT V hV F g q hpres hq hcover
  have hle := terminal_inner_le_boundary_inner hT V hV F g q hq hcover hpres gBoundary hBoundary hnonnegative
  refine ⟨gBoundary, C.metricComplete_of_inner_le p (g 0) gBoundary hcomplete hle,
    boundary_nonnegativeCurvatureOperator hT V hV F q hq hcover gBoundary hBoundary hnonnegative
      gBoundary.leviCivitaData, hle, hBoundary, ?_⟩
  intro i
  refine ⟨V i - T, sub_pos.mpr (hV i), localBackwardFlow hT (hV i) (F i),
    fun _ ht x => localBackwardFlow_nonnegativeCurvatureOperator hT (hV i) (F i) (hnonnegative i) ht x, ?_⟩
  intro x a b
  rw [localBackwardFlow_metric_zero]
  exact hBoundary i x a b

end PoincareMT.ControlledBlowupBoundary
