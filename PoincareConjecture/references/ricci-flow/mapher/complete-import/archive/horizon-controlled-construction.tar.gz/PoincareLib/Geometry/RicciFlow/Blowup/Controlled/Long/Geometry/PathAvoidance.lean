import PoincareLib.Topology.Manifold.CountableComplement
import PoincareLib.Geometry.Riemannian.Distance.Basic

/-!
# Paths avoiding a fixed positive-radius ball about a third point

Deleting one point leaves a manifold of dimension at least two path connected.
The actual distance to the deleted point has a positive minimum on that path.
This is the final topological contradiction in Morgan--Tian, Claim 11.13.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledLongGeometry

theorem exists_path_with_positive_distance
    {n : ℕ} {M : Type*} [TopologicalSpace M] [T3Space M] [ConnectedSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin (n + 2))) M] [IsManifold (𝓡 (n + 2)) ∞ M]
    (g : RiemannianMetric (n + 2) M) {x y z : M} (hxy : x ≠ y) (hzy : z ≠ y) :
    ∃ r : ℝ, 0 < r ∧ ∃ gamma : Path x z,
      ∀ s, r ≤ (g.edist y (gamma s)).toReal := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 (n + 2)) : M → Type _) :=
    ⟨g.toRiemannianMetric⟩
  let : IsContinuousRiemannianBundle (EuclideanSpace ℝ (Fin (n + 2)))
      (TangentSpace (𝓡 (n + 2)) : M → Type _) :=
    ⟨⟨g.inner, g.toContinuousRiemannianMetric.continuous, fun _ _ _ => rfl⟩⟩
  let : EMetricSpace M := EMetricSpace.ofRiemannianMetric (𝓡 (n + 2)) M
  have hconn := Poincare.Topology.Manifold.isPathConnected_compl_countable
    (n := n) (C := ({y} : Set M)) (countable_singleton y)
  obtain ⟨gamma, hgamma⟩ := hconn.joinedIn x (by simpa only [mem_compl_iff, mem_singleton_iff] using hxy)
    z (by simpa only [mem_compl_iff, mem_singleton_iff] using hzy)
  have hcontinuous := (g.continuous_toReal_edist y).comp gamma.continuous
  obtain ⟨s, _, hmin⟩ := isCompact_univ.exists_isMinOn
    ⟨(0 : unitInterval), mem_univ _⟩ hcontinuous.continuousOn
  have hpositive : 0 < (g.edist y (gamma s)).toReal := by
    apply ENNReal.toReal_pos (fun hz => ?_) (g.edist_ne_top y (gamma s))
    have heq : y = gamma s := edist_eq_zero.mp hz
    exact hgamma s (mem_singleton_iff.mpr heq.symm)
  exact ⟨(g.edist y (gamma s)).toReal, hpositive, gamma, fun t => hmin (mem_univ t)⟩

theorem exists_path_avoiding_ball
    {n : ℕ} {M : Type*} [TopologicalSpace M] [T3Space M] [ConnectedSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin (n + 2))) M] [IsManifold (𝓡 (n + 2)) ∞ M]
    (g : RiemannianMetric (n + 2) M) {x y z : M} (hxy : x ≠ y) (hzy : z ≠ y) :
    ∃ r : ℝ, 0 < r ∧ ∃ gamma : Path x z,
      ∀ s, gamma s ∉ g.ball y r := by
  obtain ⟨r, hr, gamma, hgamma⟩ := exists_path_with_positive_distance g hxy hzy
  refine ⟨r, hr, gamma, ?_⟩
  intro s hs
  change g.edist y (gamma s) < ENNReal.ofReal r at hs
  rw [← ENNReal.ofReal_toReal (g.edist_ne_top y (gamma s))] at hs
  exact (not_lt_of_ge (hgamma s)) ((ENNReal.ofReal_lt_ofReal_iff hr).mp hs)

theorem not_all_positive_balls_meet_every_path
    {n : ℕ} {M : Type*} [TopologicalSpace M] [T3Space M] [ConnectedSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin (n + 2))) M] [IsManifold (𝓡 (n + 2)) ∞ M]
    (g : RiemannianMetric (n + 2) M) {x y z : M} (hxy : x ≠ y) (hzy : z ≠ y) :
    ¬ ∀ r : ℝ, 0 < r → ∀ gamma : Path x z, ∃ s, gamma s ∈ g.ball y r := by
  intro h
  obtain ⟨r, hr, gamma, hgamma⟩ := exists_path_avoiding_ball g hxy hzy
  obtain ⟨s, hs⟩ := h r hr gamma
  exact hgamma s hs

end PoincareMT.ControlledLongGeometry
