import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Noncollapse.Source
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Noncollapse.Volume
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Noncollapse.Curvature
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Cylinders.Rebase
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Volume

/-!
# Parabolic noncollapse inherited by controlled limits

Shrink the radius to obtain a strict curvature margin on a compact backward
cylinder. The actual source balls admit rebased scale-one cylinders, so
original noncollapse gives their volume lower bound. Ball-volume convergence
and passage to the original radius preserve the noncollapse constant.

Reference: Morgan--Tian, Theorem 11.8, pp. 272 and 278--279.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter MeasureTheory
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.measurableSpace FlowCarrier.borelSpace
  FlowCarrier.t3Space FlowCarrier.secondCountable

variable {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
  (G : GeneralizedBlowupConvergence S J.domain)

private theorem eventually_source_ball_volume_lower
    {t r rho kappa r₀ : ℝ} (ht : t ∈ J.domain) (ht0 : t ≤ 0)
    (p : G.limit.carrier.carrier) (hrho : 0 < rho) (hrhor : rho < r) (hr₀ : 0 < r₀)
    (hback : Ioc (t - r ^ 2) t ⊆ J.domain)
    (hcurv : ∀ s ∈ Ioc (t - r ^ 2) t, ∀ x ∈ (G.limit.flow.metric t).ball p r,
      |(G.limit.flow.connection s).curvatureTensorNorm x| ≤ r⁻¹ ^ 2)
    (hsource : ∀ᶠ k in atTop, ∀ ht : t ∈ Icc (-G.exhaustion.time k) 0,
      GeneralizedKappaNoncollapsedAt (S.flow (G.subsequence k))
        ((G.embedding k).pointMap t ht p) kappa r₀) :
    ∀ᶠ k in atTop, ENNReal.ofReal (kappa * rho ^ 3) ≤ G.normalizedSourceBallVolume k t p rho := by
  let g := G.limit.flow.metric t
  let : EMetricSpace G.limit.carrier.carrier := G.limit.carrier.metricEMetricSpace g
  obtain ⟨a, hrhoa, har⟩ := exists_between hrhor
  have hr : 0 < r := hrho.trans hrhor
  have ha : 0 < a := hrho.trans hrhoa
  let K := closure (g.ball p a)
  have hK : IsCompact K := g.isCompact_closure_ball_of_metricComplete (G.limit.complete t ht) p a
  have hKr : K ⊆ g.ball p r := by
    intro x hx
    have hd : edist p x ≤ ENNReal.ofReal a :=
      closure_minimal (fun _ hy => le_of_lt hy)
        (isClosed_le (continuous_const.edist continuous_id) continuous_const) hx
    exact hd.trans_lt ((ENNReal.ofReal_lt_ofReal_iff hr).mpr har)
  have hI : Icc (t - rho ^ 2) t ⊆ Ioc (t - r ^ 2) t := by
    intro s hs
    constructor
    · nlinarith only [hs.1, hrho, hrhor, sq_nonneg (r - rho)]
    · exact hs.2
  have hIJ : Icc (t - rho ^ 2) t ⊆ J.domain := hI.trans hback
  have hmargin : r⁻¹ ^ 2 < rho⁻¹ ^ 2 := by
    have hi := (inv_lt_inv₀ hr hrho).mpr hrhor
    nlinarith [inv_pos.mpr hrho, inv_pos.mpr hr]
  have hnorm := G.eventually_normalizedSource_curvature_norm_lt_on_compact
    (isCompact_Icc.prod hK) (fun _ hz => hIJ hz.1)
    (B := rho⁻¹ ^ 2) (fun z hz =>
      ((le_abs_self _).trans (hcurv z.1 (hI hz.1) z.2 (hKr hz.2))).trans_lt hmargin)
  have hC : 1 < a / rho := (one_lt_div hrho).mpr hrhoa
  have hsingle : ({t} : Set ℝ) ⊆ J.domain := singleton_subset_iff.mpr ht
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset hK
  filter_upwards [hnorm, hsource,
    G.eventually_source_ball_subset_slice_image_ball isCompact_singleton hsingle
      (singleton_subset_iff.mpr ht0) p hrho hC,
    G.exhaustion.time_cofinal (Icc (t - rho ^ 2) t) isCompact_Icc hIJ,
    G.subsequence_strictMono.tendsto_atTop.eventually (S.eventually_original_radius_le hr₀),
    eventually_ge_atTop j] with k hn hnc hcover htime hradius hjk
  have htk : t ∈ Icc (-G.exhaustion.time k) 0 := htime ⟨sub_le_self _ (sq_nonneg _), le_rfl⟩
  let q := S.scale (G.subsequence k)
  let d := G.embedding k
  let R := rho / Real.sqrt q
  have hq : 0 < q := S.base_scalar_pos (G.subsequence k)
  have hR : 0 < R := div_pos hrho (Real.sqrt_pos.mpr hq)
  have hRsq : R ^ 2 * q = rho ^ 2 := by
    dsimp [R]
    rw [div_pow, Real.sq_sqrt hq.le]
    exact div_mul_cancel₀ _ hq.ne'
  have hKs : K ⊆ G.exhaustion.space k := hj.trans (G.exhaustion.space_increasing hjk)
  have hcover' : (G.normalizedSourceMetric k t).ball (d.forward t htk p) rho ⊆
      d.forward t htk '' g.ball p a := by
    simpa only [div_mul_cancel₀ _ hrho.ne'] using hcover t (mem_singleton t) htk
  have hphysical : ((S.flow (G.subsequence k)).metric
      ((S.base (G.subsequence k)).1 + t / q)).ball (d.forward t htk p) R ⊆
      d.forward t htk '' G.exhaustion.space k := by
    have hh := hcover'.trans (image_mono (subset_closure.trans hKs))
    simpa only [normalizedSourceMetric, rescaledMetric_ball_allDimensions] using hh
  obtain ⟨hinterval, c, hc0, hc⟩ := d.exists_on_normalized_slice_ball
    (G.exhaustion.space_open k) htk p rho (Ioc_subset_Icc_self.trans htime) hphysical
  have hbound : ∀ s hs, ∀ x ∈ ((S.flow (G.subsequence k)).metric
      ((S.base (G.subsequence k)).1 + t / q)).ball (d.forward t htk p) R,
      |(S.flow (G.subsequence k)).curvatureNorm (c.pointMap s hs x)| ≤ R⁻¹ ^ 2 := by
    intro s hs x hx
    obtain ⟨hclock, heq⟩ := hc s hs x hx
    rw [heq]
    have hx' : x ∈ (G.normalizedSourceMetric k t).ball (d.forward t htk p) rho := by
      simpa only [normalizedSourceMetric, rescaledMetric_ball_allDimensions] using hx
    obtain ⟨y, hy, hexy⟩ := hcover' hx'
    have hinv : d.inverse t htk x = y := by
      rw [← hexy]
      exact d.left_inverse t htk (hKs (subset_closure hy))
    have hclockI : t + q * s ∈ Icc (t - rho ^ 2) t := by
      have hlo := mul_le_mul_of_nonneg_right hs.1.le hq.le
      have hhi := mul_nonpos_of_nonneg_of_nonpos hq.le hs.2
      constructor <;> nlinarith only [hlo, hhi, hRsq]
    have h := hn (t + q * s, y) ⟨hclockI, subset_closure hy⟩ hclock
    rw [normalizedSourceConnection, rescaledMetric_curvatureTensorNorm_exact] at h
    change q⁻¹ * (S.flow (G.subsequence k)).curvatureNorm
      (d.pointMap (t + q * s) hclock y) < rho⁻¹ ^ 2 at h
    rw [hinv]
    have hnonneg : 0 ≤ (S.flow (G.subsequence k)).curvatureNorm
        (d.pointMap (t + q * s) hclock y) := Real.sqrt_nonneg _
    rw [abs_of_nonneg hnonneg]
    have hqnorm := (mul_lt_mul_of_pos_left h hq)
    rw [← mul_assoc, mul_inv_cancel₀ hq.ne', one_mul] at hqnorm
    have hscale : q * rho⁻¹ ^ 2 = R⁻¹ ^ 2 := by
      dsimp [R]
      field_simp
      rw [Real.sq_sqrt hq.le]
    exact hqnorm.le.trans_eq hscale
  have hv := hnc htk R hR hradius hinterval c hc0 hbound
  rw [calibratedMetricVolume_eq_volumeMeasure] at hv
  simp only [normalizedSourceBallVolume, dif_pos htk]
  rw [normalizedSourceMetric, rescaledMetric_ball_allDimensions, rescaledMetric_volumeMeasure,
    Measure.smul_apply, smul_eq_mul]
  have hscalar : ENNReal.ofReal (kappa * rho ^ 3) =
      ENNReal.ofReal (Real.sqrt q) ^ 3 * ENNReal.ofReal (kappa * R ^ 3) := by
    rw [← ENNReal.ofReal_pow (Real.sqrt_nonneg q),
      ← ENNReal.ofReal_mul (pow_nonneg (Real.sqrt_nonneg q) 3)]
    congr 1
    dsimp [R]
    field_simp
  rw [hscalar]
  exact mul_le_mul_right hv _

theorem ball_volume_lower_of_eventually_source_noncollapsed
    {t r kappa r₀ : ℝ} (ht : t ∈ J.domain) (ht0 : t ≤ 0)
    (p : G.limit.carrier.carrier) (hr : 0 < r) (hr₀ : 0 < r₀)
    (hback : Ioc (t - r ^ 2) t ⊆ J.domain)
    (hcurv : ∀ s ∈ Ioc (t - r ^ 2) t, ∀ x ∈ (G.limit.flow.metric t).ball p r,
      |(G.limit.flow.connection s).curvatureTensorNorm x| ≤ r⁻¹ ^ 2)
    (hsource : ∀ᶠ k in atTop, ∀ ht : t ∈ Icc (-G.exhaustion.time k) 0,
      GeneralizedKappaNoncollapsedAt (S.flow (G.subsequence k))
        ((G.embedding k).pointMap t ht p) kappa r₀) :
    ENNReal.ofReal (kappa * r ^ 3) ≤
      calibratedMetricVolume (G.limit.flow.metric t) ((G.limit.flow.metric t).ball p r) := by
  have hsmall (rho : ℝ) (hrho : 0 < rho) (hrhor : rho < r) :
      ENNReal.ofReal (kappa * rho ^ 3) ≤
        calibratedMetricVolume (G.limit.flow.metric t) ((G.limit.flow.metric t).ball p r) := by
    have hv := ge_of_tendsto (G.tendsto_normalizedSourceBallVolume ht ht0 p hrho)
      (G.eventually_source_ball_volume_lower ht ht0 p hrho hrhor hr₀ hback hcurv hsource)
    rw [calibratedMetricVolume_eq_volumeMeasure] at hv ⊢
    exact hv.trans (measure_mono (fun _ hx =>
      hx.trans_le (ENNReal.ofReal_le_ofReal hrhor.le)))
  have hcontinuous : Continuous (fun rho : ℝ => ENNReal.ofReal (kappa * rho ^ 3)) :=
    ENNReal.continuous_ofReal.comp (continuous_const.mul (continuous_id.pow 3))
  apply le_of_tendsto (f := fun rho : ℝ => ENNReal.ofReal (kappa * rho ^ 3))
    (x := 𝓝[<] r) (hcontinuous.continuousAt.tendsto.mono_left nhdsWithin_le_nhds)
  filter_upwards [self_mem_nhdsWithin,
    (eventually_gt_nhds hr).filter_mono nhdsWithin_le_nhds] with rho hrhor hrho
  exact hsmall rho hrho hrhor

/-- The original fixed physical cutoff expands to every finite normalized
radius. Thus the long controls give all-scales noncollapse of the actual
convergent limit, also on finite backward time intervals. -/
theorem noncollapsed_of_longControls
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (G : GeneralizedBlowupConvergence S (blowupBackwardInterval T₀))
    {epsilon C kappa r₀ mu : ℝ}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀) :
    BlowupLimitNoncollapsed G.limit kappa := by
  let J : SpacetimeInterval :=
    ⟨blowupBackwardInterval T₀, G.limit.flow.interval, G.limit.flow.nontrivial⟩
  intro t ht p r hr hback hcurv
  apply G.ball_volume_lower_of_eventually_source_noncollapsed
    (J := J) ht ht.1 p hr H.radius_pos hback hcurv
  obtain ⟨T, hTnonneg, htT, hT₀⟩ := ENNReal.lt_iff_exists_real_btwn.mp ht.2
  have hT : 0 < T := ENNReal.ofReal_pos.mp (bot_le.trans_lt htT)
  have htT' : -T < t := by
    have h := (ENNReal.ofReal_lt_ofReal_iff hT).mp htT
    linarith
  filter_upwards [G.eventually_source_noncollapsed_of_longControls H hT hT₀
    (isCompact_singleton (x := p))] with k hk htk
  exact hk p (mem_singleton p) t ⟨htT', ht.1⟩ htk

/-- The accepted scale-bounded conclusion is a direct restriction of the
all-scales volume inequality. -/
theorem noncollapsedAtScale_of_longControls
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (G : GeneralizedBlowupConvergence S (blowupBackwardInterval T₀))
    {epsilon C kappa r₀ mu : ℝ}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀) :
    M30LimitNoncollapsedAtScale G.limit kappa r₀ := by
  intro t ht p r hr _ hback hcurv
  exact G.noncollapsed_of_longControls H t ht p r hr hback hcurv

end PoincareMT.GeneralizedBlowupConvergence
