import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Coordinates.EmbeddingBounds

/-!
# Reference metric jets of retained pointed embeddings

The actual M07 coordinate convergence bounds every spatial metric jet at an
interior reference time. The spatial maps are the stored source embeddings;
no replacement charts or convergence certificate are introduced.

Reference: Morgan--Tian, Proposition 5.14, pp. 90--91.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 800000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.PointedGeometricConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space
attribute [local instance] normedAddCommGroupTangentSpaceVectorSpace
  normedSpaceTangentSpaceVectorSpace

variable {T' T : ℝ} {S : PointedFlowSequence 3 T' T}
  (G : PointedGeometricConvergence S)

/-- The original spatial embedding at the selected reference time, composed
with one limit coordinate chart. -/
noncomputable def referenceChartMap (q : G.limitCarrier.carrier) (k : ℕ) (τ : ℝ) :
    EuclideanSpace ℝ (Fin 3) → (S.carrier (G.subsequence k)).carrier :=
  (fun y => ((G.embedding k).toFun (τ, y)).2) ∘ (extChartAt (𝓡 3) q).symm

theorem referenceChartMap_contMDiffAt
    (q : G.limitCarrier.carrier) (k : ℕ) {τ : ℝ} (hτ : τ ∈ Ioo T' T)
    {x : EuclideanSpace ℝ (Fin 3)} (hx : x ∈ (extChartAt (𝓡 3) q).target)
    (hxe : (extChartAt (𝓡 3) q).symm x ∈ G.exhaustion k) :
    ContMDiffAt (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap q k τ) x := by
  have hc := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q hx).contMDiffAt
    (extChartAt_target_mem_nhds' hx)
  exact ((G.embedding k).spatialMap_contMDiffAt (G.exhaustion_open k) hτ hxe).comp x hc

theorem referenceChartMap_mfderiv_isInvertible
    (q : G.limitCarrier.carrier) (k : ℕ) {τ : ℝ} (hτ : τ ∈ Ioo T' T)
    {x : EuclideanSpace ℝ (Fin 3)} (hx : x ∈ (extChartAt (𝓡 3) q).target)
    (hxe : (extChartAt (𝓡 3) q).symm x ∈ G.exhaustion k) :
    (mfderiv (𝓡 3) (𝓡 3) (G.referenceChartMap q k τ) x).IsInvertible := by
  have hc := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q hx).contMDiffAt
    (extChartAt_target_mem_nhds' hx)
  have he := (G.embedding k).spatialMap_contMDiffAt (G.exhaustion_open k) hτ hxe
  have hi : (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm x).IsInvertible := by
    simpa only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] using
      isInvertible_mfderivWithin_extChartAt_symm hx
  have hbij : Function.Bijective (mfderiv (𝓡 3) (𝓡 3) (G.referenceChartMap q k τ) x) := by
    unfold referenceChartMap
    rw [mfderiv_comp x (he.mdifferentiableAt (by simp)) (hc.mdifferentiableAt (by simp))]
    exact ((G.embedding k).spatialMap_mfderiv_bijective (G.exhaustion_open k) hτ hxe).comp
      hi.bijective
  let : FiniteDimensional ℝ (TangentSpace (𝓡 3) x) := by
    unfold TangentSpace
    infer_instance
  let : FiniteDimensional ℝ (TangentSpace (𝓡 3) (G.referenceChartMap q k τ x)) := by
    unfold TangentSpace
    infer_instance
  exact ⟨(LinearEquiv.ofBijective
    (mfderiv (𝓡 3) (𝓡 3) (G.referenceChartMap q k τ) x).toLinearMap hbij).toContinuousLinearEquiv,
    rfl⟩

theorem coordinateCoefficient_eq_referenceChartMetric
    (q : G.limitCarrier.carrier) (k : ℕ) {τ : ℝ} (hτ : τ ∈ Ioo T' T)
    {x : EuclideanSpace ℝ (Fin 3)} (hx : x ∈ (extChartAt (𝓡 3) q).target)
    (hxe : (extChartAt (𝓡 3) q).symm x ∈ G.exhaustion k) (a b : Fin 3) :
    G.limitCarrier.coordinateCoefficient q
      (pullbackInnerValue G.limitFlow (S.flow (G.subsequence k)) (G.embedding k)) a b (τ, x) =
    ((S.flow (G.subsequence k)).flow.metric τ).pullbackCoefficients
      (G.referenceChartMap q k τ) x
      (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b) := by
  have hc := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q hx).contMDiffAt
    (extChartAt_target_mem_nhds' hx)
  have he := (G.embedding k).spatialMap_contMDiffAt (G.exhaustion_open k) hτ hxe
  have hd := mfderiv_comp x (he.mdifferentiableAt (by simp)) (hc.mdifferentiableAt (by simp))
  change ((S.flow (G.subsequence k)).flow.metric τ).inner
    ((G.embedding k).toFun (τ, (extChartAt (𝓡 3) q).symm x)).2
    (mfderiv (𝓡 3) (𝓡 3) (fun y => ((G.embedding k).toFun (τ, y)).2)
      ((extChartAt (𝓡 3) q).symm x)
      (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm x
        (EuclideanSpace.basisFun (Fin 3) ℝ a)))
    (mfderiv (𝓡 3) (𝓡 3) (fun y => ((G.embedding k).toFun (τ, y)).2)
      ((extChartAt (𝓡 3) q).symm x)
      (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm x
        (EuclideanSpace.basisFun (Fin 3) ℝ b))) = _
  unfold RiemannianMetric.pullbackCoefficients referenceChartMap
  erw [hd]
  rfl

/-- The reference-time spatial metric jets are uniformly bounded on each
compact coordinate set along the exact M07 source subsequence. -/
theorem exists_eventually_reference_metric_jet_bound
    (q : G.limitCarrier.carrier) {τ : ℝ} (hτ : τ ∈ Ioo T' T)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ᶠ k : ℕ in atTop, ∀ x ∈ K,
      ‖iteratedFDeriv ℝ m
        (((S.flow (G.subsequence k)).flow.metric τ).pullbackCoefficients
          (G.referenceChartMap q k τ)) x‖ ≤ B := by
  let f := fun k a b (x : EuclideanSpace ℝ (Fin 3)) =>
    G.limitCarrier.coordinateCoefficient q
      (pullbackInnerValue G.limitFlow (S.flow (G.subsequence k)) (G.embedding k)) a b (τ, x)
  let g := fun a b (x : EuclideanSpace ℝ (Fin 3)) =>
    G.limitCarrier.coordinateCoefficient q
      (fun t y v w => G.limitCarrier.metricInner (G.limitFlow.metricAt t) y v w) a b (τ, x)
  have hconv (a b : Fin 3) : TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m (f k a b)) (iteratedFDeriv ℝ m (g a b)) atTop K :=
    G.tendstoUniformlyOn_coordinate_spatial_metricJet q m a b τ hτ K hK hKc
  have hdiff (a b : Fin 3) (x : EuclideanSpace ℝ (Fin 3)) (hx : x ∈ K) :
      ContDiffAt ℝ ∞ (g a b) x :=
    (G.limitFlow.contDiffAt_coordinateCoefficient_metric q a b (τ, x) hτ (hKc hx)).comp x
      (contDiffAt_const.prodMk contDiffAt_id)
  have hcomponent (a b : Fin 3) : ∃ B : ℝ, 0 ≤ B ∧ ∀ᶠ k : ℕ in atTop,
      ∀ x ∈ K, ‖iteratedFDeriv ℝ m (f k a b) x‖ ≤ B := by
    obtain ⟨B, hB⟩ := hK.exists_bound_of_continuousOn
      (fun x hx => ((hdiff a b x hx).continuousAt_iteratedFDeriv
        (by exact_mod_cast le_top : (m : ℕ∞ω) ≤ ∞)).continuousWithinAt)
    refine ⟨max (B + 1) 0, le_max_right _ _, ?_⟩
    filter_upwards [Metric.tendstoUniformlyOn_iff.mp (hconv a b) 1 zero_lt_one]
      with k hk x hx
    apply le_trans _ (le_max_left (B + 1) 0)
    exact (norm_le_norm_add_norm_sub (iteratedFDeriv ℝ m (g a b) x)
      (iteratedFDeriv ℝ m (f k a b) x)).trans
        (add_le_add (hB x hx) (by simpa only [dist_eq_norm] using (hk x hx).le))
  choose B hB hbound using hcomponent
  let C := ∑ a : Fin 3, ∑ b : Fin 3, B a b
  have hC : 0 ≤ C := Finset.sum_nonneg fun a _ => Finset.sum_nonneg fun b _ => hB a b
  have hBC (a b : Fin 3) : B a b ≤ C := by
    apply (Finset.single_le_sum (fun b _ => hB a b) (Finset.mem_univ b)).trans
    exact Finset.single_le_sum (fun a _ => Finset.sum_nonneg fun b _ => hB a b)
      (Finset.mem_univ a)
  obtain ⟨D, hD, hnorm⟩ := NormalizedKappaSolutionSequence.exists_bilinear_jet_norm_le_components
    (EuclideanSpace ℝ (Fin 3)) m
  have hc : ContinuousOn (extChartAt (𝓡 3) q).symm K :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset (hK.image_of_continuousOn hc)
  refine ⟨D * C, mul_nonneg hD.le hC, ?_⟩
  filter_upwards [Filter.eventually_all.mpr (fun a => Filter.eventually_all.mpr (hbound a)),
    eventually_ge_atTop j] with k hk hjk x hx
  let A := ((S.flow (G.subsequence k)).flow.metric τ).pullbackCoefficients
    (G.referenceChartMap q k τ)
  have hxe := G.exhaustion_monotone hjk (hj (mem_image_of_mem _ hx))
  have hA : ContDiffAt ℝ ∞ A x :=
    ((S.flow (G.subsequence k)).flow.metric τ).contDiffAt_pullbackCoefficients
      (G.referenceChartMap_contMDiffAt q k hτ (hKc hx) hxe)
  apply hnorm _ C hC
  intro a b
  have heq : f k a b =ᶠ[𝓝 x] (NormalizedKappaSolutionSequence.coefficientEval a b ∘ A) := by
    have hcx := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q (hKc hx)).contMDiffAt
      (extChartAt_target_mem_nhds' (hKc hx))
    filter_upwards [extChartAt_target_mem_nhds' (hKc hx),
      hcx.continuousAt.preimage_mem_nhds ((G.exhaustion_open k).mem_nhds hxe)]
      with y hy hye
    exact G.coordinateCoefficient_eq_referenceChartMetric q k hτ hy hye a b
  have hderiv := (heq.iteratedFDeriv ℝ m).self_of_nhds
  rw [(NormalizedKappaSolutionSequence.coefficientEval a b).iteratedFDeriv_comp_left hA
    (by exact_mod_cast le_top : (m : ℕ∞ω) ≤ ∞)] at hderiv
  exact (hderiv ▸ hk a b x hx).trans (hBC a b)

/-- Interior metric convergence supplies a positive lower ellipticity bound
for the same reference charts, with constants uniform in the source index. -/
theorem exists_eventually_reference_ellipticity
    (q : G.limitCarrier.carrier) {τ : ℝ} (hτ : τ ∈ Ioo T' T)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) :
    ∃ a b : ℝ, 0 < a ∧ 0 < b ∧ ∀ᶠ k : ℕ in atTop, ∀ x ∈ K, ∀ v,
      a * ‖v‖ ^ 2 ≤ ((S.flow (G.subsequence k)).flow.metric τ).pullbackCoefficients
          (G.referenceChartMap q k τ) x v v ∧
      ((S.flow (G.subsequence k)).flow.metric τ).pullbackCoefficients
          (G.referenceChartMap q k τ) x v v ≤ b * ‖v‖ ^ 2 := by
  let c := extChartAt (𝓡 3) q
  let B := (G.limitFlow.metricAt τ).pullbackCoefficients c.symm
  have hcDiff (x : EuclideanSpace ℝ (Fin 3)) (hx : x ∈ K) :
      ContMDiffAt (𝓡 3) (𝓡 3) ∞ c.symm x :=
    (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q (hKc hx)).contMDiffAt
      (extChartAt_target_mem_nhds' (hKc hx))
  have hB : ContinuousOn B K := fun x hx =>
    ((G.limitFlow.metricAt τ).contDiffAt_pullbackCoefficients
      (hcDiff x hx)).continuousAt.continuousWithinAt
  have hpos : ∀ x ∈ K, ∀ v : EuclideanSpace ℝ (Fin 3), v ≠ 0 → 0 < B x v v := by
    intro x hx v hv
    apply (G.limitFlow.metricAt τ).pos
    have hi : (mfderiv (𝓡 3) (𝓡 3) c.symm x).IsInvertible := by
      simpa only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] using
        isInvertible_mfderivWithin_extChartAt_symm (hKc hx)
    intro hz
    apply hv
    apply hi.injective
    rw [map_zero]
    convert! hz using 1
  obtain ⟨α, hα, hlower⟩ := exists_uniform_bilinear_family_lower_bound hK hB hpos
  obtain ⟨β, hβ⟩ := hK.exists_bound_of_continuousOn hB
  have hc : ContinuousOn c.symm K :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  have himage := hK.image_of_continuousOn hc
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset himage
  refine ⟨α / 2, 2 * max β 1, by positivity,
    mul_pos (by norm_num) (lt_max_of_lt_right zero_lt_one), ?_⟩
  filter_upwards [G.eventually_pullback_inner_bounds himage hτ
      (by norm_num : (0 : ℝ) < 1 / 2), eventually_ge_atTop j] with k hk hjk x hx v
  let w := mfderiv (𝓡 3) (𝓡 3) c.symm x v
  have hcomparison := hk (c.symm x) (mem_image_of_mem _ hx) w
  have he := (G.embedding k).spatialMap_contMDiffAt (G.exhaustion_open k) hτ
    (G.exhaustion_monotone hjk (hj (mem_image_of_mem _ hx)))
  have hd := mfderiv_comp x (he.mdifferentiableAt (by simp))
    ((hcDiff x hx).mdifferentiableAt (by simp))
  have heq : pullbackInnerValue G.limitFlow _ (G.embedding k) τ (c.symm x) w w =
      ((S.flow (G.subsequence k)).flow.metric τ).pullbackCoefficients
        (G.referenceChartMap q k τ) x v v := by
    unfold pullbackInnerValue RiemannianMetric.pullbackCoefficients referenceChartMap
    erw [hd]
    rfl
  have href : G.limitCarrier.metricInner (G.limitFlow.metricAt τ) (c.symm x) w w =
      B x v v := rfl
  rw [heq, href] at hcomparison
  have hupper : B x v v ≤ max β 1 * ‖v‖ ^ 2 := by
    apply (le_abs_self _).trans
    calc
      |B x v v| ≤ ‖B x‖ * (‖v‖ * ‖v‖) := by
        simpa only [Real.norm_eq_abs, mul_assoc] using (B x).le_opNorm₂ v v
      _ ≤ max β 1 * ‖v‖ ^ 2 := by
        simpa only [pow_two] using mul_le_mul_of_nonneg_right
          ((hβ x hx).trans (le_max_left β 1)) (mul_nonneg (norm_nonneg v) (norm_nonneg v))
  have hnonneg : 0 ≤ B x v v := le_trans (by positivity) (hlower x hx v)
  constructor
  · nlinarith [hlower x hx v]
  · nlinarith

end PoincareMT.PointedGeometricConvergence
