import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.DenseSelection
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.TimeJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.ControlledCylinder

/-!
# Dense canonical times preserving actual normalized metric jets

Each good whole slice is chosen only after the finite compact chart family
and derivative order are fixed. Joint metric smoothness makes the errors
smaller than the prescribed vanishing tolerance, without a uniform source
time modulus or a canonical certificate at the terminal time.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12

open Set Filter Metric
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

open ControlledBlowupCylinder

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem exists_canonical_times_preserving_cylinder_metric_jets
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (sigma : ℕ → ℕ) (A T B eta : ℕ → ℝ) (hT : ∀ k, 0 < T k)
    (cyl : ∀ k, ControlledBlowupCylinder S (sigma k) (A k) (T k) (B k) (eta k))
    (n m : ℕ → ℕ) (U K : ∀ k, Fin (n k) → Set E)
    (hU : ∀ k i, IsOpen (U k i)) (hK : ∀ k i, IsCompact (K k i))
    (hKU : ∀ k i, K k i ⊆ U k i)
    (e : ∀ k, Fin (n k) → E → sourceBall S (sigma k) (A k))
    (he : ∀ k i, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k i) (U k i)) :
    ∃ s : ℕ → ℝ, Tendsto s atTop (𝓝 0) ∧
      ∀ k, s k ∈ Icc (-(T k)) 0 ∧
        (S.base (sigma k)).1 + s k / S.scale (sigma k) ∈ (S.flow (sigma k)).interval ∧
        generalizedSliceStrongCanonicalNeighborhoods (S.flow (sigma k)) epsilon C
          (4 * S.scale (sigma k))
          ((S.base (sigma k)).1 + s k / S.scale (sigma k)) ∧
        ∀ i j, j ≤ m k → ∀ x ∈ K k i,
          ‖iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric (s k)
              |>.pullbackCoefficients (e k i)) x -
            iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric 0
              |>.pullbackCoefficients (e k i)) x‖ ≤ ((k : ℝ) + 1)⁻¹ := by
  let P := fun k s => ∀ i j, j ≤ m k → ∀ x ∈ K k i,
    ‖iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric s
        |>.pullbackCoefficients (e k i)) x -
      iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric 0
        |>.pullbackCoefficients (e k i)) x‖ ≤ ((k : ℝ) + 1)⁻¹
  have hP (k : ℕ) : ∀ᶠ s in 𝓝[Icc (-(T k)) 0] 0, P k s := by
    have hsingle (i : Fin (n k)) (j : ℕ) :
        ∀ᶠ s in 𝓝[Icc (-(T k)) 0] 0, ∀ x ∈ K k i,
          ‖iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric s
              |>.pullbackCoefficients (e k i)) x -
            iteratedFDeriv ℝ j (((cyl k).ordinaryFlow (hT k)).metric 0
              |>.pullbackCoefficients (e k i)) x‖ ≤ ((k : ℝ) + 1)⁻¹ := by
      have hh := ((cyl k).ordinaryFlow (hT k)).tendstoUniformlyOn_spatialMetricJets_at_terminal
        (hT k) (hU k i) (hK k i) (hKU k i) (e k i) (he k i) j
      filter_upwards [Metric.tendstoUniformlyOn_iff.mp hh (((k : ℝ) + 1)⁻¹)
        (by positivity)] with s hs x hx
      simpa only [dist_eq_norm, norm_sub_rev] using (hs x hx).le
    have hall := (eventually_all_finite (finite_univ : (univ : Set (Fin (n k))).Finite)).mpr
      (fun i _ => (eventually_all_finite (finite_Iic (m k))).mpr (fun j _ => hsingle i j))
    exact hall.mono fun s hs i j hj => hs i (mem_univ i) j hj
  obtain ⟨s, hs, hselect⟩ := H.exists_canonical_times_preserving_terminal_properties
    sigma T hT P hP
  exact ⟨s, hs, fun k => ⟨(hselect k).1, (hselect k).2.2.2.1,
    (hselect k).2.2.2.2, (hselect k).2.2.1⟩⟩

end PoincareMT.M30CommonBlowupControls
