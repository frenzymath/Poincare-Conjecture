import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.ClosedJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.FlowRealization
import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Coordinates.TerminalPositivity

/-!
# Local backward limits retaining the prescribed terminal metric

Uniform closed-slab jets of actual source flows produce a local Ricci flow.
Convergence of the terminal tensors identifies its terminal metric without
requiring a previously constructed interior limit.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8
set_option maxHeartbeats 800000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledTerminal

private theorem exists_closed_smooth_subsequence_of_eventual_bounds
    {X Y : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X] [FiniteDimensional ℝ X]
    [NormedAddCommGroup Y] [NormedSpace ℝ Y] [FiniteDimensional ℝ Y]
    {Ω : Set X} (hΩ : IsCompact Ω) (hconvex : Convex ℝ Ω)
    (hne : (interior Ω).Nonempty) (f : ℕ → X → Y)
    (hf : ∀ k, ContDiffOn ℝ ∞ (f k) Ω)
    (hbound : ∀ m : ℕ, ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ x ∈ Ω, ‖iteratedFDerivWithin ℝ m (f k) Ω x‖ ≤ C) :
    ∃ sigma : ℕ → ℕ, StrictMono sigma ∧ ∃ F : X → Y, ContDiffOn ℝ ∞ F Ω ∧
      ∀ m, TendstoUniformlyOn (fun k => iteratedFDerivWithin ℝ m (f (sigma k)) Ω)
        (iteratedFDerivWithin ℝ m F Ω) atTop Ω := by
  classical
  have hunique := uniqueDiffOn_convex hconvex hne
  have hall (m : ℕ) : ∃ C : ℝ, 0 ≤ C ∧ ∀ k x, x ∈ Ω →
      ‖iteratedFDerivWithin ℝ m (f k) Ω x‖ ≤ C := by
    obtain ⟨C, hC, hevent⟩ := hbound m
    obtain ⟨N, hN⟩ := eventually_atTop.mp hevent
    have hfinite (k : Fin N) : ∃ B : ℝ, ∀ x ∈ Ω,
        ‖iteratedFDerivWithin ℝ m (f k) Ω x‖ ≤ B :=
      hΩ.exists_bound_of_continuousOn ((hf k).continuousOn_iteratedFDerivWithin
        (WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤)) hunique)
    choose B hB using hfinite
    let D := ∑ k : Fin N, max (B k) 0
    refine ⟨max C D, le_max_of_le_left hC, ?_⟩
    intro k x hx
    by_cases hk : N ≤ k
    · exact (hN k hk x hx).trans (le_max_left C D)
    · have hkN : k < N := lt_of_not_ge hk
      have hBD : B ⟨k, hkN⟩ ≤ D :=
        (le_max_left (B ⟨k, hkN⟩) 0).trans
          (Finset.single_le_sum (fun i _ => le_max_right (B i) 0)
            (Finset.mem_univ (⟨k, hkN⟩ : Fin N)))
      exact (hB ⟨k, hkN⟩ x hx).trans (hBD.trans (le_max_right C D))
  obtain ⟨sigma, hsigma, F, hF, hjets⟩ :=
    Poincare.AncientVolume.exists_smooth_subsequence_on_closed_convex
      hΩ.isClosed hconvex hne f hf (fun K _ hK m => by
        obtain ⟨C, hC, hboundC⟩ := hall m
        exact ⟨C, hC, fun k x hx => hboundC k x (hK hx)⟩)
  exact ⟨sigma, hsigma, F, hF, fun m => hjets m Ω hΩ Subset.rfl⟩

/-- Smooth controlled local source flows converge along a subsequence to an
actual flow with the prescribed terminal tensor. -/
theorem exists_local_flow_with_terminal_metric
    {n : ℕ} {a b : ℝ} (hab : a < b)
    {x₀ : EuclideanSpace ℝ (Fin n)} {rho : ℝ} (hrho : 0 < rho)
    (U : Opens (EuclideanSpace ℝ (Fin n)))
    (hU : (U : Set (EuclideanSpace ℝ (Fin n))) ⊆ ball x₀ rho)
    (Fseq : ℕ → RicciFlow n U (Icc a b))
    (Bseq : ℕ → ℝ × EuclideanSpace ℝ (Fin n) →
      EuclideanSpace ℝ (Fin n) →L[ℝ] EuclideanSpace ℝ (Fin n) →L[ℝ] ℝ)
    (hseq : ∀ k, ContDiffOn ℝ ∞ (Bseq k) (Icc a b ×ˢ closedBall x₀ rho))
    (hcoeff : ∀ k t, t ∈ Icc a b → ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
      ((Fseq k).metric t).inner x v w = Bseq k (t, x) v w)
    (hbound : ∀ m : ℕ, ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ z ∈ Icc a b ×ˢ closedBall x₀ rho,
        ‖iteratedFDerivWithin ℝ m (Bseq k) (Icc a b ×ˢ closedBall x₀ rho) z‖ ≤ C)
    {alpha : ℝ} (halpha : 0 < alpha)
    (hlower : ∀ᶠ k in atTop, ∀ t ∈ Icc a b, ∀ x ∈ U, ∀ v,
      alpha * ‖v‖ ^ 2 ≤ Bseq k (t, x) v v)
    (g : RiemannianMetric n U)
    (hterminal : ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
      Tendsto (fun k => ((Fseq k).metric b).inner x v w) atTop (𝓝 (g.inner x v w))) :
    ∃ sigma : ℕ → ℕ, StrictMono sigma ∧
      ∃ (B : ℝ × EuclideanSpace ℝ (Fin n) →
        EuclideanSpace ℝ (Fin n) →L[ℝ] EuclideanSpace ℝ (Fin n) →L[ℝ] ℝ)
        (F : RicciFlow n U (Icc a b)),
        ContDiffOn ℝ ∞ B (Icc a b ×ˢ closedBall x₀ rho) ∧
        (∀ t ∈ Icc a b, ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
          (F.metric t).inner x v w = B (t, x) v w) ∧
        (∀ (x : U) (v w : TangentSpace (𝓡 n) x),
          (F.metric b).inner x v w = g.inner x v w) ∧
        ∀ m, TendstoUniformlyOn
          (fun k => iteratedFDerivWithin ℝ m (Bseq (sigma k)) (Icc a b ×ˢ closedBall x₀ rho))
          (iteratedFDerivWithin ℝ m B (Icc a b ×ˢ closedBall x₀ rho))
          atTop (Icc a b ×ˢ closedBall x₀ rho) := by
  let E := EuclideanSpace ℝ (Fin n)
  let Ω := Icc a b ×ˢ closedBall x₀ rho
  have hΩ : IsCompact Ω := isCompact_Icc.prod (isCompact_closedBall x₀ rho)
  have hne : (interior Ω).Nonempty := by
    rw [interior_prod_eq, interior_Icc, interior_closedBall _ hrho.ne']
    exact ⟨((a + b) / 2, x₀), ⟨by constructor <;> linarith, mem_ball_self hrho⟩⟩
  obtain ⟨sigma, hsigma, B, hB, hjets⟩ :=
    exists_closed_smooth_subsequence_of_eventual_bounds hΩ
      ((convex_Icc a b).prod (convex_closedBall x₀ rho)) hne Bseq hseq hbound
  have hpoint (z : ℝ × E) (hz : z ∈ Ω) :
      Tendsto (fun k => Bseq (sigma k) z) atTop (𝓝 (B z)) := by
    exact AncientCompactness.tendsto_of_compact_zero_jets
      (fun k => Bseq (sigma k)) B Ω (fun K _ hK => (hjets 0).mono hK) hz
  have heval (z : ℝ × E) (hz : z ∈ Ω) (v w : E) :
      Tendsto (fun k => Bseq (sigma k) z v w) atTop (𝓝 (B z v w)) :=
    ((ContinuousLinearMap.apply ℝ ℝ w).continuous.tendsto _).comp
      (((ContinuousLinearMap.apply ℝ (E →L[ℝ] ℝ) v).continuous.tendsto _).comp (hpoint z hz))
  have hsymm : ∀ t ∈ Icc a b, ∀ x ∈ U, ∀ v w, B (t, x) v w = B (t, x) w v := by
    intro t ht x hx v w
    have hz : (t, x) ∈ Ω := ⟨ht, ball_subset_closedBall (hU hx)⟩
    apply tendsto_nhds_unique (heval (t, x) hz v w)
    apply (heval (t, x) hz w v).congr
    intro k
    rw [← hcoeff (sigma k) t ht ⟨x, hx⟩, ← hcoeff (sigma k) t ht ⟨x, hx⟩]
    exact ((Fseq (sigma k)).metric t).symm _ _ _
  have hell : ∀ t ∈ Icc a b, ∀ x ∈ U, ∃ c : ℝ, 0 < c ∧
      ∀ v, c * ‖v‖ ^ 2 ≤ B (t, x) v v := by
    intro t ht x hx
    refine ⟨alpha, halpha, fun v => ?_⟩
    apply ge_of_tendsto (heval (t, x) ⟨ht, ball_subset_closedBall (hU hx)⟩ v v)
    exact (hsigma.tendsto_atTop.eventually hlower).mono fun k hk => hk t ht x hx v
  obtain ⟨F, hF⟩ := ControlledConvergence.exists_flow_of_closed_slab_coefficients
    hab hrho U hU (fun k => Fseq (sigma k)) (fun k => Bseq (sigma k)) B
    (fun k => hseq (sigma k)) hB (fun k => hcoeff (sigma k)) hsymm hell hjets
  refine ⟨sigma, hsigma, B, F, hB, hF, ?_, hjets⟩
  intro x v w
  have hb : b ∈ Icc a b := ⟨hab.le, le_rfl⟩
  rw [hF b hb]
  have hlim := (hterminal x v w).comp hsigma.tendsto_atTop
  have hlim' : Tendsto (fun k => Bseq (sigma k) (b, x) v w) atTop (𝓝 (g.inner x v w)) := by
    simpa only [hcoeff _ b hb x v w, Function.comp_def] using hlim
  exact tendsto_nhds_unique (heval (b, x) ⟨hb, ball_subset_closedBall (hU x.property)⟩ v w) hlim'

end PoincareMT.ControlledTerminal
