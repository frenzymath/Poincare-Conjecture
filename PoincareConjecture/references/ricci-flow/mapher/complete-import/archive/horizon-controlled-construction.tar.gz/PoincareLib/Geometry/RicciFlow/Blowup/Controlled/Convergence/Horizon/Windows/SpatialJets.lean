import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.ReferenceDerivatives
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.Ellipticity

/-! # Spatial metric jets in retained charts on longer past windows -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

/-- The retained spatial maps have bounded metric jets on every strictly
smaller controlled past window, with constants independent of its source index. -/
theorem exists_eventually_reference_window_spatial_jet_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    {U V D : ℝ} (hTV : T / 2 ≤ V) (hVU : V < U) (hD : 0 ≤ D)
    (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ eta' : ℝ, ∀ d : ControlledBlowupCylinder S (idx (G.subsequence k))
        (A (G.subsequence k)) U D eta',
      ∀ s ∈ Icc (-V) 0, ∀ x ∈ K, ∀ j ≤ m,
        ‖iteratedFDeriv ℝ j
          (((d.smallFlow (hA _) (by linarith)).metric s).pullbackCoefficients
            (G.referenceChartMap q k 0)) x‖ ≤ C := by
  have hzero : -T / 2 < 0 ∧ 0 < T / 2 := ⟨by linarith, by linarith⟩
  have hV : 0 ≤ V := by linarith
  have hU : 0 < U := by linarith
  obtain ⟨α, β, hα, hβ, hell⟩ := exists_eventually_reference_window_ellipticity
    G hTV hVU.le hD q hK hKc
  choose R hR hcurv using fun j => exists_eventually_reference_window_curvatureDerivative_bound
    G P04 hAr hcompact hcomplete hV hVU hD q hK hKc j
  choose Z hZ hreference using fun j =>
    G.exists_eventually_reference_metric_jet_bound q hzero hK hKc j
  obtain ⟨C, hC, hbound⟩ := SpacetimeBounds.exists_chart_spatial_jet_bound_on_closed_interval
    3 m R Z (fun j => (hR j).le) (l := -V) (r := 0) (by linarith) hα hβ.le
  have hc : ContinuousOn (extChartAt (𝓡 3) q).symm K :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨j₀, hj₀⟩ := G.exists_exhaustion_superset (hK.image_of_continuousOn hc)
  refine ⟨C, hC, ?_⟩
  filter_upwards [hell, eventually_ge_atTop j₀,
    (eventually_all_finite (Set.finite_Iic m)).mpr (fun j _ => hcurv j),
    (eventually_all_finite (Set.finite_Iic m)).mpr (fun j _ => hreference j)]
    with k hellk hstage hcurvk href eta' d
  let F := d.smallFlow (hA _) hU
  let W := (extChartAt (𝓡 3) q).target ∩
    (extChartAt (𝓡 3) q).symm ⁻¹' G.exhaustion k
  have hW : IsOpen W :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
      (isOpen_extChartAt_target q) (G.exhaustion_open k)
  have he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap q k 0) W :=
    fun x hx => (G.referenceChartMap_contMDiffAt q k hzero hx.1 hx.2).contMDiffWithinAt
  have hi : ∀ x ∈ W, (mfderiv (𝓡 3) (𝓡 3) (G.referenceChartMap q k 0) x).IsInvertible :=
    fun x hx => G.referenceChartMap_mfderiv_isInvertible q k hzero hx.1 hx.2
  apply hbound F (fun t ht => ⟨by linarith [ht.1], ht.2⟩) hW he hi K
    (fun x hx => ⟨hKc hx, G.exhaustion_monotone hstage (hj₀ (mem_image_of_mem _ hx))⟩)
    (hellk eta' d) (fun j hj => hcurvk j hj eta' d)
    (show -T / 2 ∈ Icc (-V) 0 from ⟨by linarith, by linarith⟩)
  intro j hj x hx
  have hr := href j hj x hx
  change ‖iteratedFDeriv ℝ j
    ((((e (G.subsequence k)).smallFlow (hA _) hT).metric (0 + (-T / 2))).pullbackCoefficients
      (G.referenceChartMap q k 0)) x‖ ≤ Z j at hr
  rw [zero_add, (e (G.subsequence k)).smallFlow_metric_eq_on_common_time d (hA _) hT hU
    (-T / 2) ⟨by linarith, by linarith⟩ ⟨by linarith, by linarith⟩] at hr
  exact hr

end PoincareMT.ControlledBlowupCompactness
