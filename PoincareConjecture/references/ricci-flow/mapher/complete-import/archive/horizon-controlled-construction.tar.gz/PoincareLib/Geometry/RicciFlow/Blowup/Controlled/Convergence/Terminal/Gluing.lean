import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Terminal.Gluing

/-!
# Descent of chart flows across dense time extensions

Local Ricci flows extending an interior flow agree on chart overlaps by
continuity, including every added boundary time.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.RicciFlow

/-- Chart flows on a dense enlargement of the time domain descend to the
original manifold, retaining the interior metric exactly. -/
theorem exists_extension_of_covering_chart_flows
    {n : ℕ} {ι : Type*} [Nonempty ι] {U : ι → Type*} {M : Type*}
    [∀ i, TopologicalSpace (U i)] [TopologicalSpace M]
    [∀ i, ChartedSpace (EuclideanSpace ℝ (Fin n)) (U i)]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M]
    [∀ i, IsManifold (𝓡 n) ∞ (U i)] [IsManifold (𝓡 n) ∞ M]
    {J K : Set ℝ} (hJK : J ⊆ K) (hdense : K ⊆ closure J)
    (F : RicciFlow n M J) (Fchart : ∀ i, RicciFlow n (U i) K)
    (q : ∀ i, U i → M)
    (hq : ∀ i, IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (q i))
    (hcover : ∀ y, ∃ i x, q i x = y)
    (hinterior : ∀ t ∈ J, ∀ i (x : U i) (a b : TangentSpace (𝓡 n) x),
      ((Fchart i).metric t).inner x a b = (F.metric t).inner (q i x)
        (mfderiv (𝓡 n) (𝓡 n) (q i) x a)
        (mfderiv (𝓡 n) (𝓡 n) (q i) x b)) :
    ∃ G : RicciFlow n M K,
      (∀ t ∈ J, G.metric t = F.metric t) ∧
      ∀ t ∈ K, ∀ i (x : U i) (a b : TangentSpace (𝓡 n) x),
        ((Fchart i).metric t).inner x a b = (G.metric t).inner (q i x)
          (mfderiv (𝓡 n) (𝓡 n) (q i) x a)
          (mfderiv (𝓡 n) (𝓡 n) (q i) x b) := by
  classical
  have hinv (t : ℝ) (ht : t ∈ K) (i j : ι) (x : U i) (y : U j)
      (hxy : q i x = q j y)
      (a b : TangentSpace (𝓡 n) x) (c d : TangentSpace (𝓡 n) y)
      (ha : mfderiv (𝓡 n) (𝓡 n) (q i) x a = mfderiv (𝓡 n) (𝓡 n) (q j) y c)
      (hb : mfderiv (𝓡 n) (𝓡 n) (q i) x b = mfderiv (𝓡 n) (𝓡 n) (q j) y d) :
      ((Fchart i).metric t).inner x a b = ((Fchart j).metric t).inner y c d := by
    have hpast : EqOn (fun s => ((Fchart i).metric s).inner x a b)
        (fun s => ((Fchart j).metric s).inner y c d) J := by
      intro s hs
      dsimp only
      rw [hinterior s hs, hinterior s hs]
      have hform : ((F.metric s).inner (q i x) : EuclideanSpace ℝ (Fin n) →L[ℝ]
          EuclideanSpace ℝ (Fin n) →L[ℝ] ℝ) = (F.metric s).inner (q j y) :=
        congrArg (fun z : M => show EuclideanSpace ℝ (Fin n) →L[ℝ]
          EuclideanSpace ℝ (Fin n) →L[ℝ] ℝ from (F.metric s).inner z) hxy
      have hv : ((mfderiv (𝓡 n) (𝓡 n) (q i) x a,
          mfderiv (𝓡 n) (𝓡 n) (q i) x b) :
          EuclideanSpace ℝ (Fin n) × EuclideanSpace ℝ (Fin n)) =
          (mfderiv (𝓡 n) (𝓡 n) (q j) y c, mfderiv (𝓡 n) (𝓡 n) (q j) y d) :=
        Prod.ext ha hb
      exact congrArg₂ (fun (B : EuclideanSpace ℝ (Fin n) →L[ℝ]
        EuclideanSpace ℝ (Fin n) →L[ℝ] ℝ)
        (v : EuclideanSpace ℝ (Fin n) × EuclideanSpace ℝ (Fin n)) => B v.1 v.2) hform hv
    exact hpast.of_subset_closure
      (fun s hs => ((Fchart i).equation s hs x a b).continuousWithinAt)
      (fun s hs => ((Fchart j).equation s hs y c d).continuousWithinAt)
      hJK hdense ht
  obtain ⟨t₀, ht₀, _, _, _⟩ := (Fchart (Classical.arbitrary ι)).nontrivial
  let time (t : ℝ) := if t ∈ K then t else t₀
  have htime (t : ℝ) : time t ∈ K := by
    dsimp only [time]
    split_ifs with h
    · exact h
    · exact ht₀
  have hex (t : ℝ) := Poincare.Gluing.exists_unique_metric_of_covering_local_diffeomorphisms
    (fun i => (Fchart i).metric (time t)) q hq hcover (hinv (time t) (htime t))
  let g (t : ℝ) := Classical.choose (hex t)
  have hpres (t : ℝ) (ht : t ∈ K) (i : ι) (x : U i)
      (a b : TangentSpace (𝓡 n) x) :
      ((Fchart i).metric t).inner x a b = (g t).inner (q i x)
        (mfderiv (𝓡 n) (𝓡 n) (q i) x a) (mfderiv (𝓡 n) (𝓡 n) (q i) x b) := by
    have h := (Classical.choose_spec (hex t)).1 i x a b
    change ((Fchart i).metric (time t)).inner x a b = (g t).inner (q i x)
      (mfderiv (𝓡 n) (𝓡 n) (q i) x a) (mfderiv (𝓡 n) (𝓡 n) (q i) x b) at h
    rwa [show time t = t from if_pos ht] at h
  have heq (t : ℝ) (ht : t ∈ J) : g t = F.metric t := by
    symm
    apply (Classical.choose_spec (hex t)).2 (F.metric t)
    intro i x a b
    simpa only [time, if_pos (hJK ht)] using hinterior t ht i x a b
  have hsmooth : RiemannianMetric.IsSmoothFamilyOn g K :=
    Poincare.Gluing.isSmoothFamilyOn_of_local_diffeomorphisms
      (fun i => (Fchart i).metric) g (fun i => (Fchart i).smooth) q hq hcover hpres
  obtain ⟨G, hG⟩ := exists_of_covering_local_diffeomorphisms Fchart g hsmooth
    t₀ (g t₀).leviCivitaData q hq hcover hpres
  exact ⟨G, by simpa only [hG] using heq, by simpa only [hG] using hpres⟩

end PoincareMT.RicciFlow
