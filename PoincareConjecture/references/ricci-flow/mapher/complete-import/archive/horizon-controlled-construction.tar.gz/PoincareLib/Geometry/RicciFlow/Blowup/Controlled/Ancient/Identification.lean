import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Data
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Ancient.Nonflatness

/-!
# Infinite-horizon controlled limits as ancient kappa-solutions

The limit's terminal normalization and curvature bounds on compact time
intervals give nonflatness on every earlier slice. All-scales noncollapsing
then supplies the exact ancient identification with unchanged metric and
connection data.

Reference: Morgan--Tian, Theorems 11.1 and 11.8, pp. 267--278.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle ENNReal

universe u

namespace PoincareMT

/-- A normalized infinite-horizon limit with genuine all-scales
noncollapsing is an ancient kappa-solution on its actual carrier. -/
theorem BlowupLimitFlow.nonempty_m30AncientKappaIdentification
    (hC : RicciFlowCurvatureTheory.{u})
    (L : BlowupLimitFlow.{u} (blowupBackwardInterval ⊤))
    {kappa : ℝ} (hkappa : 0 < kappa) (hnoncollapsed : BlowupLimitNoncollapsed L kappa) :
    Nonempty (M30AncientKappaIdentification L kappa) := by
  let C := L.carrier
  letI : TopologicalSpace C.carrier := C.topologicalSpace
  letI : MeasurableSpace C.carrier := C.measurableSpace
  letI : BorelSpace C.carrier := C.borelSpace
  letI : ChartedSpace (EuclideanSpace ℝ (Fin 3)) C.carrier := C.chartedSpace
  letI : IsManifold (𝓡 3) ∞ C.carrier := C.isManifold
  letI : T2Space C.carrier := C.t2Space
  letI : T3Space C.carrier := C.t3Space
  letI : SecondCountableTopology C.carrier := C.secondCountable
  letI : ConnectedSpace C.carrier := L.connectedSpace
  have hdomain : blowupBackwardInterval ⊤ = Iic 0 := by
    ext t
    simp [blowupBackwardInterval]
  have hJ : Iic (0 : ℝ) ⊆ blowupBackwardInterval ⊤ := by rw [hdomain]
  let F : RicciFlow 3 C.carrier (Iic 0) :=
    Poincare.Geometry.RicciFlow.Harnack.restrictFlow L.flow hJ ordConnected_Iic
      ⟨-1, by norm_num, 0, by simp, by norm_num⟩
  have hcomplete : ∀ t ≤ 0, MetricComplete (F.metric t) :=
    fun t ht => L.complete t (hJ ht)
  have hoperator : ∀ t ≤ 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x :=
    fun t ht => L.nonnegative_curvature_operator t (hJ ht)
  have hslab : ∀ a < 0, ∃ K : ℝ, 0 ≤ K ∧
      ∀ t ∈ Icc a 0, ∀ x, (F.connection t).curvatureTensorNorm x ≤ K := by
    intro a _
    obtain ⟨K, hK, hbound⟩ := L.curvature_locally_bounded_in_time (Icc a 0)
      isCompact_Icc (fun _ ht => hJ ht.2)
    exact ⟨K, hK, fun t ht x => (le_abs_self _).trans (hbound t ht x)⟩
  have hnonflat : ∀ t ≤ 0, ∃ x, (F.connection t).curvatureTensorNorm x ≠ 0 := by
    apply F.nonflat_of_terminal_scalar_pos_of_locally_bounded_ancient hC
      hcomplete hoperator hslab
    refine ⟨L.base, ?_⟩
    change 0 < (L.flow.connection 0).scalarCurvature L.base
    rw [L.scalar_normalized]
    norm_num
  let K : AncientKappaSolution 3 C.carrier :=
    { flow := F
      kappa := kappa
      kappa_pos := hkappa
      complete := hcomplete
      nonnegative_curvature_operator := hoperator
      bounded_curvature := by
        intro t ht
        obtain ⟨B, hB, hbound⟩ := L.curvature_locally_bounded_in_time {t}
          isCompact_singleton (by simpa only [singleton_subset_iff] using hJ ht)
        exact ⟨B, hB, fun x => hbound t (mem_singleton t) x⟩
      nonflat := hnonflat
      noncollapsed := by
        intro r₀ _ t ht p r hr _ hcurv
        exact hnoncollapsed t (hJ ht) p r hr
          (fun s hs => hJ (hs.2.trans ht)) hcurv }
  exact ⟨{
    certificate := { solution := K, kappa_eq := rfl, metric_eq := fun _ _ => rfl }
    domain_eq := hdomain
    connection_eq := fun _ _ => HEq.rfl }⟩

end PoincareMT
