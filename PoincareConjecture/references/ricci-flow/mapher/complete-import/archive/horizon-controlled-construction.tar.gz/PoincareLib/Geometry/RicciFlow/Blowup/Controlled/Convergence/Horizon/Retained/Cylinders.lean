import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Limit.Construction
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.EmbeddingCoefficients
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.LiftedCoefficients

/-! # Actual retained cylinders for the expanding-horizon extraction -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))
  {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)

def horizonRetainedCylinder (k : ℕ) :
    GeneralizedFlowCylinder (S.flow (idx (G.subsequence (sigma k))))
      (liftedSliceCarrier.{u} G.limitCarrier)
      (S.base (idx (G.subsequence (sigma k)))).1 (S.scale (idx (G.subsequence (sigma k))))
      (Icc (-tau k) 0) (retainedSpace G (sigma k)) :=
  windowRetainedCylinder G (sigma k)
    (e (G.subsequence (sigma k)) k ((hsigma.id_le k).trans (G.subsequence_strictMono.id_le _)))

theorem horizonRetainedCylinder_base (k : ℕ) (hzero : (0 : ℝ) ∈ Icc (-tau k) 0) :
    (horizonRetainedCylinder G hsigma k).pointMap 0 hzero (ULift.up G.limitFlow.base) =
      S.base (idx (G.subsequence (sigma k))) :=
  windowRetainedCylinder_base G (sigma k) _ hzero

theorem horizonRetainedCylinder_eventually_covers_baseBall
    (hAr : Tendsto A atTop atTop)
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    {r : ℝ} (hr : 0 < r) :
    ∀ᶠ k in atTop, ∀ x ∈ S.baseBall (idx (G.subsequence (sigma k))) r,
      ∃ y ∈ retainedSpace G (sigma k), ∃ hzero,
        (horizonRetainedCylinder G hsigma k).pointMap 0 hzero y =
          (⟨(S.base (idx (G.subsequence (sigma k)))).1, x⟩ :
            (S.flow (idx (G.subsequence (sigma k)))).point) := by
  filter_upwards [hsigma.tendsto_atTop.eventually
    (windowRetainedCylinder_eventually_covers_baseBall G hAr hcomplete hr)] with k hk x hx
  have hzero : (0 : ℝ) ∈ Icc (-tau k) 0 := ⟨neg_nonpos.mpr (htau k).le, le_rfl⟩
  obtain ⟨y, hy, heq⟩ := hk _ _ _ (e (G.subsequence (sigma k)) k
    ((hsigma.id_le k).trans (G.subsequence_strictMono.id_le _))) hzero x hx
  exact ⟨y, hy, hzero, heq⟩

theorem horizonRetainedCylinder_chart_inner
    (htmono : Monotone tau) (k : ℕ) (s : ℝ) (hs : s ∈ Icc (-tau k) 0)
    (q : (liftedSliceCarrier.{u} G.limitCarrier).carrier)
    (z : EuclideanSpace ℝ (Fin 3)) (hz : z ∈ (extChartAt (𝓡 3) q).target)
    (hx : ((extChartAt (𝓡 3) q).symm z).down ∈ G.exhaustion (sigma k))
    (v w : EuclideanSpace ℝ (Fin 3)) :
    (horizonRetainedCylinder G hsigma k).pullbackInner s hs ((extChartAt (𝓡 3) q).symm z)
      (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z v)
      (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z w) =
      horizonSpacetimeCoefficients G q.down (sigma k) (s, z) v w := by
  rw [horizonRetainedCylinder, windowRetainedCylinder_chart_inner G _ _ (htau k) s hs q z hz hx]
  unfold horizonSpacetimeCoefficients
  rw [horizonSourceFlow_metric_eq hA htau e htmono (G.subsequence (sigma k)) k
    ((hsigma.id_le k).trans (G.subsequence_strictMono.id_le _)) s hs]

theorem horizon_window_interval_subset (htmono : StrictMono tau) (k : ℕ) :
    Icc (-tau k) 0 ⊆ horizonOpenTime tau ∪ {0} := by
  intro t ht
  rcases lt_or_eq_of_le ht.2 with hneg | rfl
  · exact Or.inl (mem_iUnion.mpr ⟨k + 1,
      (neg_lt_neg (htmono (Nat.lt_succ_self k))).trans_le ht.1, hneg⟩)
  · exact Or.inr (mem_singleton 0)

theorem horizon_window_interval_strict_cofinal (hpositive : ∀ j, 0 < tau j) (htmono : Monotone tau)
    {I : Set ℝ} (hI : IsCompact I) (hIsub : I ⊆ horizonOpenTime tau ∪ {0}) :
    ∀ᶠ k in atTop, I ⊆ Ioc (-tau k) 0 := by
  obtain ⟨j, hj⟩ := exists_closed_horizonWindow_of_isCompact hpositive htmono hI hIsub
  filter_upwards [eventually_ge_atTop j] with k hk t ht
  exact ⟨lt_of_le_of_lt (neg_le_neg (htmono hk)) (hj ht).1, (hj ht).2⟩

end PoincareMT.ControlledBlowupCompactness
