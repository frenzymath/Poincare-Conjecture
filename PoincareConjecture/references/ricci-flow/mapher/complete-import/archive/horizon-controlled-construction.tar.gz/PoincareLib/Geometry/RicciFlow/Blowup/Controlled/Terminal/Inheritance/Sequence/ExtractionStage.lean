import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.StageSequence
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Sequence.TimeSelection

/-!
# Actual canonical comparison stages from the terminal extraction

The retained terminal embeddings and dense common controls construct earlier
comparison maps on one prescribed precompact stage. All geometric outputs
refer to the original generalized sequence and its actual normalized slices.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1600000
set_option synthInstance.maxHeartbeats 100000

open Set Filter Metric
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.M30CommonBlowupControls

open ControlledBlowupCylinder
local notation "E3" => EuclideanSpace ℝ (Fin 3)

theorem exists_canonical_comparison_stage_of_terminal_extraction
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    {M : Type v} [TopologicalSpace M] [Nonempty M]
    [ChartedSpace E3 M] [IsManifold (𝓡 3) ∞ M]
    (g : RiemannianMetric 3 M) (D : LeviCivitaData g)
    (E : ℕ → Set M) (hE : ∀ j, IsOpen (E j)) (hmono : Monotone E)
    (hcover : ⋃ j, E j = univ) (f : ∀ k, M → S.terminalComponent (sigma k))
    (hemb : ∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x))
    (hlocal : ∀ k, IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k))
    (himage : ∀ K : Set M, IsCompact K → ∃ R : ℝ, 0 < R ∧
      ∀ᶠ k in atTop, ∀ x ∈ K, (f k x).val ∈ S.baseBall (sigma k) R)
    (hjet : ∀ q m K, IsCompact K → K ⊆ (extChartAt (𝓡 3) q).target →
      TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ m ((S.terminalComponentMetric (sigma k)).pullbackCoefficients
          (f k ∘ (extChartAt (𝓡 3) q).symm)))
        (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm)) atTop K)
    (htensor : ∀ K, IsCompact K → ∀ d > 0, ∀ᶠ k in atTop,
      ∀ x ∈ K, ∀ v w : TangentSpace (𝓡 3) x,
        g.tangentNorm x v ≤ 1 → g.tangentNorm x w ≤ 1 →
        |(S.terminalComponentMetric (sigma k)).inner (f k x)
          (mfderiv (𝓡 3) (𝓡 3) (f k) x v) (mfderiv (𝓡 3) (𝓡 3) (f k) x w) -
            g.inner x v w| < d)
    {U K₀ : Set M} (hU : IsOpen U) (hUc : IsCompact (closure U))
    (hK₀ : IsCompact K₀) (hK₀U : K₀ ⊆ U)
    (hscalar : TendstoUniformlyOn
      (fun k y => (S.terminalComponentConnection (sigma k)).scalarCurvature (f k y))
      D.scalarCurvature atTop K₀)
    {ι : Type*} [Fintype ι] (q : ι → M) (K : ι → Set M)
    (hK : ∀ i, IsCompact (K i) ∧ K i ⊆ U ∩ (extChartAt (𝓡 3) (q i)).source) :
    ∃ (sigma' : ℕ → ℕ), StrictMono sigma' ∧ ∃ t : ℕ → ℝ,
      ∃ e : ∀ k, PartialDiffeomorph (𝓡 3) (𝓡 3) M
        ((S.flow (sigma' k)).slice (t k)).carrier ∞,
      (∀ k, (e k).source = U) ∧
      (∀ k, t k ∈ (S.flow (sigma' k)).interval ∧
        generalizedSliceStrongCanonicalNeighborhoods (S.flow (sigma' k)) epsilon C
          (4 * S.scale (sigma' k)) (t k)) ∧
      (∀ i m, TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ m ((rescaledMetric ((S.flow (sigma' k)).metric (t k))
          (S.scale (sigma' k)) (S.base_scalar_pos (sigma' k))).pullbackCoefficients
            (e k ∘ (extChartAt (𝓡 3) (q i)).symm)))
        (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm))
        atTop ((extChartAt (𝓡 3) (q i)) '' K i)) ∧
      TendstoUniformlyOn (fun k y => (S.scale (sigma' k))⁻¹ *
        ((S.flow (sigma' k)).connection (t k)).scalarCurvature (e k y))
        D.scalarCurvature atTop K₀ ∧
      ∀ k y, y ∈ K₀ → ∀ w : TangentSpace (𝓡 3) y,
        g.tangentNorm y w ≤ 2 *
          (rescaledMetric ((S.flow (sigma' k)).metric (t k)) (S.scale (sigma' k))
            (S.base_scalar_pos (sigma' k))).tangentNorm (e k y)
              (mfderiv (𝓡 3) (𝓡 3) (e k) y w) := by
  obtain ⟨A, T, B, hA, hT, _hB, tau, htau, cyl, Phi, hPhi, hval, hcoeff⟩ :=
    H.exists_source_sequence_on_terminal_stage P04 hbound hsigma E hE hmono hcover
      f hemb hlocal himage hU hUc
  obtain ⟨j, hj⟩ := hUc.elim_directed_cover E hE
    (by rw [hcover]; exact subset_univ _) hmono.directed_le
  have htensor' := htau.tendsto_atTop.eventually (htensor K₀ hK₀ (1 / 2) (by norm_num))
  obtain ⟨a, ha⟩ := eventually_atTop.mp
    (htensor'.and (htau.tendsto_atTop.eventually (eventually_ge_atTop j)))
  let b := fun k => k + a
  have hb : StrictMono b := fun i j hij => Nat.add_lt_add_right hij a
  let c := fun k => cyl (b k)
  let phi := fun k => Phi (b k)
  let sig := sigma ∘ tau ∘ b
  have hphis (k : ℕ) : (phi k).source = U := hPhi (b k)
  have hUE (k : ℕ) : U ⊆ E (tau (b k)) := fun y hy =>
    hmono (ha (b k) (Nat.le_add_left a k)).2 (hj (subset_closure hy))
  have hsc0 : TendstoUniformlyOn
      (fun k y => (((c k).ordinaryFlow hT).connection 0).scalarCurvature (phi k y))
      D.scalarCurvature atTop K₀ := by
    apply (hscalar.seq_tendstoUniformlyOn (tau ∘ b) (htau.comp hb).tendsto_atTop).congr
    exact Eventually.of_forall fun k y hy =>
      ((c k).ordinaryFlow_terminal_scalarCurvature_eq_component hT (phi k y)
        (f (tau (b k)) y) (hval (b k) y (hK₀U hy))).symm
  have hlow0 (k : ℕ) (y : M) (hy : y ∈ K₀) (w : TangentSpace (𝓡 3) y) :
      g.tangentNorm y w ≤ (3 / 2 : ℝ) * (((c k).ordinaryFlow hT).metric 0).tangentNorm
        (phi k y) (mfderiv (𝓡 3) (𝓡 3) (phi k) y w) := by
    apply ControlledTerminal.tangentNorm_lower_of_unit_tensor_error
      g (((c k).ordinaryFlow hT).metric 0) (phi k) y ?_ w
    intro v w hv hw
    have hgerm : (fun z => (phi k z).val) =ᶠ[𝓝 y] fun z => (f (tau (b k)) z).val :=
      Filter.mem_of_superset (hU.mem_nhds (hK₀U hy)) (fun z hz => hval (b k) z hz)
    rw [(c k).ordinaryFlow_terminal_inner_of_component_map hT (phi k) (f (tau (b k)))
      (((phi k).isLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞ ((hphis k).symm ▸ hK₀U hy)).mdifferentiableAt
        (by simp))
      ((hlocal (tau (b k)) ⟨y, hUE k (hK₀U hy)⟩).mdifferentiableAt (by simp)) hgerm v w]
    exact (ha (b k) (Nat.le_add_left a k)).1 y hy v w hv hw
  have hjets (i : ι) (m : ℕ) : TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m (((c k).ordinaryFlow hT).metric 0
        |>.pullbackCoefficients (phi k ∘ (extChartAt (𝓡 3) (q i)).symm)))
      (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm))
      atTop ((extChartAt (𝓡 3) (q i)) '' K i) := by
    let chart := extChartAt (𝓡 3) (q i)
    have hcompact := (hK i).1.image_of_continuousOn
      ((continuousOn_extChartAt (q i)).mono (fun _ hx => ((hK i).2 hx).2))
    have hchart : chart '' K i ⊆ chart.target := by
      rintro _ ⟨y, hy, rfl⟩
      exact chart.map_source ((hK i).2 hy).2
    apply ((hjet (q i) m _ hcompact hchart).seq_tendstoUniformlyOn
      (tau ∘ b) (htau.comp hb).tendsto_atTop).congr
    refine Eventually.of_forall fun k z hz => ?_
    obtain ⟨y, hy, rfl⟩ := hz
    have hyU := ((hK i).2 hy).1
    have hyc := ((hK i).2 hy).2
    let V := chart.target ∩ chart.symm ⁻¹' U
    have hV : IsOpen V := (continuousOn_extChartAt_symm (q i)).isOpen_inter_preimage
      (isOpen_extChartAt_target (q i)) hU
    have hzV : chart y ∈ V := ⟨chart.map_source hyc, by
      change chart.symm (chart y) ∈ U
      rw [chart.left_inv hyc]
      exact hyU⟩
    have heq : (((c k).ordinaryFlow hT).metric 0).pullbackCoefficients (phi k ∘ chart.symm)
        =ᶠ[𝓝 (chart y)] (S.terminalComponentMetric (sig k)).pullbackCoefficients
          (f (tau (b k)) ∘ chart.symm) := by
      filter_upwards [hV.mem_nhds hzV] with z hz
      exact hcoeff hT (b k) (q i) z hz.1 hz.2
    exact (heq.iteratedFDeriv ℝ m).self_of_nhds.symm
  obtain ⟨s, hs, _hs0, hes, hgood, hconv, hscalarconv, hlower⟩ :=
    H.exists_canonical_stage_slices_with_scalar_and_metric_control P04 sig hA hT c g D hU
      phi hphis hK₀ hK₀U hsc0 hlow0 q K hK hjets
  refine ⟨sig, hsigma.comp (htau.comp hb),
    fun k => (S.base (sig k)).1 + s k / S.scale (sig k),
    fun k => (c k).stageSlicePartialDiffeomorph hA (s k) (hs k) (phi k),
    hes, hgood, hconv, ?_, hlower⟩
  simpa only [rescaledMetric_scalarCurvature] using hscalarconv

end PoincareMT.M30CommonBlowupControls
