import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.CoverBound
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Neck.Spatial

/-!
# Canonical control bounds the terminal null-line branch

A high-curvature neck supplies the transverse sphere directly, and a cap
supplies its end neck. The remaining canonical alternatives make the whole
connected slice compact. If no point has high curvature, the cutoff itself
is a global bound.

Reference: Morgan--Tian, Claim 11.7, p. 271.
-/

set_option autoImplicit false

open Set
open scoped Manifold ContDiff Bundle

universe u

namespace PoincareMT.GeneralizedCanonicalControl

open RicciFlow.Splitting

theorem exists_universal_local_null_scalar_bound_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ < 1 / 2 ∧
      ∀ (F : GeneralizedRicciFlowData.{u}) (t : ℝ)
        [ConnectedSpace (F.slice t).carrier],
        MetricComplete (F.metric t) →
        (∀ y : (F.slice t).carrier, ricciNullity (F.connection t) y = 1) →
        (∀ p : UnitRicciKernel (F.connection t),
          ∃ (U : Set (F.slice t).carrier)
            (V : (y : (F.slice t).carrier) → TangentSpace (𝓡 3) y),
            IsOpen U ∧ p.1.proj ∈ U ∧
            ContMDiffOn (𝓡 3) ((𝓡 3).prod (𝓡 3)) ∞ (T% V) U ∧
            V p.1.proj = p.1.snd ∧
            ∀ y ∈ U, (F.metric t).inner y (V y) (V y) = 1 ∧
              (∀ w, (F.connection t).ricci y (V y) w = 0) ∧
              ∀ w, (F.connection t).connection V y w = 0) →
      ∀ epsilon C cutoff : ℝ, 0 < epsilon → epsilon ≤ epsilon₀ →
        (∀ x : (F.slice t).carrier, cutoff < (F.connection t).scalarCurvature x →
          GeneralizedCanonicalControl t x epsilon C) →
        ∃ B : ℝ, 0 < B ∧
          ∀ x : (F.slice t).carrier, (F.connection t).scalarCurvature x ≤ B := by
  classical
  obtain ⟨epsilon₀, hpos, hsmall, hbound⟩ := exists_local_null_neck_scalar_bound_threshold.{u}
  have hhalf : epsilon₀ < 1 / 2 := by linarith
  refine ⟨epsilon₀, hpos, hhalf, ?_⟩
  intro F t _ hcomplete hdim hlocal epsilon C cutoff _ hepsilon hcanonical
  by_cases hcompact : CompactSpace (F.slice t).carrier
  · let : CompactSpace (F.slice t).carrier := hcompact
    obtain ⟨B, hB⟩ := isCompact_univ.bddAbove_image
      (F.connection t).continuous_scalarCurvature.continuousOn
    exact ⟨max 1 B, lt_of_lt_of_le zero_lt_one (le_max_left _ _),
      fun x => (hB (mem_image_of_mem _ (mem_univ x))).trans (le_max_right _ _)⟩
  by_cases hhigh : ∃ x : (F.slice t).carrier, cutoff < (F.connection t).scalarCurvature x
  · obtain ⟨x, hx⟩ := hhigh
    cases hcanonical x hx with
    | neck N _ =>
      exact hbound (F.slice t).carrier (F.metric t) (F.connection t)
        hcomplete hdim hlocal (N.spatialNeck (hepsilon.trans_lt hhalf)) hepsilon
    | cap N heq _ _ _ =>
      exact hbound (F.slice t).carrier (F.metric t) (F.connection t)
        hcomplete hdim hlocal N.end_neck ((N.end_neck_epsilon.trans heq).trans_le hepsilon)
    | component N _ =>
      apply False.elim (hcompact ?_)
      apply isCompact_univ_iff.mp
      simpa only [N.component_eq, PreconnectedSpace.connectedComponent_eq_univ]
        using N.compact
    | round N _ =>
      apply False.elim (hcompact ?_)
      apply isCompact_univ_iff.mp
      simpa only [N.component_eq, PreconnectedSpace.connectedComponent_eq_univ]
        using N.compact
  · refine ⟨max 1 cutoff, lt_of_lt_of_le zero_lt_one (le_max_left _ _), ?_⟩
    intro x
    exact (le_of_not_gt (fun hx => hhigh ⟨x, hx⟩)).trans (le_max_right _ _)

end PoincareMT.GeneralizedCanonicalControl
