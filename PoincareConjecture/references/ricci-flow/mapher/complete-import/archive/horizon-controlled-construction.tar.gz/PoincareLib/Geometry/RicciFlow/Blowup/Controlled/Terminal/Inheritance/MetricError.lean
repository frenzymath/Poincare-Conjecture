import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Ancient.Compact.Stability.Neck.Jets.Pullback
import PoincareLib.Geometry.Riemannian.Coordinates.ParametrizedCoefficients

/-!
# Terminal metric errors in varying local coordinates

Actual comparison maps and compact convergence of their pulled-back metric
jets control the errors in every uniformly bounded family of local charts.
Neither convergence of the local charts nor a common chart domain is needed.

Reference: Morgan--Tian, Claim 11.6 and Proposition 9.79(3).
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

open Set Filter
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.TerminalNeck

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem eventually_small_parametrized_metric_error_of_chart_bound
    {M : Type u} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    {X : ℕ → Type v} [∀ k, TopologicalSpace (X k)] [∀ k, ChartedSpace E (X k)]
    [∀ k, IsManifold (𝓡 3) ∞ (X k)]
    (g : ∀ k, RiemannianMetric 3 (X k)) (h : RiemannianMetric 3 M)
    (e : ∀ k, M → X k) {U : Set M} (hU : IsOpen U)
    (he : ∀ᶠ k in atTop, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) U)
    (q : M) {K : Set M} (hK : IsCompact K) (hKU : K ⊆ U)
    (hKchart : K ⊆ (extChartAt (𝓡 3) q).source)
    {ι : Type*} (f : ι → E → M)
    (hf : ∀ i, ∃ W, IsOpen W ∧ (0 : E) ∈ W ∧
      ContMDiffOn (𝓡 3) (𝓡 3) ∞ (f i) W)
    (hmap : ∀ i, f i 0 ∈ K)
    (m : ℕ) {C : ℝ} (hC : 1 ≤ C)
    (hfj : ∀ i j, 1 ≤ j → j ≤ m + 1 →
      ‖iteratedFDeriv ℝ j ((extChartAt (𝓡 3) q) ∘ f i) 0‖ ≤ C)
    (hjet : ∀ j, j ≤ m → TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ j (fun y =>
        (g k).parametrizedCoefficients (e k ∘ (extChartAt (𝓡 3) q).symm) y -
          h.parametrizedCoefficients (extChartAt (𝓡 3) q).symm y))
      (fun _ => 0) atTop ((extChartAt (𝓡 3) q) '' K))
    {η : ℝ} (hη : 0 < η) :
    ∀ᶠ k in atTop, ∀ (i : ι) (j : ℕ), j ≤ m →
      ‖iteratedFDeriv ℝ j (fun y =>
        (g k).parametrizedCoefficients (e k ∘ f i) y -
          h.parametrizedCoefficients (f i) y) 0‖ ≤ η := by
  let c := extChartAt (𝓡 3) q
  let α := fun i => c ∘ f i
  let L := c '' K
  let V := c.target ∩ c.symm ⁻¹' U
  have hL : IsCompact L := hK.image_of_continuousOn
    ((continuousOn_extChartAt q).mono hKchart)
  have hV : IsOpen V := (continuousOn_extChartAt_symm q).isOpen_inter_preimage
    (isOpen_extChartAt_target q) hU
  have hLV : L ⊆ V := by
    rintro y ⟨x, hx, rfl⟩
    refine ⟨c.map_source (hKchart hx), ?_⟩
    simpa only [mem_preimage, c.left_inv (hKchart hx)] using (hKU hx)
  have hα (i : ι) : ContDiffAt ℝ ∞ (α i) 0 := by
    obtain ⟨W, hW, h0, hfi⟩ := hf i
    exact contMDiffAt_iff_contDiffAt.mp
      (((contMDiffOn_extChartAt (n := ∞) (x := q)).contMDiffAt
        (by simpa only [extChartAt_source] using
          (isOpen_extChartAt_source (I := 𝓡 3) q).mem_nhds (hKchart (hmap i)))).comp 0
          (hfi.contMDiffAt (hW.mem_nhds h0)))
  let B := fun k y => (g k).parametrizedCoefficients (e k ∘ c.symm) y -
    h.parametrizedCoefficients c.symm y
  have hlocal : ∀ y ∈ V, ∃ W, IsOpen W ∧ y ∈ W ∧
      ∀ᶠ k in atTop, ContDiffOn ℝ ∞ (B k) W := by
    intro y hy
    refine ⟨V, hV, hy, ?_⟩
    filter_upwards [he] with k hek
    intro z hz
    apply ContDiffAt.contDiffWithinAt
    have hcs := (contMDiffOn_extChartAt_symm (n := ∞) q).contMDiffAt
      ((isOpen_extChartAt_target q).mem_nhds hz.1)
    have hes := hek.contMDiffAt (hU.mem_nhds hz.2)
    exact ((g k).contDiffAt_parametrizedCoefficients (hes.comp _ hcs)).sub
      (h.contDiffAt_parametrizedCoefficients hcs)
  have hb := eventually_small_bilinearPullback_jets_of_compact_convergence
    (B := B) (f := α) (fun _ : ι => (0 : E)) hL hLV hα
    (fun i => mem_image_of_mem c (hmap i)) hlocal m hC hfj hjet hη
  filter_upwards [hb, he] with k hkb hek i j hj
  obtain ⟨W, hW, h0, hfi⟩ := hf i
  let O := W ∩ (f i) ⁻¹' (c.source ∩ U)
  have hO : IsOpen O := hfi.continuousOn.isOpen_inter_preimage hW
    ((isOpen_extChartAt_source (I := 𝓡 3) q).inter hU)
  have h0O : (0 : E) ∈ O := ⟨h0, hKchart (hmap i), hKU (hmap i)⟩
  have hαO : ContDiffOn ℝ ∞ (α i) O := by
    apply contMDiffOn_iff_contDiffOn.mp
    exact (contMDiffOn_extChartAt (n := ∞) (x := q)).comp
      (hfi.mono inter_subset_left)
      (fun y hy => by
        change f i y ∈ (chartAt E q).source
        simpa only [c, extChartAt_source] using hy.2.1)
  have heq : (fun y => (B k (α i y)).bilinearComp
      (fderiv ℝ (α i) y) (fderiv ℝ (α i) y)) =ᶠ[𝓝 (0 : E)]
      (fun y => (g k).parametrizedCoefficients (e k ∘ f i) y -
        h.parametrizedCoefficients (f i) y) := by
    filter_upwards [hO.mem_nhds h0O] with y hy
    have hct : α i y ∈ c.target := c.map_source hy.2.1
    have hc : c.symm (α i y) = f i y := c.left_inv hy.2.1
    have hcs := (contMDiffOn_extChartAt_symm (n := ∞) q).contMDiffAt
      ((isOpen_extChartAt_target q).mem_nhds hct)
    have hes := hek.contMDiffAt (hU.mem_nhds hy.2.2)
    let ψ := e k ∘ c.symm
    have hψ : MDifferentiableAt (𝓡 3) (𝓡 3) ψ (α i y) := by
      rw [← hc] at hes
      exact (hes.comp _ hcs).mdifferentiableAt (by simp)
    have hcomp : ψ ∘ α i =ᶠ[𝓝 y] e k ∘ f i := by
      filter_upwards [hO.mem_nhds hy] with z hz
      dsimp only [ψ, α, Function.comp_apply]
      rw [c.left_inv hz.2.1]
    have hcomp₀ : c.symm ∘ α i =ᶠ[𝓝 y] f i := by
      filter_upwards [hO.mem_nhds hy] with z hz
      exact c.left_inv hz.2.1
    have hdiff := (hαO.contDiffAt (hO.mem_nhds hy)).differentiableAt (by simp)
    have hsource := (g k).parametrizedCoefficients_comp_of_eventuallyEq hψ hdiff hcomp
    have hlimit := h.parametrizedCoefficients_comp_of_eventuallyEq
      (hcs.mdifferentiableAt (by simp)) hdiff hcomp₀
    ext v w
    exact congrArg₂ (fun a b : ℝ => a - b)
      (congrArg (fun T : E →L[ℝ] E →L[ℝ] ℝ => T v w) hsource)
      (congrArg (fun T : E →L[ℝ] E →L[ℝ] ℝ => T v w) hlimit)
  rw [← (heq.iteratedFDeriv ℝ j).self_of_nhds]
  exact hkb i j hj

end PoincareMT.TerminalNeck
