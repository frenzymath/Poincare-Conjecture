import PoincareLib.Geometry.RicciFlow.Compactness.GeometricLimit.BoundaryCoverage
import PoincareLib.Geometry.Riemannian.MetricComparison
import PoincareLib.Geometry.Riemannian.Distance.Basic
import PoincareLib.Geometry.RicciFlow.Harnack.Basic
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Limit

/-!
# Completeness from static pointed metric extraction

The compact tensor convergence controls actual path lengths. Escaping source
images of exhaustion boundaries then force limit balls into compact sets.
The argument uses metrics and local diffeomorphisms and requires no flow on
the terminal slice. Source: Morgan--Tian, Section 5.1, pp. 85--89.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter MeasureTheory
open scoped Manifold ContDiff Bundle Topology ENNReal

namespace PoincareMT.ControlledTerminal

variable {n : ℕ} {M N : Type*} [TopologicalSpace M] [TopologicalSpace N]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) N]
  [IsManifold (𝓡 n) ∞ M] [IsManifold (𝓡 n) ∞ N]

omit [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M] in
theorem ball_subset_image_of_boundary_avoided [T2Space N]
    (h : RiemannianMetric n N) {U V : Set M} (f : M → N)
    (hf : ContinuousOn f U)
    (he : Topology.IsOpenEmbedding (fun x : U => f x))
    (hV : IsOpen V) (hcompact : IsCompact (closure V)) (hVU : closure V ⊆ U)
    {p : M} (hp : p ∈ V) {A : ℝ} (hA : 0 < A)
    (hboundary : ∀ x ∈ frontier V, ENNReal.ofReal A ≤ h.edist (f p) (f x)) :
    h.ball (f p) A ⊆ f '' V := by
  have hopen : IsOpen (f '' V) := by
    have hi := he.isOpenMap (Subtype.val ⁻¹' V) (hV.preimage continuous_subtype_val)
    convert hi using 1
    ext y
    constructor
    · rintro ⟨x, hx, rfl⟩
      exact ⟨⟨x, hVU (subset_closure hx)⟩, hx, rfl⟩
    · rintro ⟨x, hx, rfl⟩
      exact ⟨x, hx, rfl⟩
  have hclosed : IsClosed (f '' closure V) :=
    (hcompact.image_of_continuousOn (hf.mono hVU)).isClosed
  have hclosure : closure (f '' V) ⊆ f '' closure V :=
    closure_minimal (image_mono subset_closure) hclosed
  apply (h.isPreconnected_ball (f p) A).subset_of_closure_inter_subset hopen
  · refine ⟨f p, ?_, mem_image_of_mem f hp⟩
    change h.edist (f p) (f p) < ENNReal.ofReal A
    simpa only [RiemannianMetric.edist, Manifold.riemannianEDist_self] using
      ENNReal.ofReal_pos.mpr hA
  · rintro y ⟨hyclosure, hyball⟩
    obtain ⟨x, hx, rfl⟩ := hclosure hyclosure
    have hxV : x ∈ V := by
      by_contra hxV
      have hfront : x ∈ frontier V := by
        rw [frontier, hV.interior_eq]
        exact ⟨hx, hxV⟩
      exact (not_lt_of_ge (hboundary x hfront)) hyball
    exact mem_image_of_mem f hxV

theorem pullback_tangentNorm_le_two_of_unit_error
    (g : RiemannianMetric n M) (h : RiemannianMetric n N) (f : M → N) (x : M)
    (hclose : ∀ u w : TangentSpace (𝓡 n) x,
      g.tangentNorm x u ≤ 1 → g.tangentNorm x w ≤ 1 →
      |h.inner (f x) (mfderiv (𝓡 n) (𝓡 n) f x u) (mfderiv (𝓡 n) (𝓡 n) f x w) -
        g.inner x u w| < 1)
    (v : TangentSpace (𝓡 n) x) :
    h.tangentNorm (f x) (mfderiv (𝓡 n) (𝓡 n) f x v) ≤ 2 * g.tangentNorm x v := by
  by_cases hv : v = 0
  · subst v
    simp [RiemannianMetric.tangentNorm]
  let a := g.tangentNorm x v
  have ha : 0 < a := Real.sqrt_pos.mpr (g.pos x v hv)
  have ha2 : a ^ 2 = g.inner x v v := Real.sq_sqrt (g.pos x v hv).le
  have hinv : a⁻¹ ^ 2 * a ^ 2 = 1 := by field_simp
  let u : TangentSpace (𝓡 n) x := a⁻¹ • v
  have hu : g.tangentNorm x u = 1 := by
    change Real.sqrt _ = 1
    simp only [u, map_smul, smul_apply, smul_eq_mul]
    rw [show a⁻¹ * (a⁻¹ * g.inner x v v) = 1 by rw [← ha2]; nlinarith [hinv]]
    exact Real.sqrt_one
  have hq := (le_abs_self _).trans_lt (hclose u u hu.le hu.le)
  simp only [u, map_smul, smul_apply, smul_eq_mul] at hq
  have hbound : h.inner (f x) (mfderiv (𝓡 n) (𝓡 n) f x v)
      (mfderiv (𝓡 n) (𝓡 n) f x v) ≤ 4 * g.inner x v v := by
    have hmul := mul_lt_mul_of_pos_right hq (sq_pos_of_pos ha)
    have hscale (b c : ℝ) : (a⁻¹ * (a⁻¹ * b) - a⁻¹ * (a⁻¹ * c)) * a ^ 2 = b - c := by
      rw [show (a⁻¹ * (a⁻¹ * b) - a⁻¹ * (a⁻¹ * c)) * a ^ 2 =
        (a⁻¹ ^ 2 * a ^ 2) * (b - c) by ring, hinv, one_mul]
    rw [hscale, one_mul, ha2] at hmul
    linarith [(g.pos x v hv).le]
  change Real.sqrt _ ≤ 2 * Real.sqrt _
  rw [← Real.sqrt_sq (by norm_num : (0 : ℝ) ≤ 2), ← Real.sqrt_mul (sq_nonneg (2 : ℝ))]
  apply Real.sqrt_le_sqrt
  norm_num only [Nat.reducePow] at *
  exact hbound

theorem pathELength_comp_le_two
    (g : RiemannianMetric n M) (h : RiemannianMetric n N)
    (f : M → N) (γ : ℝ → M) (hγ : ContMDiff 𝓘(ℝ, ℝ) (𝓡 n) 1 γ)
    (hf : ∀ t ∈ Icc (0 : ℝ) 1, ContMDiffAt (𝓡 n) (𝓡 n) ∞ f (γ t))
    (hbound : ∀ t ∈ Icc (0 : ℝ) 1, ∀ v : TangentSpace (𝓡 n) (γ t),
      h.tangentNorm (f (γ t)) (mfderiv (𝓡 n) (𝓡 n) f (γ t) v) ≤
        2 * g.tangentNorm (γ t) v) :
    h.pathELength (f ∘ γ) 0 1 ≤ ENNReal.ofReal 2 * g.pathELength γ 0 1 := by
  rw [RiemannianMetric.pathELength_eq_lintegral_tangentNorm,
    RiemannianMetric.pathELength_eq_lintegral_tangentNorm,
    ← lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
  apply setLIntegral_mono' measurableSet_Icc
  intro t ht
  have hder := mfderiv_comp_apply t ((hf t ht).mdifferentiableAt (by simp))
    (hγ.mdifferentiable one_ne_zero t) (1 : ℝ)
  rw [hder]
  exact (ENNReal.ofReal_le_ofReal (hbound t ht _)).trans_eq
    (ENNReal.ofReal_mul (by norm_num))

theorem image_ball_subset_of_tangentNorm_le_two
    (g : RiemannianMetric n M) (h : RiemannianMetric n N) (f : M → N)
    (p : M) (R : ℝ)
    (hf : ∀ x ∈ g.ball p R, ContMDiffAt (𝓡 n) (𝓡 n) ∞ f x)
    (hbound : ∀ x ∈ g.ball p R, ∀ v : TangentSpace (𝓡 n) x,
      h.tangentNorm (f x) (mfderiv (𝓡 n) (𝓡 n) f x v) ≤ 2 * g.tangentNorm x v) :
    f '' g.ball p R ⊆ h.ball (f p) (2 * R) := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 n) : M → Type _) := ⟨g.toRiemannianMetric⟩
  rintro _ ⟨x, hx, rfl⟩
  obtain ⟨γ, h0, h1, hγ, hlength, _⟩ :=
    Manifold.exists_lt_locally_constant_of_riemannianEDist_lt hx zero_lt_one
  have hball : ∀ t ∈ Icc (0 : ℝ) 1, γ t ∈ g.ball p R := by
    intro t ht
    exact ((Manifold.riemannianEDist_le_pathELength
      (hγ.contMDiffOn.mono (Icc_subset_Icc le_rfl ht.2)) h0 rfl ht.1).trans
        (Manifold.pathELength_mono le_rfl ht.2)).trans_lt hlength
  have hl := pathELength_comp_le_two g h f γ hγ
    (fun t ht => hf _ (hball t ht)) (fun t ht => hbound _ (hball t ht))
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 n) : N → Type _) := ⟨h.toRiemannianMetric⟩
  have hη : ContMDiffOn 𝓘(ℝ, ℝ) (𝓡 n) 1 (f ∘ γ) (Icc 0 1) := by
    intro t ht
    exact (((hf _ (hball t ht)).of_le (by simp)).comp t hγ.contMDiffAt).contMDiffWithinAt
  have hd : h.edist (f p) (f x) ≤ h.pathELength (f ∘ γ) 0 1 :=
    Manifold.riemannianEDist_le_pathELength hη
      (by simp only [Function.comp_apply, h0]) (by simp only [Function.comp_apply, h1]) zero_le_one
  change _ < ENNReal.ofReal (2 * R)
  rw [ENNReal.ofReal_mul (by norm_num : (0 : ℝ) ≤ 2)]
  exact (hd.trans hl).trans_lt
    (ENNReal.mul_lt_mul_right (by norm_num : ENNReal.ofReal (2 : ℝ) ≠ 0)
      ENNReal.ofReal_ne_top hlength)

section Sequence

variable {D : ℕ → Type*} [∀ k, TopologicalSpace (D k)]
  [∀ k, ChartedSpace (EuclideanSpace ℝ (Fin n)) (D k)]
  [∀ k, IsManifold (𝓡 n) ∞ (D k)] [∀ k, T2Space (D k)]
  (g : RiemannianMetric n M) (gSource : ∀ k, RiemannianMetric n (D k))
  (p : M) (pSource : ∀ k, D k) (E : ℕ → Set M)
  (hE : ∀ j, IsOpen (E j)) (hEp : ∀ j, p ∈ E j)
  (hEK : ∀ j, IsCompact (closure (E j)))
  (hEstep : ∀ j, closure (E j) ⊆ E (j + 1)) (hEcover : ⋃ j, E j = univ)
  (f : ∀ k, M → D k)
  (hemb : ∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x))
  (hlocal : ∀ k, IsLocalDiffeomorphOn (𝓡 n) (𝓡 n) ∞ (f k) (E k))
  (hbase : ∀ k, f k p = pSource k)
  (herror : ∀ K : Set M, IsCompact K → ∀ ε > 0, ∀ᶠ k in atTop,
    ∀ x ∈ K, ∀ v w : TangentSpace (𝓡 n) x,
      g.tangentNorm x v ≤ 1 → g.tangentNorm x w ≤ 1 →
      |(gSource k).inner (f k x) (mfderiv (𝓡 n) (𝓡 n) (f k) x v)
        (mfderiv (𝓡 n) (𝓡 n) (f k) x w) - g.inner x v w| < ε)

include hEstep in
private theorem exhaustion_monotone : Monotone E :=
  monotone_nat_of_le_succ fun j => subset_closure.trans (hEstep j)

include hE hEstep hEcover in
private theorem exists_exhaustion_superset {K : Set M} (hK : IsCompact K) :
    ∃ j, K ⊆ E j :=
  hK.elim_directed_cover E hE (by rw [hEcover]; exact subset_univ _)
    (exhaustion_monotone E hEstep).directed_le

include hE hEp hEK hEstep hemb hlocal hbase in
omit [IsManifold (𝓡 n) ∞ M] in
theorem source_ball_coverage_of_boundary_escape
    (hescape : ∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop, ∀ x ∈ frontier (E j),
      ENNReal.ofReal A ≤ (gSource k).edist (pSource k) (f k x)) :
    ∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop,
      (gSource k).ball (pSource k) A ⊆ f k '' E j := by
  intro A hA
  obtain ⟨j, hj⟩ := hescape A hA
  refine ⟨j, ?_⟩
  filter_upwards [hj, eventually_ge_atTop (j + 1)] with k hk hjk
  have hsub := (hEstep j).trans (exhaustion_monotone E hEstep hjk)
  have h := ball_subset_image_of_boundary_avoided (gSource k) (f k)
    (hlocal k).contMDiffOn.continuousOn (hemb k) (hE j) (hEK j) hsub (hEp j) hA
    (by simpa only [hbase k] using hk)
  simpa only [hbase k] using h

include hE hEstep hEcover hlocal herror in
omit [∀ k, T2Space (D k)] in
theorem eventually_pathELength_comp_le
    (γ : ℝ → M) (hγ : ContMDiff 𝓘(ℝ, ℝ) (𝓡 n) 1 γ) :
    ∀ᶠ k in atTop,
      (gSource k).pathELength (f k ∘ γ) 0 1 ≤ ENNReal.ofReal 2 * g.pathELength γ 0 1 := by
  let K := γ '' Icc (0 : ℝ) 1
  have hK : IsCompact K := isCompact_Icc.image hγ.continuous
  obtain ⟨j, hj⟩ := exists_exhaustion_superset E hE hEstep hEcover hK
  filter_upwards [herror K hK 1 zero_lt_one, eventually_ge_atTop j] with k hk hjk
  apply pathELength_comp_le_two g (gSource k) (f k) γ hγ
  · intro t ht
    exact (hlocal k ⟨γ t, exhaustion_monotone E hEstep hjk (hj (mem_image_of_mem γ ht))⟩).contMDiffAt
  · intro t ht v
    exact pullback_tangentNorm_le_two_of_unit_error g (gSource k) (f k) (γ t)
      (hk _ (mem_image_of_mem γ ht)) v

include hE hEstep hEcover hlocal hbase herror in
omit [∀ k, T2Space (D k)] in
theorem eventually_mem_source_ball {A : ℝ} {x : M} (hx : x ∈ g.ball p A) :
    ∀ᶠ k in atTop, f k x ∈ (gSource k).ball (pSource k) (2 * A) := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 n) : M → Type _) := ⟨g.toRiemannianMetric⟩
  obtain ⟨γ, h0, h1, hγ, hlength, _⟩ :=
    Manifold.exists_lt_locally_constant_of_riemannianEDist_lt hx zero_lt_one
  obtain ⟨j, hj⟩ := exists_exhaustion_superset E hE hEstep hEcover
    (isCompact_Icc.image hγ.continuous)
  filter_upwards [eventually_pathELength_comp_le g gSource E hE hEstep hEcover f hlocal herror γ hγ,
    eventually_ge_atTop j] with k hk hjk
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 n) : D k → Type _) :=
    ⟨(gSource k).toRiemannianMetric⟩
  have hη : ContMDiffOn 𝓘(ℝ, ℝ) (𝓡 n) 1 (f k ∘ γ) (Icc 0 1) := by
    intro t ht
    exact (((hlocal k ⟨γ t, exhaustion_monotone E hEstep hjk
      (hj (mem_image_of_mem γ ht))⟩).contMDiffAt.of_le (by simp)).comp t
        hγ.contMDiffAt).contMDiffWithinAt
  have hd : (gSource k).edist (pSource k) (f k x) ≤
      (gSource k).pathELength (f k ∘ γ) 0 1 :=
    Manifold.riemannianEDist_le_pathELength hη
      (by simpa only [Function.comp_apply, h0] using hbase k)
      (by simp only [Function.comp_apply, h1]) zero_le_one
  change _ < ENNReal.ofReal (2 * A)
  rw [ENNReal.ofReal_mul (by norm_num : (0 : ℝ) ≤ 2)]
  exact (hd.trans hk).trans_lt
    (ENNReal.mul_lt_mul_right (by norm_num : ENNReal.ofReal (2 : ℝ) ≠ 0)
      ENNReal.ofReal_ne_top hlength)

include hE hEstep hEcover hemb hlocal hbase herror in
omit [∀ k, T2Space (D k)] in
theorem limit_ball_subset_exhaustion_of_source_ball_coverage
    {A : ℝ} {j : ℕ}
    (hcover : ∀ᶠ k in atTop, (gSource k).ball (pSource k) (2 * A) ⊆ f k '' E j) :
    g.ball p A ⊆ E j := by
  intro x hx
  obtain ⟨jx, hjx⟩ := exists_exhaustion_superset E hE hEstep hEcover isCompact_singleton
  obtain ⟨k, hkcover, hkball, hkj, hkjx⟩ :=
    (hcover.and ((eventually_mem_source_ball g gSource p pSource E hE hEstep hEcover
      f hlocal hbase herror hx).and
        ((eventually_ge_atTop j).and (eventually_ge_atTop jx)))).exists
  obtain ⟨y, hy, heq⟩ := hkcover hkball
  have hyk : y ∈ E k := exhaustion_monotone E hEstep hkj hy
  have hxk : x ∈ E k := exhaustion_monotone E hEstep hkjx (hjx (mem_singleton x))
  have hyx : (⟨y, hyk⟩ : E k) = ⟨x, hxk⟩ := (hemb k).injective heq
  have hxy : y = x := congrArg Subtype.val hyx
  exact hxy ▸ hy

include hE hEK hEstep hEcover hemb hlocal hbase herror in
omit [∀ k, T2Space (D k)] in
theorem isCompact_closure_limit_ball_of_source_ball_coverage
    (hcover : ∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop,
      (gSource k).ball (pSource k) A ⊆ f k '' E j)
    {A : ℝ} (hA : 0 < A) : IsCompact (closure (g.ball p A)) := by
  obtain ⟨j, hj⟩ := hcover (2 * A) (by positivity)
  exact (hEK j).of_isClosed_subset isClosed_closure
    (closure_mono (limit_ball_subset_exhaustion_of_source_ball_coverage
      g gSource p pSource E hE hEstep hEcover f hemb hlocal hbase herror hj))

include hE hEp hEK hEstep hEcover hemb hlocal hbase herror in
theorem metricComplete_of_boundary_escape [T3Space M] [PreconnectedSpace M]
    (hescape : ∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop, ∀ x ∈ frontier (E j),
      ENNReal.ofReal A ≤ (gSource k).edist (pSource k) (f k x)) : MetricComplete g := by
  have hcover := source_ball_coverage_of_boundary_escape gSource p pSource E
    hE hEp hEK hEstep f hemb hlocal hbase hescape
  have hcompact (R : ℝ) (hR : 0 < R) : IsCompact (closure (g.ball p R)) :=
    isCompact_closure_limit_ball_of_source_ball_coverage g gSource p pSource E
      hE hEK hEstep hEcover f hemb hlocal hbase herror hcover hR
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 n) : M → Type _) := ⟨g.toRiemannianMetric⟩
  let : IsContinuousRiemannianBundle (EuclideanSpace ℝ (Fin n))
      (TangentSpace (𝓡 n) : M → Type _) :=
    ⟨⟨g.inner, g.toContinuousRiemannianMetric.continuous, fun _ _ _ => rfl⟩⟩
  let : EMetricSpace M := EMetricSpace.ofRiemannianMetric (𝓡 n) M
  change CompleteSpace M
  apply EMetric.complete_of_cauchySeq_tendsto
  intro u hu
  obtain ⟨N, hN⟩ := EMetric.cauchySeq_iff'.mp hu 1 zero_lt_one
  let d := edist (u N) p
  have hd : d ≠ ⊤ := Poincare.edist_ne_top_of_preconnected _ _
  let R : ℝ := d.toReal + 2
  have hR : 0 < R := by dsimp [R]; positivity
  have htail : ∀ᶠ k in atTop, u k ∈ closure (g.ball p R) := by
    filter_upwards [eventually_ge_atTop N] with k hk
    apply subset_closure
    change edist p (u k) < ENNReal.ofReal R
    rw [edist_comm]
    calc
      edist (u k) p ≤ edist (u k) (u N) + d := edist_triangle _ _ _
      _ < 1 + d := ENNReal.add_lt_add_right hd (hN k hk)
      _ ≤ ENNReal.ofReal R := by
        dsimp [R]
        rw [ENNReal.ofReal_add ENNReal.toReal_nonneg (by norm_num), ENNReal.ofReal_toReal hd]
        norm_num
        simpa only [add_comm d] using add_le_add_left (by norm_num : (1 : ℝ≥0∞) ≤ 2) d
  obtain ⟨x, _, hx⟩ := (hcompact R hR).isComplete (map u atTop) hu
    (le_principal_iff.mpr htail)
  exact ⟨x, hx⟩

include hE hEp hEK hEstep hEcover hemb hlocal hbase herror in
theorem exists_eventually_compact_source_image_ball_bound [T3Space M] [PreconnectedSpace M]
    (hescape : ∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop, ∀ x ∈ frontier (E j),
      ENNReal.ofReal A ≤ (gSource k).edist (pSource k) (f k x))
    {K : Set M} (hK : IsCompact K) :
    ∃ R : ℝ, 0 < R ∧ ∀ᶠ k in atTop, f k '' K ⊆ (gSource k).ball (pSource k) R := by
  obtain ⟨a, ha⟩ := (hK.image (g.continuous_toReal_edist p)).bddAbove
  let R := max a 0 + 1
  have hR : 0 < R := by dsimp [R]; positivity
  have hKR : K ⊆ g.ball p R := by
    intro x hx
    change g.edist p x < ENNReal.ofReal R
    rw [ENNReal.lt_ofReal_iff_toReal_lt (g.edist_ne_top p x)]
    exact (ha (mem_image_of_mem _ hx)).trans_lt
      ((le_max_left a 0).trans_lt (lt_add_one _))
  have hcover := source_ball_coverage_of_boundary_escape gSource p pSource E
    hE hEp hEK hEstep f hemb hlocal hbase hescape
  have hcompact : IsCompact (closure (g.ball p R)) :=
    isCompact_closure_limit_ball_of_source_ball_coverage g gSource p pSource E
      hE hEK hEstep hEcover f hemb hlocal hbase herror hcover hR
  obtain ⟨j, hj⟩ := exists_exhaustion_superset E hE hEstep hEcover hcompact
  refine ⟨2 * R, by positivity, ?_⟩
  filter_upwards [herror _ hcompact 1 zero_lt_one, eventually_ge_atTop j] with k hk hjk
  have himage := image_ball_subset_of_tangentNorm_le_two g (gSource k) (f k) p R
    (fun x hx => (hlocal k ⟨x, exhaustion_monotone E hEstep hjk (hj (subset_closure hx))⟩).contMDiffAt)
    (fun x hx v => pullback_tangentNorm_le_two_of_unit_error g (gSource k) (f k) x
      (hk x (subset_closure hx)) v)
  rw [hbase k] at himage
  exact (image_mono hKR).trans himage

end Sequence

end PoincareMT.ControlledTerminal

namespace PoincareMT.M30CommonBlowupControls

noncomputable section
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

universe u

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

local instance (k : ℕ) : MetricSpace (S.terminalComponent k) :=
  (S.terminalCarrier k).metricSpaceOf (S.terminalComponentMetric k)

theorem exists_complete_terminal_metric_limit
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S) :
    ∃ sigma : ℕ → ℕ, StrictMono sigma ∧ ∃ L : FlowCarrier.{0} 3,
      letI : TopologicalSpace L.carrier := L.topologicalSpace
      letI : ChartedSpace (EuclideanSpace ℝ (Fin 3)) L.carrier := L.chartedSpace
      letI : IsManifold (𝓡 3) ∞ L.carrier := L.isManifold
      letI : T3Space L.carrier := L.t3Space
      ∃ (g : RiemannianMetric 3 L.carrier) (p : L.carrier)
        (E : ℕ → Set L.carrier) (f : ∀ k, L.carrier → S.terminalComponent (sigma k)),
        (∀ j, IsOpen (E j)) ∧ (∀ j, IsConnected (E j)) ∧
        (∀ j, p ∈ E j) ∧ (∀ j, IsCompact (closure (E j))) ∧
        (∀ j, closure (E j) ⊆ E (j + 1)) ∧ (⋃ j, E j) = univ ∧
        (∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x) ∧
          IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k) ∧
          f k p = S.terminalComponentBase (sigma k)) ∧
        (∀ q m K, IsCompact K → K ⊆ (extChartAt (𝓡 3) q).target →
          TendstoUniformlyOn
            (fun k => iteratedFDeriv ℝ m ((S.terminalComponentMetric (sigma k)).pullbackCoefficients
              (f k ∘ (extChartAt (𝓡 3) q).symm)))
            (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm)) atTop K) ∧
        (∀ K, IsCompact K → ∀ delta > 0, ∀ᶠ k in atTop,
          ∀ x ∈ K, ∀ v w : TangentSpace (𝓡 3) x,
            g.tangentNorm x v ≤ 1 → g.tangentNorm x w ≤ 1 →
            |(S.terminalComponentMetric (sigma k)).inner (f k x)
                (mfderiv (𝓡 3) (𝓡 3) (f k) x v)
                (mfderiv (𝓡 3) (𝓡 3) (f k) x w) - g.inner x v w| < delta) ∧
        (∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop, ∀ x ∈ frontier (E j),
          ENNReal.ofReal A ≤ (S.terminalComponentMetric (sigma k)).edist
            (S.terminalComponentBase (sigma k)) (f k x)) ∧
        MetricComplete g ∧
        (∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop,
          (S.terminalComponentMetric (sigma k)).ball (S.terminalComponentBase (sigma k)) A ⊆
            f k '' E j) ∧
        ∀ K : Set L.carrier, IsCompact K → ∃ R : ℝ, 0 < R ∧ ∀ᶠ k in atTop,
          f k '' K ⊆ (S.terminalComponentMetric (sigma k)).ball
            (S.terminalComponentBase (sigma k)) R := by
  obtain ⟨sigma, hsigma, L, g, p, E, f, hE, hEc, hEp, hEK, hEstep, hEcover,
    hf, hconv, herror, hescape⟩ := H.exists_terminal_metric_limit_with_escaping_boundaries P04 hbound
  let : TopologicalSpace L.carrier := L.topologicalSpace
  let : ChartedSpace (EuclideanSpace ℝ (Fin 3)) L.carrier := L.chartedSpace
  let : IsManifold (𝓡 3) ∞ L.carrier := L.isManifold
  let : T3Space L.carrier := L.t3Space
  let : PreconnectedSpace L.carrier := ⟨L.connected.isPreconnected⟩
  have hescape' : ∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop, ∀ x ∈ frontier (E j),
      ENNReal.ofReal A ≤ (S.terminalComponentMetric (sigma k)).edist
        (S.terminalComponentBase (sigma k)) (f k x) := hescape
  let gSource := fun k => S.terminalComponentMetric (sigma k)
  let pSource := fun k => S.terminalComponentBase (sigma k)
  have hemb := fun k => (hf k).1
  have hlocal := fun k => (hf k).2.1
  have hbase := fun k => (hf k).2.2
  refine ⟨sigma, hsigma, L, g, p, E, f, hE, hEc, hEp, hEK, hEstep,
    hEcover, hf, hconv, herror, hescape', ?_, ?_, ?_⟩
  · exact ControlledTerminal.metricComplete_of_boundary_escape g gSource p pSource E
      hE hEp hEK hEstep hEcover f hemb hlocal hbase herror hescape'
  · exact ControlledTerminal.source_ball_coverage_of_boundary_escape gSource p pSource E
      hE hEp hEK hEstep f hemb hlocal hbase hescape'
  · intro K hK
    exact ControlledTerminal.exists_eventually_compact_source_image_ball_bound
      g gSource p pSource E hE hEp hEK hEstep hEcover f hemb hlocal hbase herror hescape' hK

end

end PoincareMT.M30CommonBlowupControls
