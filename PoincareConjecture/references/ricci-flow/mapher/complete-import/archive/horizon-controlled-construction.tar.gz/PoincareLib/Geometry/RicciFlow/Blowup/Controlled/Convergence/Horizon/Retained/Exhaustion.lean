import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Retained.Cylinders

/-! # The retained spatial and temporal exhaustion of the full limit -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))
  (F₀ : RicciFlow 3 G.limitCarrier.carrier (Ioc (-tau 0 / 2) (tau 0 / 2)))
  (hF₀ : ∀ t ∈ Ioo (-tau 0 / 2) (tau 0 / 2), F₀.metric t = G.limitFlow.metricAt t)
  (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau ∪ {0}))
  (hmatch : ∀ t ∈ Ioc (-tau 0) 0, F.metric t = F₀.metric (t + tau 0 / 2))
  (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
  (htmono : StrictMono tau) (hB : ∀ j, 0 ≤ B j)
  {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
  (hjets : ∀ q r K, IsCompact K → K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target →
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ r (horizonSpacetimeCoefficients G q (sigma k)))
      (iteratedFDeriv ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)) atTop K)
  (heta : Tendsto eta atTop (𝓝 0))

local notation "theLimit" => liftedLimit (horizonLimit G F₀ hF₀ F hmatch P04 hAr hcompact
  hcomplete htmono.monotone hB hsigma hjets heta)

def horizonExhaustion : BlowupExhaustion theLimit where
  space := fun k => retainedSpace G (sigma k)
  space_open := fun k => retainedSpace_open G (sigma k)
  space_connected := fun k => retainedSpace_connected G (sigma k)
  space_compactClosure := fun k => retainedSpace_compactClosure G (sigma k)
  space_increasing := (retainedSpace_monotone G).comp hsigma.monotone
  space_covers := by
    apply eq_univ_of_forall
    intro x
    obtain ⟨j, hj⟩ := mem_iUnion.mp (show x ∈ ⋃ k, retainedSpace G k by rw [retainedSpace_covers]; trivial)
    exact mem_iUnion.mpr ⟨j, retainedSpace_monotone G (hsigma.id_le j) hj⟩
  base_mem := fun k => base_mem_retainedSpace G (sigma k)
  time := tau
  time_pos := htau
  time_increasing := htmono.monotone
  time_subset := horizon_window_interval_subset htmono
  time_cofinal := fun _ hI hIsub => (horizon_window_interval_strict_cofinal htau htmono.monotone hI hIsub).mono
    fun _ hk => hk.trans Ioc_subset_Icc_self

end PoincareMT.ControlledBlowupCompactness
