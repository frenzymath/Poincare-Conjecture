import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Retained.Cover
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Common.Continuity

/-! # Actual inherited necks on the metric-equal closed extension -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.EpsilonNeck

theorem exists_of_metric_eq_with_connection
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    [MeasurableSpace M] [BorelSpace M] [T2Space M] [T3Space M]
    {g h : RiemannianMetric 3 M} (heq : g = h) (N : EpsilonNeck g) (D : LeviCivitaData h) :
    ∃ N' : EpsilonNeck h,
      N'.epsilon = N.epsilon ∧ N'.center = N.center ∧ N'.connection = D := by
  subst h
  refine ⟨{ N with
    connection := D
    scalar_center_pos := ?_
    scale_eq_scalar := ?_ }, rfl, rfl, rfl⟩
  · rw [← N.connection.scalarCurvature_eq D N.center]
    exact N.scalar_center_pos
  · rw [← N.connection.scalarCurvature_eq D N.center]
    exact N.scale_eq_scalar

end PoincareMT.EpsilonNeck

namespace PoincareMT.M30CommonBlowupControls

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem retained_neck_control_on_closed_extension
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu T : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (F : RicciFlow 3 G.limit.carrier.carrier (Icc (-T) 0))
    (hmetric : ∀ t ∈ Ioc (-T) 0, F.metric t = G.limit.flow.metric t)
    (hNC : ¬ IsCompact (univ : Set G.limit.carrier.carrier))
    (hsmall : epsilon < 1 / 200)
    (hround : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold)
    {epsilon' : ℝ} (haccuracy : epsilon < epsilon') (hepsilon' : epsilon' < 1 / 2) :
    ∀ t ∈ Ioc (-T) 0, ∀ x : G.limit.carrier.carrier,
      4 < (F.connection t).scalarCurvature x →
      ∃ N : EpsilonNeck (F.metric t),
        N.epsilon = epsilon' ∧ N.connection = F.connection t ∧
        (F.metric t).edist x N.center ≤ ENNReal.ofReal
          ((4 * max C 1) * (F.connection t).scalarCurvature x ^ (-1 / 2 : ℝ)) ∧
        (F.connection t).scalarCurvature x ≤
          (4 * max C 1) * (F.connection t).scalarCurvature N.center := by
  let : ConnectedSpace G.limit.carrier.carrier := G.limit.connectedSpace
  intro t ht x hx
  have hscalar (y : G.limit.carrier.carrier) :
      (F.connection t).scalarCurvature y = (G.limit.flow.connection t).scalarCurvature y :=
    ControlledLongExtension.scalarCurvature_eq_of_metric_eq
      (F.connection t) (G.limit.flow.connection t) (hmetric t ht) y
  obtain ⟨N, hNe, _, hdist, hratio⟩ := H.retained_neck_scalar_and_center_control
    G hNC hsmall hround haccuracy hepsilon' t ht x (by rwa [← hscalar x])
  obtain ⟨N', he, hc, hD⟩ := N.exists_of_metric_eq_with_connection
    (hmetric t ht).symm (F.connection t)
  refine ⟨N', he.trans hNe, hD, ?_, ?_⟩
  · rw [hc, hscalar x, hmetric t ht]
    rw [← ENNReal.ofReal_toReal ((G.limit.flow.metric t).edist_ne_top x N.center)]
    exact ENNReal.ofReal_le_ofReal hdist
  · rw [hc, hscalar x, hscalar N.center]
    exact hratio

end PoincareMT.M30CommonBlowupControls
