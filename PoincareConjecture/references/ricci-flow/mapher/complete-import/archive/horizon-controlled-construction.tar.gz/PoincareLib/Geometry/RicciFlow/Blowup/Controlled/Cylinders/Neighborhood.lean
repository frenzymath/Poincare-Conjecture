import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Cylinders.Boxes
import Mathlib.Topology.Order.IntermediateValue

/-!
# Spatial neighborhoods of surviving worldlines

An actual compatible singleton trajectory on a closed backward interval has a
cylinder on a neighborhood of its terminal point for the same whole interval.
The local extensions use the original flow boxes. Reference: Morgan--Tian,
Theorem 11.1, pp. 268-271.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Function
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT.GeneralizedFlowCylinder

private theorem exists_terminal_box_neighborhood
    {F : GeneralizedRicciFlowData.{u}} {origin scale a c : ℝ}
    {x : (F.slice origin).carrier}
    (w : GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc a 0) {x})
    (ha : a ≤ 0)
    (hw0 : w.pointMap 0 ⟨ha, le_rfl⟩ x = (⟨origin, x⟩ : F.point))
    (hc : c ≤ 0) (b : F.box_index) (y : (F.box b).carrier.carrier)
    (hbox : ∀ s ∈ Icc c 0, origin + s / scale ∈ (F.box b).interval)
    (hxy : w.forward 0 ⟨ha, le_rfl⟩ x =
      (F.box b).forward _ (hbox 0 ⟨hc, le_rfl⟩) y) :
    ∃ V : Set (F.slice origin).carrier, IsOpen V ∧ x ∈ V ∧
      ∃ n : GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc c 0) V,
        ∀ y ∈ V, n.pointMap 0 ⟨hc, le_rfl⟩ y = (⟨origin, y⟩ : F.point) := by
  let d := ofBox b w.scale_pos hbox
  let e := d.zeroSliceHomeomorph isOpen_univ ⟨hc, le_rfl⟩
  have he : e y = x := by
    have hh := d.zeroSliceHomeomorph_pointMap isOpen_univ ⟨hc, le_rfl⟩ y
    have hh' : d.pointMap 0 ⟨hc, le_rfl⟩ y = w.pointMap 0 ⟨ha, le_rfl⟩ x :=
      congrArg (fun z => (⟨origin + 0 / scale, z⟩ : F.point)) hxy.symm
    exact eq_of_heq (Sigma.mk.inj_iff.mp (hh.symm.trans (hh'.trans hw0))).2
  refine ⟨e.target, e.open_target, ?_, d.rebaseAtZero isOpen_univ ⟨hc, le_rfl⟩,
    d.rebaseAtZero_identity isOpen_univ ⟨hc, le_rfl⟩⟩
  rw [← he]
  apply e.map_source
  rw [d.zeroSliceHomeomorph_source]
  exact mem_univ y

private theorem exists_extension_in_box
    {F : GeneralizedRicciFlowData.{u}} {origin scale a b c d : ℝ}
    {x : (F.slice origin).carrier} {V : Set (F.slice origin).carrier}
    (w : GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc a 0) {x})
    (ha : a ≤ 0)
    (hw0 : w.pointMap 0 ⟨ha, le_rfl⟩ x = (⟨origin, x⟩ : F.point))
    (old : GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc b 0) V)
    (hV : IsOpen V) (hxV : x ∈ V) (hab : a ≤ b) (hb : b ≤ 0)
    (hold : ∀ y ∈ V, old.pointMap 0 ⟨hb, le_rfl⟩ y = (⟨origin, y⟩ : F.point))
    (hcb : c ≤ b) (hbd : b < d) (hd : d ≤ 0)
    (B : F.box_index) (y : (F.box B).carrier.carrier)
    (hbox : ∀ s ∈ Icc c d, origin + s / scale ∈ (F.box B).interval)
    (hxy : w.forward b ⟨hab, hb⟩ x = (F.box B).forward _ (hbox b ⟨hcb, hbd.le⟩) y) :
    ∃ W : Set (F.slice origin).carrier, IsOpen W ∧ x ∈ W ∧
      ∃ n : GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc c 0) W,
        ∀ z ∈ W, n.pointMap 0 ⟨hcb.trans hb, le_rfl⟩ z = (⟨origin, z⟩ : F.point) := by
  let patch := ofBox B w.scale_pos hbox
  have heq : old.pointMap b ⟨le_rfl, hb⟩ x = patch.pointMap b ⟨hcb, hbd.le⟩ y := by
    have hh := old.pointMap_eq_on_overlap w ordConnected_Icc ordConnected_Icc hxV
      (mem_singleton x) ⟨hb, le_rfl⟩ ⟨ha, le_rfl⟩ ((hold x hxV).trans hw0.symm)
      b ⟨le_rfl, hb⟩ ⟨hab, hb⟩
    exact hh.trans (congrArg (fun z => (⟨origin + b / scale, z⟩ : F.point)) hxy)
  obtain ⟨W, hW, hxW, hWV, n, hn⟩ := old.exists_local_time_extension patch hV
    isOpen_univ hcb hbd hd ⟨le_rfl, hb⟩ ⟨hcb, hbd.le⟩ hxV (mem_univ y) heq
  exact ⟨W, hW, hxW, n, fun z hz => (hn 0 ⟨hb, le_rfl⟩ z hz).trans (hold z (hWV hz))⟩

/-- A compatible singleton trajectory survives on a spatial neighborhood of
its terminal point for its entire compact backward time interval. -/
theorem exists_neighborhood_of_singleton
    {F : GeneralizedRicciFlowData.{u}} {origin scale a : ℝ}
    {x : (F.slice origin).carrier}
    (w : GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc a 0) {x})
    (ha : a ≤ 0)
    (hw0 : w.pointMap 0 ⟨ha, le_rfl⟩ x = (⟨origin, x⟩ : F.point)) :
    ∃ V : Set (F.slice origin).carrier, IsOpen V ∧ x ∈ V ∧
      ∃ n : GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc a 0) V,
        (∀ y ∈ V, n.pointMap 0 ⟨ha, le_rfl⟩ y = (⟨origin, y⟩ : F.point)) ∧
        ∀ s (hs : s ∈ Icc a 0), n.pointMap s hs x = w.pointMap s hs x := by
  let P (b : ℝ) := ∃ hb : b ≤ 0,
    ∃ V : Set (F.slice origin).carrier, IsOpen V ∧ x ∈ V ∧
      ∃ n : GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc b 0) V,
        ∀ y ∈ V, n.pointMap 0 ⟨hb, le_rfl⟩ y = (⟨origin, y⟩ : F.point)
  have hzero : P 0 := by
    obtain ⟨B, y, δ, hδ, hnear⟩ :=
      w.vertical_compatibility 0 ⟨ha, le_rfl⟩ x (mem_singleton x)
    have hh := hnear 0 ⟨ha, le_rfl⟩ (by simpa using hδ)
    have hbox (s : ℝ) (hs : s ∈ Icc 0 0) : origin + s / scale ∈ (F.box B).interval := by
      have hs0 := le_antisymm hs.2 hs.1
      subst s
      exact hh.choose
    exact ⟨le_rfl, exists_terminal_box_neighborhood w ha hw0 le_rfl B y hbox hh.choose_spec⟩
  have hrestrict {b c : ℝ} (hp : P b) (hbc : b ≤ c) (hc : c ≤ 0) : P c := by
    obtain ⟨hb, V, hV, hxV, n, hn⟩ := hp
    exact ⟨hc, V, hV, hxV, n.restrict (Icc_subset_Icc_left hbc) Subset.rfl, hn⟩
  have hclosed : IsClosed ({b | P b} ∩ Icc a 0) := by
    apply isClosed_of_closure_subset
    intro t ht
    have htI : t ∈ Icc a 0 := isClosed_Icc.closure_subset_iff.mpr inter_subset_right ht
    refine ⟨?_, htI⟩
    rcases eq_or_lt_of_le htI.2 with rfl | ht0
    · exact hzero
    obtain ⟨B, y, δ, hδ, hnear⟩ :=
      w.vertical_compatibility t htI x (mem_singleton x)
    let r := min δ (-t) / 4
    have hr : 0 < r := div_pos (lt_min hδ (neg_pos.mpr ht0)) (by norm_num)
    have hrδ : 2 * r < δ := by
      have := min_le_left δ (-t)
      dsimp [r]
      linarith [lt_min hδ (neg_pos.mpr ht0)]
    have hr0 : t + 2 * r < 0 := by
      have := min_le_right δ (-t)
      dsimp [r]
      linarith [lt_min hδ (neg_pos.mpr ht0)]
    obtain ⟨b, hbO, hbP⟩ := mem_closure_iff.mp ht (Ioo (t - r) (t + r))
      isOpen_Ioo ⟨by linarith, by linarith⟩
    rcases le_total b t with hbt | htb
    · exact hrestrict hbP.1 hbt htI.2
    obtain ⟨hb, V, hV, hxV, old, hold⟩ := hbP.1
    have hbox (s : ℝ) (hs : s ∈ Icc t (t + 2 * r)) :
        origin + s / scale ∈ (F.box B).interval :=
      (hnear s ⟨htI.1.trans hs.1, hs.2.trans hr0.le⟩
        (abs_lt.mpr ⟨by linarith [hs.1], by linarith [hs.2]⟩)).choose
    have hbnear : |b - t| < δ := abs_lt.mpr ⟨by linarith [hbO.1], by linarith [hbO.2]⟩
    exact ⟨htI.2, exists_extension_in_box w ha hw0 old hV hxV hbP.2.1 hb hold
      htb (by linarith [hbO.2]) hr0.le B y hbox
      (hnear b hbP.2 hbnear).choose_spec⟩
  have hstep : ∀ b ∈ ({b | P b} : Set ℝ) ∩ Ioc a 0,
      (({b | P b} : Set ℝ) ∩ Ico a b).Nonempty := by
    intro b hb
    obtain ⟨B, y, δ, hδ, hnear⟩ :=
      w.vertical_compatibility b ⟨hb.2.1.le, hb.2.2⟩ x (mem_singleton x)
    let c := max a (b - δ / 2)
    have hac : a ≤ c := le_max_left _ _
    have hcb : c < b := max_lt hb.2.1 (by linarith)
    have hc0 : c ≤ 0 := hcb.le.trans hb.2.2
    have hclower : b - δ / 2 ≤ c := le_max_right _ _
    refine ⟨c, ?_, hac, hcb⟩
    rcases eq_or_lt_of_le hb.2.2 with hb0 | hb0
    · subst b
      have hbox (s : ℝ) (hs : s ∈ Icc c 0) : origin + s / scale ∈ (F.box B).interval :=
        (hnear s ⟨hac.trans hs.1, hs.2⟩
          (abs_lt.mpr ⟨by linarith [hs.1], by linarith [hs.2]⟩)).choose
      exact ⟨hc0, exists_terminal_box_neighborhood w ha hw0 hc0 B y hbox
        (hnear 0 ⟨ha, le_rfl⟩ (by simpa using hδ)).choose_spec⟩
    · let d := min 0 (b + δ / 2)
      have hbd : b < d := lt_min hb0 (by linarith)
      have hd0 : d ≤ 0 := min_le_left _ _
      have hdupper : d ≤ b + δ / 2 := min_le_right _ _
      have hbox (s : ℝ) (hs : s ∈ Icc c d) : origin + s / scale ∈ (F.box B).interval :=
        (hnear s ⟨hac.trans hs.1, hs.2.trans hd0⟩
          (abs_lt.mpr ⟨by linarith [hs.1], by linarith [hs.2]⟩)).choose
      obtain ⟨hb', V, hV, hxV, old, hold⟩ := hb.1
      exact ⟨hc0, exists_extension_in_box w ha hw0 old hV hxV hb.2.1.le hb' hold
        hcb.le hbd hd0 B y hbox
        (hnear b ⟨hb.2.1.le, hb.2.2⟩ (by simpa using hδ)).choose_spec⟩
  obtain ⟨_, V, hV, hxV, n, hn⟩ := hclosed.mem_of_ge_of_forall_exists_lt hzero ha hstep
  refine ⟨V, hV, hxV, n, hn, ?_⟩
  exact n.pointMap_eq_on_interval w ordConnected_Icc hxV (mem_singleton x)
    ⟨ha, le_rfl⟩ ((hn x hxV).trans hw0.symm)

end PoincareMT.GeneralizedFlowCylinder
