import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.Bound
import PoincareLib.Geometry.RicciFlow.Compactness.GeometricLimit.BoundaryCoverage

/-! # Compact scalar control from one point bounded through all backward times -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_uniform_compact_scalar_bound_of_point_bound
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {epsilon C : ℝ}
    (hM29 : ∀ S : GeneralizedBlowupSequence.{u},
      DenseGeneralizedBoundedDistanceHypotheses S epsilon C → GeneralizedBlowupBoundedDistance S)
    (H : DenseGeneralizedBoundedDistanceHypotheses S epsilon C)
    (y : G.limit.carrier.carrier) {B : ℝ}
    (hy : ∀ t ∈ Ioc (-T) 0, (G.limit.flow.connection t).scalarCurvature y ≤ B)
    {K : Set G.limit.carrier.carrier} (hK : IsCompact K) :
    ∃ D : ℝ, 0 < D ∧ ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
      (G.limit.flow.connection t).scalarCurvature x ≤ D := by
  let : ConnectedSpace G.limit.carrier.carrier := G.limit.connectedSpace
  obtain ⟨A, hA⟩ := hK.exists_bound_of_continuousOn
    ((G.limit.flow.metric 0).continuous_toReal_edist y).continuousOn
  let R := max A 0 + 1
  have hR : 0 < R := by dsimp [R]; positivity
  let U := (G.limit.flow.metric 0).ball y R
  have hKU : K ⊆ U := by
    intro x hx
    change (G.limit.flow.metric 0).edist y x < ENNReal.ofReal R
    rw [← ENNReal.ofReal_toReal ((G.limit.flow.metric 0).edist_ne_top y x)]
    apply (ENNReal.ofReal_lt_ofReal_iff hR).mpr
    have hh := ((le_abs_self _).trans (hA x hx)).trans (le_max_left A 0)
    dsimp [R]
    linarith
  have hyU : y ∈ U := by
    change (G.limit.flow.metric 0).edist y y < ENNReal.ofReal R
    simpa only [RiemannianMetric.edist, Manifold.riemannianEDist_self]
      using ENNReal.ofReal_pos.mpr hR
  have hUc : IsCompact (closure U) := (G.limit.flow.metric 0).isCompact_closure_ball_of_metricComplete
    (G.limit.complete 0 G.limit.zero_mem) y R
  have hUconn : IsPreconnected (closure U) := ((G.limit.flow.metric 0).isPreconnected_ball y R).closure
  obtain ⟨D, hD, hbound⟩ := G.exists_uniform_compact_scalar_bound_of_minimum_bound hT
    P04 P06 hM29 H hUc hUconn (fun t ht => ⟨y, subset_closure hyU, hy t ht⟩)
  exact ⟨D, hD, fun t ht x hx => hbound t ht x (subset_closure (hKU hx))⟩

end PoincareMT.GeneralizedBlowupConvergence
