import PoincareLib.Geometry.Riemannian.Metric.LocalDiffeomorph
import PoincareLib.Geometry.Manifold.OpenEmbedding
import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.AncientVolume.ScalarRatio.Annular.ChartFlow
import PoincareLib.Geometry.Manifold.InverseFunction.LocalDiffeomorph
import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Coordinates.PartialCharts

/-!
# The prescribed terminal metric on a coordinate neighborhood
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle

namespace PoincareMT.ControlledTerminal

variable {n : ℕ} {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
  (Phi : PartialDiffeomorph (𝓡 n) (𝓡 n) (EuclideanSpace ℝ (Fin n)) M ∞)
  (U : TopologicalSpace.Opens (EuclideanSpace ℝ (Fin n)))
  (hU : (U : Set (EuclideanSpace ℝ (Fin n))) ⊆ Phi.source)

include hU in
omit [IsManifold (𝓡 n) ∞ M] in
theorem partialChartMap_isLocalDiffeomorph :
    IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (fun x : U => Phi x) := by
  intro x
  exact (Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 n) U x).comp (𝓡 n) M
    ⟨Phi, hU x.property, Set.eqOn_refl _ _⟩

def partialChartMetric (g : RiemannianMetric n M) : RiemannianMetric n U :=
  g.pullbackOfLocalDiffeomorph (fun x : U => Phi x)
    (partialChartMap_isLocalDiffeomorph Phi U hU)

theorem partialChartMetric_inner (g : RiemannianMetric n M)
    (x : U) (v w : TangentSpace (𝓡 n) x) :
    (partialChartMetric Phi U hU g).inner x v w = g.pullbackCoefficients Phi x v w := by
  have hid : mfderiv (𝓡 n) (𝓡 n) (Subtype.val : U → EuclideanSpace ℝ (Fin n)) x =
      ContinuousLinearMap.id ℝ (EuclideanSpace ℝ (Fin n)) := by
    change mfderiv (𝓡 n) (𝓡 n) (extChartAt (𝓡 n) x) x = _
    exact mfderiv_extChartAt_self
  have hPhi := (Phi.contMDiffOn_toFun x (hU x.property)).contMDiffAt
    (Phi.open_source.mem_nhds (hU x.property))
  have hc := mfderiv_comp x (hPhi.mdifferentiableAt (by simp))
    ((contMDiff_subtype_val (I := 𝓡 n) (U := U) (n := ∞) x).mdifferentiableAt (by simp))
  have hc' : mfderiv (𝓡 n) (𝓡 n) (fun y : U => Phi y) x =
      mfderiv (𝓡 n) (𝓡 n) Phi (x : EuclideanSpace ℝ (Fin n)) := by
    ext a
    have ha := congrArg (fun A => A a) hc
    change mfderiv (𝓡 n) (𝓡 n) (fun y : U => Phi y) x a =
      mfderiv (𝓡 n) (𝓡 n) Phi (x : EuclideanSpace ℝ (Fin n))
        (mfderiv (𝓡 n) (𝓡 n) (Subtype.val : U → EuclideanSpace ℝ (Fin n)) x a) at ha
    rw [hid] at ha
    exact ha
  change g.inner (Phi x) (mfderiv (𝓡 n) (𝓡 n) (fun y : U => Phi y) x v)
    (mfderiv (𝓡 n) (𝓡 n) (fun y : U => Phi y) x w) = _
  rw [hc']
  rfl

/-- The inverse manifold chart as a smooth partial diffeomorphism. -/
def inverseMetricChart (q : M) :
    PartialDiffeomorph (𝓡 n) (𝓡 n) (EuclideanSpace ℝ (Fin n)) M ∞ :=
  AncientCompactness.partialDiffeomorphOfInjOn (isOpen_extChartAt_target q)
    (extChartAt (𝓡 n) q).symm (extChartAt (𝓡 n) q).symm.injOn (by
      apply Poincare.isLocalDiffeomorphOn_of_contMDiffOn_bijective_mfderiv
        (isOpen_extChartAt_target q) (contMDiffOn_extChartAt_symm q)
      intro x hx
      have hi : (mfderiv (𝓡 n) (𝓡 n) (extChartAt (𝓡 n) q).symm x).IsInvertible := by
        simpa only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] using
          isInvertible_mfderivWithin_extChartAt_symm (I := 𝓡 n) hx
      exact hi.bijective)

end PoincareMT.ControlledTerminal
