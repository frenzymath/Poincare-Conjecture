import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.StageCapture

/-!
# Controlled source sequences on a prescribed terminal stage

One precompact open comparison domain has a common cylinder duration and
curvature bound along a subsequence. The stage and the original terminal
metric parametrizations are retained exactly.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.M30CommonBlowupControls

open ControlledBlowupCylinder

theorem exists_source_sequence_on_terminal_stage
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    {M : Type v} [TopologicalSpace M] [Nonempty M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    (E : ℕ → Set M) (hE : ∀ j, IsOpen (E j)) (hmono : Monotone E)
    (hcover : ⋃ j, E j = univ) (f : ∀ k, M → S.terminalComponent (sigma k))
    (hemb : ∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x))
    (hlocal : ∀ k, IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k))
    (himage : ∀ K : Set M, IsCompact K → ∃ R : ℝ, 0 < R ∧
      ∀ᶠ k in atTop, ∀ x ∈ K, (f k x).val ∈ S.baseBall (sigma k) R)
    {U : Set M} (hU : IsOpen U) (hUc : IsCompact (closure U)) :
    ∃ A T B : ℝ, 0 < A ∧ 0 < T ∧ 0 < B ∧
      ∃ tau : ℕ → ℕ, StrictMono tau ∧
        ∃ cyl : ∀ i, ControlledBlowupCylinder S (sigma (tau i)) A T B 1,
        ∃ Phi : ∀ i, PartialDiffeomorph (𝓡 3) (𝓡 3) M
          (sourceBall S (sigma (tau i)) A) ∞,
          (∀ i, (Phi i).source = U) ∧
          (∀ i x, x ∈ U → (Phi i x).val = (f (tau i) x).val) ∧
          ∀ (hT : 0 < T) i q z, z ∈ (extChartAt (𝓡 3) q).target →
            (extChartAt (𝓡 3) q).symm z ∈ U →
            (((cyl i).ordinaryFlow hT).metric 0).pullbackCoefficients
                (Phi i ∘ (extChartAt (𝓡 3) q).symm) z =
              (S.terminalComponentMetric (sigma (tau i))).pullbackCoefficients
                (f (tau i) ∘ (extChartAt (𝓡 3) q).symm) z := by
  obtain ⟨A, hA, hcapture⟩ := ControlledTerminal.eventually_captured_terminal_stage
    sigma E hE hmono hcover f hemb hlocal himage hU hUc
  obtain ⟨T, B, hT, hB, hcyl⟩ := H.eventually_controlled_cylinders_on_fixed_ball
    P04 hbound A hA
  have hboth := (hsigma.tendsto_atTop.eventually (hcyl 1 zero_lt_one)).and
    (hcapture A le_rfl)
  obtain ⟨tau, htau, hselect⟩ := Poincare.exists_strictMono_forall_le_of_eventually
    (fun _ : ℕ => hboth)
  let cyl (i : ℕ) := Classical.choice (hselect i i le_rfl).1
  let Phi (i : ℕ) := (hselect i i le_rfl).2.choose
  have hPhi (i : ℕ) := (hselect i i le_rfl).2.choose_spec
  exact ⟨A, T, B, hA, hT, hB, tau, htau, cyl, Phi,
    fun i => (hPhi i).1, fun i => (hPhi i).2.1,
    fun hT' i => (hPhi i).2.2 T B 1 (cyl i) hT'⟩

end PoincareMT.M30CommonBlowupControls
