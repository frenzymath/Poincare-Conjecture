import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.JetPositivity
import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.AncientVolume.ScalarRatio.Annular.LimitCurvature
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.NegativeCurvature

/-!
# Curvature in shifted terminal coordinate realizations

Actual pullback metric germs retain scalar curvature, curvature norm, and
negative curvature part. Translating a moving coordinate point to zero
puts varying source carriers in the fixed space used by metric-jet limits.
Source: Morgan--Tian, Section 5.1, pp. 85--89.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledTerminal

theorem exists_shifted_pullback_realization
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {g : RiemannianMetric 3 M} (D : LeviCivitaData g)
    (phi : EuclideanSpace ℝ (Fin 3) → M) (x : EuclideanSpace ℝ (Fin 3))
    (hphi : ∀ᶠ y in 𝓝 x, ContMDiffAt (𝓡 3) (𝓡 3) ∞ phi y ∧
      Function.Injective (mfderiv (𝓡 3) (𝓡 3) phi y)) :
    ∃ gd : Σ h : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3)), LeviCivitaData h,
      (gd.1.euclideanCoefficients =ᶠ[𝓝 0]
        fun y => g.pullbackCoefficients phi (y + x)) ∧
      gd.2.scalarCurvature 0 = D.scalarCurvature (phi x) ∧
      gd.2.curvatureTensorNorm 0 = D.curvatureTensorNorm (phi x) ∧
      gd.2.negativeCurvaturePart 0 = D.negativeCurvaturePart (phi x) ∧
      (gd.2.NonnegativeCurvatureOperator 0 ↔ D.NonnegativeCurvatureOperator (phi x)) := by
  obtain ⟨V, hVphi, hVo, hxV⟩ := mem_nhds_iff.mp hphi
  let U := (fun y => y + x) ⁻¹' V
  have hU : IsOpen U := hVo.preimage (continuous_id.add continuous_const)
  have h0 : (0 : EuclideanSpace ℝ (Fin 3)) ∈ U := by
    simpa only [U, mem_preimage, zero_add] using hxV
  have hshift : ContMDiff (𝓡 3) (𝓡 3) ∞
      (fun y : EuclideanSpace ℝ (Fin 3) => y + x) :=
    (contDiff_id.add contDiff_const).contMDiff
  have hd (y) (hy : y ∈ U) :
      mfderiv (𝓡 3) (𝓡 3) (fun z => phi (z + x)) y =
        mfderiv (𝓡 3) (𝓡 3) phi (y + x) := by
    have hh := mfderiv_comp y ((hVphi hy).1.mdifferentiableAt (by simp))
      (hshift.mdifferentiable (by simp) y)
    change mfderiv (𝓡 3) (𝓡 3) (phi ∘ (fun z => z + x)) y = _
    rw [hh]
    ext v
    simp +instances [mfderiv_eq_fderiv, fderiv_add_const]
    rfl
  have hpos : ∀ y ∈ U, ∀ v, v ≠ 0 → 0 < g.pullbackCoefficients phi (y + x) v v := by
    intro y hy v hv
    apply g.pos (phi (y + x))
    intro hz
    apply hv
    apply (hVphi hy).2
    rw [map_zero]
    convert! hz using 1
  obtain ⟨h, Dh, W, hWo, h0W, hWU, heq⟩ := RiemannianMetric.exists_local_realization hU h0
    (fun y => g.pullbackCoefficients phi (y + x))
    (fun y hy => ((g.contDiffAt_pullbackCoefficients (hVphi hy).1).comp y
      (contDiff_id.add contDiff_const).contDiffAt).contDiffWithinAt)
    (fun y _ v w => g.symm _ _ _) hpos
  have hmap : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (fun y => phi (y + x)) W :=
    fun y hy => ((hVphi (hWU hy)).1.comp y hshift.contMDiffAt).contMDiffWithinAt
  have hmetric : ∀ y ∈ W, ∀ v w : TangentSpace (𝓡 3) y,
      h.inner y v w = g.inner (phi (y + x))
        (mfderiv (𝓡 3) (𝓡 3) (fun z => phi (z + x)) y v)
        (mfderiv (𝓡 3) (𝓡 3) (fun z => phi (z + x)) y w) := by
    intro y hy v w
    change h.euclideanCoefficients y v w = _
    rw [heq y hy, hd y (hWU hy)]
    rfl
  refine ⟨⟨h, Dh⟩, Filter.Eventually.mono (hWo.mem_nhds h0W) heq, ?_, ?_, ?_, ?_⟩
  · simpa only [zero_add] using Dh.scalarCurvature_eq_of_local_isometry D hWo hmap hmetric h0W
  · simpa only [zero_add] using Dh.curvatureTensorNorm_eq_of_local_isometry D hWo hmap hmetric h0W
  · simpa only [zero_add] using Dh.negativeCurvaturePart_eq_of_local_isometry D hWo hmap hmetric h0W
  · simpa only [zero_add] using
      Dh.nonnegativeCurvatureOperator_iff_of_local_isometry D hWo hmap hmetric h0W

theorem scalar_jets_of_bilinear_jets
    {α : Type*} {l : Filter α}
    {gseq : α → RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3))}
    {g : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3))}
    (x a b : EuclideanSpace ℝ (Fin 3)) (r : ℕ)
    (h : Tendsto (fun k => iteratedFDeriv ℝ r (gseq k).euclideanCoefficients x)
      l (𝓝 (iteratedFDeriv ℝ r g.euclideanCoefficients x))) :
    Tendsto (fun k => iteratedFDeriv ℝ r (fun y => (gseq k).inner y a b) x)
      l (𝓝 (iteratedFDeriv ℝ r (fun y => g.inner y a b) x)) := by
  let E := EuclideanSpace ℝ (Fin 3)
  let L : (E →L[ℝ] E →L[ℝ] ℝ) →L[ℝ] ℝ :=
    (ContinuousLinearMap.apply ℝ ℝ b).comp
      (ContinuousLinearMap.apply ℝ (E →L[ℝ] ℝ) a)
  have heq (g' : RiemannianMetric 3 E) :
      iteratedFDeriv ℝ r (fun y => g'.inner y a b) x =
        L.compContinuousMultilinearMap (iteratedFDeriv ℝ r g'.euclideanCoefficients x) := by
    ext v
    exact g'.iteratedFDeriv_inner_eq x a b r v
  have hpost := ((ContinuousLinearMap.compContinuousMultilinearMapL ℝ
    (fun _ : Fin r => E) (E →L[ℝ] E →L[ℝ] ℝ) ℝ L).continuous.tendsto _).comp h
  change Tendsto (fun k => L.compContinuousMultilinearMap
    (iteratedFDeriv ℝ r (gseq k).euclideanCoefficients x)) l
    (𝓝 (L.compContinuousMultilinearMap (iteratedFDeriv ℝ r g.euclideanCoefficients x))) at hpost
  rw [← heq g] at hpost
  exact hpost.congr (fun k => (heq (gseq k)).symm)

end PoincareMT.ControlledTerminal
