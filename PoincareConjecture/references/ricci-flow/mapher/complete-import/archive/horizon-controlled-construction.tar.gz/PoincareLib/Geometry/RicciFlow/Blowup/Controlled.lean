import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Ancient.Convergence
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.NonnegativeWindow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.FiniteCylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.LiftedLimit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Completeness
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Curvature.Inheritance
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Backward
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Bounds
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Limit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Source
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.ScalarBound
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.TimeControl
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.UniformBounds
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.ClosedJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.FiniteWindow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.FullHorizon
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Descent
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.EmbeddingCoefficients
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.ReferenceJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Restriction.Short
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourceCurvature
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourceDerivatives
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourcePositivity
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SpatialBounds
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.CurvatureNorm
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Derivatives
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Slabs
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.UniformCylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.ClosedLimit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Limit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.Carrier
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.NeckCover
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.PointControl
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Distance.Monotonicity
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Charts
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Common.Cylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Cylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.TerminalJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.CapExitCurvature
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.DistantCaps
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.DistantNecks
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.FarPoint
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.PathAvoidance
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.SeparatingNecks
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Horizon.Continuation
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Proof
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Short
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Subsequence
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Canonical
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.CanonicalNull
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Coordinates
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Capture
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.CapLimit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.ComponentRatio
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.MetricJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.MetricError
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Neck
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Normalization
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Transport
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NeckControl
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NullCover
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NullOrientation
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.ProductFactor

/-!
# Controlled generalized-flow blow-up estimates

These producers construct fixed-ball controlled cylinders, terminal chart
covers, complete terminal metrics with local backward flows, and exact
generalized convergence on the full prescribed horizon of geometric controls.
The short branch has one universal threshold and exact closed-time convergence.
Long-branch producers include controlled-center neck geometry, complete
backward boundary slices, and common source extensions from a global boundary
scalar bound. A maximal-horizon argument retains compatible source indices
and assembles noncollapse and ancient identification from finite extensions.
Actual canonical inheritance on the old limit and its backward boundary
completes `m30ControlledGeneralizedBlowupLimits`, with the unchanged public
type in `Controlled.Theory` and exactly the four frozen predecessor services.
-/
