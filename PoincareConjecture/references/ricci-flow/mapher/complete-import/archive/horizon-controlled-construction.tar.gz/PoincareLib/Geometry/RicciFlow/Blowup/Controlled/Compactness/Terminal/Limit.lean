import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Coefficients
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Extraction
import PoincareLib.Geometry.RicciFlow.Compactness.GeometricLimit.BoundaryCoverage

/-!
# The pointed terminal metric from common blow-up controls

Dense bounded-distance control, terminal volume, and M04 estimates construct
the normal charts used by the metric extractor. This theorem retains their
actual normalized source metrics, pointed embeddings, and escaping boundaries.
Reference: Morgan--Tian, Claim 11.5, p. 270.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter Metric
open scoped Manifold ContDiff Topology ENNReal

universe u

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

local instance (k : ℕ) : MetricSpace (S.terminalComponent k) :=
  (S.terminalCarrier k).metricSpaceOf (S.terminalComponentMetric k)

theorem exists_terminal_metric_limit_with_escaping_boundaries
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S) :
    ∃ sigma : ℕ → ℕ, StrictMono sigma ∧ ∃ L : FlowCarrier.{0} 3,
      letI : TopologicalSpace L.carrier := L.topologicalSpace
      letI : ChartedSpace (EuclideanSpace ℝ (Fin 3)) L.carrier := L.chartedSpace
      letI : IsManifold (𝓡 3) ∞ L.carrier := L.isManifold
      ∃ (g : RiemannianMetric 3 L.carrier) (p : L.carrier)
        (E : ℕ → Set L.carrier) (f : ∀ k, L.carrier → S.terminalComponent (sigma k)),
        (∀ j, IsOpen (E j)) ∧ (∀ j, IsConnected (E j)) ∧
        (∀ j, p ∈ E j) ∧ (∀ j, IsCompact (closure (E j))) ∧
        (∀ j, closure (E j) ⊆ E (j + 1)) ∧ (⋃ j, E j) = univ ∧
        (∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x) ∧
          IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k) ∧
          f k p = S.terminalComponentBase (sigma k)) ∧
        (∀ q m K, IsCompact K → K ⊆ (extChartAt (𝓡 3) q).target →
          TendstoUniformlyOn
            (fun k => iteratedFDeriv ℝ m ((S.terminalComponentMetric (sigma k)).pullbackCoefficients
              (f k ∘ (extChartAt (𝓡 3) q).symm)))
            (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm)) atTop K) ∧
        (∀ K, IsCompact K → ∀ delta > 0, ∀ᶠ k in atTop,
          ∀ x ∈ K, ∀ v w : TangentSpace (𝓡 3) x,
            g.tangentNorm x v ≤ 1 → g.tangentNorm x w ≤ 1 →
            |(S.terminalComponentMetric (sigma k)).inner (f k x)
                (mfderiv (𝓡 3) (𝓡 3) (f k) x v)
                (mfderiv (𝓡 3) (𝓡 3) (f k) x w) - g.inner x v w| < delta) ∧
        ∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop, ∀ x ∈ frontier (E j),
          ENNReal.ofReal A ≤ edist (S.terminalComponentBase (sigma k)) (f k x) := by
  classical
  obtain ⟨sigma, hsigma, R, rho, N, _B, hparams, _hB, hcovers⟩ :=
    H.exists_diagonal_terminal_normalChartCovers_with_metric_jets P04 hbound
  let cover := fun k j (hjk : j ≤ k) => (hcovers k j hjk).choose
  have hrho : ∀ j, 0 < rho j := fun j => (hparams j).1
  have hrhoR : ∀ j, rho j / 2 ≤ R j := by
    intro j
    linarith [(hparams j).1, (hparams j).2]
  let U := fun _ : ℕ => ball (0 : EuclideanSpace ℝ (Fin 3)) 1
  have hU : ∀ i, IsOpen (U i) := fun _ => isOpen_ball
  let : ∀ i, Nonempty (Poincare.Gluing.Piece U i) := fun _ => ⟨⟨0, by simp [U]⟩⟩
  let e := ControlledTerminal.chartMap cover hrho hrhoR
  choose Lip c hc hLip hlower using
    ControlledTerminal.chartMap_distance_bounds cover hrho hrhoR
  have hconn : ∀ k (p : S.terminalComponent (sigma k)) r,
      IsPreconnected (ball p r) := by
    intro k p r
    rw [FlowCarrier.metricBall_eq_metricBallOf (S.terminalCarrier (sigma k))
      (S.terminalComponentMetric (sigma k))]
    exact (S.terminalComponentMetric (sigma k)).isPreconnected_ball p r
  have hjets (i : ℕ) : Poincare.Analysis.Calculus.LocallyEventuallyBoundedDerivatives
      (U i) (fun k => (S.terminalComponentMetric (sigma k)).pullbackCoefficients
        (ChartDistance.chartParametrization U hU (i := i) (e k i))) := by
    apply ControlledTerminal.chartMap_eventually_bounded_derivatives cover hrho hrhoR i
    intro m
    let j := (Nat.unpair i).1
    obtain ⟨B, _hB, hjet⟩ := H.eventually_terminal_normalChartCover_metric_jet_bound
      P04 hbound (N := N j) (R := R j) (rho := rho j)
      (by positivity : 0 < (j : ℝ) + 1) (hrho j)
      (by linarith [hrho j, (hparams j).2]) m
    refine ⟨B, ?_⟩
    filter_upwards [hsigma.tendsto_atTop.eventually hjet] with k hk hkj l x hx
    exact hk (cover k j hkj) l x hx
  obtain ⟨tau, htau, L, g, p, E, f, hE, hEc, hEp, hEK, hEstep, hEcover,
      hf, hconv, htensor, hescape⟩ := ChartDistance.exists_pointed_metric_limit_of_controlled_charts
    U hU e Lip (fun k i => hLip i k) c hc (fun k i => hlower i k)
    (ControlledTerminal.chartMap_isOpenEmbedding cover hrho hrhoR) hconn
    (ControlledTerminal.chartMap_isLocalDiffeomorph cover hrho hrhoR)
    (ControlledTerminal.chartMap_pairwise_bounded cover hrho hrhoR Lip (fun k i => hLip i k))
    (i₀ := 0) ⟨0, by simp [U]⟩ (by
      simpa only [e, ControlledTerminal.chartMap_zero] using
        ControlledTerminal.chartMap_compact_cover cover hrho hrhoR)
    (fun k => S.terminalComponentMetric (sigma k)) hjets (by
      intro i K _hK hKU
      obtain ⟨a, ha, hbound⟩ :=
        ControlledTerminal.chartMap_eventually_lower_coefficients cover hrho hrhoR i
      exact ⟨a, ha, hbound.mono fun k hk x hx => hk x (hKU hx)⟩)
  let : TopologicalSpace L.carrier := L.topologicalSpace
  let : ChartedSpace (EuclideanSpace ℝ (Fin 3)) L.carrier := L.chartedSpace
  let : IsManifold (𝓡 3) ∞ L.carrier := L.isManifold
  refine ⟨sigma ∘ tau, hsigma.comp htau, L, g, p, E, f,
    hE, hEc, hEp, hEK, hEstep, hEcover, ?_, hconv, htensor, ?_⟩
  · intro k
    exact ⟨(hf k).1, (hf k).2.1, (hf k).2.2.trans
      (ControlledTerminal.chartMap_zero cover hrho hrhoR (tau k))⟩
  · simpa only [e, ControlledTerminal.chartMap_zero, Function.comp_apply] using hescape

end PoincareMT.M30CommonBlowupControls
