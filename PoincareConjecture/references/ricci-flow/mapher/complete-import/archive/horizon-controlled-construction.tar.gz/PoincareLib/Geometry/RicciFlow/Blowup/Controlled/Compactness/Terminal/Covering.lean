import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Charts
import PoincareLib.Geometry.Riemannian.Comparison.Covering
import PoincareLib.Geometry.Riemannian.Curvature.Bounds.Ricci
import PoincareLib.Geometry.Riemannian.Curvature.SectionalBounds

/-!
# Uniform finite covers of terminal balls

Local curvature and precompactness bound the number of small balls needed
to cover each normalized terminal ball. Source completeness is unnecessary.
Reference: Morgan--Tian Theorem 5.6, pp. 86-87, and Claim 11.5, p. 270.
-/

set_option autoImplicit false

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem eventually_uniform_terminal_finset_cover
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {A delta : ℝ} (hA : 0 < A) (hdelta : 0 < delta) :
    ∃ N : ℕ, ∀ᶠ k : ℕ in atTop,
      ∃ centers : Finset ((S.flow k).slice (S.base k).1).carrier,
        (↑centers : Set _) ⊆ S.baseBall k A ∧ centers.card ≤ N ∧
        S.baseBall k A ⊆ ⋃ x ∈ centers, (S.normalizedTerminalMetric k).ball x delta := by
  classical
  by_cases hdeltaA : delta ≤ A
  · obtain ⟨K, hK, hcurv⟩ := H.eventually_normalized_terminal_curvature_bound
      P04 hbound (5 * A) (by positivity)
    refine ⟨⌈RiemannianMetric.modelVolume 3 K (3 * A) /
      RiemannianMetric.modelVolume 3 K (delta / 2)⌉₊, ?_⟩
    filter_upwards [hcurv, H.balls_compact (5 * A) (by positivity)] with k hk hcompact
    let g := S.normalizedTerminalMetric k
    let D := S.normalizedTerminalConnection k
    have hRic : ∀ x ∈ g.ball (S.base k).2 (5 * A), ∀ v : TangentSpace (𝓡 3) x,
        -(((3 : ℝ) - 1) * K) * g.inner x v v ≤ D.ricci x v v := by
      intro x hx v
      have hx' : x ∈ S.baseBall k (5 * A) := by
        rwa [S.normalizedTerminalMetric_ball] at hx
      have hsec := fun u w =>
        (D.abs_sectionalCurvature_le_curvatureTensorNorm x u w).trans (hk x hx')
      simpa only [g, Nat.cast_ofNat, neg_mul] using
        D.ricci_quadratic_lower_bound_of_abs_sectionalCurvature_le x K hsec v
    have hc : IsCompact (closure (g.ball (S.base k).2 (5 * A))) := by
      rwa [S.normalizedTerminalMetric_ball]
    obtain ⟨centers, hcenters, hcard, _, hcover⟩ :=
      g.exists_finset_cover_of_precompact_ball (S.base k).2 (by norm_num)
        hA hdelta hdeltaA hK.le hc D hRic
    exact ⟨centers, by simpa only [g, S.normalizedTerminalMetric_ball] using hcenters,
      hcard, by simpa only [g, S.normalizedTerminalMetric_ball] using hcover⟩
  · refine ⟨1, Eventually.of_forall (fun k => ?_)⟩
    refine ⟨{(S.base k).2}, ?_, by simp, ?_⟩
    · intro x hx
      have hxb : x = (S.base k).2 := by simpa using hx
      simpa only [hxb] using S.base_mem_baseBall k hA
    · intro x hx
      refine mem_iUnion₂.mpr ⟨(S.base k).2, by simp, ?_⟩
      change (S.normalizedTerminalMetric k).edist (S.base k).2 x < ENNReal.ofReal delta
      rw [← S.normalizedTerminalMetric_ball] at hx
      exact hx.trans_le (ENNReal.ofReal_le_ofReal (lt_of_not_ge hdeltaA).le)

end PoincareMT.M30CommonBlowupControls
