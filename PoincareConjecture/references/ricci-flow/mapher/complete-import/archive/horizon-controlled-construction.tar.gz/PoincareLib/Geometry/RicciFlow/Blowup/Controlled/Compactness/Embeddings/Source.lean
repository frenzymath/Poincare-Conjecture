import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.FiniteWindow
import PoincareLib.Geometry.RicciFlow.Compactness.Convergence.Volume.SpatialEmbedding
import PoincareLib.Geometry.RicciFlow.Lift
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.NeckTransfer

/-!
# Original-carrier spatial maps of controlled cylinder limits

The source component inclusion and the universe identifications are actual
smooth partial coordinate maps. Composing them with the retained M07 map
puts each finite-window limit into the original generalized slice.
Source: Morgan--Tian, Theorems 5.15 and 11.8, pp. 92 and 274--279.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

private noncomputable def openInclusion
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] (U : Opens M) [Nonempty U] :
    PartialDiffeomorph (𝓡 3) (𝓡 3) U M ∞ := by
  let e := U.isOpen.isOpenEmbedding_subtypeVal.toOpenPartialHomeomorph
  exact {
    toPartialEquiv := e.toPartialEquiv
    open_source := e.open_source
    open_target := e.open_target
    contMDiffOn_toFun := contMDiff_subtype_val.contMDiffOn
    contMDiffOn_invFun := by
      intro y hy
      apply (ContMDiffWithinAt.subtypeVal_comp_iff U e.symm e.target y).mp
      apply contMDiffWithinAt_id.congr
      · intro z hz
        exact e.right_inv hz
      · exact e.right_inv hy }

private theorem openInclusion_source
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] (U : Opens M) [Nonempty U] :
    (openInclusion U).source = univ := rfl

private theorem openInclusion_target
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] (U : Opens M) [Nonempty U] :
    (openInclusion U).target = U := by
  simp only [openInclusion, Topology.IsOpenEmbedding.toOpenPartialHomeomorph_target]
  ext x
  constructor
  · rintro ⟨y, rfl⟩
    exact y.property
  · intro hx
    exact ⟨⟨x, hx⟩, rfl⟩

def liftedCarrier (C : FlowCarrier.{0} 3) : FlowCarrier.{u} 3 := by
  let : ConnectedSpace C.carrier := connectedSpace_iff_univ.mpr C.connected
  let : ConnectedSpace (ULift.{u} C.carrier) :=
    Homeomorph.ulift.connectedSpace_iff.mpr inferInstance
  let : SecondCountableTopology (ULift.{u} C.carrier) :=
    Homeomorph.ulift.secondCountableTopology
  exact {
    carrier := ULift.{u} C.carrier
    topologicalSpace := inferInstance
    measurableSpace := inferInstance
    borelSpace := inferInstance
    chartedSpace := inferInstance
    isManifold := inferInstance
    t2Space := inferInstance
    t3Space := inferInstance
    secondCountable := inferInstance
    connected := isConnected_univ }

def liftedSliceCarrier (C : FlowCarrier.{0} 3) : GeneralizedSliceCarrier.{u} where
  carrier := (liftedCarrier.{u} C).carrier
  topologicalSpace := (liftedCarrier.{u} C).topologicalSpace
  measurableSpace := (liftedCarrier.{u} C).measurableSpace
  borelSpace := (liftedCarrier.{u} C).borelSpace
  chartedSpace := (liftedCarrier.{u} C).chartedSpace
  isManifold := (liftedCarrier.{u} C).isManifold
  t2Space := (liftedCarrier.{u} C).t2Space
  t3Space := (liftedCarrier.{u} C).t3Space
  secondCountable := (liftedCarrier.{u} C).secondCountable

open ControlledBlowupCylinder

noncomputable def smallSourceCoordinate
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ) {A : ℝ} (hA : 0 < A) :
    PartialDiffeomorph (𝓡 3) (𝓡 3) (componentCarrier S k hA).shrink.carrier
      ((S.flow k).slice (S.base k).1).carrier ∞ := by
  let : Nonempty (sourceBall S k A) := ⟨sourceBase S k hA⟩
  let : Nonempty (componentCarrier S k hA).carrier := ⟨componentBase S k hA⟩
  exact ((Poincare.Manifold.shrinkDiffeomorph (𝓡 3)
    (componentCarrier S k hA).carrier).symm.toPartialDiffeomorph.trans
      (openInclusion (Poincare.connectedComponentOpens
        (EuclideanSpace ℝ (Fin 3)) (sourceBase S k hA)))).trans
          (openInclusion (sourceBall S k A))

theorem smallSourceCoordinate_apply
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ) {A : ℝ} (hA : 0 < A)
    (x : (componentCarrier S k hA).shrink.carrier) :
    smallSourceCoordinate S k hA x =
      ((equivShrink (componentCarrier S k hA).carrier).symm x).val.val := rfl

theorem smallSourceCoordinate_source
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ) {A : ℝ} (hA : 0 < A) :
    (smallSourceCoordinate S k hA).source = univ := by
  ext x
  change ((x ∈ univ ∧ _ ∈ univ) ∧ _ ∈ univ) ↔ x ∈ univ
  simp

theorem smallSourceCoordinate_target_subset
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ) {A : ℝ} (hA : 0 < A) :
    (smallSourceCoordinate S k hA).target ⊆ S.baseBall k A := by
  let : Nonempty (sourceBall S k A) := ⟨sourceBase S k hA⟩
  intro x hx
  have hx' : x ∈ (openInclusion (sourceBall S k A)).target := hx.1
  rwa [openInclusion_target] at hx'

end PoincareMT.ControlledBlowupCompactness
