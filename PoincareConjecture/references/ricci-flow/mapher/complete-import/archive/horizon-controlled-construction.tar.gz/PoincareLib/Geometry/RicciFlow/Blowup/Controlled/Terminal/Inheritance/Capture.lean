import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Separation.Diameter
import PoincareLib.Topology.Manifold.NeckCap.Cap.Bounds

/-!
# Uniform ball capture of necks and caps

A positive lower scalar bound at the selected point bounds the radius of
the entire neighborhood, including its closure. These bounds turn pointed
source-ball coverage into capture of varying canonical neighborhoods.

Reference: Morgan--Tian, Claim 11.6 and Proposition 9.79(3).
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle ENNReal

universe u

namespace PoincareMT

variable {M : Type u} [TopologicalSpace M] [T3Space M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
  [MeasurableSpace M] [BorelSpace M]
  {g : RiemannianMetric 3 M}

theorem EpsilonNeck.edist_center_le_on_closure_of_scalar_lower
    (N : EpsilonNeck g) {l : ℝ} (hl : 0 < l)
    (hscalar : l ≤ N.connection.scalarCurvature N.center)
    {y : M} (hy : y ∈ closure N.carrier) :
    g.edist N.center y ≤
      ENNReal.ofReal ((2 * Real.pi + 2 * N.epsilon⁻¹) * l ^ (-1 / 2 : ℝ)) := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
    ⟨g.toRiemannianMetric⟩
  let : IsContinuousRiemannianBundle (EuclideanSpace ℝ (Fin 3))
      (TangentSpace (𝓡 3) : M → Type _) :=
    ⟨⟨g.inner, g.toContinuousRiemannianMetric.continuous, fun _ _ _ => rfl⟩⟩
  let : EMetricSpace M := EMetricSpace.ofRiemannianMetric (𝓡 3) M
  have hscale : N.scale ≤ l ^ (-1 / 2 : ℝ) := by
    rw [N.scale_eq_scalar]
    exact Real.rpow_le_rpow_of_nonpos hl hscalar (by norm_num)
  apply closure_minimal (s := N.carrier) ?_
    (isClosed_le (continuous_const.edist continuous_id) continuous_const) hy
  intro z hz
  exact (N.edist_center_le_of_mem_carrier hz).trans
    (ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_left hscale
      (by positivity [Real.pi_pos, N.epsilon_pos])))

theorem EpsilonNeck.closure_carrier_subset_ball_of_scalar_lower
    (N : EpsilonNeck g) {l A : ℝ} (hl : 0 < l) (hA : 0 ≤ A)
    (hscalar : l ≤ N.connection.scalarCurvature N.center)
    (p : M) (hcenter : g.edist p N.center ≤ ENNReal.ofReal A) :
    closure N.carrier ⊆ g.ball p
      (A + (2 * Real.pi + 2 * N.epsilon⁻¹) * l ^ (-1 / 2 : ℝ) + 1) := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
    ⟨g.toRiemannianMetric⟩
  intro y hy
  have hB : 0 ≤ (2 * Real.pi + 2 * N.epsilon⁻¹) * l ^ (-1 / 2 : ℝ) := by
    positivity [Real.pi_pos, N.epsilon_pos]
  have hdist := (Manifold.riemannianEDist_triangle (x := p) (y := N.center) (z := y)).trans
    (add_le_add hcenter (N.edist_center_le_on_closure_of_scalar_lower hl hscalar hy))
  rw [← ENNReal.ofReal_add hA hB] at hdist
  exact hdist.trans_lt ((ENNReal.ofReal_lt_ofReal_iff (by positivity)).2 (by linarith))

theorem CapCertificate.closure_carrier_subset_ball_of_scalar_lower
    [T2Space M]
    (N : CapCertificate g) {l A C : ℝ} (hl : 0 < l) (hA : 0 ≤ A)
    (hconstant : N.cap_constant ≤ C) {x : M} (hx : x ∈ N.carrier)
    (hscalar : l ≤ N.connection.scalarCurvature x)
    (p : M) (hcenter : g.edist p x ≤ ENNReal.ofReal A) :
    closure N.carrier ⊆ g.ball p (A + C * l ^ (-1 / 2 : ℝ) + 1) := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
    ⟨g.toRiemannianMetric⟩
  have hC : 0 < C := N.cap_constant_pos.trans_le hconstant
  have hpower : N.connection.scalarCurvature x ^ (-1 / 2 : ℝ) ≤ l ^ (-1 / 2 : ℝ) :=
    Real.rpow_le_rpow_of_nonpos hl hscalar (by norm_num)
  intro y hy
  have hny := (N.edist_le_of_mem_closure hconstant hx hy).trans
    (ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_left hpower hC.le))
  have hB : 0 ≤ C * l ^ (-1 / 2 : ℝ) := by positivity
  have hdist := (Manifold.riemannianEDist_triangle (x := p) (y := x) (z := y)).trans
    (add_le_add hcenter hny)
  rw [← ENNReal.ofReal_add hA hB] at hdist
  exact hdist.trans_lt ((ENNReal.ofReal_lt_ofReal_iff (by positivity)).2 (by linarith))

end PoincareMT
