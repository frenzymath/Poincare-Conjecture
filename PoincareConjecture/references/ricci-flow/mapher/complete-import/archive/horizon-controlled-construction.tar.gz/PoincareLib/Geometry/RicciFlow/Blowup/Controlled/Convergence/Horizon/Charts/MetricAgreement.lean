import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.Carrier
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.InitialAgreement

/-! # Exact metric agreement on the initial backward window -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT

theorem RiemannianMetric.eq_of_covering_coordinate_coefficients
    {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
    [IsManifold (𝓡 3) ∞ M] (g h : RiemannianMetric 3 M) (q : ℕ → M)
    (hcover : ∀ x : M, ∃ i, x ∈ (extChartAt (𝓡 3) (q i)).source)
    (hcoeff : ∀ i x, x ∈ (extChartAt (𝓡 3) (q i)).target → ∀ v w,
      g.pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm x v w =
        h.pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm x v w) : g = h := by
  have hinner : g.inner = h.inner := by
    funext y
    ext v w
    obtain ⟨i, hi⟩ := hcover y
    let c := extChartAt (𝓡 3) (q i)
    have hx : c y ∈ c.target := c.map_source hi
    have hinv := isInvertible_mfderivWithin_extChartAt_symm hx
    simp only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] at hinv
    obtain ⟨a, ha⟩ := hinv.surjective v
    obtain ⟨b, hb⟩ := hinv.surjective w
    change mfderiv (𝓡 3) (𝓡 3) c.symm (c y) a = v at ha
    change mfderiv (𝓡 3) (𝓡 3) c.symm (c y) b = w at hb
    have heq := hcoeff i (c y) hx a b
    change g.inner (c.symm (c y)) (mfderiv (𝓡 3) (𝓡 3) c.symm (c y) a)
      (mfderiv (𝓡 3) (𝓡 3) c.symm (c y) b) =
      h.inner (c.symm (c y)) (mfderiv (𝓡 3) (𝓡 3) c.symm (c y) a)
        (mfderiv (𝓡 3) (𝓡 3) c.symm (c y) b) at heq
    have hcy : c.symm (c y) = y := c.left_inv hi
    have hform : (show EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ
        from g.inner (c.symm (c y))) = g.inner y := congrArg (fun z =>
      show EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ from g.inner z) hcy
    have hform' : (show EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ
        from h.inner (c.symm (c y))) = h.inner y := congrArg (fun z =>
      show EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ from h.inner z) hcy
    exact (congrArg₂ (fun (a b : EuclideanSpace ℝ (Fin 3)) =>
      g.inner y a b = h.inner y a b) ha hb).mp
        ((congrArg₂ (fun (g h : EuclideanSpace ℝ (Fin 3) →L[ℝ]
          EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ) =>
          g (mfderiv (𝓡 3) (𝓡 3) c.symm (c y) a) (mfderiv (𝓡 3) (𝓡 3) c.symm (c y) b) =
          h (mfderiv (𝓡 3) (𝓡 3) c.symm (c y) a) (mfderiv (𝓡 3) (𝓡 3) c.symm (c y) b))
          hform hform').mp heq)
  cases g
  cases h
  congr

namespace ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

theorem horizon_flow_metric_eq_initial
    (htmono : Monotone tau) (q : ℕ → G.limitCarrier.carrier)
    (hcover : ∀ x : G.limitCarrier.carrier, ∃ i, x ∈ (extChartAt (𝓡 3) (q i)).source)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    (f : ℕ → ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3)
    (hpoint : ∀ i z, z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target →
      Tendsto (fun k => horizonSpacetimeCoefficients G (q i) (sigma k) z) atTop (𝓝 (f i z)))
    (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau))
    (hF : ∀ t ∈ horizonOpenTime tau, ∀ i x, x ∈ (extChartAt (𝓡 3) (q i)).target → ∀ v w,
      f i (t, x) v w = (F.metric t).pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm x v w)
    {s : ℝ} (hs : s ∈ Ioo (-tau 0) 0) : F.metric s = G.limitFlow.metricAt (s + tau 0 / 2) := by
  apply RiemannianMetric.eq_of_covering_coordinate_coefficients _ _ q hcover
  intro i x hx v w
  rw [← hF s (mem_iUnion.mpr ⟨0, hs⟩) i x hx v w,
    horizon_limit_eq_initial G htmono (q i) hsigma (hpoint i) hs hx]

end ControlledBlowupCompactness
end PoincareMT
