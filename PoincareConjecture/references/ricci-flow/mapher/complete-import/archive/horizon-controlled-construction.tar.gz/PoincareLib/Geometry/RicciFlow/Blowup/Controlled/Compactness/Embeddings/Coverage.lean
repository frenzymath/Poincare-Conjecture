import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Retained
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Balls
import PoincareLib.Geometry.RicciFlow.Compactness.Convergence.Volume.SourceBalls

/-!
# Coverage of original terminal balls by retained cylinders

Complete interior limits cover fixed balls in their source flows. Uniform
metric comparison transfers this coverage to the original terminal slice.
Source: Morgan--Tian, Theorem 11.8, pp. 274--279.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

open ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

theorem eventually_baseBall_subset_retainedSource_image
    (hAr : Tendsto A atTop atTop)
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    {r : ℝ} (hr : 0 < r) :
    ∀ᶠ k in atTop, S.baseBall (idx (G.subsequence k)) r ⊆
      retainedSourceCoordinate G k '' (ULift.down ⁻¹' G.exhaustion k) := by
  let R := Real.exp (3 * B * |(-T / 2)|) * r
  have hR : 0 < R := mul_pos (Real.exp_pos _) hr
  have ht : (0 : ℝ) ∈ Ioo (-T / 2) (T / 2) := ⟨by linarith, by linarith⟩
  have hcompact : IsCompact (closure (G.limitFlow.ballAt 0 (2 * R))) :=
    (G.limitFlow.metricAt 0).isCompact_closure_ball_of_metricComplete
      hcomplete G.limitFlow.base (2 * R)
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset hcompact
  have hidx : Tendsto (fun k => A (G.subsequence k)) atTop atTop :=
    hAr.comp G.subsequence_strictMono.tendsto_atTop
  filter_upwards [hidx.eventually_ge_atTop r, eventually_ge_atTop j,
    G.eventually_source_ball_subset_image_ball ht ht hcomplete hR (by norm_num : (1 : ℝ) < 2)]
    with k hkA hjk hk
  intro x hx
  rw [← smallSourceCoordinate_terminal_image_ball (e (G.subsequence k))
    (hA (G.subsequence k)) hT hkA] at hx
  obtain ⟨y, hy, rfl⟩ := hx
  have hys : y ∈ ((interiorSequence S idx A eta T B hA hT e).flow (G.subsequence k)).ballAt 0 R := by
    have h := smallFlow_ball_subset_other_time (e (G.subsequence k))
      (hA (G.subsequence k)) hT (show (0 : ℝ) ∈ Icc (-T) 0 by constructor <;> linarith)
      (show (-T / 2) ∈ Icc (-T) 0 by constructor <;> linarith) r hy
    simpa only [interiorSequence, BasedFlow.ballAt, BasedFlow.metricAt, FlowCarrier.metricBall,
      RicciFlow.translate, zero_add, sub_zero, R] using h
  obtain ⟨z, hz, heq⟩ := hk hys
  refine ⟨ULift.up z, (hj.trans (G.exhaustion_monotone hjk)) (subset_closure hz), ?_⟩
  rw [retainedSourceCoordinate_apply]
  exact congrArg (smallSourceCoordinate S (idx (G.subsequence k)) (hA (G.subsequence k))) heq

theorem retainedCylinder_eventually_covers_baseBall
    (hAr : Tendsto A atTop atTop)
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    {r : ℝ} (hr : 0 < r) :
    ∀ᶠ k in atTop, ∀ x ∈ S.baseBall (idx (G.subsequence k)) r,
      ∃ y ∈ (ULift.down ⁻¹' G.exhaustion k), ∃ hzero,
        (retainedCylinder G k).pointMap 0 hzero y =
          (⟨(S.base (idx (G.subsequence k))).1, x⟩ : (S.flow (idx (G.subsequence k))).point) := by
  filter_upwards [eventually_baseBall_subset_retainedSource_image G hAr hcomplete hr]
    with k hk
  intro x hx
  obtain ⟨y, hy, rfl⟩ := hk hx
  have hzero : (0 : ℝ) ∈ Icc (-T) 0 := ⟨by linarith, le_rfl⟩
  refine ⟨y, hy, hzero, ?_⟩
  change (e (G.subsequence k)).embedding.pointMap 0 hzero (retainedSourceCoordinate G k y) = _
  apply (e (G.subsequence k)).zero_identity hzero
  apply retainedSourceCoordinate_target_subset G k
  apply (retainedSourceCoordinate G k).map_source
  rwa [retainedSourceCoordinate_source]

end PoincareMT.ControlledBlowupCompactness
