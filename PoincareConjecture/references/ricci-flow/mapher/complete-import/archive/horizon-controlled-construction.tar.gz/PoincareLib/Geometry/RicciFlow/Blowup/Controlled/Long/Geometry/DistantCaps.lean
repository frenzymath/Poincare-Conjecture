import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.DistantTriangles
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.CapExitCurvature

/-!
# Uniform past scalar bounds on distant cap cores

The universal small-cap threshold is selected before the flow and its past
interval. Beyond a fixed terminal radius, actual cap cores have uniformly
bounded scalar curvature at every time in that interval.
Reference: Morgan--Tian, Claims 11.13--11.14, pp. 276--277.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongGeometry

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem exists_uniform_past_distant_cap_core_scalar_bound :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 1000 ∧
      ∀ (_P04 : RicciFlowCurvatureTheory.{u}) (_P06 : HarnackAncientTheory.{u})
        {T : ℝ}, 0 < T → ∀ (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
        (p : L.carrier.carrier) {B : ℝ}, 0 < B →
        ∃ A D : ℝ, 0 < A ∧ 0 < D ∧ ∀ y : L.carrier.carrier,
          A ≤ ((L.flow.metric 0).edist p y).toReal →
          ∀ t ∈ Ioc (-T) 0, ∀ C : CapCertificate (L.flow.metric t),
            C.epsilon ≤ epsilon₀ → C.cap_constant ≤ B → y ∈ C.core →
            (L.flow.connection t).scalarCurvature y ≤ D := by
  obtain ⟨epsilon₀, hepsilon₀, hsmall, hcap⟩ :=
    CapCertificate.exists_large_triangle_core_scalar_bound_threshold.{u}
  refine ⟨epsilon₀, hepsilon₀, hsmall, ?_⟩
  intro P04 P06 T hT L p B hB
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  obtain ⟨A, hA, htriangle⟩ := exists_uniform_past_large_triangles P04 P06 hT L p
  refine ⟨A, (B / A) ^ 2, hA, sq_pos_of_pos (div_pos hB hA), ?_⟩
  intro y hy t ht C hCepsilon hCB hyC
  obtain ⟨z, hz⟩ := htriangle y hy
  obtain ⟨ha, hb, ha', hb', hfar⟩ := hz t ht
  have hd : 0 < ((L.flow.metric 0).edist p y).toReal := hA.trans_le hy
  have hsec : (L.flow.connection t).NonnegativeSectionalCurvature := fun x v w =>
    (L.flow.connection t).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
      x (L.nonnegative_curvature_operator t ht x) v w
  have hbound := hcap C hCepsilon (L.flow.connection t) (L.complete t ht) hsec
    hd hCB ha hb ha' hb' hfar hyC
  apply hbound.le.trans
  exact (sq_le_sq₀ (div_pos hB hd).le (div_pos hB hA).le).mpr
    (div_le_div_of_nonneg_left hB.le hA hy)

end PoincareMT.ControlledLongGeometry
