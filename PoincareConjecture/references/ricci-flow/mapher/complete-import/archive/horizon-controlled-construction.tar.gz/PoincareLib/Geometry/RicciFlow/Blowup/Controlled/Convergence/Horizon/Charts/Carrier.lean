import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.MetricFamily
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.Flow

/-! # The full open-horizon Ricci flow on the retained carrier -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

theorem horizonOpenTime_ordConnected (tau : ℕ → ℝ) : OrdConnected (horizonOpenTime tau) := by
  constructor
  intro x hx y hy z hz
  obtain ⟨i, hi⟩ := mem_iUnion.mp hx
  obtain ⟨j, hj⟩ := mem_iUnion.mp hy
  exact mem_iUnion.mpr ⟨i, ⟨hi.1.trans_le hz.1, hz.2.trans_lt hj.2⟩⟩

theorem horizonOpenTime_nontrivial {tau : ℕ → ℝ} (htau : 0 < tau 0) :
    (horizonOpenTime tau).Nontrivial :=
  ⟨-tau 0 / 2, mem_iUnion.mpr ⟨0, ⟨by linarith, by linarith⟩⟩,
    -tau 0 / 3, mem_iUnion.mpr ⟨0, ⟨by linarith, by linarith⟩⟩, by linarith⟩

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

/-- Positive compatible horizon chart limits satisfy the Ricci equation on
the entire open horizon, on the exact original pointed limit carrier. -/
theorem exists_horizon_flow_of_chart_limits
    (htmono : Monotone tau) (hB : ∀ j, 0 ≤ B j)
    (q : ℕ → G.limitCarrier.carrier)
    (hcover : ∀ x : G.limitCarrier.carrier, ∃ i, x ∈ (extChartAt (𝓡 3) (q i)).source)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    (f : ℕ → ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3)
    (hf : ∀ i, ContDiffOn ℝ ∞ (f i) (horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target))
    (hjets : ∀ i m K, IsCompact K →
      K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target → TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ m (horizonSpacetimeCoefficients G (q i) (sigma k)))
        (iteratedFDeriv ℝ m (f i)) atTop K) :
    ∃ F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau),
      ∀ t ∈ horizonOpenTime tau, ∀ i x, x ∈ (extChartAt (𝓡 3) (q i)).target → ∀ v w,
        f i (t, x) v w = (F.metric t).pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm x v w := by
  classical
  have hpoint (i : ℕ) (z : ℝ × EuclideanSpace ℝ (Fin 3))
      (hz : z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target) :
      Tendsto (fun k => horizonSpacetimeCoefficients G (q i) (sigma k) z) atTop (𝓝 (f i z)) := by
    have he := (ContinuousMultilinearMap.uniformContinuous_eval_const
      (0 : Fin 0 → ℝ × EuclideanSpace ℝ (Fin 3))).comp_tendstoUniformlyOn
        (hjets i 0 {z} isCompact_singleton (singleton_subset_iff.mpr hz))
    simpa only [Function.comp_apply, iteratedFDeriv_zero_apply] using he.tendsto_at (mem_singleton z)
  obtain ⟨g, hg, hgcoeff⟩ := exists_horizon_metricFamily G htmono hB q hcover hsigma f hf hpoint
  choose chartIndex hchartIndex using hcover
  let P := horizonOpenTime tau × G.limitCarrier.carrier
  let j (p : P) := chartIndex p.2
  let x₀ (p : P) := extChartAt (𝓡 3) (q (j p)) p.2
  have hcenter (p : P) : x₀ p ∈ (extChartAt (𝓡 3) (q (j p))).target :=
    (extChartAt (𝓡 3) (q (j p))).map_source (hchartIndex p.2)
  have hexrho (p : P) : ∃ rho : ℝ, 0 < rho ∧
      closedBall (x₀ p) rho ⊆ (extChartAt (𝓡 3) (q (j p))).target := by
    obtain ⟨r, hr, hrc⟩ := Metric.mem_nhds_iff.mp
      ((isOpen_extChartAt_target (q (j p))).mem_nhds (hcenter p))
    exact ⟨r / 2, by positivity,
      (closedBall_subset_ball (by linarith : r / 2 < r)).trans hrc⟩
  choose rho hrho hchart using hexrho
  have hextime (p : P) : ∃ a b : ℝ, a < p.1.val ∧ p.1.val < b ∧
      Icc a b ⊆ horizonOpenTime tau := by
    obtain ⟨i, hi⟩ := mem_iUnion.mp p.1.property
    refine ⟨(-tau i + p.1.val) / 2, p.1.val / 2, by linarith [hi.1], by linarith [hi.2], ?_⟩
    intro s hs
    exact mem_iUnion.mpr ⟨i, ⟨by linarith [hi.1, hs.1], by linarith [hi.2, hs.2]⟩⟩
  choose a b hat htb htime using hextime
  let U (p : P) : Opens (EuclideanSpace ℝ (Fin 3)) := ⟨ball (x₀ p) (rho p), isOpen_ball⟩
  have hU (p : P) : (U p : Set _) ⊆ (extChartAt (𝓡 3) (q (j p))).target :=
    ball_subset_closedBall.trans (hchart p)
  have hexF (p : P) := exists_horizon_chart_flow_on_closed_slab G htmono hB (q (j p)) hsigma
    (f (j p)) (hf (j p)) (hjets (j p)) ((hat p).trans (htb p)) (htime p)
    (hrho p) (hchart p) (U p) subset_rfl
  choose Fchart hFchart using hexF
  obtain ⟨F, hF⟩ := RicciFlow.exists_of_local_time_covering_diffeomorphisms
    (horizonOpenTime_ordConnected tau) (horizonOpenTime_nontrivial (htau 0))
    (fun p : P => Icc (a p) (b p)) Fchart g hg
    (fun p => G.referenceOpenMap (q (j p)) (U p))
    (fun p => G.referenceOpenMap_isLocalDiffeomorph (q (j p)) (U p) (hU p))
    (by
      intro t ht y
      let p : P := (⟨t, ht⟩, y)
      refine ⟨p, ⟨x₀ p, mem_ball_self (hrho p)⟩, ⟨(hat p).le, (htb p).le⟩,
        mem_nhdsWithin_of_mem_nhds (Icc_mem_nhds (hat p) (htb p)), ?_⟩
      exact (extChartAt (𝓡 3) (q (j p))).left_inv (hchartIndex y))
    (by
      intro p t ht x v w
      rw [hFchart p t ht, hgcoeff t (htime p ht) (j p) x (hU p x.property)]
      rw [G.referenceOpenMap_mfderiv (q (j p)) (U p) (hU p) x]
      rfl)
  exact ⟨F, by simpa only [hF] using hgcoeff⟩

end PoincareMT.ControlledBlowupCompactness
