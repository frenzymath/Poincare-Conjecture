import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.ReferenceJets
import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Coordinates.PartialCharts
import PoincareLib.Geometry.Manifold.InverseFunction.LocalDiffeomorph
import PoincareLib.Geometry.RicciFlow.Compactness.Convergence.Volume.SpatialEmbedding

/-!
# Actual retained coordinate charts on finite windows
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

open Set Filter
open scoped Manifold ContDiff Topology

namespace PoincareMT.PointedGeometricConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space

variable {a b : ℝ} {S : PointedFlowSequence 3 a b}
  (G : PointedGeometricConvergence S)

/-- The reference-coordinate domain of the retained source embedding. -/
def referenceChartSource (q : G.limitCarrier.carrier) (k : ℕ) :
    Set (EuclideanSpace ℝ (Fin 3)) :=
  (extChartAt (𝓡 3) q).target ∩ (extChartAt (𝓡 3) q).symm ⁻¹' G.exhaustion k

theorem referenceChartSource_open (q : G.limitCarrier.carrier) (k : ℕ) :
    IsOpen (G.referenceChartSource q k) :=
  (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
    (isOpen_extChartAt_target (I := 𝓡 3) q) (G.exhaustion_open k)

theorem referenceChartMap_injOn (q : G.limitCarrier.carrier) (k : ℕ)
    {τ : ℝ} (hτ : τ ∈ Ioo a b) :
    InjOn (G.referenceChartMap q k τ) (G.referenceChartSource q k) := by
  intro x hx y hy hxy
  apply (extChartAt (𝓡 3) q).symm.injOn hx.1 hy.1
  exact ((G.embedding k).spatialHomeomorph (G.exhaustion_open k) hτ).injOn hx.2 hy.2 hxy

theorem referenceChartMap_isLocalDiffeomorphOn (q : G.limitCarrier.carrier) (k : ℕ)
    {τ : ℝ} (hτ : τ ∈ Ioo a b) :
    IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap q k τ)
      (G.referenceChartSource q k) :=
  Poincare.isLocalDiffeomorphOn_of_contMDiffOn_bijective_mfderiv
    (G.referenceChartSource_open q k)
    (fun _ hx => (G.referenceChartMap_contMDiffAt q k hτ hx.1 hx.2).contMDiffWithinAt)
    (fun _ hx => (G.referenceChartMap_mfderiv_isInvertible q k hτ hx.1 hx.2).bijective)

/-- The original retained spatial map, packaged on its exact coordinate source. -/
def referencePartialChart (q : G.limitCarrier.carrier) (k : ℕ)
    {τ : ℝ} (hτ : τ ∈ Ioo a b) :
    PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
      (S.carrier (G.subsequence k)).carrier ∞ :=
  AncientCompactness.partialDiffeomorphOfInjOn (G.referenceChartSource_open q k)
    (G.referenceChartMap q k τ) (G.referenceChartMap_injOn q k hτ)
    (G.referenceChartMap_isLocalDiffeomorphOn q k hτ)

@[simp] theorem referencePartialChart_source (q : G.limitCarrier.carrier) (k : ℕ)
    {τ : ℝ} (hτ : τ ∈ Ioo a b) :
    (G.referencePartialChart q k hτ).source = G.referenceChartSource q k := rfl

@[simp] theorem referencePartialChart_coe (q : G.limitCarrier.carrier) (k : ℕ)
    {τ : ℝ} (hτ : τ ∈ Ioo a b) :
    (G.referencePartialChart q k hτ : EuclideanSpace ℝ (Fin 3) →
      (S.carrier (G.subsequence k)).carrier) = G.referenceChartMap q k τ := rfl

theorem eventually_subset_referencePartialChart_source
    (q : G.limitCarrier.carrier) {τ : ℝ} (hτ : τ ∈ Ioo a b)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) :
    ∀ᶠ k : ℕ in atTop, K ⊆ (G.referencePartialChart q k hτ).source := by
  have hc : ContinuousOn (extChartAt (𝓡 3) q).symm K :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset (hK.image_of_continuousOn hc)
  filter_upwards [eventually_ge_atTop j] with k hk x hx
  exact ⟨hKc hx, G.exhaustion_monotone hk (hj (mem_image_of_mem _ hx))⟩

/-- A coordinate ball in the original limit chart. -/
def referenceBall (q : G.limitCarrier.carrier) (r : ℝ) :
    TopologicalSpace.Opens (EuclideanSpace ℝ (Fin 3)) :=
  ⟨Metric.ball (extChartAt (𝓡 3) q q) r, Metric.isOpen_ball⟩

def referenceBallMap (q : G.limitCarrier.carrier) (r : ℝ) :
    G.referenceBall q r → G.limitCarrier.carrier := fun x => (extChartAt (𝓡 3) q).symm x

theorem exists_referenceBall_radius (q : G.limitCarrier.carrier) :
    ∃ r : ℝ, 0 < r ∧
      Metric.closedBall (extChartAt (𝓡 3) q q) r ⊆ (extChartAt (𝓡 3) q).target := by
  obtain ⟨ε, hε, hεc⟩ := Metric.mem_nhds_iff.mp
    ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds (mem_extChartAt_target q))
  exact ⟨ε / 2, by positivity,
    (Metric.closedBall_subset_ball (by linarith : ε / 2 < ε)).trans hεc⟩

theorem referenceBallMap_isLocalDiffeomorph
    (q : G.limitCarrier.carrier) (r : ℝ)
    (hsource : Metric.ball (extChartAt (𝓡 3) q q) r ⊆ (extChartAt (𝓡 3) q).target) :
    IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ (G.referenceBallMap q r) := by
  let d : PartialDiffeomorph (𝓡 3) (𝓡 3) G.limitCarrier.carrier
      (EuclideanSpace ℝ (Fin 3)) ∞ :=
    { toPartialEquiv := (chartAt (EuclideanSpace ℝ (Fin 3)) q).toPartialEquiv
      open_source := (chartAt (EuclideanSpace ℝ (Fin 3)) q).open_source
      open_target := (chartAt (EuclideanSpace ℝ (Fin 3)) q).open_target
      contMDiffOn_toFun := contMDiffOn_chart
      contMDiffOn_invFun := contMDiffOn_chart_symm }
  intro x
  have hx : (x : EuclideanSpace ℝ (Fin 3)) ∈ d.target := by
    simpa only [extChartAt_target, modelWithCornersSelf_coe,
      modelWithCornersSelf_coe_symm, preimage_id, range_id, inter_univ] using hsource x.property
  exact (Poincare.isLocalDiffeomorph_opensSubtypeVal
    (𝓡 3) (G.referenceBall q r) x).comp (𝓡 3) G.limitCarrier.carrier
      (d.symm.isLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞ hx)

theorem referenceBallMap_covers
    (r : G.limitCarrier.carrier → ℝ) (hr : ∀ q, 0 < r q) :
    ∀ y : G.limitCarrier.carrier, ∃ q : G.limitCarrier.carrier,
      ∃ x : G.referenceBall q (r q), G.referenceBallMap q (r q) x = y := by
  intro y
  refine ⟨y, ⟨extChartAt (𝓡 3) y y, Metric.mem_ball_self (hr y)⟩, ?_⟩
  exact (extChartAt (𝓡 3) y).left_inv (mem_extChartAt_source y)

end PoincareMT.PointedGeometricConvergence
