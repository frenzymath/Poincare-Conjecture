import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Ancient.Compact.Stability.Neck.Jets.Coefficients

/-! # Unnormalized source-neck jets from a lower center scalar bound -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff

universe u

namespace PoincareMT.MetricSurgery

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem exists_centered_neck_jet_bound_of_scalar_lower (m : ℕ) :
    ∃ C : ℝ, 0 < C ∧
      ∀ {M : Type u} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
        {g : RiemannianMetric 3 M} (N : EpsilonNeck g) {l : ℝ},
        0 < l → l ≤ N.connection.scalarCurvature N.center → m ≤ ⌊N.epsilon⁻¹⌋₊ →
        ∀ z : RoundCylinderSpace, z.2 ∈ Ioo (-N.epsilon⁻¹) N.epsilon⁻¹ →
        ∀ j, j ≤ m → ‖iteratedFDeriv ℝ j
          (g.parametrizedCoefficients (centeredNeckLift N z.1 z.2)) 0‖ ≤ C / l := by
  obtain ⟨C, hC, hbound⟩ := exists_normalizedNeck_centered_coefficient_jet_bounds.{u} m
  refine ⟨C, hC, ?_⟩
  intro M _ _ _ g N l hl hscalar horder z hz j hj
  let Q := N.connection.scalarCurvature N.center
  have hQ : 0 < Q := N.scalar_center_pos
  let f := centeredNeckLift N z.1 z.2
  have heq : g.parametrizedCoefficients f = fun p =>
      Q⁻¹ • (normalizedNeckMetric N).parametrizedCoefficients f p := by
    funext p
    ext v w
    change _ = Q⁻¹ * (Q * _)
    rw [inv_mul_cancel_left₀ hQ.ne']
    rfl
  have hn := (normalizedNeckMetric N).contDiffAt_parametrizedCoefficients
    (centeredNeckLift_contMDiffAt N z.1 z.2 (zero_mem_centeredNeckDomain N hz))
  rw [heq, iteratedFDeriv_const_smul_apply' (hn.of_le (by exact_mod_cast le_top))]
  let : IsBoundedSMul ℝ (E →L[ℝ] E →L[ℝ] ℝ) :=
    NormedSpace.toIsBoundedSMul (𝕜 := ℝ) («E» := E →L[ℝ] E →L[ℝ] ℝ)
  apply (ContinuousMultilinearMap.opNorm_smul_le _ _).trans
  rw [Real.norm_of_nonneg (inv_pos.mpr hQ).le]
  have hh := mul_le_mul ((inv_le_inv₀ hQ hl).2 hscalar)
    (hbound N j hj (hj.trans horder) z hz) (norm_nonneg _) (inv_pos.mpr hl).le
  simpa only [div_eq_mul_inv, mul_comm] using hh

end PoincareMT.MetricSurgery
