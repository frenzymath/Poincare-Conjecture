import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourceDerivatives
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.ReferenceJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SpatialBounds
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.FiniteWindow
import PoincareLib.Geometry.RicciFlow.Compactness.Embedding.CompactBallTransfer

/-!
# Curvature derivatives on the retained compactness charts

The complete interior limit transfers a compact chart into a uniformly
bounded source ball. A fixed spatial buffer then gives all curvature
derivative bounds through the terminal time on those exact source maps.

Reference: Morgan--Tian, Proposition 5.14, pp. 90--91.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 800000

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

/-- The original fixed zero-time embeddings retain uniform curvature
derivative bounds throughout the final half-cylinder, including its endpoint. -/
theorem exists_eventually_reference_curvatureDerivative_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ k : ℕ in atTop,
      ∀ t ∈ Icc (-T / 2) 0, ∀ x ∈ K,
        (((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).connection t).curvatureDerivativeNorm
          m (G.referenceChartMap q k 0 x) ≤ D := by
  have hzero : -T / 2 < 0 ∧ 0 < T / 2 := ⟨by linarith, by linarith⟩
  have hc : ContinuousOn (extChartAt (𝓡 3) q).symm K :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨R, hR, himage⟩ := G.exists_pos_eventually_image_subset_ballAt hzero hzero
    hcomplete (hK.image_of_continuousOn hc)
  let R' := Real.exp (3 * B * |(-T / 2)|) * R
  have hR' : 0 < R' := mul_pos (Real.exp_pos _) hR
  obtain ⟨D, hD, hderiv⟩ := exists_uniform_curvatureDerivative_bound_of_unit_buffer
    P04 hT hB m
  have hAr' : Tendsto (fun k => A (G.subsequence k)) atTop atTop :=
    hAr.comp G.subsequence_strictMono.tendsto_atTop
  refine ⟨D, hD, ?_⟩
  filter_upwards [himage, hAr'.eventually_ge_atTop (R' + 1)] with k hk hAk t ht x hx
  rw [(e (G.subsequence k)).smallFlow_curvatureDerivativeNorm]
  apply hderiv S (idx (G.subsequence k)) (A (G.subsequence k)) R'
    (eta (G.subsequence k)) hR' hAk (e (G.subsequence k)) (hcompact _) t ht
  have hxsmall := hk (mem_image_of_mem _ (mem_image_of_mem _ hx))
  change (((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).metric
    (0 + (-T / 2))).edist (smallBase S (idx (G.subsequence k)) (hA _))
      (G.referenceChartMap q k 0 x) < ENNReal.ofReal R at hxsmall
  rw [zero_add] at hxsmall
  unfold smallFlow smallBase at hxsmall
  rw [RicciFlow.shrink_edist, Equiv.symm_apply_apply] at hxsmall
  unfold componentFlow at hxsmall
  rw [RicciFlow.restrictComponent_edist] at hxsmall
  exact (e (G.subsequence k)).ordinaryFlow_ball_subset_terminal_ball
    (hA _) hT (show -T / 2 ∈ Icc (-T) 0 from ⟨by linarith, by linarith⟩) R hxsmall

/-- Interior metric convergence and the actual cylinder curvature bound give
uniform ellipticity through the included terminal time. -/
theorem exists_eventually_reference_closed_ellipticity
    (hB : 0 ≤ B) (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) :
    ∃ a b : ℝ, 0 < a ∧ 0 < b ∧ ∀ᶠ k : ℕ in atTop,
      ∀ t ∈ Icc (-T / 2) 0, ∀ x ∈ K, ∀ v,
        a * ‖v‖ ^ 2 ≤
          (((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).metric t).pullbackCoefficients
            (G.referenceChartMap q k 0) x v v ∧
        (((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).metric t).pullbackCoefficients
            (G.referenceChartMap q k 0) x v v ≤ b * ‖v‖ ^ 2 := by
  have hzero : -T / 2 < 0 ∧ 0 < T / 2 := ⟨by linarith, by linarith⟩
  obtain ⟨α, β, hα, hβ, href⟩ := G.exists_eventually_reference_ellipticity q hzero hK hKc
  let D : ℝ := (3 : ℝ) ^ 3 * B
  have hD : 0 ≤ D := by dsimp [D]; positivity
  refine ⟨Real.exp (-(2 * D) * (T / 2)) * α, Real.exp (2 * D * (T / 2)) * β,
    mul_pos (Real.exp_pos _) hα, mul_pos (Real.exp_pos _) hβ, ?_⟩
  filter_upwards [href] with k hreference t ht x hx v
  let F := (e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT
  let f := G.referenceChartMap q k 0
  let w := mfderiv (𝓡 3) (𝓡 3) f x v
  have hnonneg (s : ℝ) : 0 ≤ (F.metric s).inner (f x) w w := by
    by_cases hw : w = 0
    · simp [hw]
    · exact ((F.metric s).pos _ _ hw).le
  have hsub : Icc (-T / 2) 0 ⊆ Icc (-T) 0 :=
    fun s hs => ⟨by linarith [hs.1], hs.2⟩
  have hRic : ∀ s ∈ Icc (-T / 2) 0,
      |(F.connection s).ricci (f x) w w| ≤ D * (F.metric s).inner (f x) w w := by
    intro s hs
    have h := (F.connection s).abs_ricci_quadratic_le_curvatureTensorNorm (f x) w
    have hdim : Module.finrank ℝ (TangentSpace (𝓡 3) (f x)) = 3 := finrank_euclideanSpace_fin
    simp only [Fintype.card_fin, hdim] at h
    exact h.trans (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left ((le_abs_self _).trans
        ((e (G.subsequence k)).smallFlow_curvature_bound (hA _) hT s (hsub hs) (f x)))
        (by positivity)) (hnonneg s))
  have hcomp := F.metric_inner_self_exp_bounds (convex_Icc (-T / 2) 0) hsub
    (f x) w D hRic (show -T / 2 ∈ Icc (-T / 2) 0 from ⟨le_rfl, by linarith⟩) ht
  have hdist : |t - (-T / 2)| ≤ T / 2 := by
    rw [abs_le]
    constructor <;> linarith [ht.1, ht.2]
  have hreference := hreference x hx v
  change α * ‖v‖ ^ 2 ≤ (F.metric (0 + (-T / 2))).inner (f x) w w ∧
    (F.metric (0 + (-T / 2))).inner (f x) w w ≤ β * ‖v‖ ^ 2 at hreference
  rw [zero_add] at hreference
  constructor
  · calc
      (Real.exp (-(2 * D) * (T / 2)) * α) * ‖v‖ ^ 2 =
          Real.exp (-(2 * D) * (T / 2)) * (α * ‖v‖ ^ 2) := mul_assoc _ _ _
      _ ≤ Real.exp (-(2 * D) * (T / 2)) * (F.metric (-T / 2)).inner (f x) w w :=
        mul_le_mul_of_nonneg_left hreference.1 (Real.exp_nonneg _)
      _ ≤ Real.exp (-(2 * D) * |t - (-T / 2)|) * (F.metric (-T / 2)).inner (f x) w w :=
        mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr
          (mul_le_mul_of_nonpos_left hdist (by linarith))) (hnonneg (-T / 2))
      _ ≤ _ := hcomp.1
  · calc
      _ ≤ Real.exp (2 * D * |t - (-T / 2)|) * (F.metric (-T / 2)).inner (f x) w w := hcomp.2
      _ ≤ Real.exp (2 * D * (T / 2)) * (F.metric (-T / 2)).inner (f x) w w :=
        mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr
          (mul_le_mul_of_nonneg_left hdist (by positivity))) (hnonneg (-T / 2))
      _ ≤ Real.exp (2 * D * (T / 2)) * (β * ‖v‖ ^ 2) :=
        mul_le_mul_of_nonneg_left hreference.2 (Real.exp_nonneg _)
      _ = (Real.exp (2 * D * (T / 2)) * β) * ‖v‖ ^ 2 := (mul_assoc _ _ _).symm

/-- Every spatial metric jet of the retained source charts is uniformly
bounded on the final closed half-cylinder. -/
theorem exists_eventually_reference_closed_spatial_jet_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k : ℕ in atTop,
      ∀ t ∈ Icc (-T / 2) 0, ∀ x ∈ K, ∀ j ≤ m,
        ‖iteratedFDeriv ℝ j
          ((((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).metric t).pullbackCoefficients
            (G.referenceChartMap q k 0)) x‖ ≤ C := by
  have hzero : -T / 2 < 0 ∧ 0 < T / 2 := ⟨by linarith, by linarith⟩
  obtain ⟨α, β, hα, hβ, hell⟩ := exists_eventually_reference_closed_ellipticity G hB q hK hKc
  choose D hD hcurv using fun j => exists_eventually_reference_curvatureDerivative_bound
    G P04 hB hAr hcompact hcomplete q hK hKc j
  choose Z hZ hreference using fun j =>
    G.exists_eventually_reference_metric_jet_bound q hzero hK hKc j
  obtain ⟨C, hC, hbound⟩ := SpacetimeBounds.exists_chart_spatial_jet_bound_on_closed_interval
    3 m D Z (fun j => (hD j).le) (l := -T / 2) (r := 0) (by linarith) hα hβ.le
  have hc : ContinuousOn (extChartAt (𝓡 3) q).symm K :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨j₀, hj₀⟩ := G.exists_exhaustion_superset (hK.image_of_continuousOn hc)
  refine ⟨C, hC, ?_⟩
  filter_upwards [hell, eventually_ge_atTop j₀,
    (eventually_all_finite (Set.finite_Iic m)).mpr (fun j _ => hcurv j),
    (eventually_all_finite (Set.finite_Iic m)).mpr (fun j _ => hreference j)]
    with k hellk hstage hcurvk href
  let F := (e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT
  let U := (extChartAt (𝓡 3) q).target ∩
    (extChartAt (𝓡 3) q).symm ⁻¹' G.exhaustion k
  have hU : IsOpen U :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
      (isOpen_extChartAt_target q) (G.exhaustion_open k)
  have he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap q k 0) U :=
    fun x hx => (G.referenceChartMap_contMDiffAt q k hzero hx.1 hx.2).contMDiffWithinAt
  have hi : ∀ x ∈ U, (mfderiv (𝓡 3) (𝓡 3) (G.referenceChartMap q k 0) x).IsInvertible :=
    fun x hx => G.referenceChartMap_mfderiv_isInvertible q k hzero hx.1 hx.2
  apply hbound F (fun t ht => ⟨by linarith [ht.1], ht.2⟩) hU he hi K
    (fun x hx => ⟨hKc hx, G.exhaustion_monotone hstage (hj₀ (mem_image_of_mem _ hx))⟩)
    hellk (fun j hj => hcurvk j hj)
    (show -T / 2 ∈ Icc (-T / 2) 0 from ⟨le_rfl, by linarith⟩)
  intro j hj x hx
  simpa only [interiorSequence, RicciFlow.translate, zero_add] using href j hj x hx

end PoincareMT.ControlledBlowupCompactness
