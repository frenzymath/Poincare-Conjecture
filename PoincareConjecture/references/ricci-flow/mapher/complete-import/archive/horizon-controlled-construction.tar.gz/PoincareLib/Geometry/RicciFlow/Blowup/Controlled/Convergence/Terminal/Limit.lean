import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Sign
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Completeness
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.NonnegativeWindow

/-!
# Normalized complete finite controlled blow-up limits
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT

namespace LeviCivitaData

variable {n : ℕ} {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
  {g h : RiemannianMetric n M} [T2Space M]

theorem curvatureTensorNorm_eq_of_metric_eq
    (D : LeviCivitaData g) (E : LeviCivitaData h) (heq : g = h) (x : M) :
    D.curvatureTensorNorm x = E.curvatureTensorNorm x := by
  subst h
  exact D.curvatureTensorNorm_eq E x

theorem nonnegativeCurvatureOperator_iff_of_metric_eq
    (D : LeviCivitaData g) (E : LeviCivitaData h) (heq : g = h) (x : M) :
    D.NonnegativeCurvatureOperator x ↔ E.NonnegativeCurvatureOperator x := by
  subst h
  simp only [NonnegativeCurvatureOperator, curvatureOperatorQuadratic, D.curvatureTensor_eq E]

end LeviCivitaData

namespace ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)
  (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
  (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : ∀ t ∈ Ioo (-T / 2) (T / 2),
    G.limitCarrier.metricComplete (G.limitFlow.metricAt t))
  (hbound : ∀ t ∈ Ioo (-T / 2) (T / 2), ∀ x,
    (G.limitFlow.flow.connection t).curvatureTensorNorm x ≤ B)
  (heta : Tendsto eta atTop (𝓝 0))

include hF P04 hB hAr hcompact hcomplete hbound heta

/-- All finite-window geometric properties, including the terminal slice,
hold on the actual extended source limit before clock translation. -/
theorem terminal_flow_properties :
    (∀ t ∈ Ioc (-T / 2) (T / 2), G.limitCarrier.metricComplete (F.metric t)) ∧
    (∀ t ∈ Ioc (-T / 2) (T / 2), ∀ x,
      (F.connection t).NonnegativeCurvatureOperator x) ∧
    (∀ t ∈ Ioc (-T / 2) (T / 2), ∀ x,
      |(F.connection t).curvatureTensorNorm x| ≤ B) := by
  have hc0 := hcomplete 0 ⟨by linarith, by linarith⟩
  refine ⟨?_, ?_, ?_⟩
  · intro t ht
    rcases lt_or_eq_of_le ht.2 with hlt | rfl
    · rw [hF t ⟨ht.1, hlt⟩]
      exact hcomplete t ⟨ht.1, hlt⟩
    · exact terminal_metricComplete G F hF P04 hB hAr hcompact hc0
  · intro t ht x
    rcases lt_or_eq_of_le ht.2 with hlt | rfl
    · apply ((F.connection t).nonnegativeCurvatureOperator_iff_of_metric_eq
        (G.limitFlow.flow.connection t) (hF t ⟨ht.1, hlt⟩) x).mpr
      exact interiorSequence_limit_nonnegativeCurvatureOperator S idx A eta hA hT e
        heta G t ⟨ht.1, hlt⟩ x
    · exact terminal_nonnegativeCurvatureOperator G F hF P04 hB hAr hcompact hc0 heta
        ⟨by positivity, le_rfl⟩ x
  · intro t ht x
    rw [abs_of_nonneg (by unfold LeviCivitaData.curvatureTensorNorm; positivity)]
    rcases lt_or_eq_of_le ht.2 with hlt | rfl
    · rw [(F.connection t).curvatureTensorNorm_eq_of_metric_eq
        (G.limitFlow.flow.connection t) (hF t ⟨ht.1, hlt⟩) x]
      exact hbound t ⟨ht.1, hlt⟩ x
    · exact terminal_curvatureTensorNorm_le G F hF P04 hB hAr hcompact hc0
        ⟨by positivity, le_rfl⟩ x

/-- The actual normalized finite blow-up limit on the unchanged M07 carrier,
with its clock returned to the original normalized source interval. -/
def terminalLimit : BlowupLimitFlow.{0} (Ioc (-T) 0) where
  carrier := G.limitCarrier
  connectedSpace := connectedSpace_iff_univ.mpr G.limitCarrier.connected
  base := G.limitFlow.base
  flow := F.translate (T / 2)
    (by rintro _ ⟨t, ht, rfl⟩; exact ⟨by linarith [ht.1], by linarith [ht.2]⟩)
    ordConnected_Ioc (by refine ⟨-T / 2, ⟨by linarith, by linarith⟩,
      0, ⟨by linarith, le_rfl⟩, by linarith⟩)
  zero_mem := ⟨by linarith, le_rfl⟩
  scalar_normalized := by
    change (F.connection (0 + T / 2)).scalarCurvature G.limitFlow.base = 1
    rw [zero_add]
    exact terminal_scalar_normalized G F hF P04 hB hAr hcompact
      (hcomplete 0 ⟨by linarith, by linarith⟩)
  complete := by
    intro t ht
    exact (terminal_flow_properties G F hF P04 hB hAr hcompact hcomplete hbound heta).1
      (t + T / 2) ⟨by linarith [ht.1], by linarith [ht.2]⟩
  nonnegative_curvature_operator := by
    intro t ht x
    exact (terminal_flow_properties G F hF P04 hB hAr hcompact hcomplete hbound heta).2.1
      (t + T / 2) ⟨by linarith [ht.1], by linarith [ht.2]⟩ x
  curvature_locally_bounded_in_time := by
    intro I _ hI
    exact ⟨B, hB, fun t ht x =>
      (terminal_flow_properties G F hF P04 hB hAr hcompact hcomplete hbound heta).2.2
        (t + T / 2) ⟨by linarith [(hI ht).1], by linarith [(hI ht).2]⟩ x⟩

end ControlledBlowupCompactness
end PoincareMT
