import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NeckTransverse
import PoincareLib.Geometry.Riemannian.Metric.Product.Curvature
import PoincareLib.Topology.Manifold.NeckCap.Cylinder.Sphere
import PoincareLib.Topology.Manifold.NeckCap.Overlap.GraphProjection

/-!
# A small neck forces a compact factor in an actual line product

The neck's central sphere projects locally diffeomorphically to the surface
factor: a vector in the projection kernel would be both horizontal in the
neck and Ricci-null. Its compact open image covers the connected factor.

Reference: Morgan--Tian, Claim 11.7, p. 271.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle

universe u

namespace PoincareMT.RiemannianMetric

variable {S M : Type u} [TopologicalSpace S] [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 2)) S] [IsManifold (𝓡 2) ∞ S]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]

theorem ricci_self_eq_zero_of_line_product_vertical
    (h : RiemannianMetric 2 S) (g : RiemannianMetric 3 M) (D : LeviCivitaData g)
    (e : (S × ℝ) ≃ₘ⟮(𝓡 2).prod 𝓘(ℝ, ℝ), 𝓡 3⟯ M)
    (hmetric : ∀ (z : S × ℝ) (v w : TangentSpace ((𝓡 2).prod 𝓘(ℝ, ℝ)) z),
      g.inner (e z)
        (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z v)
        (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z w) =
        h.inner z.1 v.1 w.1 + v.2 * w.2)
    (z : S × ℝ) (c : ℝ) :
    D.ricci (e z)
      (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z (0, c))
      (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z (0, c)) = 0 := by
  let f : M → ℝ := Prod.snd ∘ e.symm
  have hf : ContMDiff (𝓡 3) 𝓘(ℝ, ℝ) ∞ f := contMDiff_snd.comp e.symm.contMDiff
  have hz := (product_height_hasUnitGradient_and_hasZeroHessian h g D e hmetric).2
  have hinverse (v : TangentSpace ((𝓡 2).prod 𝓘(ℝ, ℝ)) z) :
      mfderiv (𝓡 3) ((𝓡 2).prod 𝓘(ℝ, ℝ)) e.symm (e z)
        (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z v) = v := by
    have heq : (e.symm : M → S × ℝ) ∘ e = id := funext e.symm_apply_apply
    have hc := mfderiv_comp z (e.symm.contMDiff.mdifferentiable (by simp) _)
      (e.contMDiff.mdifferentiable (by simp) _)
    rw [heq, mfderiv_id] at hc
    exact (congrArg (fun L => L v) hc).symm
  have hgrad : D.gradient f (e z) =
      mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z (0, 1) := by
    apply (g.inner_isInvertible (e z)).injective
    ext w
    obtain ⟨v, rfl⟩ := (e.mfderivToContinuousLinearEquiv (by simp) z).surjective w
    change g.inner (e z) (D.gradient f (e z))
      (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z v) =
      g.inner (e z) (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z (0, 1))
        (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z v)
    rw [D.inner_gradient, hmetric]
    change mfderiv (𝓡 3) 𝓘(ℝ, ℝ) (Prod.snd ∘ e.symm) (e z)
      (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z v) = _
    rw [mfderiv_comp_apply _ mdifferentiableAt_snd
      (e.symm.contMDiff.mdifferentiable (by simp) _), hinverse, mfderiv_snd]
    simp
    rfl
  have hnull : D.ricci (e z) (D.gradient f (e z)) (D.gradient f (e z)) = 0 := by
    unfold LeviCivitaData.ricci
    apply Finset.sum_eq_zero
    intro i _
    exact (curvatureTensor_gradient_slots_eq_zero hf hz (e z)
      (g.orthonormalBasis (e z) i) (D.gradient f (e z))
      (g.orthonormalBasis (e z) i)).1
  have hvertical : mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z (0, c) =
      c • D.gradient f (e z) := by
    rw [hgrad, ← map_smul]
    congr 1
    change ((0, c) : EuclideanSpace ℝ (Fin 2) × ℝ) = c • (0, 1)
    simp
  rw [hvertical, ← RicciFlow.Splitting.ricciBilinear_apply]
  simp only [map_smul, LinearMap.smul_apply, smul_eq_mul,
    RicciFlow.Splitting.ricciBilinear_apply, hnull, mul_zero]

/-- The threshold precedes both factors and the actual product isometry.
One small spherical neck is enough to construct compactness of the factor. -/
theorem exists_neck_compact_line_factor_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 200 ∧
      ∀ (S M : Type u) [TopologicalSpace S] [T2Space S] [ConnectedSpace S]
        [ChartedSpace (EuclideanSpace ℝ (Fin 2)) S] [IsManifold (𝓡 2) ∞ S]
        [TopologicalSpace M] [T2Space M] [T3Space M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
        [MeasurableSpace M] [BorelSpace M],
      ∀ (h : RiemannianMetric 2 S) (g : RiemannianMetric 3 M) (_D : LeviCivitaData g)
        (e : (S × ℝ) ≃ₘ⟮(𝓡 2).prod 𝓘(ℝ, ℝ), 𝓡 3⟯ M),
        (∀ (z : S × ℝ) (v w : TangentSpace ((𝓡 2).prod 𝓘(ℝ, ℝ)) z),
          g.inner (e z)
            (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z v)
            (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z w) =
            h.inner z.1 v.1 w.1 + v.2 * w.2) →
        ∀ N : EpsilonNeck g, N.epsilon ≤ epsilon₀ → CompactSpace S := by
  obtain ⟨epsilon₀, hpos, hsmall, htrans⟩ := EpsilonNeck.exists_null_transverse_threshold.{u}
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro S M _ _ _ _ _ _ _ _ _ _ _ _ h g D e hmetric N hN
  let f : UnitTwoSphere → S := fun q => (e.symm (N.coordinate_map (q, 0))).1
  have hf : ContMDiff (𝓡 2) (𝓡 2) ∞ f :=
    contMDiff_fst.comp (e.symm.contMDiff.comp N.centralSphere_contMDiff)
  have hbij (q : UnitTwoSphere) : Function.Bijective (mfderiv (𝓡 2) (𝓡 2) f q) := by
    let A := mfderiv (𝓡 2) (𝓡 2) f q
    have hinj : Function.Injective A := by
      apply (injective_iff_map_eq_zero A).mpr
      intro v hv
      let x := N.coordinate_map (q, 0)
      let w := mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) N.coordinate_map (q, 0) (v, 0)
      let u := mfderiv (𝓡 3) ((𝓡 2).prod 𝓘(ℝ, ℝ)) e.symm x w
      have hzero : (0 : ℝ) ∈ Ioo (-N.epsilon⁻¹) N.epsilon⁻¹ :=
        ⟨neg_neg_of_pos (inv_pos.mpr N.epsilon_pos), inv_pos.mpr N.epsilon_pos⟩
      have hmap := (N.coordinate_map_smooth.contMDiffAt
        (N.cylinderDomain_open.mem_nhds
          (show (q, (0 : ℝ)) ∈ N.cylinderDomain from ⟨mem_univ q, hzero⟩))).mdifferentiableAt
        (by simp)
      have hpair := (hasMFDerivAt_id (I := 𝓡 2) q).prodMk
        (hasMFDerivAt_const (I := 𝓡 2) (I' := 𝓘(ℝ, ℝ)) (0 : ℝ) q)
      have hc := (e.symm.contMDiff.mdifferentiable (by simp) x).hasMFDerivAt.comp q
        (hmap.hasMFDerivAt.comp q hpair)
      have hfst := (hasMFDerivAt_fst (I := 𝓡 2) (I' := 𝓘(ℝ, ℝ)) (e.symm x)).comp q hc
      have hu : u.1 = 0 := (congrArg (fun L => L v) hfst.mfderiv).symm.trans hv
      have hback : mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e (e.symm x) u = w := by
        have heq : (e : S × ℝ → M) ∘ e.symm = id := funext e.apply_symm_apply
        have hh := mfderiv_comp x (e.contMDiff.mdifferentiable (by simp) _)
          (e.symm.contMDiff.mdifferentiable (by simp) _)
        rw [heq, mfderiv_id] at hh
        exact (congrArg (fun L => L w) hh).symm
      have hnull := ricci_self_eq_zero_of_line_product_vertical h g D e hmetric (e.symm x) u.2
      have hu' : (0, u.2) = u := Prod.ext hu.symm rfl
      erw [hu', hback, e.apply_symm_apply] at hnull
      by_contra hvne
      have hnonzero : (v, (0 : ℝ)) ≠ (0 : RoundCylinderTangent (q, 0)) := by
        intro heq
        exact hvne (congrArg Prod.fst heq)
      exact (htrans N D hN (q, 0) ⟨mem_univ _, hzero⟩ (v, 0) hnull).2 hnonzero rfl
    let : FiniteDimensional ℝ (TangentSpace (𝓡 2) q) := by
      unfold TangentSpace
      infer_instance
    exact ⟨hinj, (LinearMap.injective_iff_surjective (f := A.toLinearMap)).mp hinj⟩
  have hopen : IsOpen (range f) :=
    (Poincare.isLocalDiffeomorph_of_contMDiff_bijective_mfderiv hf hbij).isOpenMap.isOpen_range
  have hcompact : IsCompact (range f) := by
    simpa only [image_univ] using isCompact_univ.image hf.continuous
  have hwhole : range f = univ :=
    (show IsClopen (range f) from ⟨hcompact.isClosed, hopen⟩).eq_univ (range_nonempty f)
  exact ⟨hwhole ▸ hcompact⟩

/-- A small neck in an actual line product bounds scalar curvature everywhere,
by constructing compactness of the surface factor. -/
theorem exists_neck_line_product_scalar_bound_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 200 ∧
      ∀ (S M : Type u) [TopologicalSpace S] [T2Space S] [ConnectedSpace S]
        [ChartedSpace (EuclideanSpace ℝ (Fin 2)) S] [IsManifold (𝓡 2) ∞ S]
        [TopologicalSpace M] [T2Space M] [T3Space M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
        [MeasurableSpace M] [BorelSpace M],
      ∀ (h : RiemannianMetric 2 S) (g : RiemannianMetric 3 M) (D : LeviCivitaData g)
        (e : (S × ℝ) ≃ₘ⟮(𝓡 2).prod 𝓘(ℝ, ℝ), 𝓡 3⟯ M),
        (∀ (z : S × ℝ) (v w : TangentSpace ((𝓡 2).prod 𝓘(ℝ, ℝ)) z),
          g.inner (e z)
            (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z v)
            (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) e z w) =
            h.inner z.1 v.1 w.1 + v.2 * w.2) →
        ∀ N : EpsilonNeck g, N.epsilon ≤ epsilon₀ →
          ∃ B : ℝ, 0 < B ∧ ∀ x : M, D.scalarCurvature x ≤ B := by
  obtain ⟨epsilon₀, hpos, hsmall, hcompact⟩ :=
    exists_neck_compact_line_factor_threshold.{u}
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro S M _ _ _ _ _ _ _ _ _ _ _ _ h g D e hmetric N hN
  let : CompactSpace S := hcompact S M h g D e hmetric N hN
  obtain ⟨B, hB⟩ := isCompact_univ.bddAbove_image
    h.leviCivitaData.continuous_scalarCurvature.continuousOn
  refine ⟨max 1 B, lt_of_lt_of_le zero_lt_one (le_max_left _ _), ?_⟩
  intro x
  obtain ⟨z, rfl⟩ := e.surjective x
  change D.scalarCurvature (e z) ≤ max 1 B
  rw [scalarCurvature_eq_of_line_product h g h.leviCivitaData D e hmetric]
  exact (hB (mem_image_of_mem _ (mem_univ z.1))).trans (le_max_right _ _)

end PoincareMT.RiemannianMetric
