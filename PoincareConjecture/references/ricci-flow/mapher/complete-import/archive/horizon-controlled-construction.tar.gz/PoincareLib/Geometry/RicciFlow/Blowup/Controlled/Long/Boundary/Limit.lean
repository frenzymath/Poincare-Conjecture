import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Charts
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.LocalFlow

/-! # The complete backward boundary of the actual finite blow-up limit -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space

/-- The boundary is realized by actual extensions of the old limit in every
coordinate ball, with their time overlap and boundary metric retained. -/
theorem exists_complete_backward_boundary_with_retained_extensions
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u})
    {epsilon C kappa r₀ mu : ℝ} {T₀ : ℝ≥0∞}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    (horizon : ENNReal.ofReal T < T₀)
    (hcompact : ∀ K : Set G.limit.carrier.carrier, IsCompact K →
      ∃ D : ℝ, ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
        (G.limit.flow.connection t).scalarCurvature x ≤ D) :
    ∃ gBoundary : G.limit.carrier.metric,
      G.limit.carrier.metricComplete gBoundary ∧
      (∀ y, gBoundary.leviCivitaData.NonnegativeCurvatureOperator y) ∧
      (∀ y v, (G.limit.flow.metric 0).inner y v v ≤ gBoundary.inner y v v) ∧
      ∀ q : G.limit.carrier.carrier, ∃ rho V : ℝ, 0 < rho ∧ T < V ∧
        ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target ∧
        let U : Opens (EuclideanSpace ℝ (Fin 3)) := ⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩
        ∃ F : RicciFlow 3 U (Icc (-V) 0),
          (∀ t ∈ Icc (-V) 0, ∀ x : U, (F.connection t).NonnegativeCurvatureOperator x) ∧
          (∀ t ∈ Ioc (-T) 0, ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
            (F.metric t).inner x v w = (G.limit.flow.metric t).pullbackCoefficients
              (extChartAt (𝓡 3) q).symm x v w) ∧
          ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
            (F.metric (-T)).inner x v w = gBoundary.pullbackCoefficients
              (extChartAt (𝓡 3) q).symm x v w :=
  ControlledBlowupBoundary.exists_complete_boundary_metric_with_retained_chart_extensions
    G.limit.carrier G.limit.base hT G.limit.flow.metric (G.limit.complete 0 G.limit.zero_mem)
    (G.exists_local_backward_extension_of_compact_scalar_bounds hT P04 H horizon hcompact)

/-- Compact all-past scalar bounds produce a complete boundary metric on
the same carrier and local backward flows ending exactly at that metric. -/
theorem exists_complete_backward_boundary_of_compact_scalar_bounds
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u})
    {epsilon C kappa r₀ mu : ℝ} {T₀ : ℝ≥0∞}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    (horizon : ENNReal.ofReal T < T₀)
    (hcompact : ∀ K : Set G.limit.carrier.carrier, IsCompact K →
      ∃ D : ℝ, ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
        (G.limit.flow.connection t).scalarCurvature x ≤ D) :
    ∃ gBoundary : G.limit.carrier.metric,
      G.limit.carrier.metricComplete gBoundary ∧
      (∀ y, gBoundary.leviCivitaData.NonnegativeCurvatureOperator y) ∧
      (∀ y v, (G.limit.flow.metric 0).inner y v v ≤ gBoundary.inner y v v) ∧
      ∀ q : G.limit.carrier.carrier, ∃ rho d : ℝ, 0 < rho ∧ 0 < d ∧
        ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target ∧
        let U : Opens (EuclideanSpace ℝ (Fin 3)) := ⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩
        ∃ F : RicciFlow 3 U (Icc (-d) 0),
          (∀ t ∈ Icc (-d) 0, ∀ x : U, (F.connection t).NonnegativeCurvatureOperator x) ∧
          ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
            (F.metric 0).inner x v w = gBoundary.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w :=
  ControlledBlowupBoundary.exists_complete_boundary_metric_of_chart_extensions G.limit.carrier G.limit.base hT
    G.limit.flow.metric (G.limit.complete 0 G.limit.zero_mem)
    (G.exists_local_backward_extension_of_compact_scalar_bounds hT P04 H horizon hcompact)

end PoincareMT.GeneralizedBlowupConvergence
