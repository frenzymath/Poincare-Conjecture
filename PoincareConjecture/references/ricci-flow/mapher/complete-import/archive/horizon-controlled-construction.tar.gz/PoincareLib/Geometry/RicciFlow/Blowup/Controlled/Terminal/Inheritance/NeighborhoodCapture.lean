import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Capture
import PoincareLib.Geometry.RicciFlow.Compactness.Convergence.Volume.Coverage
import PoincareLib.Geometry.RicciFlow.Compactness.Convergence.Volume.SpatialEmbedding
import PoincareLib.Geometry.Riemannian.Comparison.Laplacian.Branch.Complete

/-!
# Capturing whole canonical neighborhoods through local comparison maps

Completeness of the limit metric and a differential lower bound on one
compact limit ball capture the corresponding source ball. The scalar and
diameter bounds of the actual source neck or cap then capture its closure.
No completeness of the source slice is used.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Topology ENNReal Bundle

universe u v

namespace PoincareMT.ControlledTerminal

variable {M : Type u} {X : Type v} [TopologicalSpace M] [T3Space M]
  [TopologicalSpace X] [T2Space X] [T3Space X]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) X] [IsManifold (𝓡 3) ∞ X]
  [MeasurableSpace X] [BorelSpace X]

omit [T3Space X] [MeasurableSpace X] [BorelSpace X] in
theorem compact_capture_of_inverse_tangent_control
    (g : RiemannianMetric 3 M) (h : RiemannianMetric 3 X)
    (hcomplete : MetricComplete g) (e : OpenPartialHomeomorph M X)
    (he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e e.source)
    (hei : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e.symm e.target)
    (p : M) {r : ℝ} (hr : 0 < r)
    (hsource : closure (g.ball p (2 * r + 1)) ⊆ e.source)
    (hbound : ∀ x ∈ closure (g.ball p (2 * r + 1)), ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ 2 * h.tangentNorm (e x) (mfderiv (𝓡 3) (𝓡 3) e x v))
    {V : Set X} (hV : V ⊆ h.ball (e p) r) :
    V ⊆ e.target ∧ e.symm '' V ⊆ closure (g.ball p (2 * r)) := by
  have hed : e.MDifferentiable (𝓡 3) (𝓡 3) :=
    ⟨he.mdifferentiableOn (by simp), hei.mdifferentiableOn (by simp)⟩
  have hcover := g.ball_subset_image_ball_of_inverse_tangentNorm_le h e p
    (by positivity : 0 < 2 * r + 1) (by norm_num : (0 : ℝ) < 2) (by linarith)
    (g.isCompact_closure_ball_of_metricComplete hcomplete p (2 * r + 1)) hsource
    (fun y hy => (hei.contMDiffAt (e.open_target.mem_nhds hy)).of_le (by simp))
    (g.inverse_tangentNorm_le_of_le h e hed hsource hbound)
  have hsmall : g.ball p (2 * r) ⊆ e.source := by
    intro x hx
    exact hsource (subset_closure (hx.trans_le (ENNReal.ofReal_le_ofReal (by linarith))))
  constructor
  · intro y hy
    obtain ⟨x, hx, rfl⟩ := hcover (hV hy)
    exact e.map_source (hsmall hx)
  · rintro _ ⟨y, hy, rfl⟩
    obtain ⟨x, hx, rfl⟩ := hcover (hV hy)
    rw [e.left_inv (hsmall hx)]
    exact subset_closure hx

theorem neck_closure_capture_of_metric_control
    (g : RiemannianMetric 3 M) (h : RiemannianMetric 3 X)
    (hcomplete : MetricComplete g) (e : OpenPartialHomeomorph M X)
    (he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e e.source)
    (hei : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e.symm e.target)
    (p : M) (N : EpsilonNeck h) (hcenter : N.center = e p)
    {l r : ℝ} (hl : 0 < l) (hscalar : l ≤ N.connection.scalarCurvature N.center)
    (hradius : (2 * Real.pi + 2 * N.epsilon⁻¹) * l ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hsource : closure (g.ball p (2 * r + 1)) ⊆ e.source)
    (hbound : ∀ x ∈ closure (g.ball p (2 * r + 1)), ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ 2 * h.tangentNorm (e x) (mfderiv (𝓡 3) (𝓡 3) e x v)) :
    closure N.carrier ⊆ e.target ∧
      e.symm '' closure N.carrier ⊆ closure (g.ball p (2 * r)) := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : X → Type _) :=
    ⟨h.toRiemannianMetric⟩
  have hr : 0 < r := lt_of_lt_of_le (by positivity [Real.pi_pos, N.epsilon_pos]) hradius
  apply compact_capture_of_inverse_tangent_control g h hcomplete e he hei p hr hsource hbound
  have hcap := N.closure_carrier_subset_ball_of_scalar_lower hl (A := 0) le_rfl hscalar
    N.center (by simp [RiemannianMetric.edist, Manifold.riemannianEDist_self])
  intro y hy
  have hh := hcap hy
  rw [zero_add, hcenter] at hh
  exact hh.trans_le (ENNReal.ofReal_le_ofReal hradius)

theorem cap_closure_capture_of_metric_control
    (g : RiemannianMetric 3 M) (h : RiemannianMetric 3 X)
    (hcomplete : MetricComplete g) (e : OpenPartialHomeomorph M X)
    (he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e e.source)
    (hei : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e.symm e.target)
    (p : M) (N : CapCertificate h) (hp : e p ∈ N.carrier)
    {l r C : ℝ} (hl : 0 < l) (hconstant : N.cap_constant ≤ C)
    (hscalar : l ≤ N.connection.scalarCurvature (e p))
    (hradius : C * l ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hsource : closure (g.ball p (2 * r + 1)) ⊆ e.source)
    (hbound : ∀ x ∈ closure (g.ball p (2 * r + 1)), ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ 2 * h.tangentNorm (e x) (mfderiv (𝓡 3) (𝓡 3) e x v)) :
    closure N.carrier ⊆ e.target ∧
      e.symm '' closure N.carrier ⊆ closure (g.ball p (2 * r)) := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : X → Type _) :=
    ⟨h.toRiemannianMetric⟩
  have hC : 0 < C := N.cap_constant_pos.trans_le hconstant
  have hr : 0 < r := lt_of_lt_of_le (by positivity) hradius
  apply compact_capture_of_inverse_tangent_control g h hcomplete e he hei p hr hsource hbound
  have hcap := N.closure_carrier_subset_ball_of_scalar_lower hl (A := 0) le_rfl hconstant
    hp hscalar (e p) (by simp [RiemannianMetric.edist, Manifold.riemannianEDist_self])
  intro y hy
  have hh := hcap hy
  rw [zero_add] at hh
  exact hh.trans_le (ENNReal.ofReal_le_ofReal hradius)

end PoincareMT.ControlledTerminal
