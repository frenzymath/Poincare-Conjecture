import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.DenseSelection
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.NeckTransfer
import PoincareLib.Geometry.Spacetime.Realization.Interval.Topology

/-!
# Dense canonical times around an arbitrary retained slice

The original whole-slice dense hypothesis is sampled below a chosen limit
time. The samples stay in one retained compact time interval and converge
to its upper endpoint in the normalized clock.
-/

set_option autoImplicit false

open Set Filter
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT

theorem generalizedEarlierDenseStrongCanonicalNeighborhoods.exists_normalized_good_time_at
    {F : GeneralizedRicciFlowData.{u}} {epsilon C origin : ℝ}
    {x : (F.slice origin).carrier}
    (h : generalizedEarlierDenseStrongCanonicalNeighborhoods F epsilon C origin x)
    {q t delta : ℝ} (hq : 0 < q) (ht : origin + t / q ∈ F.interval)
    (ht0 : t ≤ 0) (hdelta : 0 < delta) :
    ∃ s : ℝ, s ∈ Ioc (t - delta) t ∧ origin + s / q ∈ F.interval ∧
      generalizedSliceStrongCanonicalNeighborhoods F epsilon C
        (4 * F.scalar ⟨origin, x⟩) (origin + s / q) := by
  have hbefore : origin + t / q ≤ origin :=
    add_le_of_nonpos_right (div_nonpos_of_nonpos_of_nonneg ht0 hq.le)
  obtain ⟨v, hv, hvlow, hvtop, hgood⟩ := h (origin + t / q) ht hbefore
    (origin + (t - delta) / q) (by
      have hh := (div_lt_div_iff_of_pos_right hq).mpr (sub_lt_self t hdelta)
      linarith)
  let s := (v - origin) * q
  have htime : origin + s / q = v := by
    dsimp [s]
    rw [mul_div_cancel_right₀ _ hq.ne']
    ring
  have hdiv : s / q = v - origin := mul_div_cancel_right₀ _ hq.ne'
  refine ⟨s, ⟨?_, ?_⟩, htime ▸ hv, htime ▸ hgood⟩
  · apply (div_lt_div_iff_of_pos_right hq).mp
    rw [hdiv]
    linarith
  · apply (div_le_div_iff_of_pos_right hq).mp
    rw [hdiv]
    linarith

namespace M30CommonBlowupControls

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space

theorem exists_canonical_times_near_retained_time
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    {J : SpacetimeInterval} (G : GeneralizedBlowupConvergence S J.domain)
    {a t : ℝ} (hat : a < t) (ht0 : t ≤ 0) (hI : Icc a t ⊆ J.domain) :
    ∃ n : ℕ, ∃ s : ℕ → ℝ, Tendsto s atTop (𝓝 t) ∧
      (∀ k, s k ∈ Icc a t) ∧
      ∃ _hs : ∀ k, s k ∈ Icc (-G.exhaustion.time (k + n)) 0,
        ∀ k, generalizedSliceStrongCanonicalNeighborhoods (S.flow (G.subsequence (k + n)))
          epsilon C (4 * S.scale (G.subsequence (k + n)))
          ((S.base (G.subsequence (k + n))).1 + s k / S.scale (G.subsequence (k + n))) := by
  have htimes := G.exhaustion.time_cofinal (Icc a t) isCompact_Icc hI
  obtain ⟨n, hn⟩ := eventually_atTop.mp htimes
  have ht (k : ℕ) : t ∈ Icc (-G.exhaustion.time (k + n)) 0 :=
    hn (k + n) (Nat.le_add_left n k) ⟨hat.le, le_rfl⟩
  have hex (k : ℕ) := (H.canonical (G.subsequence (k + n))).exists_normalized_good_time_at
    (S.base_scalar_pos _) ((S.flow (G.subsequence (k + n))).slice_nonempty_iff _ |>.mp
      ⟨(G.embedding (k + n)).forward t (ht k) G.limit.base⟩) ht0
    (lt_min (sub_pos.mpr hat) (by positivity : 0 < ((k : ℝ) + 1)⁻¹))
  choose s hs using hex
  have hsI (k : ℕ) : s k ∈ Icc a t := by
    have hlo := (hs k).1.1
    have hmin := min_le_left (t - a) (((k : ℝ) + 1)⁻¹)
    exact ⟨by linarith, (hs k).1.2⟩
  refine ⟨n, s, ?_, hsI, fun k => hn (k + n) (Nat.le_add_left n k) (hsI k),
    fun k => (hs k).2.2⟩
  have hsmall : Tendsto (fun k : ℕ => ((k : ℝ) + 1)⁻¹) atTop (𝓝 0) :=
    tendsto_inv_atTop_zero.comp
      (tendsto_atTop_add_const_right atTop 1 tendsto_natCast_atTop_atTop)
  have hlower : Tendsto (fun k : ℕ => t - ((k : ℝ) + 1)⁻¹) atTop (𝓝 t) := by
    simpa only [sub_zero] using tendsto_const_nhds.sub hsmall
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le hlower tendsto_const_nhds
  · intro k
    have hlo := (hs k).1.1
    have hmin := min_le_right (t - a) (((k : ℝ) + 1)⁻¹)
    linarith
  · exact fun k => (hs k).1.2

end M30CommonBlowupControls
end PoincareMT
