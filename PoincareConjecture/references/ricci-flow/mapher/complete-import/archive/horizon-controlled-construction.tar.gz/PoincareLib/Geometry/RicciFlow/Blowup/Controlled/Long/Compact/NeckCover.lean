import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.MovingNecks.Distant
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.PointControl
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.Carrier

/-!
# Compact past curvature control from inherited neck geometry

On a noncompact limit a sufficiently distant fixed point is controlled by
the actual neck cover. The dense bounded-distance predecessor then propagates
its bound to every compact set. Compact carriers use the scalar minimum bound.
Reference: Morgan--Tian, Claims 11.10--11.14, pp. 274--277.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.RiemannianMetric

theorem exists_point_with_distance_ge_of_noncompact
    {n : ℕ} {M : Type*} [TopologicalSpace M] [T3Space M] [ConnectedSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    (g : RiemannianMetric n M) (hcomplete : MetricComplete g)
    (hnoncompact : ¬CompactSpace M) (p : M) (A : ℝ) :
    ∃ y : M, A ≤ (g.edist p y).toReal := by
  by_contra hn
  push Not at hn
  have hall : {y | g.edist p y ≤ ENNReal.ofReal A} = univ := by
    apply eq_univ_of_forall
    intro y
    change g.edist p y ≤ ENNReal.ofReal A
    rw [← ENNReal.ofReal_toReal (g.edist_ne_top p y)]
    exact ENNReal.ofReal_le_ofReal (hn y).le
  have hcompact := g.isCompact_closedBall_of_metricComplete hcomplete p A
  rw [hall] at hcompact
  exact hnoncompact (isCompact_univ_iff.mp hcompact)

end PoincareMT.RiemannianMetric

namespace PoincareMT.ControlledLongGeometry

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem exists_point_with_uniform_past_scalar_bound_of_neck_cover
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T epsilon K cutoff : ℝ} (hT : 0 < T) (hepsilon : 0 < epsilon)
    (hsmall : epsilon ≤ 1 / (400 * Real.pi)) (hK : 0 < K)
    (L : BlowupLimitFlow.{u} (Ioc (-T) 0)) (hnoncompact : ¬CompactSpace L.carrier.carrier)
    (hcover : ∀ t ∈ Ioc (-T) 0, ∀ y : L.carrier.carrier,
      cutoff < (L.flow.connection t).scalarCurvature y →
      ∃ N : EpsilonNeck (L.flow.metric t), N.epsilon = epsilon ∧
        ((L.flow.metric t).edist y N.center).toReal ≤
          K * (L.flow.connection t).scalarCurvature y ^ (-1 / 2 : ℝ) ∧
        (L.flow.connection t).scalarCurvature y ≤
          K * (L.flow.connection t).scalarCurvature N.center) :
    ∃ y : L.carrier.carrier, ∃ B : ℝ, 0 < B ∧ ∀ t ∈ Ioc (-T) 0,
      (L.flow.connection t).scalarCurvature y ≤ B := by
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  obtain ⟨A, _, hbound⟩ := exists_uniform_past_distant_controlled_neck_scalar_bound
    P04 P06 hT hepsilon hsmall hK L L.base
  obtain ⟨y, hy⟩ := (L.flow.metric 0).exists_point_with_distance_ge_of_noncompact
    (L.complete 0 L.zero_mem) hnoncompact L.base A
  obtain ⟨B, hB, hpoint⟩ := hbound y hy
  refine ⟨y, max cutoff B, hB.trans_le (le_max_right _ _), ?_⟩
  intro t ht
  by_cases hlow : (L.flow.connection t).scalarCurvature y ≤ cutoff
  · exact hlow.trans (le_max_left _ _)
  obtain ⟨N, heq, hcenter, hscalar⟩ := hcover t ht y (lt_of_not_ge hlow)
  exact (hpoint t ht N heq hcenter hscalar).trans (le_max_right _ _)

end PoincareMT.ControlledLongGeometry

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem exists_uniform_compact_scalar_bound_of_controlled_neck_cover
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {epsilon C neckEpsilon neckConstant cutoff : ℝ}
    (hepsilon : 0 < neckEpsilon) (hsmall : neckEpsilon ≤ 1 / (400 * Real.pi))
    (hconstant : 0 < neckConstant)
    (hM29 : ∀ S : GeneralizedBlowupSequence.{u},
      DenseGeneralizedBoundedDistanceHypotheses S epsilon C → GeneralizedBlowupBoundedDistance S)
    (H : DenseGeneralizedBoundedDistanceHypotheses S epsilon C)
    (hcover : ¬CompactSpace G.limit.carrier.carrier →
      ∀ t ∈ Ioc (-T) 0, ∀ y : G.limit.carrier.carrier,
        cutoff < (G.limit.flow.connection t).scalarCurvature y →
        ∃ N : EpsilonNeck (G.limit.flow.metric t), N.epsilon = neckEpsilon ∧
          ((G.limit.flow.metric t).edist y N.center).toReal ≤
            neckConstant * (G.limit.flow.connection t).scalarCurvature y ^ (-1 / 2 : ℝ) ∧
          (G.limit.flow.connection t).scalarCurvature y ≤
            neckConstant * (G.limit.flow.connection t).scalarCurvature N.center)
    {K : Set G.limit.carrier.carrier} (hK : IsCompact K) :
    ∃ D : ℝ, 0 < D ∧ ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
      (G.limit.flow.connection t).scalarCurvature x ≤ D := by
  by_cases hcompact : CompactSpace G.limit.carrier.carrier
  · let : CompactSpace G.limit.carrier.carrier := hcompact
    obtain ⟨D, hD, hbound⟩ := G.exists_uniform_scalar_bound_of_compact_limit hT P04 P06 hM29 H
    exact ⟨D, hD, fun t ht x _ => hbound t ht x⟩
  obtain ⟨y, B, _, hpoint⟩ := ControlledLongGeometry.exists_point_with_uniform_past_scalar_bound_of_neck_cover
    P04 P06 hT hepsilon hsmall hconstant G.limit hcompact (hcover hcompact)
  exact G.exists_uniform_compact_scalar_bound_of_point_bound hT P04 P06 hM29 H y hpoint hK

end PoincareMT.GeneralizedBlowupConvergence
