import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.Derivatives
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourceCurvature

/-! # Curvature derivative control in retained charts on larger past windows -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

/-- The same retained M07 spatial maps have derivative control on every
larger controlled cylinder with a positive time margin. -/
theorem exists_eventually_reference_window_curvatureDerivative_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    {U V D : ℝ} (hV : 0 ≤ V) (hVU : V < U) (hD : 0 ≤ D)
    (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ k in atTop,
      ∀ eta' : ℝ, ∀ d : ControlledBlowupCylinder S (idx (G.subsequence k))
        (A (G.subsequence k)) U D eta',
      ∀ s ∈ Icc (-V) 0, ∀ x ∈ K,
        ((d.smallFlow (hA _) (hV.trans_lt hVU)).connection s).curvatureDerivativeNorm m
          (G.referenceChartMap q k 0 x) ≤ C := by
  have hzero : -T / 2 < 0 ∧ 0 < T / 2 := ⟨by linarith, by linarith⟩
  have hc : ContinuousOn (extChartAt (𝓡 3) q).symm K :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨R, hR, himage⟩ := G.exists_pos_eventually_image_subset_ballAt hzero hzero
    hcomplete (hK.image_of_continuousOn hc)
  let R' := Real.exp (3 * B * |(-T / 2)|) * R
  have hR' : 0 < R' := mul_pos (Real.exp_pos _) hR
  obtain ⟨C, hC, hderiv⟩ := exists_uniform_curvatureDerivative_bound_of_margins
    P04 hV hVU hD m
  have hAr' : Tendsto (fun k => A (G.subsequence k)) atTop atTop :=
    hAr.comp G.subsequence_strictMono.tendsto_atTop
  refine ⟨C, hC, ?_⟩
  filter_upwards [himage, hAr'.eventually_ge_atTop (R' + 1)] with k hk hAk eta' d s hs x hx
  rw [d.smallFlow_curvatureDerivativeNorm]
  apply hderiv S (idx (G.subsequence k)) (A (G.subsequence k)) R' eta' hR' hAk d
    (hcompact _) s hs
  have hxsmall := hk (mem_image_of_mem _ (mem_image_of_mem _ hx))
  change (((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).metric
    (0 + (-T / 2))).edist (smallBase S (idx (G.subsequence k)) (hA _))
      (G.referenceChartMap q k 0 x) < ENNReal.ofReal R at hxsmall
  rw [zero_add] at hxsmall
  unfold smallFlow smallBase at hxsmall
  rw [RicciFlow.shrink_edist, Equiv.symm_apply_apply] at hxsmall
  unfold componentFlow at hxsmall
  rw [RicciFlow.restrictComponent_edist] at hxsmall
  exact (e (G.subsequence k)).ordinaryFlow_ball_subset_terminal_ball
    (hA _) hT (show -T / 2 ∈ Icc (-T) 0 from ⟨by linarith, by linarith⟩) R hxsmall

end PoincareMT.ControlledBlowupCompactness
