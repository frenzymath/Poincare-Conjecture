import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Distance.Bound

/-! # Uniform compact-set diameter bounds on a finite backward limit -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongDistance

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_uniform_compact_diameter_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T : ℝ} (hT : 0 < T) (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    (K : Set L.carrier.carrier) (hK : IsCompact K) :
    ∃ D : ℝ, 0 < D ∧ ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K, ∀ y ∈ K,
      ((L.flow.metric t).edist x y).toReal ≤ D := by
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : L.carrier.carrier → Type _) :=
    ⟨(L.flow.metric 0).toRiemannianMetric⟩
  obtain ⟨C, hC, hdist⟩ := exists_uniform_additive_distance_bound P04 P06 hT L
  obtain ⟨A, hA⟩ := hK.exists_bound_of_continuousOn
    ((L.flow.metric 0).continuous_toReal_edist L.base).continuousOn
  refine ⟨2 * max A 0 + C, by positivity, ?_⟩
  intro t ht x hx y hy
  have hxA : ((L.flow.metric 0).edist x L.base).toReal ≤ max A 0 := by
    rw [show (L.flow.metric 0).edist x L.base = (L.flow.metric 0).edist L.base x from
      Manifold.riemannianEDist_comm]
    exact ((le_abs_self _).trans (hA x hx)).trans (le_max_left _ _)
  have hyA : ((L.flow.metric 0).edist L.base y).toReal ≤ max A 0 :=
    ((le_abs_self _).trans (hA y hy)).trans (le_max_left _ _)
  have htri := (L.flow.metric 0).toReal_edist_triangle x L.base y
  have htime := hdist t ht x y
  linarith

theorem exists_uniform_ball_expansion
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T : ℝ} (hT : 0 < T) (L : BlowupLimitFlow.{u} (Ioc (-T) 0)) :
    ∃ C : ℝ, 0 < C ∧ ∀ t ∈ Ioc (-T) 0, ∀ p : L.carrier.carrier, ∀ R : ℝ,
      (L.flow.metric 0).ball p R ⊆ (L.flow.metric t).ball p (R + C) := by
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  obtain ⟨C, hC, hdist⟩ := exists_uniform_additive_distance_bound P04 P06 hT L
  refine ⟨C, hC, ?_⟩
  intro t ht p R x hx
  have hR : 0 < R := by
    exact ENNReal.ofReal_pos.mp (bot_le.trans_lt hx)
  have hxR : ((L.flow.metric 0).edist p x).toReal < R := by
    have hx' := hx
    change (L.flow.metric 0).edist p x < ENNReal.ofReal R at hx'
    rw [← ENNReal.ofReal_toReal ((L.flow.metric 0).edist_ne_top p x)] at hx'
    exact (ENNReal.ofReal_lt_ofReal_iff hR).mp hx'
  change (L.flow.metric t).edist p x < ENNReal.ofReal (R + C)
  rw [← ENNReal.ofReal_toReal ((L.flow.metric t).edist_ne_top p x)]
  exact (ENNReal.ofReal_lt_ofReal_iff (by positivity)).mpr
    ((hdist t ht p x).trans_lt (by linarith))

end PoincareMT.ControlledLongDistance
