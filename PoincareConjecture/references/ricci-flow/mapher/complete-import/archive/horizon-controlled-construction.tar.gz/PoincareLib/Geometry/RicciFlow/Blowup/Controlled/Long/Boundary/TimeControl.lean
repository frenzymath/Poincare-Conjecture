import PoincareLib.Geometry.RicciFlow.Curvature.Theory
import PoincareLib.Geometry.RicciFlow.MetricComparison
import PoincareLib.Geometry.Riemannian.Comparison.Volume.Rigidity.Curvature
import Mathlib.Topology.UniformSpace.HeineCantor

/-! # Uniform scalar and tangent bounds at a closed backward endpoint -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.RicciFlow

variable {M : Type u} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
  {J : Set ℝ} (P04 : RicciFlowCurvatureTheory.{u}) (F : RicciFlow 3 M J)

include P04

theorem exists_scalar_upper_bound_on_compact
    (hJ : IsCompact J) {K : Set M} (hK : IsCompact K) :
    ∃ B : ℝ, 0 < B ∧ ∀ s ∈ J, ∀ x ∈ K, (F.connection s).scalarCurvature x ≤ B := by
  have hc : ContinuousOn (fun z : ℝ × M => (F.connection z.1).scalarCurvature z.2)
      (J ×ˢ K) := (P04.scalar_regular 3 M J F).continuousOn.mono
    (prod_mono subset_rfl (subset_univ _))
  obtain ⟨B, hB⟩ := (hJ.prod hK).exists_bound_of_continuousOn hc
  refine ⟨max B 1, lt_of_lt_of_le zero_lt_one (le_max_right _ _), ?_⟩
  intro s hs x hx
  exact ((le_abs_self _).trans (by simpa only [Real.norm_eq_abs] using hB (s, x) ⟨hs, hx⟩)).trans
    (le_max_left _ _)

theorem tendstoUniformlyOn_scalar_at_included_time
    {K : Set M} (hK : IsCompact K) {t : ℝ} (ht : t ∈ J) :
    TendstoUniformlyOn (fun s x => (F.connection s).scalarCurvature x)
      (F.connection t).scalarCurvature (𝓝[J] t) K := by
  have hc : ContinuousOn (fun z : ℝ × M => (F.connection z.1).scalarCurvature z.2)
      (J ×ˢ K) := (P04.scalar_regular 3 M J F).continuousOn.mono
    (prod_mono subset_rfl (subset_univ _))
  apply Metric.tendstoUniformlyOn_iff.mpr
  intro delta hdelta
  obtain ⟨V, hV, hbound⟩ := hK.mem_uniformity_of_prod
    (f := fun s x => (F.connection s).scalarCurvature x) hc ht (Metric.dist_mem_uniformity hdelta)
  exact Filter.mem_of_superset hV fun s hs x hx => by
    simpa only [Set.mem_setOf_eq, dist_comm] using hbound s hs x hx

/-- On a fixed compact set, nearby metrics have a common inverse tangent
bound. Only the accepted scalar regularity and actual Ricci equation are used. -/
theorem eventually_tangentNorm_le_twice_at_included_time
    [T2Space M] (hJ : IsCompact J) (hconvex : Convex ℝ J)
    (hnonnegative : ∀ s ∈ J, ∀ x, (F.connection s).NonnegativeCurvatureOperator x)
    {K : Set M} (hK : IsCompact K) {t : ℝ} (ht : t ∈ J) :
    ∀ᶠ s in 𝓝[J] t, ∀ x ∈ K, ∀ v : TangentSpace (𝓡 3) x,
      (F.metric t).tangentNorm x v ≤ 2 * (F.metric s).tangentNorm x v := by
  have hcont : ContinuousOn (fun z : ℝ × M => (F.connection z.1).scalarCurvature z.2)
      (J ×ˢ K) := (P04.scalar_regular 3 M J F).continuousOn.mono
    (prod_mono subset_rfl (subset_univ _))
  obtain ⟨B, hB⟩ := (hJ.prod hK).exists_bound_of_continuousOn hcont
  have hscalar (s : ℝ) (hs : s ∈ J) (x : M) (hx : x ∈ K) :
      (F.connection s).scalarCurvature x ≤ B :=
    (le_abs_self _).trans (by simpa only [Real.norm_eq_abs] using hB (s, x) ⟨hs, hx⟩)
  have hexp : ∀ᶠ s in 𝓝 t, Real.exp (B * |t - s|) < 2 := by
    have hc : Continuous (fun s : ℝ => Real.exp (B * |t - s|)) := by fun_prop
    exact hc.continuousAt (gt_mem_nhds (by norm_num : Real.exp (B * |t - t|) < 2))
  filter_upwards [self_mem_nhdsWithin, hexp.filter_mono nhdsWithin_le_nhds] with s hs he x hx v
  have hRic (r : ℝ) (hr : r ∈ J) :
      |(F.connection r).ricci x v v| ≤ B * (F.metric r).inner x v v := by
    have hnonneg := fun w => (F.connection r).ricci_nonneg_of_nonnegative_curvatureOperator
      x (hnonnegative r hr x) w
    rw [abs_of_nonneg (hnonneg v)]
    apply ((F.connection r).ricci_le_scalarCurvature_mul_inner_of_nonneg x hnonneg v).trans
    apply mul_le_mul_of_nonneg_right (hscalar r hr x hx)
    by_cases hv : v = 0
    · subst v; simp
    · exact ((F.metric r).pos x v hv).le
  exact (F.tangentNorm_le_exp_of_ricci_bound hconvex subset_rfl x v B hRic hs ht).trans
    (mul_le_mul_of_nonneg_right he.le (Real.sqrt_nonneg _))

end PoincareMT.RicciFlow
