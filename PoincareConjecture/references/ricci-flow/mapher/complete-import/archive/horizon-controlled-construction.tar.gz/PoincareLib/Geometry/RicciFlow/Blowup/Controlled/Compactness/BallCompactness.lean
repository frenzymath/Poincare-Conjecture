import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.TerminalMetric
import PoincareLib.Geometry.RicciFlow.Rescaling.Volume
import PoincareLib.Geometry.Riemannian.Distance.TangentBound

/-!
# Compact balls inside controlled cylinders

A terminal spatial buffer and the uniform curvature bound retain compact
closures of intrinsic balls at every cylinder time. No completeness of the
open source cylinder is required. Source: Morgan--Tian, Theorem 5.15, p. 92,
and Theorem 11.1, pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

theorem normalized_terminal_ball (r : ℝ) :
    (rescaledMetric ((S.flow k).metric (S.base k).1) (S.scale k)
      (S.base_scalar_pos k)).ball (S.base k).2 r = S.baseBall k r :=
  rescaledMetric_ball_allDimensions _ _ _ _ _

/-- Intrinsic cylinder balls remain in the normalized terminal ambient ball. -/
theorem ordinaryFlow_ball_subset_terminal_ball
    (e : ControlledBlowupCylinder S k A T B eta) (hA : 0 < A) (hT : 0 < T)
    {s : ℝ} (hs : s ∈ Icc (-T) 0) (r : ℝ) :
    ((e.ordinaryFlow hT).metric s).ball (sourceBase S k hA) r ⊆
      (Subtype.val : sourceBall S k A → _) ⁻¹'
        S.baseBall k (Real.exp (3 * B * |s|) * r) := by
  let g := rescaledMetric ((S.flow k).metric (S.base k).1) (S.scale k)
    (S.base_scalar_pos k)
  have hdist (x y : sourceBall S k A) :
      g.edist x.val y.val ≤ ENNReal.ofReal (Real.exp (3 * B * |s|)) *
        ((e.ordinaryFlow hT).metric s).edist x y := by
    apply RiemannianMetric.edist_le_mul_of_tangentNorm_mfderiv_le _ _
      contMDiff_subtype_val (Real.exp_pos _) _ x y
    intro z v
    have hi := e.ordinaryFlow_terminal_inner hT z v v
    have hn := congrArg Real.sqrt hi
    change ((e.ordinaryFlow hT).metric 0).tangentNorm z v =
      g.tangentNorm z.val (mfderiv (𝓡 3) (𝓡 3) Subtype.val z v) at hn
    rw [← hn]
    simpa only [zero_sub, abs_neg] using
      e.ordinaryFlow_tangentNorm_le hT z v hs (show (0 : ℝ) ∈ Icc (-T) 0 by
        exact ⟨by linarith, le_rfl⟩)
  intro x hx
  rw [← normalized_terminal_ball]
  change g.edist (S.base k).2 x.val < ENNReal.ofReal (Real.exp (3 * B * |s|) * r)
  rw [ENNReal.ofReal_mul (Real.exp_nonneg _)]
  exact (hdist (sourceBase S k hA) x).trans_lt
    (ENNReal.mul_lt_mul_right (ENNReal.ofReal_pos.mpr (Real.exp_pos _)).ne'
      ENNReal.ofReal_ne_top hx)

/-- The strict half-ball buffer converts ambient compactness to intrinsic
compactness at any controlled time. -/
theorem ordinaryFlow_isCompact_closure_ball
    (e : ControlledBlowupCylinder S k A T B eta) (hA : 0 < A) (hT : 0 < T)
    (hcompact : IsCompact (closure (S.baseBall k A)))
    {s : ℝ} (hs : s ∈ Icc (-T) 0) {r : ℝ}
    (hbuffer : Real.exp (3 * B * |s|) * r ≤ A / 2) :
    IsCompact (closure (((e.ordinaryFlow hT).metric s).ball (sourceBase S k hA) r)) := by
  let g := rescaledMetric ((S.flow k).metric (S.base k).1) (S.scale k)
    (S.base_scalar_pos k)
  have hhalf : closure (S.baseBall k (A / 2)) ⊆ S.baseBall k A := by
    rw [← normalized_terminal_ball, ← normalized_terminal_ball]
    exact RicciFlowAnalysis.initial_half_ball_closure_subset_initial_ball g (S.base k).2 hA
  have hhalfcompact : IsCompact (closure (S.baseBall k (A / 2))) :=
    hcompact.of_isClosed_subset isClosed_closure (hhalf.trans subset_closure)
  have hpre : IsCompact ((Subtype.val : sourceBall S k A → _) ⁻¹'
      closure (S.baseBall k (A / 2))) :=
    Topology.IsEmbedding.subtypeVal.isInducing.isCompact_preimage' hhalfcompact
      (by intro x hx; exact ⟨⟨x, hhalf hx⟩, rfl⟩)
  apply hpre.of_isClosed_subset isClosed_closure
  apply closure_minimal _ (isClosed_closure.preimage continuous_subtype_val)
  intro x hx
  apply subset_closure
  have h := e.ordinaryFlow_ball_subset_terminal_ball hA hT hs r hx
  change ((S.flow k).metric (S.base k).1).edist (S.base k).2 x.val < _ at h ⊢
  exact h.trans_le (ENNReal.ofReal_le_ofReal
    (div_le_div_of_nonneg_right hbuffer (Real.sqrt_nonneg _)))

/-- The buffered compactness survives both based-component and universe
restriction, as required by the frozen Type-0 compactness service. -/
theorem smallFlow_isCompact_closure_ball
    (e : ControlledBlowupCylinder S k A T B eta) (hA : 0 < A) (hT : 0 < T)
    (hcompact : IsCompact (closure (S.baseBall k A)))
    {s : ℝ} (hs : s ∈ Icc (-T) 0) {r : ℝ}
    (hbuffer : Real.exp (3 * B * |s|) * r ≤ A / 2) :
    IsCompact (closure (((e.smallFlow hA hT).metric s).ball (smallBase S k hA) r)) := by
  let E := Poincare.Topology.SecondCountable.homeomorphShrink
    (componentCarrier S k hA).carrier
  let f : (componentCarrier S k hA).shrink.carrier → sourceBall S k A :=
    fun x => (E.symm x).val
  have he : Topology.IsClosedEmbedding f :=
    (isClosed_connectedComponent.isClosedEmbedding_subtypeVal).comp E.symm.isClosedEmbedding
  have hc := he.isCompact_preimage (e.ordinaryFlow_isCompact_closure_ball hA hT hcompact hs hbuffer)
  apply hc.of_isClosed_subset isClosed_closure
  apply closure_minimal _ (isClosed_closure.preimage he.continuous)
  intro x hx
  apply subset_closure
  change ((e.smallFlow hA hT).metric s).edist (smallBase S k hA) x < _ at hx
  unfold smallFlow smallBase at hx
  rw [RicciFlow.shrink_edist, Equiv.symm_apply_apply] at hx
  unfold componentFlow at hx
  rw [RicciFlow.restrictComponent_edist] at hx
  exact hx

end PoincareMT.ControlledBlowupCylinder
