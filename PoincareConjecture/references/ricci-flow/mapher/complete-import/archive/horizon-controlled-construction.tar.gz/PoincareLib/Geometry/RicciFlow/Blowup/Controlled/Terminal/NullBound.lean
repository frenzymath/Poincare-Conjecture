import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NullOrientation
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.ProductFactor
import PoincareLib.Geometry.Riemannian.Splitting.ParallelGradient.ProductIsometry

/-!
# Scalar bounds from the terminal parallel null direction

The complete parallel gradient flow constructs the actual line product.
A sufficiently small neck makes its transverse surface compact, giving a
global scalar bound. On a simply connected finite-slab terminal slice, the
coordinate itself is produced from the sectional null plane.

Reference: Morgan--Tian, Claim 11.7, p. 271.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set TopologicalSpace
open Poincare.Geometry.Manifold.RegularLevel
open scoped Manifold ContDiff Bundle

universe u

namespace PoincareMT.RiemannianMetric

/-- Completeness constructs the product; the neck constructs compactness of
the transverse factor. Neither product nor compact factor is an input. -/
theorem exists_parallel_potential_neck_scalar_bound_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 200 ∧
      ∀ (M : Type u) [TopologicalSpace M] [T2Space M] [T3Space M] [ConnectedSpace M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
        [MeasurableSpace M] [BorelSpace M],
      ∀ (g : RiemannianMetric 3 M) (D : LeviCivitaData g) (f : M → ℝ),
        MetricComplete g → ContMDiff (𝓡 3) 𝓘(ℝ, ℝ) ∞ f →
        HasUnitGradient D f → HasZeroHessian D f →
        ∀ N : EpsilonNeck g, N.epsilon ≤ epsilon₀ →
          ∃ B : ℝ, 0 < B ∧ ∀ x : M, D.scalarCurvature x ≤ B := by
  obtain ⟨epsilon₀, hpos, hsmall, hbound⟩ :=
    exists_neck_line_product_scalar_bound_threshold.{u}
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro M _ _ _ _ _ _ _ _ g D f hcomplete hf hu hz N hN
  let : Fact (Module.finrank ℝ (EuclideanSpace ℝ (Fin 3)) = 2 + 1) :=
    ⟨finrank_euclideanSpace_fin⟩
  let hreg := fun x (_ : x ∈ (⊤ : Opens M)) => regular_of_hasUnitGradient hu x
  let := openLevelSetChartedSpace hf (⊤ : Opens M) hreg 2 0
  let := isManifold_openLevelSet hf (⊤ : Opens M) hreg 2 0
  let h := regularLevelMetric hf (⊤ : Opens M) hreg 0 g
  obtain ⟨_, hconnected, _, _, e, _, _, _, _, _, hmetric, _⟩ :=
    exists_parallelGradient_productIsometry (n := 2) hcomplete hf hu hz
  let : ConnectedSpace (zeroLevelSet f) := hconnected
  exact hbound (zeroLevelSet f) M h g D e hmetric N hN

end PoincareMT.RiemannianMetric

namespace PoincareMT.RicciFlow

/-- A terminal null plane and one small neck bound curvature on a complete
simply connected terminal slice of an actual nonnegative finite-slab flow. -/
theorem exists_simplyConnected_terminal_null_neck_scalar_bound_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 200 ∧
      ∀ (M : Type u) [TopologicalSpace M] [T2Space M] [T3Space M]
        [ConnectedSpace M] [SimplyConnectedSpace M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
        [MeasurableSpace M] [BorelSpace M],
      ∀ (_hC : RicciFlowCurvatureTheory.{u}) {a b : ℝ}, a < b →
      ∀ F : RicciFlow 3 M (Icc a b),
        (∀ t ∈ Icc a b, ∀ x, (F.connection t).NonnegativeCurvatureOperator x) →
        (∃ p, (F.connection b).curvatureTensorNorm p ≠ 0) →
        MetricComplete (F.metric b) →
      ∀ (x : M) (v w : TangentSpace (𝓡 3) x),
        (F.metric b).inner x v v = 1 → (F.metric b).inner x w w = 1 →
        (F.metric b).inner x v w = 0 →
        (F.connection b).curvatureTensor x v w v w = 0 →
      ∀ N : EpsilonNeck (F.metric b), N.epsilon ≤ epsilon₀ →
        ∃ B : ℝ, 0 < B ∧ ∀ y : M, (F.connection b).scalarCurvature y ≤ B := by
  obtain ⟨epsilon₀, hpos, hsmall, hbound⟩ :=
    RiemannianMetric.exists_parallel_potential_neck_scalar_bound_threshold.{u}
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro M _ _ _ _ _ _ _ _ _ hC a b hab F hoperator hnonflat hcomplete x v w hv hw hvw
    hzero N hN
  have hsec (t : ℝ) (ht : t ∈ Icc a b) :
      (F.connection t).NonnegativeSectionalCurvature := fun y u z =>
    (F.connection t).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
      y (hoperator t ht y) u z
  have hdim := F.ricciNullity_eq_one_of_closed_slab_terminal_null_plane
    hC hab hoperator hnonflat x v w hv hw hvw hzero
  obtain ⟨f, hf, _, hu, hz⟩ :=
    Splitting.exists_parallel_potential_of_simplyConnected_terminal_nullity_one
      hC hab F hsec hdim x
  exact hbound M (F.metric b) (F.connection b) f hcomplete hf hu hz N hN

end PoincareMT.RicciFlow
