import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.LiftedLimit

/-! # Coordinate coefficients of universe-lifted blow-up limits -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold
  normedAddCommGroupTangentSpaceVectorSpace normedSpaceTangentSpaceVectorSpace

theorem liftedLimit_coordinateCoefficient {J : Set ℝ} (L : BlowupLimitFlow.{0} J)
    (q : (liftedLimit.{u} L).carrier.carrier) (a b : Fin 3)
    (p : ℝ × EuclideanSpace ℝ (Fin 3))
    (hp : p.2 ∈ (extChartAt (𝓡 3) q).target) :
    (liftedLimit.{u} L).carrier.coordinateCoefficient q
      (fun t x v w => ((liftedLimit.{u} L).flow.metric t).inner x v w) a b p =
    L.carrier.coordinateCoefficient q.down
      (fun t x v w => (L.flow.metric t).inner x v w) a b p := by
  let e := Poincare.Manifold.uliftDiffeomorph (𝓡 3) L.carrier.carrier
  let c := extChartAt (𝓡 3) q
  have hc := ((contMDiffOn_extChartAt_symm (n := ∞) q).contMDiffAt
    ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds hp)).mdifferentiableAt (by simp)
  have hd := mfderiv_comp p.2 (e.contMDiff.mdifferentiable (by simp) (c.symm p.2)) hc
  have hda := congrArg (fun A => A (EuclideanSpace.basisFun (Fin 3) ℝ a)) hd
  have hdb := congrArg (fun A => A (EuclideanSpace.basisFun (Fin 3) ℝ b)) hd
  change _ = mfderiv (𝓡 3) (𝓡 3) e (c.symm p.2)
    (mfderiv (𝓡 3) (𝓡 3) c.symm p.2 (EuclideanSpace.basisFun (Fin 3) ℝ a)) at hda
  change _ = mfderiv (𝓡 3) (𝓡 3) e (c.symm p.2)
    (mfderiv (𝓡 3) (𝓡 3) c.symm p.2 (EuclideanSpace.basisFun (Fin 3) ℝ b)) at hdb
  change (L.flow.metric p.1).inner (e (c.symm p.2))
    (mfderiv (𝓡 3) (𝓡 3) e (c.symm p.2)
      (mfderiv (𝓡 3) (𝓡 3) c.symm p.2 (EuclideanSpace.basisFun (Fin 3) ℝ a)))
    (mfderiv (𝓡 3) (𝓡 3) e (c.symm p.2)
      (mfderiv (𝓡 3) (𝓡 3) c.symm p.2 (EuclideanSpace.basisFun (Fin 3) ℝ b))) = _
  rw [← hda, ← hdb]
  rfl

theorem liftedLimit_coordinateJet {J : Set ℝ} (L : BlowupLimitFlow.{0} J)
    (q : (liftedLimit.{u} L).carrier.carrier) (a b : Fin 3)
    (W : Set (ℝ × EuclideanSpace ℝ (Fin 3))) (r : ℕ)
    (p : ℝ × EuclideanSpace ℝ (Fin 3))
    (hp : p.2 ∈ (extChartAt (𝓡 3) q).target) :
    iteratedFDerivWithin ℝ r
      ((liftedLimit.{u} L).carrier.coordinateCoefficient q
        (fun t x v w => ((liftedLimit.{u} L).flow.metric t).inner x v w) a b) W p =
    iteratedFDerivWithin ℝ r
      (L.carrier.coordinateCoefficient q.down
        (fun t x v w => (L.flow.metric t).inner x v w) a b) W p := by
  have heq : (liftedLimit.{u} L).carrier.coordinateCoefficient q
      (fun t x v w => ((liftedLimit.{u} L).flow.metric t).inner x v w) a b =ᶠ[𝓝 p]
      L.carrier.coordinateCoefficient q.down (fun t x v w => (L.flow.metric t).inner x v w) a b := by
    filter_upwards [continuousAt_snd.preimage_mem_nhds (extChartAt_target_mem_nhds' hp)] with z hz
    exact liftedLimit_coordinateCoefficient L q a b z hz
  exact (heq.filter_mono nhdsWithin_le_nhds).iteratedFDerivWithin_eq heq.self_of_nhds r

end PoincareMT.ControlledBlowupCompactness
