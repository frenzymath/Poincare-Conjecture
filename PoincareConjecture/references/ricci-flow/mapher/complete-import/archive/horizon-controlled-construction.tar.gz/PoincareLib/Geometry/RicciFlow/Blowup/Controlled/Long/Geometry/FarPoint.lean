import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.AncientVolume.ScalarRatio.Cone.Metric.RayDensity

/-!
# A distant point with a farther equidistant companion

Uniform sublinear ray approximation and the intermediate value theorem
give the geometric input of Morgan--Tian, Lemma 11.12, pp. 275--276.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledLongGeometry

theorem exists_distant_equidistant_companion
    {n : ℕ} {M : Type*} [TopologicalSpace M] [T3Space M] [ConnectedSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    (g : RiemannianMetric n M) (D : LeviCivitaData g)
    (hcomplete : MetricComplete g) (hsec : D.NonnegativeSectionalCurvature) (p : M) :
    ∃ A : ℝ, 0 < A ∧ ∀ y : M, A ≤ (g.edist p y).toReal → ∃ x : M,
      (g.edist y x).toReal = (g.edist p y).toReal ∧
        3 * (g.edist p y).toReal / 2 < (g.edist p x).toReal := by
  obtain ⟨A, hA, happrox⟩ := g.exists_uniform_sublinear_ray_approximation D hcomplete hsec p
    (by norm_num : (0 : ℝ) < 1 / 4)
  refine ⟨A, hA, ?_⟩
  intro y hy
  let d := (g.edist p y).toReal
  have hd : 0 < d := hA.trans_le hy
  obtain ⟨ray, hray0, hray, herror⟩ := happrox y hy
  have hray' (s : ℝ) (hs : 0 ≤ s) (t : ℝ) (ht : 0 ≤ t) :
      (g.edist (ray s) (ray t)).toReal = |s - t| := by
    rw [hray s hs t ht, ENNReal.toReal_ofReal (abs_nonneg _)]
  have hbase (t : ℝ) (ht : 0 ≤ t) : (g.edist p (ray t)).toReal = t := by
    rw [← hray0, hray' 0 le_rfl t ht]
    simp only [zero_sub, abs_neg, abs_of_nonneg ht]
  have herror' : (g.edist y (ray d)).toReal < d / 4 := by
    have hh := (div_lt_iff₀ hd).mp herror
    dsimp [d] at *
    linarith
  have hcont : ContinuousOn (fun t => (g.edist y (ray t)).toReal) (Icc d (3 * d)) := by
    apply LipschitzOnWith.continuousOn (K := 1)
    apply LipschitzOnWith.of_dist_le_mul
    intro s hs t ht
    have h := g.abs_toReal_edist_sub_le y (ray s) (ray t)
    rw [hray' s (hd.le.trans hs.1) t (hd.le.trans ht.1)] at h
    simpa only [Real.dist_eq, NNReal.coe_one, one_mul] using h
  have hlower : (g.edist y (ray d)).toReal ≤ d := by linarith
  have hupper : d ≤ (g.edist y (ray (3 * d))).toReal := by
    have h := g.toReal_edist_triangle p y (ray (3 * d))
    rw [hbase (3 * d) (by positivity)] at h
    change 3 * d ≤ d + (g.edist y (ray (3 * d))).toReal at h
    linarith
  obtain ⟨t, ht, hvalue⟩ := intermediate_value_Icc (by linarith : d ≤ 3 * d)
    hcont (show d ∈ Icc ((g.edist y (ray d)).toReal)
      ((g.edist y (ray (3 * d))).toReal) from ⟨hlower, hupper⟩)
  change (g.edist y (ray t)).toReal = d at hvalue
  refine ⟨ray t, hvalue, ?_⟩
  rw [hbase t (hd.le.trans ht.1)]
  have h := g.toReal_edist_triangle y (ray d) (ray t)
  rw [hvalue, hray' d hd.le t (hd.le.trans ht.1), abs_of_nonpos (by linarith [ht.1])] at h
  change 3 * d / 2 < t
  linarith

end PoincareMT.ControlledLongGeometry
