import PoincareLib.Geometry.Riemannian.Coordinates.ParametrizedCoefficients

/-! # Finite compact chart covers inside a prescribed open set -/

set_option autoImplicit false

open Set
open scoped Manifold ContDiff

namespace PoincareMT.TerminalNeck

theorem exists_finite_compact_chart_cover
    {M : Type*} [TopologicalSpace M] [T2Space M] [T3Space M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {A U : Set M} (hA : IsCompact A) (hU : IsOpen U) (hAU : A ⊆ U) :
    ∃ (s : Finset A) (K : A → Set M),
      (∀ q, IsCompact (K q) ∧ K q ⊆ U ∩ (extChartAt (𝓡 3) q.val).source) ∧
      ∀ x ∈ A, ∃ q ∈ s, x ∈ K q := by
  classical
  let : LocallyCompactSpace M := ChartedSpace.locallyCompactSpace (EuclideanSpace ℝ (Fin 3)) M
  have hlocal (q : A) : ∃ K : Set M, IsCompact K ∧ q.val ∈ interior K ∧
      K ⊆ U ∩ (extChartAt (𝓡 3) q.val).source := by
    obtain ⟨K, hK, hq, hKU⟩ := exists_compact_between isCompact_singleton
      (hU.inter (isOpen_extChartAt_source (I := 𝓡 3) q.val))
      (singleton_subset_iff.mpr ⟨hAU q.property, mem_extChartAt_source (I := 𝓡 3) q.val⟩)
    exact ⟨K, hK, hq (mem_singleton q.val), hKU⟩
  choose K hK hq hKU using hlocal
  obtain ⟨s, hs⟩ := hA.elim_finite_subcover (fun q : A => interior (K q))
    (fun _ => isOpen_interior) (fun x hx => mem_iUnion.mpr ⟨⟨x, hx⟩, hq ⟨x, hx⟩⟩)
  refine ⟨s, K, fun q => ⟨hK q, hKU q⟩, ?_⟩
  intro x hx
  obtain ⟨q, hqs, hxq⟩ := mem_iUnion₂.mp (hs hx)
  exact ⟨q, hqs, interior_subset hxq⟩

end PoincareMT.TerminalNeck
