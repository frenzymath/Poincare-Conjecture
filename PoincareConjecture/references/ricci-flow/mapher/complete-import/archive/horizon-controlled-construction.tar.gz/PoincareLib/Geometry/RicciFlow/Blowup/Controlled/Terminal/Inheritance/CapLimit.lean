import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.NeckLimit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.ScalarRatio

/-!
# Actual limit necks controlling points in source caps

Source cap ratios bound the end-neck normalization. The transported end
neck and convergence at its center then retain the scalar domination
needed for the terminal boundedness argument.

Reference: Morgan--Tian, Claims 11.6 and 11.7, pp. 270--271.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.TerminalNeck

open MetricSurgery

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem eventually_end_necks_with_scalar_control_of_cap_convergence
    {X : ℕ → Type u} [∀ k, TopologicalSpace (X k)] [∀ k, T3Space (X k)]
    [∀ k, ChartedSpace E (X k)] [∀ k, IsManifold (𝓡 3) ∞ (X k)]
    [∀ k, MeasurableSpace (X k)] [∀ k, BorelSpace (X k)]
    {M : Type v} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    (g : ∀ k, RiemannianMetric 3 (X k)) (h : RiemannianMetric 3 M)
    (N : ∀ k, CapCertificate (g k)) (e : ∀ k, OpenPartialHomeomorph (X k) M)
    (he : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source)
    (hei : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k).symm (e k).target)
    (hcapture : ∀ k, (N k).end_neck.carrier ⊆ (e k).source)
    (D : LeviCivitaData h) (x : M) (hxpos : 0 < D.scalarCurvature x)
    (hx : ∀ k, (e k).symm x ∈ (N k).carrier)
    {δ ε l u C : ℝ} (hδ : 0 < δ) (hδε : δ < ε) (hε : ε < 1 / 2)
    (hNeq : ∀ k, (N k).epsilon = δ) (hC : ∀ k, (N k).cap_constant ≤ C)
    (hl : 0 < l) (hu : 0 < u)
    (hscalar : ∀ k, l ≤ (N k).connection.scalarCurvature ((e k).symm x) ∧
      (N k).connection.scalarCurvature ((e k).symm x) ≤ u)
    (herror : ∀ η : ℝ, 0 < η → ∀ᶠ k in atTop, ∀ z : RoundCylinderSpace,
      z.2 ∈ Ioo (-(N k).end_neck.epsilon⁻¹) (N k).end_neck.epsilon⁻¹ →
      ∀ j, j ≤ ⌊ε⁻¹⌋₊ → ‖iteratedFDeriv ℝ j (fun p =>
        (g k).parametrizedCoefficients (centeredNeckLift (N k).end_neck z.1 z.2) p -
        h.parametrizedCoefficients (e k ∘ centeredNeckLift (N k).end_neck z.1 z.2) p) 0‖ ≤ η)
    (hgap : ∀ η : ℝ, 0 < η → ∀ᶠ k in atTop,
      |D.scalarCurvature (e k (N k).end_neck.center) -
        (N k).connection.scalarCurvature (N k).end_neck.center| ≤ η)
    (hxgap : ∀ η : ℝ, 0 < η → ∀ᶠ k in atTop,
      |D.scalarCurvature x - (N k).connection.scalarCurvature ((e k).symm x)| ≤ η) :
    ∀ᶠ k in atTop, ∃ L : EpsilonNeck h, L.epsilon = ε ∧
      L.center = e k (N k).end_neck.center ∧ L.connection = D ∧
      L.central_sphere = e k '' (N k).end_neck.central_sphere ∧
      D.scalarCurvature x ≤ 2 * C * D.scalarCurvature L.center := by
  have hCpos : 0 < C := (N 0).cap_constant_pos.trans_le (hC 0)
  have hbounds (k : ℕ) :
      l / C ≤ (N k).end_neck.connection.scalarCurvature (N k).end_neck.center ∧
      (N k).end_neck.connection.scalarCurvature (N k).end_neck.center ≤ C * u :=
    (N k).end_center_scalar_bounds_of_point_bounds (hx k) (hC k)
      (hscalar k).1 (hscalar k).2
  have hnecks := eventually_transported_necks_of_metric_and_scalar_errors
    g h (fun k => (N k).end_neck) e he hei hcapture D hδ hδε hε
    (fun k => (N k).end_neck_epsilon.trans (hNeq k))
    (div_pos hl hCpos) (mul_pos hCpos hu) hbounds herror
    (fun η hη => (hgap η hη).mono fun k hk => by
      simpa only [(N k).end_neck_connection] using hk)
  let η := D.scalarCurvature x / (2 * (C + 1))
  have hη : 0 < η := by positivity
  filter_upwards [hnecks, hgap η hη, hxgap η hη] with k hk hkgap hkxgap
  obtain ⟨L, hLe, hLc, hLD, hLs, _hcarrier⟩ := hk
  refine ⟨L, hLe, hLc, hLD, hLs, ?_⟩
  rw [hLc]
  have hcenter : (e k).symm (e k (N k).end_neck.center) = (N k).end_neck.center :=
    (e k).left_inv (hcapture k
      ((N k).end_neck.central_sphere_subset (N k).end_neck.center_on_central_sphere))
  apply (N k).scalar_le_twice_constant_mul_of_end_scalar_errors D (e k).symm
    (hx k) hcenter (hC k) le_rfl hkxgap
  simpa only [hcenter] using hkgap

end PoincareMT.TerminalNeck
