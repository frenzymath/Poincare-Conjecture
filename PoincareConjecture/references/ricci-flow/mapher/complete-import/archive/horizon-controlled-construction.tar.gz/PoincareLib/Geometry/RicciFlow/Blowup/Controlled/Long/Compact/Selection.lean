import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Distance.Compact
import PoincareLib.Geometry.Riemannian.Curvature.Scalar.Regularity
import Mathlib.Topology.Order.IntermediateValue

/-! # Selecting bounded positive reference curvatures on connected compact sets -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongCompact

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_reference_scalar_between
    {n : ℕ} {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    {g : RiemannianMetric n M} (D : LeviCivitaData g) (hD : D.CurvatureTensorCalculus)
    {K : Set M} (hK : IsPreconnected K) {C c : ℝ}
    (hlow : ∃ y ∈ K, D.scalarCurvature y ≤ C)
    (hhigh : ∃ z ∈ K, c ≤ D.scalarCurvature z) :
    ∃ y ∈ K, c ≤ D.scalarCurvature y ∧ D.scalarCurvature y ≤ max C c := by
  obtain ⟨y, hy, hys⟩ := hlow
  by_cases hyc : c ≤ D.scalarCurvature y
  · exact ⟨y, hy, hyc, hys.trans (le_max_left _ _)⟩
  obtain ⟨z, hz, hzs⟩ := hhigh
  obtain ⟨w, hw, hws⟩ := hK.intermediate_value hy hz
    hD.contMDiff_scalarCurvature.continuous.continuousOn
    (show c ∈ Icc (D.scalarCurvature y) (D.scalarCurvature z) from
      ⟨(lt_of_not_ge hyc).le, hzs⟩)
  exact ⟨w, hw, hws.symm.le, hws.le.trans (le_max_right _ _)⟩

theorem exists_curvature_contrast_sequence_of_unbounded
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T : ℝ} (hT : 0 < T) (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    {K : Set L.carrier.carrier} (hK : IsCompact K) (hconn : IsPreconnected K)
    {C : ℝ} (hmin : ∀ t ∈ Ioc (-T) 0, ∃ y ∈ K, (L.flow.connection t).scalarCurvature y ≤ C)
    (hunbounded : ¬ ∃ B : ℝ, ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
      (L.flow.connection t).scalarCurvature x ≤ B) :
    ∃ A B : ℝ, 0 < A ∧ 0 < B ∧ ∃ t : ℕ → ℝ,
      ∃ y z : ℕ → L.carrier.carrier,
      (∀ m, t m ∈ Ioc (-T) 0) ∧
      (∀ m, y m ∈ K ∧ z m ∈ K) ∧
      (∀ m, 2 ≤ (L.flow.connection (t m)).scalarCurvature (y m)) ∧
      (∀ m, (L.flow.connection (t m)).scalarCurvature (y m) ≤ B) ∧
      (∀ m : ℕ, (m : ℝ) + 2 ≤ (L.flow.connection (t m)).scalarCurvature (z m)) ∧
      ∀ m, z m ∈ (L.flow.metric (t m)).ball (y m) A := by
  classical
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  have hbad : ∀ m : ℕ, ∃ t ∈ Ioc (-T) 0, ∃ z ∈ K,
      (m : ℝ) + 2 < (L.flow.connection t).scalarCurvature z := by
    push Not at hunbounded
    exact fun m => hunbounded ((m : ℝ) + 2)
  choose t ht z hz hzs using hbad
  have href (m : ℕ) : ∃ y ∈ K, 2 ≤ (L.flow.connection (t m)).scalarCurvature y ∧
      (L.flow.connection (t m)).scalarCurvature y ≤ max C 2 := by
    apply exists_reference_scalar_between _ (P04.tensor_calculus 3 L.carrier.carrier _ _)
      hconn (hmin (t m) (ht m))
    exact ⟨z m, hz m, by linarith [hzs m, Nat.cast_nonneg (α := ℝ) m]⟩
  choose y hy hyl hyu using href
  obtain ⟨A, hA, hdiam⟩ := ControlledLongDistance.exists_uniform_compact_diameter_bound
    P04 P06 hT L K hK
  refine ⟨A + 1, max C 2, by positivity, lt_of_lt_of_le (by norm_num) (le_max_right _ _),
    t, y, z, ht, fun m => ⟨hy m, hz m⟩, hyl, hyu, fun m => (hzs m).le, ?_⟩
  intro m
  change (L.flow.metric (t m)).edist (y m) (z m) < ENNReal.ofReal (A + 1)
  rw [← ENNReal.ofReal_toReal ((L.flow.metric (t m)).edist_ne_top (y m) (z m))]
  apply (ENNReal.ofReal_lt_ofReal_iff (by positivity)).mpr
  have hh := hdiam (t m) (ht m) (y m) (hy m) (z m) (hz m)
  linarith

end PoincareMT.ControlledLongCompact
