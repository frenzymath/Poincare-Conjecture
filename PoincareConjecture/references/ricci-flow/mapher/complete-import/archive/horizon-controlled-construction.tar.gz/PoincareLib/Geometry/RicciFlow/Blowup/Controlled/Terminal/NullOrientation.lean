import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NullCover
import PoincareLib.Geometry.RicciFlow.Soliton.ThreeDimensional.Splitting.Global.CoverCoordinate
import PoincareLib.Geometry.Riemannian.Splitting.ParallelPrimitive.Global
import Mathlib.Topology.Homotopy.Lifting

/-!
# Orienting a local parallel Ricci-null line

On a simply connected manifold the identity lifts into the actual unit
Ricci-kernel cover. Local prescribed parallel sections prove that this
continuous lift is a smooth parallel unit vector field. Its global primitive
is the coordinate for the complete product splitting.

Reference: Morgan--Tian, Claim 11.7, p. 271.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Bundle
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT.RicciFlow.Splitting

variable {n : ℕ} {M : Type u} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
  [SimplyConnectedSpace M] {g : RiemannianMetric n M}

/-- A section of the actual null-line cover gives a global parallel field;
the local sections may come from different backward flow neighborhoods. -/
theorem exists_parallel_unit_field_of_simplyConnected_null_cover
    (D : LeviCivitaData g)
    (hc : IsCoveringMap (unitRicciKernelProjection D))
    (hdim : ∀ y : M, ricciNullity D y = 1)
    (hlocal : ∀ p : UnitRicciKernel D,
      ∃ (U : Set M) (V : (y : M) → TangentSpace (𝓡 n) y),
        IsOpen U ∧ p.1.proj ∈ U ∧
        ContMDiffOn (𝓡 n) ((𝓡 n).prod (𝓡 n)) ∞ (T% V) U ∧ V p.1.proj = p.1.snd ∧
        ∀ y ∈ U, g.inner y (V y) (V y) = 1 ∧
          (∀ w, D.ricci y (V y) w = 0) ∧ ∀ w, D.connection V y w = 0)
    (p₀ : UnitRicciKernel D) :
    ∃ V : (y : M) → TangentSpace (𝓡 n) y,
      ContMDiff (𝓡 n) ((𝓡 n).prod (𝓡 n)) ∞ (T% V) ∧
      ∀ y, g.inner y (V y) (V y) = 1 ∧
        (∀ w, D.ricci y (V y) w = 0) ∧ ∀ w, D.connection V y w = 0 := by
  let : LocallyPathConnectedSpace M :=
    ChartedSpace.locallyPathConnectedSpace (EuclideanSpace ℝ (Fin n)) M
  obtain ⟨s, ⟨_, hsp⟩, _⟩ :=
    hc.existsUnique_continuousMap_lifts (ContinuousMap.id M) p₀.1.proj p₀ rfl
  have hs (y : M) : (s y).1.proj = y := congrFun hsp y
  let V : (y : M) → TangentSpace (𝓡 n) y := fun y => (s y).1.snd
  have hsections (y : M) :
      ∃ W : (z : M) → TangentSpace (𝓡 n) z,
        ContMDiffAt (𝓡 n) ((𝓡 n).prod (𝓡 n)) ∞ (T% W) y ∧
        V =ᶠ[𝓝 y] W ∧ ∀ w, D.connection W y w = 0 := by
    obtain ⟨U, W, hU, hy, hW, hWy, hn⟩ := hlocal (s y)
    have hy' : y ∈ U := hs y ▸ hy
    refine ⟨W, hW.contMDiffAt (hU.mem_nhds hy'), ?_, (hn y hy').2.2⟩
    have heq := (s.continuous.continuousAt (x := y)).eventually
      (unitRicciKernel_eventually_eq_section D hU W hW (fun z _ => hdim z)
        (fun z hz => (hn z hz).1) (fun z hz => (hn z hz).2.1) (s y) hy hWy)
    filter_upwards [heq] with z hz
    change (s z).1.snd = W z
    exact hz.trans (congrArg (fun p : M => (W p : EuclideanSpace ℝ (Fin n))) (hs z))
  have hV : ContMDiff (𝓡 n) ((𝓡 n).prod (𝓡 n)) ∞ (T% V) := by
    intro y
    obtain ⟨W, hW, heq, _⟩ := hsections y
    apply hW.congr_of_eventuallyEq
    filter_upwards [heq] with z hz
    exact congrArg (fun v : TangentSpace (𝓡 n) z => (v : TangentBundle (𝓡 n) M)) hz
  refine ⟨V, hV, fun y => ⟨?_, ?_, ?_⟩⟩
  · have hu := (s y).2.1
    change g.inner (s y).1.proj (V y) (V y) = 1 at hu
    erw [hs y] at hu
    exact hu
  · intro w
    have hn := (s y).2.2 w
    change D.ricci (s y).1.proj (V y) w = 0 at hn
    erw [hs y] at hn
    exact hn
  · intro w
    obtain ⟨W, hW, heq, hparallel⟩ := hsections y
    have hconn := D.connection.isCovariantDerivativeOnUniv.congr_of_eventuallyEq
      ((hV y).mdifferentiableAt (by simp)) (hW.mdifferentiableAt (by simp))
      (by simp) heq
    exact (congrArg (fun L => L w) hconn).trans (hparallel w)

/-- Local finite-slab null-line geometry has a global unit-gradient,
zero-Hessian coordinate on a simply connected terminal slice. -/
theorem exists_parallel_potential_of_simplyConnected_terminal_nullity_one
    (hC : RicciFlowCurvatureTheory.{u}) {a b : ℝ} (hab : a < b)
    (F : RicciFlow n M (Icc a b))
    (hsec : ∀ t ∈ Icc a b, (F.connection t).NonnegativeSectionalCurvature)
    (hdim : ∀ y : M, ricciNullity (F.connection b) y = 1) (p : M) :
    ∃ f : M → ℝ, ContMDiff (𝓡 n) 𝓘(ℝ, ℝ) ∞ f ∧ f p = 0 ∧
      RiemannianMetric.HasUnitGradient (F.connection b) f ∧
      RiemannianMetric.HasZeroHessian (F.connection b) f := by
  obtain ⟨U, W, _, hp, _, hn⟩ :=
    exists_local_parallel_unit_ricci_null_section hC hab F hsec hdim p
  let p₀ : UnitRicciKernel (F.connection b) :=
    ⟨⟨p, W p⟩, (hn p hp).1, (hn p hp).2.1⟩
  obtain ⟨V, hV, hparallel⟩ :=
    exists_parallel_unit_field_of_simplyConnected_null_cover (F.connection b)
      (unitRicciKernel_isCoveringMap_of_terminal_nullity_one hC hab F hsec hdim) hdim
      (exists_local_parallel_unit_ricci_null_section_through hC hab F hsec hdim) p₀
  obtain ⟨f, hf, hfp, _, hgrad⟩ := (F.connection b).exists_global_potential_of_parallel
    hV (fun y => (hparallel y).2.2) p 0
  refine ⟨f, hf, hfp, ?_, ?_⟩
  · intro y
    rw [hgrad]
    exact (hparallel y).1
  · intro y v w
    rw [(F.connection b).hessian_eq_inner_connection_gradient (hf y), hgrad,
      (hparallel y).2.2 v, map_zero, zero_apply]

end PoincareMT.RicciFlow.Splitting
