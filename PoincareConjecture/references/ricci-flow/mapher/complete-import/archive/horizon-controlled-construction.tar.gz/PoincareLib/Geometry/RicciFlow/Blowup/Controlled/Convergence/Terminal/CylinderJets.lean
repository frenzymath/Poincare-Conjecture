import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.ClockJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Exhaustion

/-! # Canonical jets of the actual retained generalized cylinders -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)
  (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
  (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : ∀ t ∈ Ioo (-T / 2) (T / 2),
    G.limitCarrier.metricComplete (G.limitFlow.metricAt t))
  (hbound : ∀ t ∈ Ioo (-T / 2) (T / 2), ∀ x,
    (G.limitFlow.flow.connection t).curvatureTensorNorm x ≤ B)
  (heta : Tendsto eta atTop (𝓝 0))

local notation "theLimit" => liftedLimit (terminalLimit G F hF P04 hB hAr hcompact hcomplete hbound heta)

theorem finiteRetainedCylinder_coefficient_eq (k : ℕ)
    (q : (liftedSliceCarrier.{u} G.limitCarrier).carrier) (a b : Fin 3)
    (p : ℝ × EuclideanSpace ℝ (Fin 3))
    (ht : p.1 ∈ Icc (-finiteTimeRadius T k) 0)
    (hp : p.2 ∈ (extChartAt (𝓡 3) q).target)
    (hx : (extChartAt (𝓡 3) q).symm p.2 ∈ retainedSpace G k) :
    blowupPullbackCoefficient (L := theLimit) (finiteRetainedCylinder G k) q a b p =
      G.spatialSpacetimeCoefficients q.down k (p.1 + T / 2, p.2)
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b) := by
  rw [blowupPullbackCoefficient, dif_pos ht]
  exact finiteRetainedCylinder_chart_inner G k p.1 ht q p.2 hp hx _ _

/-- The cylinder zero extension has exactly the canonical source jets on
each compact test set once its space and time are inside the exhaustion. -/
theorem eventually_finiteRetainedCylinder_jet_eq
    (q : (liftedSliceCarrier.{u} G.limitCarrier).carrier) (j r : ℕ)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKU : K ⊆ {p | p ∈ Ioc (-T) 0 ×ˢ (extChartAt (𝓡 3) q).target ∧
      (extChartAt (𝓡 3) q).symm p.2 ∈ retainedSpace G j}) :
    ∀ᶠ k in atTop,
      K ⊆ Icc (-finiteTimeRadius T k) 0 ×ˢ (extChartAt (𝓡 3) q).target ∧
      ∀ a b : Fin 3, ∀ p ∈ K,
        iteratedFDerivWithin ℝ r
          (blowupPullbackCoefficient (L := theLimit) (finiteRetainedCylinder G k) q a b)
          (Icc (-finiteTimeRadius T k) 0 ×ˢ (extChartAt (𝓡 3) q).target) p =
        iteratedFDerivWithin ℝ r
          (fun z => G.spatialSpacetimeCoefficients q.down k (z.1 + T / 2, z.2)
            (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))
          (Ioc (-T) 0 ×ˢ (extChartAt (𝓡 3) q).target) p := by
  have hIt : Prod.fst '' K ⊆ Ioc (-T) 0 := by
    rintro _ ⟨p, hp, rfl⟩
    exact (hKU hp).1.1
  filter_upwards [eventually_ge_atTop j,
    finiteTimeRadius_interval_strict_cofinal hT (hK.image continuous_fst) hIt] with k hkj htime
  have hkp (p) (hp : p ∈ K) : p.1 ∈ Ioc (-finiteTimeRadius T k) 0 :=
    htime (mem_image_of_mem Prod.fst hp)
  refine ⟨fun p hp => ⟨Ioc_subset_Icc_self (hkp p hp), (hKU hp).1.2⟩, ?_⟩
  intro a b p hp
  let D := Icc (-finiteTimeRadius T k) 0 ×ˢ (extChartAt (𝓡 3) q).target
  let U := Ioc (-T) 0 ×ˢ (extChartAt (𝓡 3) q).target
  let W := (extChartAt (𝓡 3) q).target ∩
    (extChartAt (𝓡 3) q).symm ⁻¹' retainedSpace G k
  have hWo : IsOpen W := (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
    (isOpen_extChartAt_target q) (retainedSpace_open G k)
  have hpW : p.2 ∈ W := ⟨(hKU hp).1.2, retainedSpace_monotone G hkj (hKU hp).2⟩
  have hnear : Prod.snd ⁻¹' W ∈ 𝓝 p := (hWo.preimage continuous_snd).mem_nhds hpW
  have heq : (blowupPullbackCoefficient (L := theLimit) (finiteRetainedCylinder G k) q a b) =ᶠ[𝓝[D] p]
      (fun z => G.spatialSpacetimeCoefficients q.down k (z.1 + T / 2, z.2)
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) := by
    filter_upwards [mem_nhdsWithin_of_mem_nhds hnear, self_mem_nhdsWithin] with z hz hzD
    exact finiteRetainedCylinder_coefficient_eq G F hF P04 hB hAr hcompact hcomplete hbound
      heta k q a b z hzD.1 hz.1 hz.2
  have hpD : p ∈ D := ⟨Ioc_subset_Icc_self (hkp p hp), (hKU hp).1.2⟩
  rw [heq.iteratedFDerivWithin_eq (heq.eq_of_nhdsWithin hpD) r]
  apply iteratedFDerivWithin_congr_set _ r
  have htnear : Prod.fst ⁻¹' Ioi (-finiteTimeRadius T k) ∈ 𝓝 p :=
    (isOpen_Ioi.preimage continuous_fst).mem_nhds (hkp p hp).1
  filter_upwards [htnear] with z hz
  apply propext
  constructor
  · intro hzD
    exact ⟨⟨(neg_lt_neg (finiteTimeRadius_lt hT k)).trans (show -finiteTimeRadius T k < z.1 from hz),
      hzD.1.2⟩, hzD.2⟩
  · intro hzU
    exact ⟨⟨le_of_lt hz, hzU.1.2⟩, hzU.2⟩

end PoincareMT.ControlledBlowupCompactness
