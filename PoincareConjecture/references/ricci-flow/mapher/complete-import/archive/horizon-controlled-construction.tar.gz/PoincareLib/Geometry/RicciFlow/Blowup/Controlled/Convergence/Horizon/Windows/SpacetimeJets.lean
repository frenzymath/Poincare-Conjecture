import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.SpatialJets
import PoincareLib.Geometry.RicciFlow.AncientKappa.Asymptotic.Compactness.Coordinates.SpacetimeJets

/-! # Uniform mixed jets on retained charts over longer past windows -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder SpacetimeBounds SpacetimeBounds.Bootstrap

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

/-- Mixed jets of every admissible larger cylinder obey a common bound on
each fixed smaller open slab, in the original retained source coordinates. -/
theorem exists_eventually_reference_window_spacetime_jet_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    {U V D : ℝ} (hTV : T / 2 ≤ V) (hVU : V < U) (hD : 0 ≤ D)
    (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ eta' : ℝ, ∀ d : ControlledBlowupCylinder S (idx (G.subsequence k))
        (A (G.subsequence k)) U D eta',
      ∀ s ∈ Ioo (-V) 0, ∀ x ∈ K,
        ‖iteratedFDeriv ℝ m (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
          ((d.smallFlow (hA _) (by linarith)).metric z.1).pullbackCoefficients
            (G.referenceChartMap q k 0) z.2) (s, x)‖ ≤ C := by
  let E := EuclideanSpace ℝ (Fin 3)
  let I := Σ k : ℕ, Σ eta' : ℝ, ControlledBlowupCylinder S (idx (G.subsequence k))
    (A (G.subsequence k)) U D eta'
  let L : Filter I := Filter.comap Sigma.fst atTop
  let c := extChartAt (𝓡 3) q
  let W := fun a : I => c.target ∩ c.symm ⁻¹' G.exhaustion a.1
  let Q := fun a : I => Ioo (-V) 0 ×ˢ (K ∩ W a)
  have hU : 0 < U := by linarith
  let F := fun a : I => a.2.2.smallFlow (hA _) hU
  let f := fun a : I => fun z : ℝ × E =>
    ((F a).metric z.1).pullbackCoefficients (G.referenceChartMap q a.1 0) z.2
  have hzero : -T / 2 < 0 ∧ 0 < T / 2 := ⟨by linarith, by linarith⟩
  have hW (a : I) : IsOpen (W a) :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
      (isOpen_extChartAt_target q) (G.exhaustion_open a.1)
  have he (a : I) : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap q a.1 0) (W a) :=
    fun x hx => (G.referenceChartMap_contMDiffAt q a.1 hzero hx.1 hx.2).contMDiffWithinAt
  have hi (a : I) : ∀ x ∈ W a,
      (mfderiv (𝓡 3) (𝓡 3) (G.referenceChartMap q a.1 0) x).IsInvertible :=
    fun x hx => G.referenceChartMap_mfderiv_isInvertible q a.1 hzero hx.1 hx.2
  have hne : (Ioo (-U) 0).Nontrivial :=
    ⟨-U / 3, ⟨by linarith, by linarith⟩, -2 * U / 3,
      ⟨by linarith, by linarith⟩, by linarith⟩
  let Fo := fun a : I => Poincare.Geometry.RicciFlow.Harnack.restrictFlow (F a)
    Ioo_subset_Icc_self ordConnected_Ioo hne
  have hf (a : I) : ContDiffOn ℝ ∞ (f a) (Ioo (-U) 0 ×ˢ W a) :=
    (Fo a).contDiffOn_pullbackCoefficients isOpen_Ioo (hW a) (he a)
  have hrange (a : I) (z : ℝ × E) (hz : z ∈ Ioo (-U) 0 ×ˢ W a) :
      spatialJet 2 (f a) z ∈ jetRicciFlowDomain 3 := by
    change ((twoJetProjection 3 (spatialJet 2 (f a) z)).1).IsInvertible
    rw [twoJetProjection_spatialJet]
    exact ((F a).metric z.1).isInvertible_pullbackCoefficients (hi a z.2 hz.2).injective
  have hevol (a : I) (z : ℝ × E) (hz : z ∈ Ioo (-U) 0 ×ˢ W a) :
      deriv (fun t => f a (t, z.2)) z.1 = jetRicciFlowOperator 3 (spatialJet 2 (f a) z) := by
    rw [jetRicciFlowOperator, Function.comp_apply, twoJetProjection_spatialJet]
    exact deriv_pullbackCoefficients_eq_ricciFlowOperator (Fo a)
      isOpen_Ioo (hW a) (he a) (hi a) hz.1 hz.2
  have hall (r : ℕ) : ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ a in L,
      ∀ z ∈ Q a, ∀ j ≤ r, ‖iteratedFDeriv ℝ j (fun x => f a (z.1, x)) z.2‖ ≤ C := by
    obtain ⟨C, hC, hbound⟩ := exists_eventually_reference_window_spatial_jet_bound
      G P04 hAr hcompact hcomplete hTV hVU hD q hK hKc r
    refine ⟨C, hC, Filter.eventually_comap.mpr ?_⟩
    filter_upwards [hbound] with k hk a ha z hz j hj
    subst k
    exact hk a.2.1 a.2.2 z.1 (Ioo_subset_Icc_self hz.1) z.2 hz.2.1 j hj
  have hspatial (r : ℕ) : ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ a in L,
      ∀ z ∈ Q a, ‖iteratedFDeriv ℝ r (fun x => f a (z.1, x)) z.2‖ ≤ C := by
    obtain ⟨C, hC, hbound⟩ := hall r
    exact ⟨C, hC, hbound.mono fun a ha z hz => ha z hz r le_rfl⟩
  obtain ⟨α, β, hα, _, hell⟩ := exists_eventually_reference_window_ellipticity
    G hTV hVU.le hD q hK hKc
  have hbox (r : ℕ) : ∃ Z : Set (Jet E (MetricCoefficient 3) (2 + r)),
      IsCompact Z ∧ Z ⊆ (baseProjection 2 r) ⁻¹' jetRicciFlowDomain 3 ∧
        ∀ᶠ a in L, MapsTo (spatialJet (2 + r) (f a)) (Q a) Z := by
    obtain ⟨C, hC, hbound⟩ := hall (2 + r)
    obtain ⟨Z, hZ, hZU, hbox⟩ := exists_compact_elliptic_jet_box 3 r hα C
    have hell' : ∀ᶠ a : I in L, ∀ s ∈ Icc (-V) 0, ∀ x ∈ K, ∀ v,
        α * ‖v‖ ^ 2 ≤ f a (s, x) v v := Filter.eventually_comap.mpr (hell.mono (by
      intro k hk a ha s hs x hx v
      subst k
      exact (hk a.2.1 a.2.2 s hs x hx v).1))
    refine ⟨Z, hZ, hZU, ?_⟩
    filter_upwards [hbound, hell'] with a ha heq z hz
    apply hbox
    · exact (pi_norm_le_iff_of_nonneg hC).mpr (fun j => ha z hz j (by omega))
    · exact fun v => heq z.1 (Ioo_subset_Icc_self hz.1) z.2 hz.2.1 v
  obtain ⟨C, hC, hbound⟩ := eventuallyBounded_spacetime_jets L
    (isOpen_jetRicciFlowDomain 3) (contDiffOn_jetRicciFlowOperator 3)
    f (fun _ => Ioo (-U) 0) W Q hf (fun _ => isOpen_Ioo) hW
    (fun _ _ hz => ⟨⟨by linarith [hz.1.1], hz.1.2⟩, hz.2.2⟩)
    hrange hevol hspatial hbox m
  have hc : ContinuousOn c.symm K :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset (hK.image_of_continuousOn hc)
  refine ⟨C, hC, ?_⟩
  filter_upwards [Filter.eventually_comap.mp hbound, eventually_ge_atTop j]
    with k hk hjk eta' d s hs x hx
  exact hk ⟨k, eta', d⟩ rfl (s, x)
    ⟨hs, hx, hKc hx, G.exhaustion_monotone hjk (hj (mem_image_of_mem _ hx))⟩

end PoincareMT.ControlledBlowupCompactness
