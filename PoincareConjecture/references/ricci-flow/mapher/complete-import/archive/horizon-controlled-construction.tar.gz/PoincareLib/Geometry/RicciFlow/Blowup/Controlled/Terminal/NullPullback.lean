import PoincareLib.Geometry.RicciFlow.Soliton.ThreeDimensional.Splitting.UnitCover
import PoincareLib.Geometry.Riemannian.Connection.Pullback
import PoincareLib.Geometry.Riemannian.Curvature.LocalIsometryInvariants

/-!
# Transporting terminal null lines through a local isometry

The covering differential identifies the actual Ricci kernels and pulls
local parallel unit sections back to local parallel unit sections, with
their prescribed values retained. No global flow interval is used.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Bundle
open scoped Manifold ContDiff Topology

namespace PoincareMT.RicciFlow.Splitting

variable {n : ℕ} {E M : Type*} [TopologicalSpace E] [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) E] [IsManifold (𝓡 n) ∞ E]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
  {g : RiemannianMetric n E} {h : RiemannianMetric n M}

theorem ricciNullity_eq_of_local_metric_pullback
    (D : LeviCivitaData g) (D' : LeviCivitaData h) {f : E → M}
    (hf : IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ f)
    (hmetric : ∀ (x : E) (v w : TangentSpace (𝓡 n) x),
      g.inner x v w = h.inner (f x)
        (mfderiv (𝓡 n) (𝓡 n) f x v) (mfderiv (𝓡 n) (𝓡 n) f x w))
    (x : E) : ricciNullity D x = ricciNullity D' (f x) := by
  let L := (hf.mfderivToContinuousLinearEquiv (by simp) x).toLinearEquiv
  have hricci (v w : TangentSpace (𝓡 n) x) :
      D.ricci x v w = D'.ricci (f x) (L v) (L w) :=
    D.ricci_eq_of_local_isometry D' isOpen_univ hf.contMDiff.contMDiffOn
      (fun y _ => hmetric y) (mem_univ x) v w
  have hker : ricciKernel D' (f x) = (ricciKernel D x).map L.toLinearMap := by
    ext v
    rw [Submodule.mem_map_equiv, mem_ricciKernel, mem_ricciKernel]
    constructor
    · intro hv w
      rw [hricci, L.apply_symm_apply]
      exact hv _
    · intro hv w
      obtain ⟨z, rfl⟩ := L.surjective w
      have hz := hv z
      rw [hricci, L.apply_symm_apply] at hz
      exact hz
  unfold ricciNullity
  rw [hker, LinearEquiv.finrank_map_eq]

theorem exists_local_parallel_null_section_of_local_metric_pullback
    (D : LeviCivitaData g) (D' : LeviCivitaData h) {f : E → M}
    (hf : IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ f)
    (hmetric : ∀ (x : E) (v w : TangentSpace (𝓡 n) x),
      g.inner x v w = h.inner (f x)
        (mfderiv (𝓡 n) (𝓡 n) f x v) (mfderiv (𝓡 n) (𝓡 n) f x w))
    (hlocal : ∀ p : UnitRicciKernel D',
      ∃ (U : Set M) (V : (y : M) → TangentSpace (𝓡 n) y),
        IsOpen U ∧ p.1.proj ∈ U ∧
        ContMDiffOn (𝓡 n) ((𝓡 n).prod (𝓡 n)) ∞ (T% V) U ∧ V p.1.proj = p.1.snd ∧
        ∀ y ∈ U, h.inner y (V y) (V y) = 1 ∧
          (∀ w, D'.ricci y (V y) w = 0) ∧ ∀ w, D'.connection V y w = 0)
    (p : UnitRicciKernel D) :
    ∃ (U : Set E) (V : (y : E) → TangentSpace (𝓡 n) y),
      IsOpen U ∧ p.1.proj ∈ U ∧
      ContMDiffOn (𝓡 n) ((𝓡 n).prod (𝓡 n)) ∞ (T% V) U ∧ V p.1.proj = p.1.snd ∧
      ∀ y ∈ U, g.inner y (V y) (V y) = 1 ∧
        (∀ w, D.ricci y (V y) w = 0) ∧ ∀ w, D.connection V y w = 0 := by
  have hinv (x : E) : (mfderiv (𝓡 n) (𝓡 n) f x).IsInvertible :=
    ⟨hf.mfderivToContinuousLinearEquiv (by simp) x, rfl⟩
  have hricci (x : E) (v w : TangentSpace (𝓡 n) x) :
      D.ricci x v w = D'.ricci (f x)
        (mfderiv (𝓡 n) (𝓡 n) f x v) (mfderiv (𝓡 n) (𝓡 n) f x w) :=
    D.ricci_eq_of_local_isometry D' isOpen_univ hf.contMDiff.contMDiffOn
      (fun y _ => hmetric y) (mem_univ x) v w
  let q : UnitRicciKernel D' :=
    ⟨⟨f p.1.proj, mfderiv (𝓡 n) (𝓡 n) f p.1.proj p.1.snd⟩, by
      constructor
      · exact (hmetric p.1.proj p.1.snd p.1.snd).symm.trans p.2.1
      · intro w
        obtain ⟨z, rfl⟩ := (hf.mfderivToContinuousLinearEquiv (by simp) p.1.proj).surjective w
        exact (hricci p.1.proj p.1.snd z).symm.trans (p.2.2 z)⟩
  obtain ⟨U, W, hU, hp, hW, hWp, hn⟩ := hlocal q
  let V := VectorField.mpullback (𝓡 n) (𝓡 n) f W
  have hmap (y : E) : mfderiv (𝓡 n) (𝓡 n) f y (V y) = W (f y) :=
    (hinv y).self_apply_inverse _
  refine ⟨f ⁻¹' U, V, hU.preimage hf.contMDiff.continuous, hp, ?_, ?_, ?_⟩
  · intro y hy
    exact ((hW.contMDiffAt (hU.mem_nhds hy)).mpullback_vectorField_preimage
      (f := f) (hf.contMDiff y) (hinv y) (by simp)).contMDiffWithinAt
  · change (mfderiv (𝓡 n) (𝓡 n) f p.1.proj).inverse (W (f p.1.proj)) = p.1.snd
    change W (f p.1.proj) = mfderiv (𝓡 n) (𝓡 n) f p.1.proj p.1.snd at hWp
    rw [hWp, (hinv p.1.proj).inverse_apply_self]
  · intro y hy
    refine ⟨?_, ?_, ?_⟩
    · rw [hmetric, hmap]
      exact (hn (f y) hy).1
    · intro w
      rw [hricci, hmap]
      exact (hn (f y) hy).2.1 _
    · intro w
      rw [D.connection_mpullback_of_metric_pullback D' (hf.contMDiff y)
        (Eventually.of_forall hinv) (Eventually.of_forall hmetric)
        ((hW.contMDiffAt (hU.mem_nhds hy)).mdifferentiableAt (by simp)),
        (hn (f y) hy).2.2, map_zero]

end PoincareMT.RicciFlow.Splitting
