import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Metric
import PoincareLib.Geometry.RicciFlow.Measure.Monotonicity
import PoincareLib.Geometry.Riemannian.Comparison.Volume.Rigidity.Curvature
import PoincareLib.Geometry.Riemannian.Curvature.LocalIsometryInvariants
import PoincareLib.Geometry.Riemannian.Connection.Construction

/-! # Curvature and metric order at a finite backward boundary -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledBlowupBoundary

variable {n : ℕ} {ι : Type*} {U : ι → Type*} {M : Type*}
  [∀ i, TopologicalSpace (U i)] [TopologicalSpace M]
  [∀ i, ChartedSpace (EuclideanSpace ℝ (Fin n)) (U i)]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M]
  [∀ i, IsManifold (𝓡 n) ∞ (U i)] [IsManifold (𝓡 n) ∞ M]
  {T : ℝ} (hT : 0 < T) (V : ι → ℝ) (hV : ∀ i, T < V i)
  (F : ∀ i, RicciFlow n (U i) (Icc (-V i) 0))
  (g : ℝ → RiemannianMetric n M) (q : ∀ i, U i → M)
  (hq : ∀ i, IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (q i))
  (hcover : ∀ y, ∃ i x, q i x = y)
  (hpres : ∀ i, ∀ t ∈ Ioc (-T) 0, ∀ (x : U i) (a b : TangentSpace (𝓡 n) x),
    ((F i).metric t).inner x a b = (g t).inner (q i x)
      (mfderiv (𝓡 n) (𝓡 n) (q i) x a) (mfderiv (𝓡 n) (𝓡 n) (q i) x b))
  (gBoundary : RiemannianMetric n M)
  (hBoundary : ∀ i (x : U i) (a b : TangentSpace (𝓡 n) x),
    ((F i).metric (-T)).inner x a b = gBoundary.inner (q i x)
      (mfderiv (𝓡 n) (𝓡 n) (q i) x a) (mfderiv (𝓡 n) (𝓡 n) (q i) x b))
  (hnonnegative : ∀ i, ∀ t ∈ Icc (-V i) 0, ∀ x, ((F i).connection t).NonnegativeCurvatureOperator x)

include hT hV hq hcover hBoundary hnonnegative

theorem boundary_nonnegativeCurvatureOperator (D : LeviCivitaData gBoundary) (y : M) :
    D.NonnegativeCurvatureOperator y := by
  obtain ⟨i, x, rfl⟩ := hcover y
  apply (((F i).connection (-T)).nonnegativeCurvatureOperator_iff_of_local_isometry D
    isOpen_univ (hq i).contMDiff.contMDiffOn (fun x _ a b => hBoundary i x a b) (mem_univ x)).mp
  exact hnonnegative i (-T) ⟨neg_le_neg (hV i).le, by linarith⟩ x

include hpres in
theorem terminal_inner_le_boundary_inner (y : M) (v : TangentSpace (𝓡 n) y) :
    (g 0).inner y v v ≤ gBoundary.inner y v v := by
  obtain ⟨i, x, rfl⟩ := hcover y
  let A := (hq i x).mfderivToContinuousLinearEquiv (by simp)
  obtain ⟨a, ha⟩ := A.surjective v
  have ha' : mfderiv (𝓡 n) (𝓡 n) (q i) x a = v := ha
  have hmono := (F i).inner_antitone_of_nonnegative_ricci (convex_Icc _ _)
    (fun t ht x v => ((F i).connection t).ricci_nonneg_of_nonnegative_curvatureOperator
      x (hnonnegative i t ht x) v)
    (show -T ∈ Icc (-V i) 0 from ⟨neg_le_neg (hV i).le, by linarith⟩)
    (show (0 : ℝ) ∈ Icc (-V i) 0 from ⟨by linarith [hV i], le_rfl⟩)
    (by linarith : -T ≤ 0) x a
  rw [hpres i 0 ⟨by linarith, le_rfl⟩ x a a, hBoundary i x a a, ha'] at hmono
  exact hmono

end PoincareMT.ControlledBlowupBoundary
