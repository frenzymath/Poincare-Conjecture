import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.BallCompactness
import PoincareLib.Geometry.Riemannian.Measure.LocalIsometry

/-!
# Intrinsic balls in the terminal cylinder

Short paths from the center stay inside their ambient ball. The ordinary
terminal metric therefore has the same smaller centered balls and volumes
as the actual normalized source slice. Source: Morgan--Tian, Theorem 11.1,
pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter MeasureTheory
open scoped Manifold ContDiff Bundle Topology ENNReal

namespace PoincareMT.RiemannianMetric

variable {n : ℕ} {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]

/-- The inclusion of an ambient ball preserves its smaller centered balls. -/
theorem image_centered_ball_subtype_val {U : TopologicalSpace.Opens M}
    (g : RiemannianMetric n M) (gU : RiemannianMetric n U)
    (hinner : ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
      gU.inner x v w = g.inner x.val
        (mfderiv (𝓡 n) (𝓡 n) (Subtype.val : U → M) x v)
        (mfderiv (𝓡 n) (𝓡 n) (Subtype.val : U → M) x w))
    (p : U) {A r : ℝ} (hU : (U : Set M) = g.ball p.val A) (hrA : r ≤ A) :
    Subtype.val '' gU.ball p r = g.ball p.val r := by
  classical
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 n) : M → Type _) :=
    ⟨g.toRiemannianMetric⟩
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 n) : U → Type _) :=
    ⟨gU.toRiemannianMetric⟩
  ext x
  constructor
  · rintro ⟨y, hy, rfl⟩
    exact (edist_map_le_of_metric_pullback gU g contMDiff_subtype_val hinner p y).trans_lt hy
  · intro hx
    have hxU : x ∈ U := by
      change x ∈ (U : Set M)
      rw [hU]
      exact hx.trans_le (ENNReal.ofReal_le_ofReal hrA)
    obtain ⟨γ, h0, h1, hγ, hlen, _⟩ :=
      Manifold.exists_lt_locally_constant_of_riemannianEDist_lt hx zero_lt_one
    have hpath : ∀ t ∈ Icc (0 : ℝ) 1, γ t ∈ U := by
      intro t ht
      change γ t ∈ (U : Set M)
      rw [hU]
      exact ((Manifold.riemannianEDist_le_pathELength
        (hγ.contMDiffOn.mono (Icc_subset_Icc le_rfl ht.2)) h0 rfl ht.1).trans
          (Manifold.pathELength_mono le_rfl ht.2)).trans_lt
            (hlen.trans_le (ENNReal.ofReal_le_ofReal hrA))
    let γU : ℝ → U := fun t => if h : γ t ∈ U then ⟨γ t, h⟩ else p
    have hval {t : ℝ} (ht : γ t ∈ U) : (γU t).val = γ t := by simp [γU, ht]
    have hsmooth {t : ℝ} (ht : t ∈ Icc (0 : ℝ) 1) :
        ContMDiffAt 𝓘(ℝ, ℝ) (𝓡 n) 1 γU t := by
      have heq : (Subtype.val ∘ γU) =ᶠ[𝓝 t] γ := by
        filter_upwards [hγ.continuous.continuousAt (U.isOpen.mem_nhds (hpath t ht))] with s hs
        exact hval hs
      apply (ChartedSpace.liftPropWithinAt_subtypeVal_comp_iff
        (P := ContDiffWithinAtProp 𝓘(ℝ, ℝ) (𝓡 n) 1) γU univ t).mp
      exact ((hγ t).congr_of_eventuallyEq heq).contMDiffWithinAt
    have hlenU : gU.pathELength γU 0 1 = g.pathELength γ 0 1 := by
      rw [pathELength_eq_lintegral_tangentNorm, pathELength_eq_lintegral_tangentNorm]
      apply setLIntegral_congr_fun measurableSet_Icc
      intro t ht
      have heq : (Subtype.val ∘ γU) =ᶠ[𝓝 t] γ := by
        filter_upwards [hγ.continuous.continuousAt (U.isOpen.mem_nhds (hpath t ht))] with s hs
        exact hval hs
      have hder := mfderiv_comp t
        ((contMDiff_subtype_val (n := 1)).mdifferentiable one_ne_zero (γU t))
        ((hsmooth ht).mdifferentiableAt one_ne_zero)
      rw [heq.mfderiv_eq] at hder
      have hi := congrArg Real.sqrt (hinner (γU t)
        (mfderiv 𝓘(ℝ, ℝ) (𝓡 n) γU t 1) (mfderiv 𝓘(ℝ, ℝ) (𝓡 n) γU t 1))
      apply congrArg ENNReal.ofReal
      change gU.tangentNorm (γU t) _ = g.tangentNorm (γU t).val _ at hi
      rw [← ContinuousLinearMap.comp_apply, ← hder, hval (hpath t ht)] at hi
      exact hi
    refine ⟨⟨x, hxU⟩, ?_, rfl⟩
    have hstart : γU 0 = p := Subtype.ext ((hval (hpath 0 ⟨le_rfl, zero_le_one⟩)).trans h0)
    have hend : γU 1 = ⟨x, hxU⟩ :=
      Subtype.ext ((hval (hpath 1 ⟨zero_le_one, le_rfl⟩)).trans h1)
    exact (Manifold.riemannianEDist_le_pathELength
      (fun t ht => (hsmooth ht).contMDiffWithinAt) hstart hend zero_le_one).trans_lt
        (hlenU.trans_lt hlen)

end PoincareMT.RiemannianMetric

universe u

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

theorem ordinaryFlow_terminal_image_ball (e : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (hT : 0 < T) {r : ℝ} (hrA : r ≤ A) :
    Subtype.val '' ((e.ordinaryFlow hT).metric 0).ball (sourceBase S k hA) r =
      S.baseBall k r := by
  rw [← normalized_terminal_ball]
  exact RiemannianMetric.image_centered_ball_subtype_val _ _
    (e.ordinaryFlow_terminal_inner hT) (sourceBase S k hA)
    (normalized_terminal_ball A).symm hrA

theorem ordinaryFlow_terminal_volume_ball (e : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (hT : 0 < T) {r : ℝ} (hrA : r ≤ A) :
    ((e.ordinaryFlow hT).metric 0).volumeMeasure
        (((e.ordinaryFlow hT).metric 0).ball (sourceBase S k hA) r) =
      (rescaledMetric ((S.flow k).metric (S.base k).1) (S.scale k)
        (S.base_scalar_pos k)).volumeMeasure (S.baseBall k r) := by
  rw [← e.ordinaryFlow_terminal_image_ball hA hT hrA]
  symm
  apply RiemannianMetric.volumeMeasure_image_eq_of_injOn_metric_pullback _ _
    contMDiff_subtype_val (e.ordinaryFlow_terminal_inner hT) isOpen_univ
    (Subtype.val_injective.injOn)
    (RicciFlowAnalysis.initial_ball_isOpen _ _ _).measurableSet (subset_univ _)

end PoincareMT.ControlledBlowupCylinder
