import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Data

/-!
# Choosing canonical slices inside terminal neighborhoods

The frozen left-dense whole-slice hypothesis permits selection after any
finite collection of terminal continuity tolerances has been specified.
The normalized good times converge to zero, and all points of each chosen
slice have the original canonical control above the original cutoff.

Reference: Morgan--Tian, Claim 11.6, p. 270.
-/

set_option autoImplicit false

open Set Filter Metric
open scoped Topology

universe u

namespace PoincareMT

theorem generalizedEarlierDenseStrongCanonicalNeighborhoods.exists_normalized_good_time
    {F : GeneralizedRicciFlowData.{u}} {epsilon C t : ℝ}
    {x : (F.slice t).carrier}
    (h : generalizedEarlierDenseStrongCanonicalNeighborhoods F epsilon C t x)
    {q delta : ℝ} (hq : 0 < q) (hdelta : 0 < delta) :
    ∃ s : ℝ, s ∈ Ioc (-delta) 0 ∧ t + s / q ∈ F.interval ∧
      generalizedSliceStrongCanonicalNeighborhoods F epsilon C
        (4 * F.scalar ⟨t, x⟩) (t + s / q) := by
  have ht : t ∈ F.interval := (F.slice_nonempty_iff t).mp ⟨x⟩
  obtain ⟨v, hv, hvlow, hvtop, hgood⟩ :=
    h t ht le_rfl (t - delta / q) (sub_lt_self _ (div_pos hdelta hq))
  let s := (v - t) * q
  have htime : t + s / q = v := by
    dsimp [s]
    rw [mul_div_cancel_right₀ _ hq.ne']
    ring
  refine ⟨s, ⟨?_, ?_⟩, htime ▸ hv, htime ▸ hgood⟩
  · dsimp [s]
    have hd : delta / q * q = delta := div_mul_cancel₀ delta hq.ne'
    nlinarith
  · exact mul_nonpos_of_nonpos_of_nonneg (sub_nonpos.mpr hvtop) hq.le

namespace M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem exists_canonical_time_in_terminal_neighborhood
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu) (k : ℕ)
    {T delta : ℝ} (hT : 0 < T) (hdelta : 0 < delta)
    (P : ℝ → Prop) (hP : ∀ᶠ s in 𝓝[Icc (-T) 0] 0, P s) :
    ∃ s : ℝ, s ∈ Icc (-T) 0 ∧ -delta < s ∧ P s ∧
      (S.base k).1 + s / S.scale k ∈ (S.flow k).interval ∧
      generalizedSliceStrongCanonicalNeighborhoods (S.flow k) epsilon C
        (4 * S.scale k) ((S.base k).1 + s / S.scale k) := by
  obtain ⟨V, hV, hVP⟩ := mem_nhdsWithin_iff_exists_mem_nhds_inter.mp hP
  obtain ⟨r, hr, hrV⟩ := Metric.mem_nhds_iff.mp hV
  obtain ⟨s, hs, htime, hgood⟩ :=
    (H.canonical k).exists_normalized_good_time (S.base_scalar_pos k)
      (lt_min hT (lt_min hdelta hr))
  have hsT : s ∈ Icc (-T) 0 :=
    ⟨(neg_le_neg (min_le_left T (min delta r))).trans hs.1.le, hs.2⟩
  have hsdelta : -delta < s :=
    (neg_le_neg ((min_le_right T (min delta r)).trans (min_le_left delta r))).trans_lt hs.1
  have hsr : -r < s :=
    (neg_le_neg ((min_le_right T (min delta r)).trans (min_le_right delta r))).trans_lt hs.1
  have hsV : s ∈ V := hrV (by
    simp only [Metric.mem_ball, Real.dist_eq, sub_zero, abs_of_nonpos hs.2]
    linarith)
  exact ⟨s, hsT, hsdelta, hVP ⟨hsV, hsT⟩, htime, hgood⟩

theorem exists_canonical_times_preserving_terminal_properties
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (sigma : ℕ → ℕ) (T : ℕ → ℝ) (hT : ∀ k, 0 < T k)
    (P : ℕ → ℝ → Prop) (hP : ∀ k, ∀ᶠ s in 𝓝[Icc (-(T k)) 0] 0, P k s) :
    ∃ s : ℕ → ℝ, Tendsto s atTop (𝓝 0) ∧
      ∀ k, s k ∈ Icc (-(T k)) 0 ∧ -((k : ℝ) + 1)⁻¹ < s k ∧ P k (s k) ∧
        (S.base (sigma k)).1 + s k / S.scale (sigma k) ∈ (S.flow (sigma k)).interval ∧
        generalizedSliceStrongCanonicalNeighborhoods (S.flow (sigma k)) epsilon C
          (4 * S.scale (sigma k))
          ((S.base (sigma k)).1 + s k / S.scale (sigma k)) := by
  classical
  have hex (k : ℕ) := H.exists_canonical_time_in_terminal_neighborhood
    (sigma k) (hT k) (by positivity : 0 < ((k : ℝ) + 1)⁻¹) (P k) (hP k)
  choose s hs using hex
  refine ⟨s, ?_, hs⟩
  have hsmall : Tendsto (fun k : ℕ => ((k : ℝ) + 1)⁻¹) atTop (𝓝 0) :=
    tendsto_inv_atTop_zero.comp
      (tendsto_atTop_add_const_right atTop 1 tendsto_natCast_atTop_atTop)
  have hnegative : Tendsto (fun k : ℕ => -((k : ℝ) + 1)⁻¹) atTop (𝓝 0) := by
    simpa only [neg_zero] using hsmall.neg
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le hnegative tendsto_const_nhds
    (fun k => (hs k).2.1.le) (fun k => (hs k).1.2)

end M30CommonBlowupControls

end PoincareMT
