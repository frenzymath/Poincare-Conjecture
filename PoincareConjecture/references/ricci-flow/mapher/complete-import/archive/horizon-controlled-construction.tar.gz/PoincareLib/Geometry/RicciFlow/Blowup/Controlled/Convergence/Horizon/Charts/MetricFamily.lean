import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.Compatibility
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.Domains
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Descent
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.MetricFamily

/-! # The smooth horizon metric family on the original limit carrier -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

theorem exists_horizon_metricFamily
    (htmono : Monotone tau) (hB : ∀ j, 0 ≤ B j)
    (q : ℕ → G.limitCarrier.carrier)
    (hcover : ∀ x : G.limitCarrier.carrier, ∃ i, x ∈ (extChartAt (𝓡 3) (q i)).source)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    (f : ℕ → ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3)
    (hf : ∀ i, ContDiffOn ℝ ∞ (f i) (horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target))
    (hpoint : ∀ i z, z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target →
      Tendsto (fun k => horizonSpacetimeCoefficients G (q i) (sigma k) z) atTop (𝓝 (f i z))) :
    ∃ g : ℝ → RiemannianMetric 3 G.limitCarrier.carrier,
      RiemannianMetric.IsSmoothFamilyOn g (horizonOpenTime tau) ∧
      ∀ t ∈ horizonOpenTime tau, ∀ i x, x ∈ (extChartAt (𝓡 3) (q i)).target → ∀ v w,
        f i (t, x) v w = (g t).pullbackCoefficients (extChartAt (𝓡 3) (q i)).symm x v w := by
  classical
  let U (i : ℕ) : Opens (EuclideanSpace ℝ (Fin 3)) :=
    ⟨(extChartAt (𝓡 3) (q i)).target, isOpen_extChartAt_target (q i)⟩
  have hJ : (horizonOpenTime tau).Nonempty :=
    ⟨-tau 0 / 2, mem_iUnion.mpr ⟨0, ⟨by linarith [htau 0], by linarith [htau 0]⟩⟩⟩
  have hex (i : ℕ) := RiemannianMetric.exists_smoothFamily_of_coefficients_on_timeSet
    hJ (U i) (f i) (hf i)
    (fun t ht x hx v w => horizon_limit_symmetric G (q i) (hpoint i) ht hx v w)
    (fun t ht x hx => horizon_limit_positive G htmono hB (q i) hsigma (hpoint i) ht hx)
  choose gchart hgsmooth hgcoeff using hex
  have hmapscover : ∀ y, ∃ i x, G.referenceOpenMap (q i) (U i) x = y := by
    intro y
    obtain ⟨i, hi⟩ := hcover y
    exact ⟨i, ⟨extChartAt (𝓡 3) (q i) y, (extChartAt (𝓡 3) (q i)).map_source hi⟩,
      (extChartAt (𝓡 3) (q i)).left_inv hi⟩
  have hcompat : ∀ t ∈ horizonOpenTime tau, ∀ i j (x : U i) (y : U j),
      G.referenceOpenMap (q i) (U i) x = G.referenceOpenMap (q j) (U j) y →
      ∀ (a b : TangentSpace (𝓡 3) x) (c d : TangentSpace (𝓡 3) y),
        mfderiv (𝓡 3) (𝓡 3) (G.referenceOpenMap (q i) (U i)) x a =
          mfderiv (𝓡 3) (𝓡 3) (G.referenceOpenMap (q j) (U j)) y c →
        mfderiv (𝓡 3) (𝓡 3) (G.referenceOpenMap (q i) (U i)) x b =
          mfderiv (𝓡 3) (𝓡 3) (G.referenceOpenMap (q j) (U j)) y d →
        (gchart i t).inner x a b = (gchart j t).inner y c d := by
    intro t ht i j x y hxy a b c d ha hb
    rw [hgcoeff i t ht, hgcoeff j t ht]
    rw [G.referenceOpenMap_mfderiv (q i) (U i) subset_rfl x,
      G.referenceOpenMap_mfderiv (q j) (U j) subset_rfl y] at ha hb
    exact horizon_limit_compatible G (q i) (q j) hsigma
      (hpoint i (t, x) ⟨ht, x.property⟩) (hpoint j (t, y) ⟨ht, y.property⟩)
      x.property y.property hxy a b c d ha hb
  obtain ⟨g, hg, hpres⟩ := Poincare.Gluing.exists_smoothFamily_of_compatible_local_diffeomorphisms
    hJ gchart hgsmooth (fun i => G.referenceOpenMap (q i) (U i))
    (fun i => G.referenceOpenMap_isLocalDiffeomorph (q i) (U i) subset_rfl) hmapscover hcompat
  refine ⟨g, hg, ?_⟩
  intro t ht i x hx v w
  have hp := hpres t ht i ⟨x, hx⟩ v w
  rw [hgcoeff i t ht, G.referenceOpenMap_mfderiv (q i) (U i) subset_rfl ⟨x, hx⟩] at hp
  exact hp

end PoincareMT.ControlledBlowupCompactness
