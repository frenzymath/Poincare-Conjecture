import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Geometry.NeckExit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Geometry.LocalSeparation
import PoincareLib.Topology.Manifold.NeckCap.Chain.Extension.NoReturn

/-!
# Actual path separation from opposite minimizing neck exits

A minimizing segment from the center cannot return to the central sphere
after its length exceeds the sphere diameter. The two tails and any path
between their endpoints would therefore join opposite collar halves while
avoiding a separating sphere, which is impossible.

Reference: Morgan--Tian, Claims 11.13--11.14.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.EpsilonNeck

variable {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
  [IsManifold (𝓡 3) ∞ M] [MeasurableSpace M] [BorelSpace M]
  [T2Space M] [T3Space M] [ConnectedSpace M] {g : RiemannianMetric 3 M}

omit [ConnectedSpace M] in
/-- Actual minimizing distance from the center prevents late returns to the
central sphere, independently of what happens outside the neck carrier. -/
theorem not_mem_central_sphere_of_center_distance
    (N : EpsilonNeck g) {x : M} {s : ℝ}
    (hdist : g.edist N.center x = ENNReal.ofReal s)
    (hs : 2 * Real.pi * N.scale < s) : x ∉ N.central_sphere := by
  intro hx
  have hu := N.edist_central_sphere_le_two_pi_mul_scale N.center_on_central_sphere hx
  rw [hdist] at hu
  have hscale := N.scale_pos
  have hr : 0 ≤ 2 * Real.pi * N.scale := by positivity
  exact not_lt_of_ge ((ENNReal.ofReal_le_ofReal_iff hr).mp hu) hs

/-- A separating neck with opposite long minimizing exits separates the
original endpoints by its actual central sphere. -/
theorem every_path_meets_central_sphere_of_opposite_tails
    (N : EpsilonNeck g) (hsep : N.IsSeparating)
    {γ σ : ℝ → M} {a b r t : ℝ}
    (hr : r ∈ Icc 0 a) (ht : t ∈ Icc 0 b)
    (hrlong : 2 * Real.pi * N.scale < r) (htlong : 2 * Real.pi * N.scale < t)
    (hγcont : ContinuousOn γ (Icc 0 a)) (hσcont : ContinuousOn σ (Icc 0 b))
    (hγdist : ∀ s ∈ Icc 0 a, g.edist N.center (γ s) = ENNReal.ofReal s)
    (hσdist : ∀ s ∈ Icc 0 b, g.edist N.center (σ s) = ENNReal.ofReal s)
    (hrN : γ r ∈ N.carrier) (htN : σ t ∈ N.carrier)
    (hopposite :
      ((N.coordinate_inverse (γ r)).2 < 0 ∧ 0 < (N.coordinate_inverse (σ t)).2) ∨
      (0 < (N.coordinate_inverse (γ r)).2 ∧ (N.coordinate_inverse (σ t)).2 < 0)) :
    ∀ P : Path (γ a) (σ b), ∃ s, P s ∈ N.central_sphere := by
  intro P
  by_contra hnone
  push Not at hnone
  let A := γ '' Icc r a
  let B := σ '' Icc t b
  let U := (A ∪ range P) ∪ B
  have hAsub : Icc r a ⊆ Icc 0 a := fun _ hs => ⟨hr.1.trans hs.1, hs.2⟩
  have hBsub : Icc t b ⊆ Icc 0 b := fun _ hs => ⟨ht.1.trans hs.1, hs.2⟩
  have hA : IsPreconnected A := isPreconnected_Icc.image γ (hγcont.mono hAsub)
  have hB : IsPreconnected B := isPreconnected_Icc.image σ (hσcont.mono hBsub)
  have hP : IsPreconnected (range P) := isPreconnected_range P.continuous
  have hAP : (A ∩ range P).Nonempty :=
    ⟨γ a, ⟨a, ⟨hr.2, le_rfl⟩, rfl⟩, 0, P.source⟩
  have hPB : ((A ∪ range P) ∩ B).Nonempty :=
    ⟨σ b, Or.inr ⟨1, P.target⟩, b, ⟨ht.2, le_rfl⟩, rfl⟩
  have hU : IsPreconnected U := (hA.union' hAP hP).union' hPB hB
  have havoid : Disjoint U N.central_sphere := by
    apply disjoint_left.mpr
    intro x hx hxS
    rcases hx with (hx | hx) | hx
    · obtain ⟨s, hs, rfl⟩ := hx
      exact N.not_mem_central_sphere_of_center_distance (hγdist s (hAsub hs))
        (hrlong.trans_le hs.1) hxS
    · obtain ⟨s, rfl⟩ := hx
      exact hnone s hxS
    · obtain ⟨s, hs, rfl⟩ := hx
      exact N.not_mem_central_sphere_of_center_distance (hσdist s (hBsub hs))
        (htlong.trans_le hs.1) hxS
  have hrU : γ r ∈ U := Or.inl (Or.inl ⟨r, ⟨le_rfl, hr.2⟩, rfl⟩)
  have htU : σ t ∈ U := Or.inr ⟨t, ⟨le_rfl, ht.2⟩, rfl⟩
  apply N.not_meets_both_halves_of_isSeparating hsep hU
    (by rw [PreconnectedSpace.connectedComponent_eq_univ]; exact subset_univ _) havoid
  have har := (N.coordinate_inverse_mem (γ r) hrN).2
  have hat := (N.coordinate_inverse_mem (σ t) htN).2
  rcases hopposite with h | h
  · exact ⟨⟨γ r, hrU, hrN, har.1, h.1⟩, ⟨σ t, htU, htN, h.2, hat.2⟩⟩
  · exact ⟨⟨σ t, htU, htN, hat.1, h.2⟩, ⟨γ r, hrU, hrN, h.1, har.2⟩⟩

/-- The large-triangle comparison supplies the opposite exits, and actual
distance minimality extends separation to the original endpoints. -/
theorem every_path_meets_central_sphere_of_large_triangle
    (N : EpsilonNeck g) (D : LeviCivitaData g)
    (hcomplete : MetricComplete g) (hsec : D.NonnegativeSectionalCurvature)
    (hsep : N.IsSeparating) (hsmall : N.epsilon ≤ 1 / (400 * Real.pi))
    {γ σ : ℝ → M} {a b d : ℝ} (hd : 0 < d)
    (ha : d ≤ a) (hb : d ≤ b) (ha' : a ≤ 3 * d / 2) (hb' : b ≤ 3 * d / 2)
    (hfar : d ≤ (g.edist (γ a) (σ b)).toReal)
    (hγ : g.IsGeodesicOn γ (Icc 0 a)) (hσ : g.IsGeodesicOn σ (Icc 0 b))
    (hγ0 : γ 0 = N.center) (hσ0 : σ 0 = N.center)
    (hγspeed : ∀ s ∈ Icc 0 a,
      g.tangentNorm (γ s) (mfderiv 𝓘(ℝ, ℝ) (𝓡 3) γ s 1) = 1)
    (hσspeed : ∀ s ∈ Icc 0 b,
      g.tangentNorm (σ s) (mfderiv 𝓘(ℝ, ℝ) (𝓡 3) σ s 1) = 1)
    (hγmin : ∀ s ∈ Icc 0 a, ∀ t ∈ Icc 0 a,
      g.edist (γ s) (γ t) = ENNReal.ofReal |s - t|)
    (hσmin : ∀ s ∈ Icc 0 b, ∀ t ∈ Icc 0 b,
      g.edist (σ s) (σ t) = ENNReal.ofReal |s - t|)
    (hγout : γ a ∉ N.coordinate_map ''
      (univ ×ˢ Icc (-N.epsilon⁻¹ / 2) (N.epsilon⁻¹ / 2)))
    (hσout : σ b ∉ N.coordinate_map ''
      (univ ×ˢ Icc (-N.epsilon⁻¹ / 2) (N.epsilon⁻¹ / 2))) :
    ∀ P : Path (γ a) (σ b), ∃ s, P s ∈ N.central_sphere := by
  have he := N.epsilon_pos
  have hs := N.scale_pos
  have haxis0 : (N.coordinate_inverse N.center).2 = 0 :=
    ((N.mem_central_sphere_iff N.center).mp N.center_on_central_sphere).2
  obtain ⟨r, hr, t, ht, hrN, htN, hopposite, _, _⟩ :=
    N.exists_opposite_half_neck_exits_of_large_triangle D hcomplete hsec hsmall
      hd ha hb ha' hb' hfar hγ hσ hγ0 hσ0 hγspeed hσspeed hγmin hσmin
      (N.central_sphere_subset N.center_on_central_sphere)
      (by rw [haxis0]; norm_num) hγout hσout
  have hsmall' : N.epsilon ≤ 1 / 4 := by
    have h := (le_div_iff₀ (by positivity : 0 < 400 * Real.pi)).mp hsmall
    nlinarith [Real.two_le_pi]
  have hlong : 2 * Real.pi * N.scale < N.scale / (100 * N.epsilon) := by
    apply (lt_div_iff₀ (by positivity : 0 < 100 * N.epsilon)).mpr
    have h := (le_div_iff₀ (by positivity : 0 < 400 * Real.pi)).mp hsmall
    have hm := mul_le_mul_of_nonneg_right h hs.le
    nlinarith
  have hrabs : |(N.coordinate_inverse (γ r)).2| = N.epsilon⁻¹ / 2 := by
    rcases hopposite with h | h <;> rw [h.1] <;> simp [abs_of_nonneg (by positivity : 0 ≤ N.epsilon⁻¹ / 2)]
  have htabs : |(N.coordinate_inverse (σ t)).2| = N.epsilon⁻¹ / 2 := by
    rcases hopposite with h | h <;> rw [h.2] <;> simp [abs_of_nonneg (by positivity : 0 ≤ N.epsilon⁻¹ / 2)]
  have hrsub : Icc 0 r ⊆ Icc 0 a := fun _ hu => ⟨hu.1, hu.2.trans hr.2⟩
  have htsub : Icc 0 t ⊆ Icc 0 b := fun _ hu => ⟨hu.1, hu.2.trans ht.2⟩
  have hrlong := hlong.trans (N.half_neck_time_gt_of_unit_speed hr.1.le hsmall'
    (fun s hs => hγ s (hrsub hs)) hrN (fun s hs => hγspeed s (hrsub hs))
    (by rw [hγ0, haxis0]; norm_num) hrabs)
  have htlong := hlong.trans (N.half_neck_time_gt_of_unit_speed ht.1.le hsmall'
    (fun s hs => hσ s (htsub hs)) htN (fun s hs => hσspeed s (htsub hs))
    (by rw [hσ0, haxis0]; norm_num) htabs)
  apply N.every_path_meets_central_sphere_of_opposite_tails hsep
    ⟨hr.1.le, hr.2⟩ ⟨ht.1.le, ht.2⟩ hrlong htlong
    (fun s hs => (hγ.contMDiffAt hs).continuousAt.continuousWithinAt)
    (fun s hs => (hσ.contMDiffAt hs).continuousAt.continuousWithinAt)
    ?_ ?_ (hrN ⟨hr.1.le, le_rfl⟩) (htN ⟨ht.1.le, le_rfl⟩) ?_
  · intro s hs
    simpa only [hγ0, zero_sub, abs_neg, abs_of_nonneg hs.1] using
      hγmin 0 ⟨le_rfl, hd.le.trans ha⟩ s hs
  · intro s hs
    simpa only [hσ0, zero_sub, abs_neg, abs_of_nonneg hs.1] using
      hσmin 0 ⟨le_rfl, hd.le.trans hb⟩ s hs
  · rcases hopposite with h | h
    · exact Or.inl ⟨by rw [h.1]; exact neg_lt_zero.mpr (half_pos (inv_pos.mpr he)),
        by rw [h.2]; exact half_pos (inv_pos.mpr he)⟩
    · exact Or.inr ⟨by rw [h.1]; exact half_pos (inv_pos.mpr he),
        by rw [h.2]; exact neg_lt_zero.mpr (half_pos (inv_pos.mpr he))⟩

end PoincareMT.EpsilonNeck
