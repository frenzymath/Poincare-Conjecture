import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.NeckLimit

/-!
# Scalar control from a captured source neck sequence

Compact-uniform scalar convergence controls the moving neck centers. The
actual transported necks retain the source scalar ratio with a factor of
two; both direct necks and cap end necks meet the same hypotheses.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Metric
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.TerminalNeck

open MetricSurgery
local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem eventually_necks_with_scalar_control_of_captured_convergence
    {X : ℕ → Type u} [∀ k, TopologicalSpace (X k)] [∀ k, ChartedSpace E (X k)]
    [∀ k, IsManifold (𝓡 3) ∞ (X k)]
    {M : Type v} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    (g : ∀ k, RiemannianMetric 3 (X k)) (h : RiemannianMetric 3 M)
    (N : ∀ k, EpsilonNeck (g k)) (e : ∀ k, OpenPartialHomeomorph (X k) M)
    (he : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source)
    (hei : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k).symm (e k).target)
    (hcapture : ∀ k, (N k).carrier ⊆ (e k).source)
    {A : Set M} (himage : ∀ k, e k '' (N k).carrier ⊆ A)
    (D : LeviCivitaData h) (x : M) (hxA : x ∈ A) (hxpos : 0 < D.scalarCurvature x)
    {δ ε l u C : ℝ} (hδ : 0 < δ) (hδε : δ < ε) (hε : ε < 1 / 2)
    (hNeq : ∀ k, (N k).epsilon = δ) (hl : 0 < l) (hu : 0 < u) (hC : 0 < C)
    (hscalar : ∀ k, l ≤ (N k).connection.scalarCurvature (N k).center ∧
      (N k).connection.scalarCurvature (N k).center ≤ u)
    (hratio : ∀ k, (N k).connection.scalarCurvature ((e k).symm x) ≤
      C * (N k).connection.scalarCurvature (N k).center)
    (herror : ∀ η : ℝ, 0 < η → ∀ᶠ k in atTop, ∀ z : RoundCylinderSpace,
      z.2 ∈ Ioo (-(N k).epsilon⁻¹) (N k).epsilon⁻¹ → ∀ j, j ≤ ⌊ε⁻¹⌋₊ →
        ‖iteratedFDeriv ℝ j (fun p =>
          (g k).parametrizedCoefficients (centeredNeckLift (N k) z.1 z.2) p -
          h.parametrizedCoefficients (e k ∘ centeredNeckLift (N k) z.1 z.2) p) 0‖ ≤ η)
    (hscalarconv : TendstoUniformlyOn
      (fun k y => (N k).connection.scalarCurvature ((e k).symm y))
      D.scalarCurvature atTop A) :
    ∀ᶠ k in atTop, ∃ L : EpsilonNeck h, L.epsilon = ε ∧ L.connection = D ∧
      L.center = e k (N k).center ∧
      D.scalarCurvature x ≤ 2 * C * D.scalarCurvature L.center := by
  have hc (k : ℕ) : (N k).center ∈ (N k).carrier :=
    (N k).central_sphere_subset (N k).center_on_central_sphere
  have hcenterA (k : ℕ) : e k (N k).center ∈ A :=
    himage k (mem_image_of_mem _ (hc k))
  have hleft (k : ℕ) : (e k).symm (e k (N k).center) = (N k).center :=
    (e k).left_inv (hcapture k (hc k))
  have hgap (η : ℝ) (hη : 0 < η) : ∀ᶠ k in atTop,
      |D.scalarCurvature (e k (N k).center) -
        (N k).connection.scalarCurvature (N k).center| ≤ η := by
    filter_upwards [Metric.tendstoUniformlyOn_iff.mp hscalarconv η hη] with k hk
    have hh := (hk _ (hcenterA k)).le
    simpa only [Real.dist_eq, hleft] using hh
  have hnecks := eventually_transported_necks_of_metric_and_scalar_errors
    g h N e he hei hcapture D hδ hδε hε hNeq hl hu hscalar herror hgap
  let η := D.scalarCurvature x / (2 * (C + 1))
  have hη : 0 < η := by positivity
  have hηeq : η * (2 * (C + 1)) = D.scalarCurvature x :=
    div_mul_cancel₀ _ (by positivity)
  filter_upwards [hnecks, hgap η hη,
    Metric.tendstoUniformlyOn_iff.mp hscalarconv η hη] with k hk hkcenter hkall
  obtain ⟨L, hLe, hLc, hLD, _hLs, _hLcarrier⟩ := hk
  refine ⟨L, hLe, hLD, hLc, ?_⟩
  have hxgap : |D.scalarCurvature x -
      (N k).connection.scalarCurvature ((e k).symm x)| ≤ η := by
    simpa only [Real.dist_eq] using (hkall x hxA).le
  have hxle : D.scalarCurvature x ≤
      (N k).connection.scalarCurvature ((e k).symm x) + η := by
    linarith [(abs_le.mp hxgap).2]
  have hcle : (N k).connection.scalarCurvature (N k).center ≤
      D.scalarCurvature (e k (N k).center) + η := by
    linarith [(abs_le.mp hkcenter).1]
  have hbound : D.scalarCurvature x ≤
      C * D.scalarCurvature (e k (N k).center) + (C + 1) * η := by
    calc
      _ ≤ (N k).connection.scalarCurvature ((e k).symm x) + η := hxle
      _ ≤ C * (N k).connection.scalarCurvature (N k).center + η :=
        add_le_add (hratio k) le_rfl
      _ ≤ C * (D.scalarCurvature (e k (N k).center) + η) + η :=
        add_le_add (mul_le_mul_of_nonneg_left hcle hC.le) le_rfl
      _ = _ := by ring
  rw [hLc]
  nlinarith

end PoincareMT.TerminalNeck
