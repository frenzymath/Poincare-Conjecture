import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Curvature.ScalarCompact
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Metric.Coverage
import PoincareLib.Geometry.RicciFlow.Curvature.Theory

/-!
# Approximation by the actual generalized source slices

Scalar approximation is uniform on compact spacetime sets, and images of
fixed-time limit balls lie in slightly larger normalized source balls.
These estimates permit the diagonal earlier-basepoint choices in
Morgan--Tian Lemma 11.10, pp. 274--275.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable

variable {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
  (G : GeneralizedBlowupConvergence S J.domain)

theorem eventually_normalizedSource_scalar_error_on_compact
    (P04 : RicciFlowCurvatureTheory.{u})
    {K : Set (ℝ × G.limit.carrier.carrier)} (hK : IsCompact K)
    (hKJ : ∀ z ∈ K, z.1 ∈ J.domain) {delta : ℝ} (hdelta : 0 < delta) :
    ∀ᶠ k in atTop, ∀ z ∈ K, ∀ ht : z.1 ∈ Icc (-G.exhaustion.time k) 0,
      |(G.normalizedSourceConnection k z.1).scalarCurvature
          ((G.embedding k).forward z.1 ht z.2) -
        (G.limit.flow.connection z.1).scalarCurvature z.2| < delta := by
  classical
  by_contra h
  have hf : ∃ᶠ k in atTop, ∃ z ∈ K, ∃ ht : z.1 ∈ Icc (-G.exhaustion.time k) 0,
      delta ≤ |(G.normalizedSourceConnection k z.1).scalarCurvature
          ((G.embedding k).forward z.1 ht z.2) -
        (G.limit.flow.connection z.1).scalarCurvature z.2| := by
    simpa only [not_forall, not_lt, exists_prop] using (not_eventually.mp h)
  obtain ⟨sigma, hsigma, hbad⟩ := extraction_of_frequently_atTop hf
  choose z hz ht hbad using hbad
  obtain ⟨y, hy, tau, htau, hzy⟩ := hK.tendsto_subseq hz
  have hsource := G.tendsto_normalizedSource_scalar (fun k => hKJ _ (hz (tau k)))
    (hKJ _ hy) hzy (hsigma.tendsto_atTop.comp htau.tendsto_atTop) (fun k => ht (tau k))
  have hregular := P04.scalar_regular 3 G.limit.carrier.carrier J.domain G.limit.flow
  have hlimit := (hregular.continuousOn.mono (fun z hz => ⟨hKJ z hz, mem_univ _⟩) y hy).tendsto
  have hlimit' := hlimit.comp (tendsto_nhdsWithin_iff.mpr
    ⟨hzy, Eventually.of_forall fun k => hz (tau k)⟩)
  have herror : Tendsto (fun k =>
      |(G.normalizedSourceConnection (sigma (tau k)) (z (tau k)).1).scalarCurvature
          ((G.embedding (sigma (tau k))).forward (z (tau k)).1 (ht (tau k)) (z (tau k)).2) -
        (G.limit.flow.connection (z (tau k)).1).scalarCurvature (z (tau k)).2|)
      atTop (𝓝 0) := by
    simpa only [Function.comp_apply, sub_self, abs_zero] using (hsource.sub hlimit').abs
  obtain ⟨k, hk⟩ := (herror.eventually (Iio_mem_nhds hdelta)).exists
  exact (not_lt_of_ge (hbad (tau k))) hk

theorem eventually_normalizedSource_image_ball_subset
    {t : ℝ} (ht : t ∈ J.domain) (ht0 : t ≤ 0)
    (p : G.limit.carrier.carrier) {r C : ℝ} (hr : 0 < r) (hC : 1 < C) :
    ∀ᶠ k in atTop, ∀ htk : t ∈ Icc (-G.exhaustion.time k) 0,
      (G.embedding k).forward t htk '' (G.limit.flow.metric t).ball p r ⊆
        (G.normalizedSourceMetric k t).ball ((G.embedding k).forward t htk p) (C * r) := by
  let g := G.limit.flow.metric t
  let V := g.ball p r
  have hcompact : IsCompact (closure V) :=
    g.isCompact_closure_ball_of_metricComplete (G.limit.complete t ht) p r
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset hcompact
  filter_upwards [G.eventually_normalized_tangentNorm_bounds
    (isCompact_singleton.prod hcompact) (fun z hz => (mem_singleton_iff.mp hz.1).symm ▸ ht)
    hC, eventually_ge_atTop j] with k hk hjk htk
  let e := (G.embedding k).sliceHomeomorph (G.exhaustion.space_open k) t htk
  have hVe : V ⊆ e.source := subset_closure.trans (hj.trans (G.exhaustion.space_increasing hjk))
  have he : ∀ x ∈ e.source, ContMDiffAt (𝓡 3) (𝓡 3) ∞ e x :=
    fun x hx => ((G.embedding k).forward_smooth t htk x hx).contMDiffAt
      (e.open_source.mem_nhds hx)
  exact g.image_ball_subset_ball_of_tangentNorm_le (G.normalizedSourceMetric k t) e p
    (zero_lt_one.trans hC) hVe (fun x hx => (he x hx).of_le (by simp))
    (fun x hx v => (hk (t, x) ⟨mem_singleton t, subset_closure hx⟩ htk v).1)

end PoincareMT.GeneralizedBlowupConvergence
