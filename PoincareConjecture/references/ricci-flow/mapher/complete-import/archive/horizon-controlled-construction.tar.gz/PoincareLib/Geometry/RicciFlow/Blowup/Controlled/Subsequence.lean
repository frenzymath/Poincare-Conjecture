import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Data

/-! # Subsequence transport of controlled blow-up data -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT

def GeneralizedBlowupSequence.subsequence
    (S : GeneralizedBlowupSequence.{u}) (sigma : ℕ → ℕ) (hsigma : StrictMono sigma) :
    GeneralizedBlowupSequence.{u} where
  flow k := S.flow (sigma k)
  base k := S.base (sigma k)
  base_scalar_pos k := S.base_scalar_pos (sigma k)
  scalar_diverges := S.scalar_diverges.comp hsigma.tendsto_atTop

def M30CommonBlowupControls.subsequence
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (sigma : ℕ → ℕ) (hsigma : StrictMono sigma) :
    M30CommonBlowupControls (S.subsequence sigma hsigma) epsilon C kappa r₀ mu where
  epsilon_pos := H.epsilon_pos
  C_pos := H.C_pos
  kappa_pos := H.kappa_pos
  radius_pos := H.radius_pos
  branch k := H.branch (sigma k)
  canonical k := H.canonical (sigma k)
  analytic_constant := H.analytic_constant
  analytic_constant_pos := H.analytic_constant_pos
  scalar_gradient_bound k := H.scalar_gradient_bound (sigma k)
  scalar_time_derivative_bound k := H.scalar_time_derivative_bound (sigma k)
  balls_compact A hA := hsigma.tendsto_atTop.eventually (H.balls_compact A hA)
  noncollapsed_at_zero A hA := hsigma.tendsto_atTop.eventually (H.noncollapsed_at_zero A hA)
  mu_pos := H.mu_pos
  maximal_worldlines A hA := hsigma.tendsto_atTop.eventually (H.maximal_worldlines A hA)

def M30LongBlowupControls.subsequence
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ} {T₀ : ℝ≥0∞}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    (sigma : ℕ → ℕ) (hsigma : StrictMono sigma) :
    M30LongBlowupControls (S.subsequence sigma hsigma) epsilon C kappa r₀ mu T₀ where
  toM30CommonBlowupControls := H.toM30CommonBlowupControls.subsequence sigma hsigma
  horizon_pos := H.horizon_pos
  slabs T hT hT₀ A hA := by
    filter_upwards [hsigma.tendsto_atTop.eventually (H.slabs T hT hT₀ A hA)] with k hk
    obtain ⟨e⟩ := hk
    exact ⟨{ embedding := e.embedding
             zero_identity := e.zero_identity
             noncollapsed := e.noncollapsed }⟩

def GeneralizedBlowupConvergence.ofSubsequence
    {S : GeneralizedBlowupSequence.{u}} {J : Set ℝ}
    {sigma : ℕ → ℕ} {hsigma : StrictMono sigma}
    (G : GeneralizedBlowupConvergence (S.subsequence sigma hsigma) J) :
    GeneralizedBlowupConvergence S J where
  limit := G.limit
  subsequence := sigma ∘ G.subsequence
  subsequence_strictMono := hsigma.comp G.subsequence_strictMono
  exhaustion := G.exhaustion
  embedding := G.embedding
  base_preserving := G.base_preserving
  source_balls_in_image := G.source_balls_in_image
  pullback_metric_CInfinity := G.pullback_metric_CInfinity

end PoincareMT
