import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Retained.Generalized
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.InitialWindow

/-! # Full-horizon controlled generalized blow-up convergence -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

/-- Geometric controls on all finite subhorizons produce the exact accepted
generalized convergence on the entire prescribed horizon, including zero. -/
theorem nonempty_generalizedBlowupConvergence_of_geometricLongControls
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀) :
    Nonempty (GeneralizedBlowupConvergence S (blowupBackwardInterval T₀)) := by
  obtain ⟨tau, htmono, htau, hhorizon, hcofinal⟩ :=
    exists_strictly_increasing_horizon_windows H.horizon_pos
  obtain ⟨B, hB, idx, hidx, hcompact, e, G, hcomplete, _⟩ :=
    exists_initial_limit_with_horizon_cylinders P H tau htau hhorizon
  have hAr : Tendsto expandingRadius atTop atTop :=
    tendsto_atTop_add_const_right atTop 1 tendsto_natCast_atTop_atTop
  have heta : Tendsto (fun i => (expandingRadius i)⁻¹) atTop (𝓝 0) :=
    tendsto_inv_atTop_zero.comp hAr
  have hc := hcomplete 0 ⟨by linarith [htau 0], by linarith [htau 0]⟩
  obtain ⟨F₀, hF₀, sigma, hsigma, F, hmatch, hjets⟩ :=
    exists_full_horizon_flow_with_open_jets G P.m04 hAr hcompact hc htmono hB
  rw [blowupBackwardInterval_eq_horizonOpenTime_union_zero htau hhorizon hcofinal]
  exact ⟨horizonConvergence G F₀ hF₀ F hmatch P.m04 hAr hcompact hc htmono hB hsigma hjets heta hidx⟩

end PoincareMT.ControlledBlowupCompactness
