import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Completeness

/-! # Completeness transported in either time direction on a controlled slab -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal NNReal

namespace PoincareMT

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space

/-- Uniform curvature on a closed interval transports completeness between
any two of its times, including backwards from a complete reference slice. -/
theorem RicciFlow.metricComplete_of_reference_curvature_bound
    {n : ℕ} (C : FlowCarrier n) {J : Set ℝ} (F : RicciFlow n C.carrier J)
    (p : C.carrier) {a b s t B : ℝ} (hJ : Icc a b ⊆ J)
    (hs : s ∈ Icc a b) (ht : t ∈ Icc a b)
    (hcomplete : C.metricComplete (F.metric s))
    (hcurv : ∀ u ∈ Icc a b, ∀ x, (F.connection u).curvatureTensorNorm x ≤ B) :
    C.metricComplete (F.metric t) := by
  let d₀ := (C.metricEMetricSpace (F.metric s)).toPseudoEMetricSpace
  let d₁ := (C.metricEMetricSpace (F.metric t)).toPseudoEMetricSpace
  change @CompleteSpace C.carrier d₁.toUniformSpace
  apply Poincare.completeSpace_of_continuous_local_edist_bound d₀ d₁ p hcomplete
  · change @Continuous C.carrier C.carrier C.topologicalSpace C.topologicalSpace id
    exact continuous_id
  · exact fun x => @Poincare.edist_ne_top_of_preconnected C.carrier d₁
      (C.preconnected_metricEMetricSpace (F.metric t)) x p
  · intro R
    let r : ℝ := R + 1
    have hr : 0 < r := by dsimp only [r]; positivity
    let L : ℝ := (n : ℝ) ^ 3 * B
    let Q : ℝ := Real.exp (L * |s - t|)
    refine ⟨Real.toNNReal Q, fun x y hx hy => ?_⟩
    have hRic : ∀ u ∈ Icc a b, ∀ z ∈ (F.metric t).ball p (3 * r),
        ∀ v : C.tangent z,
          |(F.connection u).ricci z v v| ≤ L * (F.metric u).inner z v v := by
      intro u hu z _ v
      have hQ : 0 ≤ (F.metric u).inner z v v := by
        by_cases hv : v = 0
        · subst v; simp
        · exact ((F.metric u).pos z v hv).le
      have hnorm := (F.connection u).abs_ricci_quadratic_le_curvatureTensorNorm z v
      have hdim : Module.finrank ℝ (TangentSpace (𝓡 n) z) = n := finrank_euclideanSpace_fin
      simp only [Fintype.card_fin, hdim] at hnorm
      exact hnorm.trans (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (hcurv u hu z) (by positivity)) hQ)
    have hR : (R : ℝ≥0∞) < ENNReal.ofReal r := by
      rw [← ENNReal.ofReal_coe_nnreal]
      exact (ENNReal.ofReal_lt_ofReal_iff hr).mpr (by dsimp only [r]; linarith)
    have hmem (z : C.carrier) (hz : d₁.edist z p ≤ R) : z ∈ (F.metric t).ball p r := by
      change d₁.edist p z < ENNReal.ofReal r
      rw [d₁.edist_comm]
      exact hz.trans_lt hR
    exact F.edist_le_exp_mul_of_ricci_bound (convex_Icc a b) hJ p r L hr
      ht hs hRic (hmem x hx) (hmem y hy)

end PoincareMT
