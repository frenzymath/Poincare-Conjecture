import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.MetricAgreement
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.Times
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Carrier

/-! # Attaching the included terminal slice to the full backward horizon -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

theorem blowupBackwardInterval_eq_horizonOpenTime_union_zero
    {T₀ : ℝ≥0∞} {tau : ℕ → ℝ} (htau : ∀ j, 0 < tau j)
    (hhorizon : ∀ j, ENNReal.ofReal (tau j) < T₀)
    (hcofinal : ∀ I : Set ℝ, IsCompact I → I ⊆ blowupBackwardInterval T₀ →
      ∀ᶠ j in atTop, I ⊆ Ioc (-tau j) 0) :
    blowupBackwardInterval T₀ = horizonOpenTime tau ∪ {0} := by
  have hT₀ : 0 < T₀ := (ENNReal.ofReal_pos.mpr (htau 0)).trans (hhorizon 0)
  ext t
  constructor
  · intro ht
    by_cases ht0 : t = 0
    · exact Or.inr (mem_singleton_iff.mpr ht0)
    · have htneg : t < 0 := lt_of_le_of_ne ht.1 ht0
      obtain ⟨j, hj⟩ := (hcofinal {t} isCompact_singleton (singleton_subset_iff.mpr ht)).exists
      exact Or.inl (mem_iUnion.mpr ⟨j, (hj (mem_singleton t)).1, htneg⟩)
  · rintro (ht | ht)
    · obtain ⟨j, hj⟩ := mem_iUnion.mp ht
      exact ⟨hj.2.le, ((ENNReal.ofReal_lt_ofReal_iff (htau j)).mpr (by linarith [hj.1])).trans
        (hhorizon j)⟩
    · have ht0 : t = 0 := mem_singleton_iff.mp ht
      subst t
      exact ⟨le_rfl, by simpa using hT₀⟩

theorem exists_attach_horizon_terminal_flow
    {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
    [IsManifold (𝓡 3) ∞ M]
    {tau : ℕ → ℝ} (htau : 0 < tau 0)
    (F : RicciFlow 3 M (horizonOpenTime tau)) (H : RicciFlow 3 M (Ioc (-tau 0) 0))
    (hmatch : ∀ t ∈ Ioo (-tau 0) 0, F.metric t = H.metric t) :
    ∃ L : RicciFlow 3 M (horizonOpenTime tau ∪ {0}),
      (∀ t ∈ horizonOpenTime tau, L.metric t = F.metric t) ∧ L.metric 0 = H.metric 0 := by
  classical
  let J := horizonOpenTime tau ∪ {0}
  let g (t : ℝ) := if t < 0 then F.metric t else H.metric t
  have hJ : OrdConnected J := by
    constructor
    intro x hx y hy z hz
    by_cases hz0 : z = 0
    · exact Or.inr (mem_singleton_iff.mpr hz0)
    · have hxneg : x ∈ horizonOpenTime tau := by
        rcases hx with hx | hx
        · exact hx
        · have hx0 := mem_singleton_iff.mp hx
          have hy0 : y ≤ 0 := by
            rcases hy with hy | hy
            · obtain ⟨j, hj⟩ := mem_iUnion.mp hy
              exact hj.2.le
            · exact (mem_singleton_iff.mp hy).le
          exact (hz0 (by linarith [hz.1, hz.2])).elim
      obtain ⟨j, hj⟩ := mem_iUnion.mp hxneg
      have hy0 : y ≤ 0 := by
        rcases hy with hy | hy
        · obtain ⟨i, hi⟩ := mem_iUnion.mp hy
          exact hi.2.le
        · exact (mem_singleton_iff.mp hy).le
      exact Or.inl (mem_iUnion.mpr ⟨j, hj.1.trans_le hz.1, lt_of_le_of_ne (hz.2.trans hy0) hz0⟩)
  have hne : J.Nontrivial := (horizonOpenTime_nontrivial htau).mono subset_union_left
  obtain ⟨L, hL⟩ := RicciFlow.exists_of_locally_matching_flows hJ hne g (by
    intro t ht
    by_cases htneg : t < 0
    · have htopen : t ∈ horizonOpenTime tau := by
        rcases ht with ht | ht
        · exact ht
        · exact (htneg.ne (mem_singleton_iff.mp ht)).elim
      refine ⟨horizonOpenTime tau, F, htopen,
        mem_nhdsWithin_of_mem_nhds ((horizonOpenTime_isOpen tau).mem_nhds htopen), ?_⟩
      filter_upwards [mem_nhdsWithin_of_mem_nhds (Iio_mem_nhds htneg)] with s hs
      exact if_pos hs
    · have ht0 : t = 0 := by
        rcases ht with ht | ht
        · obtain ⟨j, hj⟩ := mem_iUnion.mp ht
          exact (htneg hj.2).elim
        · exact mem_singleton_iff.mp ht
      subst t
      have hnear : Ioi (-tau 0) ∈ 𝓝[J] 0 :=
        mem_nhdsWithin_of_mem_nhds (Ioi_mem_nhds (neg_lt_zero.mpr htau))
      have hnonpos : ∀ s ∈ J, s ≤ 0 := by
        intro s hs
        rcases hs with hs | hs
        · obtain ⟨j, hj⟩ := mem_iUnion.mp hs
          exact hj.2.le
        · exact (mem_singleton_iff.mp hs).le
      refine ⟨Ioc (-tau 0) 0, H, ⟨by linarith, le_rfl⟩, ?_, ?_⟩
      · filter_upwards [hnear, self_mem_nhdsWithin] with s hs hsJ
        exact ⟨hs, hnonpos s hsJ⟩
      · filter_upwards [hnear, self_mem_nhdsWithin] with s hs hsJ
        dsimp only [g]
        split_ifs with hsneg
        · exact hmatch s ⟨hs, hsneg⟩
        · rfl)
  exact ⟨L, fun t ht => by
    obtain ⟨j, hj⟩ := mem_iUnion.mp ht
    rw [hL]
    exact if_pos hj.2,
    by rw [hL]; exact if_neg (lt_irrefl 0)⟩

end PoincareMT.ControlledBlowupCompactness
