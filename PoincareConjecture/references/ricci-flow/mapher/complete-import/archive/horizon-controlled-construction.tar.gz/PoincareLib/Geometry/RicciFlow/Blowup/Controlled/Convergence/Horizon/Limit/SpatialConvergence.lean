import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.AllCharts
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.JetSlices

/-! # Spatial curvature jets of the expanding-horizon sources -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

theorem tendsto_horizon_spatial_pullbackJet
    (htmono : Monotone tau) {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau))
    (q : G.limitCarrier.carrier)
    (hjets : ∀ r K, IsCompact K → K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target →
      TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ r (horizonSpacetimeCoefficients G q (sigma k)))
        (iteratedFDeriv ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
          (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)) atTop K)
    {t : ℝ} (ht : t ∈ horizonOpenTime tau) {p : EuclideanSpace ℝ (Fin 3)}
    (hp : p ∈ (extChartAt (𝓡 3) q).target) (r : ℕ) (a b : Fin 3) :
    Tendsto (fun k => iteratedFDeriv ℝ r (fun x =>
      ((horizonSourceFlow hA htau e (G.subsequence (sigma k))).metric t).pullbackCoefficients
        (G.referenceChartMap q (sigma k) 0) x
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) p)
      atTop (𝓝 (iteratedFDeriv ℝ r (fun x =>
        (F.metric t).pullbackCoefficients (extChartAt (𝓡 3) q).symm x
          (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) p)) := by
  let E := EuclideanSpace ℝ (Fin 3)
  let f := fun k => horizonSpacetimeCoefficients G q (sigma k)
  let g := fun z : ℝ × E => (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2
  let R := ContinuousMultilinearMap.compContinuousLinearMapL
    (𝕜 := ℝ) (F := SpacetimeBounds.MetricCoefficient 3)
    (fun _ : Fin r => ContinuousLinearMap.inr ℝ ℝ E)
  let e₀ : E →L[ℝ] ℝ × E := ContinuousLinearMap.inr ℝ ℝ E
  have hm : (r : ℕ∞ω) ≤ ∞ := WithTop.coe_le_coe.mpr (le_top : (r : ℕ∞) ≤ ⊤)
  have hg : ContDiffAt ℝ ∞ g (t, p) := F.smooth.contDiffAt_spacetime_pullbackCoefficients
    (horizonOpenTime_isOpen tau)
    ((contMDiffOn_extChartAt_symm (n := ∞) q).contMDiffAt
      ((isOpen_extChartAt_target q).mem_nhds hp)) ht
  have hs := hsigma.tendsto_atTop.eventually
    (horizonSpacetimeCoefficients_locallyEventuallyContDiff G htmono q {(t, p)}
      isCompact_singleton (singleton_subset_iff.mpr ⟨ht, hp⟩))
  have hfs : ∀ᶠ k in atTop, ContDiffAt ℝ ∞ (f k) (t, p) := hs.mono (by
    rintro k ⟨W, hW, hKW, hfd⟩
    exact hfd.contDiffAt (hW.mem_nhds (hKW (mem_singleton _))))
  have hsliceeq (C : ℝ × E → SpacetimeBounds.MetricCoefficient 3)
      (hC : ContDiffAt ℝ ∞ C (t, p)) :
      iteratedFDeriv ℝ r (fun x => C (t, x)) p = R (iteratedFDeriv ℝ r C (t, p)) := by
    let shifted := fun z : ℝ × E => C ((t, 0) + z)
    have hshift : ContDiffAt ℝ ∞ shifted (e₀ p) := by
      have hC' : ContDiffAt ℝ ∞ C ((t, 0) + e₀ p) := by
        simpa only [e₀, ContinuousLinearMap.inr_apply, Prod.mk_add_mk, add_zero, zero_add] using hC
      exact hC'.comp (e₀ p) (contDiffAt_const.add contDiffAt_id)
    have heq := Poincare.Analysis.Calculus.iteratedFDeriv_comp_continuousLinearMap_of_contDiffAt e₀ hshift r
    have hadd : iteratedFDeriv ℝ r shifted (e₀ p) = iteratedFDeriv ℝ r C (t, p) := by
      simpa only [shifted, e₀, ContinuousLinearMap.inr_apply, Prod.mk_add_mk, add_zero, zero_add]
        using iteratedFDeriv_comp_add_left (𝕜 := ℝ) (f := C) r (t, (0 : E)) (e₀ p)
    rw [hadd] at heq
    simpa only [R, ContinuousMultilinearMap.compContinuousLinearMapL_apply,
      shifted, e₀, Function.comp_def, ContinuousLinearMap.inr_apply,
      Prod.mk_add_mk, add_zero, zero_add] using heq
  have hjet := (hjets r {(t, p)} isCompact_singleton (singleton_subset_iff.mpr ⟨ht, hp⟩)).tendsto_at
    (mem_singleton (t, p))
  have hb := R.continuous.continuousAt.tendsto.comp hjet
  rw [← hsliceeq g hg] at hb
  have hbil : Tendsto (fun k => iteratedFDeriv ℝ r (fun x => f k (t, x)) p) atTop
      (𝓝 (iteratedFDeriv ℝ r (fun x => g (t, x)) p)) :=
    hb.congr' (hfs.mono fun k hk => (hsliceeq (f k) hk).symm)
  let L := NormalizedKappaSolutionSequence.coefficientEval a b
  have hscalar := L.continuous_postcomp_continuousMultilinearMap |>.continuousAt.tendsto.comp hbil
  have hgs : ContDiffAt ℝ ∞ (fun x => g (t, x)) p :=
    hg.comp p (contDiffAt_const.prodMk contDiffAt_id)
  rw [← L.iteratedFDeriv_comp_left hgs hm] at hscalar
  apply hscalar.congr'
  filter_upwards [hfs] with k hk
  have hks : ContDiffAt ℝ ∞ (fun x => f k (t, x)) p :=
    hk.comp p (contDiffAt_const.prodMk contDiffAt_id)
  exact (L.iteratedFDeriv_comp_left hks hm).symm

end PoincareMT.ControlledBlowupCompactness
