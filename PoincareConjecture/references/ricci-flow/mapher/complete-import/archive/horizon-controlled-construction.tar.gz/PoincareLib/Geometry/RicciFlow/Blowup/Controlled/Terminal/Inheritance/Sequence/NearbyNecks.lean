import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.CenterCapture
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.MetricJetsEventual
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.ScalarNeckLimit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Sequence.Jets

/-!
# Nearby terminal necks from captured canonical alternatives

A finite set of compact comparison charts suffices to transfer the direct
source neck or the source cap's end neck. Completeness and the differential
lower bound capture their whole domains before the transport is applied.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Topology Bundle

universe u v

namespace PoincareMT.ControlledTerminal

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem exists_nearby_terminal_neck_of_convergent_canonical_alternatives
    {M : Type v} [TopologicalSpace M] [T3Space M]
    [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    {X : ℕ → Type u} [∀ k, TopologicalSpace (X k)] [∀ k, T3Space (X k)]
    [∀ k, ChartedSpace E (X k)] [∀ k, IsManifold (𝓡 3) ∞ (X k)]
    [∀ k, MeasurableSpace (X k)] [∀ k, BorelSpace (X k)]
    (g : RiemannianMetric 3 M) (D : LeviCivitaData g)
    (h : ∀ k, RiemannianMetric 3 (X k)) (Ds : ∀ k, LeviCivitaData (h k))
    (hcomplete : MetricComplete g) (e : ∀ k, OpenPartialHomeomorph M (X k))
    (he : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source)
    (hei : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k).symm (e k).target)
    {U : Set M} (hU : IsOpen U) (hUe : ∀ k, U ⊆ (e k).source)
    (x : M) (hx : 0 < D.scalarCurvature x)
    {delta epsilon C l u r : ℝ}
    (hdelta : 0 < delta) (hsmall : delta < 1 / 200)
    (haccuracy : delta < epsilon) (hepsilon : epsilon < 1 / 2)
    (hC : 1 ≤ C) (hl : 0 < l) (hu : 0 < u)
    (hscalar : ∀ k, l ≤ (Ds k).scalarCurvature (e k x) ∧
      (Ds k).scalarCurvature (e k x) ≤ u)
    (hneckradius : (2 * Real.pi + 2 * delta⁻¹) * l ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hcapradius : C * l ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hsource : closure (g.ball x (2 * r + 1)) ⊆ U)
    (hbound : ∀ k y, y ∈ closure (g.ball x (2 * r + 1)) →
      ∀ v : TangentSpace (𝓡 3) y,
        g.tangentNorm y v ≤ 2 * (h k).tangentNorm (e k y)
          (mfderiv (𝓡 3) (𝓡 3) (e k) y v))
    (hcanonical : ∀ k, (∃ N : EpsilonNeck (h k),
      N.epsilon = delta ∧ N.center = e k x ∧ N.connection = Ds k) ∨
      ∃ N : CapCertificate (h k), N.epsilon = delta ∧
        N.cap_constant ≤ C ∧ e k x ∈ N.core ∧ N.connection = Ds k)
    {ι : Type*} (s : Finset ι) (q : ι → M) (K : ι → Set M)
    (hK : ∀ i ∈ s, IsCompact (K i) ∧ K i ⊆ U ∩ (extChartAt (𝓡 3) (q i)).source)
    (hcover : ∀ y ∈ closure (g.ball x (2 * r)), ∃ i ∈ s, y ∈ K i)
    (hjet : ∀ i ∈ s, ∀ m, TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((h k).parametrizedCoefficients
        (e k ∘ (extChartAt (𝓡 3) (q i)).symm)))
      (iteratedFDeriv ℝ m (g.parametrizedCoefficients (extChartAt (𝓡 3) (q i)).symm))
      atTop ((extChartAt (𝓡 3) (q i)) '' K i))
    (hscalarconv : TendstoUniformlyOn (fun k y => (Ds k).scalarCurvature (e k y))
      D.scalarCurvature atTop (closure (g.ball x (2 * r)))) :
    ∃ N : EpsilonNeck g, N.epsilon = epsilon ∧ N.connection = D ∧
      D.scalarCurvature x ≤ 2 * C * D.scalarCurvature N.center ∧
      N.center ∈ closure (g.ball x (2 * C * l ^ (-1 / 2 : ℝ))) := by
  have hCpos : 0 < C := zero_lt_one.trans_le hC
  have hrpos : 0 < r := lt_of_lt_of_le (by positivity) hcapradius
  have hxA : x ∈ closure (g.ball x (2 * r)) := by
    apply subset_closure
    let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
      ⟨g.toRiemannianMetric⟩
    change g.edist x x < ENNReal.ofReal (2 * r)
    rw [RiemannianMetric.edist]
    rw [Manifold.riemannianEDist_self]
    exact ENNReal.ofReal_pos.mpr (by positivity : 0 < 2 * r)
  have hN (k : ℕ) := exists_captured_neck_with_center_control_of_neck_or_cap g (h k) (Ds k)
    hcomplete (e k) (he k) (hei k) x hC hl hu (hscalar k)
    hneckradius hcapradius (hsource.trans (hUe k)) (hbound k) (hcanonical k)
  choose N hNe hND hNl hNu hNr hNc hNi hcenter using hN
  let m := ⌊epsilon⁻¹⌋₊
  have hepsilonpos : 0 < epsilon := hdelta.trans haccuracy
  have hm : 1 ≤ m := (Nat.one_le_floor_iff _).mpr
    ((one_le_inv₀ hepsilonpos).mpr (hepsilon.le.trans (by norm_num)))
  have horder (k : ℕ) : m ≤ ⌊(N k).epsilon⁻¹⌋₊ := by
    rw [hNe k]
    exact Nat.floor_mono ((inv_le_inv₀ hepsilonpos hdelta).mpr haccuracy.le)
  have hcontrols (i : ι) (hi : i ∈ s) := reference_controls_of_comparison_metric_convergence
    g h e he hUe (q i) (hK i hi).1 (hK i hi).2 (hjet i hi) m
  have herr (d : ℝ) (hd : 0 < d) :=
    TerminalNeck.eventually_small_transported_neck_errors_of_finite_chart_cover
      h g N (fun k => (e k).symm) hei he hNc hU hUe hNi
      (fun k => by rw [hNe k]; exact hsmall) s q K hK hcover
      m hm horder (div_pos hl hCpos) (mul_pos hCpos hu)
      (fun k => by simpa only [hND k] using And.intro (hNl k) (hNu k))
      (fun i hi => (hcontrols i hi).1) (fun i hi => (hcontrols i hi).2.1)
      (fun i hi j _ => (hcontrols i hi).2.2 j) hd
  have hconvN : TendstoUniformlyOn
      (fun k y => (N k).connection.scalarCurvature ((e k).symm.symm y))
      D.scalarCurvature atTop (closure (g.ball x (2 * r))) := by
    simpa only [OpenPartialHomeomorph.symm_symm, hND] using hscalarconv
  have hresult := TerminalNeck.eventually_necks_with_scalar_control_of_captured_convergence
    h g N (fun k => (e k).symm) hei he hNc hNi D x hxA hx hdelta haccuracy
    hepsilon hNe (div_pos hl hCpos) (mul_pos hCpos hu) hCpos
    (fun k => by simpa only [hND k] using And.intro (hNl k) (hNu k))
    (fun k => by simpa only [OpenPartialHomeomorph.symm_symm, hND k] using hNr k)
    herr hconvN
  obtain ⟨k, N', hN'e, hN'D, hN'c, hN'r⟩ := hresult.exists
  refine ⟨N', hN'e, hN'D, hN'r, ?_⟩
  rw [hN'c]
  exact hcenter k

end PoincareMT.ControlledTerminal

