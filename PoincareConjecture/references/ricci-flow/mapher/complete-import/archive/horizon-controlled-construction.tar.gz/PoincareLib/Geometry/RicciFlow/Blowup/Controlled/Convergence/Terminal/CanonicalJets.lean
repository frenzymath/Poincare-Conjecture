import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Jets

/-!
# Canonical jets on the full included finite interval
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)

include hF

theorem tendstoUniformlyOn_canonical_bilinearJet_interior
    (q : G.limitCarrier.carrier) (r : ℕ)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKU : K ⊆ Ioo (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target) :
    TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r (G.spatialSpacetimeCoefficients q k)
        (Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target))
      (iteratedFDerivWithin ℝ r
        (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
          (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)
        (Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target)) atTop K := by
  let U := Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target
  let V := Ioo (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target
  have hVo : IsOpen V := isOpen_Ioo.prod (isOpen_extChartAt_target q)
  have hnhds (z) (hz : z ∈ K) : U =ᶠ[𝓝 z] univ :=
    Filter.eventuallyEq_univ.mpr (mem_of_superset (hVo.mem_nhds (hKU hz))
      (prod_mono Ioo_subset_Ioc_self Subset.rfl))
  have hconv := G.tendstoUniformlyOn_spatialSpacetimeCoefficients_jets
    ⟨by linarith, by linarith⟩ q r hK hKU
  have htarget : TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ r (G.spatialSpacetimeCoefficients q k))
      (iteratedFDerivWithin ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2) U) atTop K :=
    hconv.congr_right fun z hz => by
    rw [iteratedFDerivWithin_congr_set (hnhds z hz) r, iteratedFDerivWithin_univ]
    have heq : (fun w : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (G.limitFlow.metricAt w.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm w.2) =ᶠ[𝓝 z]
        (fun w : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric w.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm w.2) := by
      filter_upwards [hVo.mem_nhds (hKU hz)] with w hw
      rw [hF w.1 hw.1]
    exact (heq.iteratedFDeriv ℝ r).self_of_nhds
  apply htarget.congr
  exact Eventually.of_forall fun k z hz => by
    rw [iteratedFDerivWithin_congr_set (hnhds z hz) r, iteratedFDerivWithin_univ]

theorem tendstoUniformlyOn_canonical_bilinearJet_terminal_ball
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier) {x₀ : EuclideanSpace ℝ (Fin 3)} {ρ : ℝ} (hρ : 0 < ρ)
    (hchart : closedBall x₀ ρ ⊆ (extChartAt (𝓡 3) q).target) (r : ℕ)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))}
    (hKU : K ⊆ Ioc 0 (T / 2) ×ˢ ball x₀ ρ) :
    TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r (G.spatialSpacetimeCoefficients q k)
        (Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target))
      (iteratedFDerivWithin ℝ r
        (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
          (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)
        (Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target)) atTop K := by
  have hgerm (z) (hz : z ∈ K) :
      (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ) =ᶠ[𝓝 z]
        (Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target) := by
    filter_upwards [(isOpen_Ioi.prod isOpen_ball).mem_nhds
      (show z ∈ Ioi 0 ×ˢ ball x₀ ρ from ⟨(hKU hz).1.1, (hKU hz).2⟩)] with w hw
    apply propext
    constructor
    · intro hw'
      exact ⟨⟨by linarith [show 0 < w.1 from hw.1], hw'.1.2⟩,
        hchart (ball_subset_closedBall hw.2)⟩
    · intro hw'
      exact ⟨⟨le_of_lt hw.1, hw'.1.2⟩, ball_subset_closedBall hw.2⟩
  have hconv := (tendstoUniformlyOn_terminal_bilinearJet_on_closedBall G F hF P04 hB hAr
    hcompact hcomplete q hρ hchart r).mono
      (hKU.trans (prod_mono Ioc_subset_Icc_self ball_subset_closedBall))
  have htarget := hconv.congr_right fun z hz => iteratedFDerivWithin_congr_set (hgerm z hz) r
  exact htarget.congr (Eventually.of_forall fun k z hz =>
    iteratedFDerivWithin_congr_set (hgerm z hz) r)

/-- Compact sets in every original chart have uniform canonical jet
convergence on the entire finite interval, including its terminal time. -/
theorem tendstoUniformlyOn_canonical_bilinearJet
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier) (r : ℕ)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKU : K ⊆ Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target) :
    TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r (G.spatialSpacetimeCoefficients q k)
        (Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target))
      (iteratedFDerivWithin ℝ r
        (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
          (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)
        (Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target)) atTop K := by
  let U := Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target
  apply (tendstoLocallyUniformlyOn_iff_tendstoUniformlyOn_of_compact hK).mp
  apply TendstoLocallyUniformlyOn.mono (s := U) _ hKU
  apply tendstoLocallyUniformlyOn_of_forall_exists_nhds
  intro z hz
  rcases lt_or_eq_of_le hz.1.2 with hlt | heq
  · have hzn : Ioo (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target ∈ 𝓝 z :=
      (isOpen_Ioo.prod (isOpen_extChartAt_target q)).mem_nhds ⟨⟨hz.1.1, hlt⟩, hz.2⟩
    obtain ⟨ρ, hρ, hρsub⟩ := Metric.mem_nhds_iff.mp hzn
    let C := closedBall z (ρ / 2)
    have hCsub := (closedBall_subset_ball (by linarith : ρ / 2 < ρ)).trans hρsub
    exact ⟨C, mem_nhdsWithin_of_mem_nhds (closedBall_mem_nhds z (by positivity)),
      tendstoUniformlyOn_canonical_bilinearJet_interior G F hF q r
        (isCompact_closedBall _ _) hCsub⟩
  · obtain ⟨R, hR, hRsub⟩ := Metric.mem_nhds_iff.mp
      ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds hz.2)
    let ρ := R / 2
    have hρ : 0 < ρ := by dsimp [ρ]; positivity
    have hchart : closedBall z.2 ρ ⊆ (extChartAt (𝓡 3) q).target :=
      (closedBall_subset_ball (by dsimp [ρ]; linarith)).trans hRsub
    let C := Icc (T / 4) (T / 2) ×ˢ closedBall z.2 (ρ / 2)
    have hCsmall : C ⊆ Ioc 0 (T / 2) ×ˢ ball z.2 ρ :=
      prod_mono (fun t ht => ⟨by linarith [ht.1], ht.2⟩)
        (closedBall_subset_ball (by linarith))
    have hCnhds : C ∈ 𝓝[U] z := by
      have hn : Ioi (T / 4) ×ˢ ball z.2 (ρ / 2) ∈ 𝓝 z :=
        (isOpen_Ioi.prod isOpen_ball).mem_nhds ⟨by change T / 4 < z.1; linarith,
          mem_ball_self (by positivity)⟩
      apply mem_of_superset (inter_mem (mem_nhdsWithin_of_mem_nhds hn) self_mem_nhdsWithin)
      intro w hw
      exact ⟨⟨hw.1.1.le, hw.2.1.2⟩, ball_subset_closedBall hw.1.2⟩
    exact ⟨C, hCnhds, tendstoUniformlyOn_canonical_bilinearJet_terminal_ball G F hF
      P04 hB hAr hcompact hcomplete q hρ hchart r hCsmall⟩

end PoincareMT.ControlledBlowupCompactness
