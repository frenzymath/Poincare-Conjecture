import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.Selection
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.Times

/-! # Initial pointed limit retaining all later horizon controls -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

/-- M07 is applied after simultaneous horizon selection, so its exact source
subsequence retains every fixed later-time-window control eventually. -/
theorem exists_initial_limit_with_horizon_cylinders
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀)
    (tau : ℕ → ℝ) (htau : ∀ j, 0 < tau j)
    (hhorizon : ∀ j, ENNReal.ofReal (tau j) < T₀) :
    ∃ B : ℕ → ℝ, (∀ j, 0 ≤ B j) ∧ ∃ idx : ℕ → ℕ, StrictMono idx ∧
      (∀ i, IsCompact (closure (S.baseBall (idx i) (expandingRadius i)))) ∧
      ∃ e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i)
        (expandingRadius i) (tau j) (B j) ((expandingRadius i)⁻¹),
      ∃ G : PointedGeometricConvergence
        (interiorSequence S idx expandingRadius (fun i => (expandingRadius i)⁻¹)
          (tau 0) (B 0) expandingRadius_pos (htau 0) (fun i => e i 0 (Nat.zero_le i))),
        (∀ t ∈ Ioo (-tau 0 / 2) (tau 0 / 2),
          G.limitCarrier.metricComplete (G.limitFlow.metricAt t)) ∧
        ∀ t ∈ Ioo (-tau 0 / 2) (tau 0 / 2), ∀ x : G.limitCarrier.carrier,
          (G.limitFlow.flow.connection t).curvatureTensorNorm x ≤ B 0 := by
  classical
  obtain ⟨B, hB, idx, hidx, hcompact, hvol, hex⟩ :=
    exists_simultaneous_horizon_cylinders H tau htau hhorizon
  let e := fun i j hji => Classical.choice (hex i j hji)
  obtain ⟨rho, v, hrho, hv, hvolume⟩ := hvol
  have hAr : Tendsto expandingRadius atTop atTop :=
    tendsto_atTop_add_const_right atTop 1 tendsto_natCast_atTop_atTop
  obtain ⟨K, hK⟩ := exists_pointedCompactnessHypotheses S idx expandingRadius
    (fun i => (expandingRadius i)⁻¹) expandingRadius_pos (htau 0) (hB 0)
    (fun i => e i 0 (Nat.zero_le i)) hAr hcompact hrho hv (Eventually.of_forall hvolume)
  obtain ⟨L⟩ := P.m07 K
  have hlimit : ∃ G : PointedGeometricConvergence K.sequence,
      ∀ t ∈ Ioo (-tau 0 / 2) (tau 0 / 2),
        G.limitCarrier.metricComplete (G.limitFlow.metricAt t) :=
    ⟨L.geometric_limit, L.complete_interior⟩
  rw [hK] at hlimit
  obtain ⟨G, hcomplete⟩ := hlimit
  refine ⟨B, hB, idx, hidx, hcompact, e, G, hcomplete, ?_⟩
  apply G.curvatureTensorNorm_le_of_uniform_ball_bound
    ⟨by linarith [htau 0], by linarith [htau 0]⟩
  intro r _
  refine Eventually.of_forall (fun i t ht x _ => ?_)
  exact (le_abs_self _).trans ((e i 0 (Nat.zero_le i)).smallFlow_curvature_bound
    (expandingRadius_pos i) (htau 0) (t + (-tau 0 / 2))
      ⟨by linarith [ht.1], by linarith [ht.2]⟩ x)

end PoincareMT.ControlledBlowupCompactness
