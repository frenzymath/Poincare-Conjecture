import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Data
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.BoundsTheory

/-!
# Terminal scalar bounds and backward lifetimes

The opening of Morgan--Tian's proof of Theorem 11.1, pp. 269--270,
uses bounded-distance estimates to obtain a positive backward lifetime on
each fixed terminal ball. These estimates retain the maximal worldlines in
the primitive hypotheses. Their spatial gluing is a further step.
-/

set_option autoImplicit false

open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT

namespace M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem boundedDistance_of_threshold
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    {epsilon₀ : ℝ}
    (distance : ∀ epsilon : ℝ, 0 < epsilon → epsilon ≤ epsilon₀ →
      ∀ C : ℝ, 0 < C → ∀ S : GeneralizedBlowupSequence.{u},
        DenseGeneralizedBoundedDistanceHypotheses S epsilon C →
          GeneralizedBlowupBoundedDistance S)
    (hepsilon : epsilon ≤ epsilon₀) : GeneralizedBlowupBoundedDistance S :=
  distance epsilon H.epsilon_pos hepsilon C H.C_pos S ⟨H.branch, H.canonical⟩

/-- The M29 threshold is selected before all sequence-dependent parameters.
The factor two leaves the same threshold available at doubled accuracy. -/
theorem exists_universal_boundedDistance_threshold
    (P : DenseGeneralizedBoundedDistanceTheory.{u}) :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 400 ∧
      ∀ (S : GeneralizedBlowupSequence.{u}) (epsilon C kappa r₀ mu : ℝ),
        epsilon ≤ 2 * epsilon₀ →
        M30CommonBlowupControls S epsilon C kappa r₀ mu →
        GeneralizedBlowupBoundedDistance S := by
  obtain ⟨delta, hdelta, _, hbound⟩ := P.constants
  refine ⟨min (delta / 2) (1 / 400), lt_min (by positivity) (by norm_num),
    min_le_right _ _, ?_⟩
  intro S epsilon C kappa r₀ mu hepsilon H
  apply H.boundedDistance_of_threshold hbound
  have hmin := min_le_left (delta / 2) (1 / 400 : ℝ)
  linarith

end M30CommonBlowupControls

theorem m30BackwardDuration_pos
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
    (x : ((S.flow k).slice (S.base k).1).carrier)
    {mu : ℝ} (hmu : 0 < mu) : 0 < m30BackwardDuration S k x mu := by
  have hscale : 0 < S.scale k := S.base_scalar_pos k
  exact div_pos (mul_pos hmu hscale) (lt_of_lt_of_le hscale (le_max_left _ _))

/-- A terminal scalar bound controls the denominator in the prescribed
maximal-worldline lifetime without requiring positive scalar at every point. -/
theorem le_m30BackwardDuration_of_scalar_le
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
    (x : ((S.flow k).slice (S.base k).1).carrier)
    {D mu : ℝ} (hD : 1 ≤ D) (hmu : 0 ≤ mu)
    (hscalar : (S.flow k).scalar ⟨(S.base k).1, x⟩ ≤ D * S.scale k) :
    mu / D ≤ m30BackwardDuration S k x mu := by
  have hscale : 0 < S.scale k := S.base_scalar_pos k
  have hDpos : 0 < D := lt_of_lt_of_le zero_lt_one hD
  have hmax : max (S.scale k) ((S.flow k).scalar ⟨(S.base k).1, x⟩) ≤
      D * S.scale k := max_le (by nlinarith) hscalar
  have hmaxpos : 0 < max (S.scale k) ((S.flow k).scalar ⟨(S.base k).1, x⟩) :=
    lt_of_lt_of_le hscale (le_max_left _ _)
  unfold m30BackwardDuration
  apply (le_div_iff₀ hmaxpos).2
  calc
    mu / D * max (S.scale k) ((S.flow k).scalar ⟨(S.base k).1, x⟩) ≤
        mu / D * (D * S.scale k) := mul_le_mul_of_nonneg_left hmax (by positivity)
    _ = mu * S.scale k := by field_simp

namespace M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

/-- On a fixed normalized ball the given maximal worldlines all contain
one common positive closed backward interval, eventually in the sequence. -/
theorem eventually_uniform_worldline_duration
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (hbound : GeneralizedBlowupBoundedDistance S) (A : ℝ) (hA : 0 < A) :
    ∃ T : ℝ, 0 < T ∧ ∀ᶠ k : ℕ in Filter.atTop,
      ∀ x ∈ S.baseBall k A, ∃ W : GeneralizedMaximalBackwardFlowLine
        (S.flow k) ⟨(S.base k).1, x⟩ (S.scale k) (m30BackwardDuration S k x mu),
        Set.Icc (-T) 0 ⊆ W.maximal_interval := by
  obtain ⟨D, hD, hscalar⟩ := hbound A hA
  refine ⟨mu / max 1 D, div_pos H.mu_pos (lt_of_lt_of_le zero_lt_one
    (le_max_left _ _)), ?_⟩
  filter_upwards [hscalar, H.maximal_worldlines A hA] with k hk hW
  intro x hx
  obtain ⟨W⟩ := hW x hx
  refine ⟨W, Set.Subset.trans ?_ W.requested_interval_subset⟩
  apply Set.Icc_subset_Icc_left
  apply neg_le_neg
  apply le_m30BackwardDuration_of_scalar_le S k x (le_max_left _ _) H.mu_pos.le
  exact (hk x hx).trans (mul_le_mul_of_nonneg_right (le_max_right _ _)
    (S.base_scalar_pos k).le)

end M30CommonBlowupControls

end PoincareMT
