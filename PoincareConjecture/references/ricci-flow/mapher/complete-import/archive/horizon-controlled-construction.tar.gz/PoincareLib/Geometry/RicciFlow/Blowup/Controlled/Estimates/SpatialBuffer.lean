import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.BallCompactness
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Cylinders

/-!
# Compact spatial buffers around terminal core points

The terminal spatial margin confines small intrinsic balls centered anywhere
in the smaller terminal ball. This supplies the local compactness premise of
Shi estimates uniformly over that ball, including at the terminal time.
Reference: Morgan--Tian Corollary 11.4, pp. 269-270.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

theorem ordinaryFlow_isCompact_closure_ball_at
    (e : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    (hcompact : IsCompact (closure (S.baseBall k A)))
    {R : ℝ} (hR : 0 < R) (hRA : R < A)
    (x : sourceBall S k A) (hx : x.val ∈ S.baseBall k R)
    {s : ℝ} (hs : s ∈ Icc (-T) 0) {r : ℝ}
    (hbuffer : Real.exp (3 * B * |s|) * r ≤ (A - R) / 2) :
    IsCompact (closure (((e.ordinaryFlow hT).metric s).ball x r)) := by
  let g := rescaledMetric ((S.flow k).metric (S.base k).1) (S.scale k)
    (S.base_scalar_pos k)
  let R' := (A + R) / 2
  have hR' : 0 < R' := by dsimp [R']; linarith
  have hR'A : R' < A := by dsimp [R']; linarith
  have hsub : closure (S.baseBall k R') ⊆ S.baseBall k A :=
    S.closure_baseBall_subset k hR' hR'A
  have hc : IsCompact (closure (S.baseBall k R')) :=
    hcompact.of_isClosed_subset isClosed_closure (hsub.trans subset_closure)
  have hpre : IsCompact ((Subtype.val : sourceBall S k A → _) ⁻¹'
      closure (S.baseBall k R')) :=
    Topology.IsEmbedding.subtypeVal.isInducing.isCompact_preimage' hc
      (by intro z hz; exact ⟨⟨z, hsub hz⟩, rfl⟩)
  apply hpre.of_isClosed_subset isClosed_closure
  apply closure_minimal _ (isClosed_closure.preimage continuous_subtype_val)
  intro y hy
  apply subset_closure
  rw [← normalized_terminal_ball]
  have hdist : g.edist x.val y.val ≤ ENNReal.ofReal (Real.exp (3 * B * |s|)) *
      ((e.ordinaryFlow hT).metric s).edist x y := by
    apply RiemannianMetric.edist_le_mul_of_tangentNorm_mfderiv_le _ _
      contMDiff_subtype_val (Real.exp_pos _) _ x y
    intro z v
    have hn := congrArg Real.sqrt (e.ordinaryFlow_terminal_inner hT z v v)
    change ((e.ordinaryFlow hT).metric 0).tangentNorm z v =
      g.tangentNorm z.val (mfderiv (𝓡 3) (𝓡 3) Subtype.val z v) at hn
    rw [← hn]
    simpa only [zero_sub, abs_neg] using
      e.ordinaryFlow_tangentNorm_le hT z v hs
        (show (0 : ℝ) ∈ Icc (-T) 0 from ⟨by linarith, le_rfl⟩)
  have hxy : g.edist x.val y.val < ENNReal.ofReal ((A - R) / 2) := by
    apply (hdist.trans_lt
      (ENNReal.mul_lt_mul_right (ENNReal.ofReal_pos.mpr (Real.exp_pos _)).ne'
        ENNReal.ofReal_ne_top hy)).trans_le
    rw [← ENNReal.ofReal_mul (Real.exp_nonneg _)]
    exact ENNReal.ofReal_le_ofReal hbuffer
  have hxg : g.edist (S.base k).2 x.val < ENNReal.ofReal R := by
    change x.val ∈ g.ball (S.base k).2 R
    rw [normalized_terminal_ball]
    exact hx
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) :
      ((S.flow k).slice (S.base k).1).carrier → Type _) := ⟨g.toRiemannianMetric⟩
  change g.edist (S.base k).2 y.val < ENNReal.ofReal R'
  calc
    g.edist (S.base k).2 y.val ≤ g.edist (S.base k).2 x.val + g.edist x.val y.val :=
      Manifold.riemannianEDist_triangle
    _ < ENNReal.ofReal R + ENNReal.ofReal ((A - R) / 2) := ENNReal.add_lt_add hxg hxy
    _ = ENNReal.ofReal R' := by
      rw [← ENNReal.ofReal_add hR.le (by linarith : 0 ≤ (A - R) / 2)]
      congr 1
      dsimp [R']
      ring

end PoincareMT.ControlledBlowupCylinder
