import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.SpatialBuffer
import PoincareLib.Geometry.RicciFlow.TimeTranslation

/-!
# Terminal curvature derivative bounds on controlled cylinders

M04's local Shi estimate applies on short translated intervals ending at each
time in the final half-cylinder. The spatial buffer supplies compact balls
uniformly at every center in a smaller terminal ball.
Reference: Morgan--Tian Corollary 11.4, pp. 269-270.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

/-- Every derivative order is bounded uniformly on a smaller terminal ball,
through the final time, with its bound chosen before the sequence index. -/
theorem exists_uniform_curvatureDerivative_bound_on_subwindow
    (P04 : RicciFlowCurvatureTheory.{u}) {A R T V B : ℝ}
    (hR : 0 < R) (hRA : R < A) (hT : 0 < T) (hVT : V < T)
    (hB : 0 ≤ B) (m : ℕ) :
    ∃ D : ℝ, 0 < D ∧ ∀ (S : GeneralizedBlowupSequence.{u}) (k : ℕ) (eta : ℝ)
      (e : ControlledBlowupCylinder S k A T B eta),
      IsCompact (closure (S.baseBall k A)) →
      ∀ s ∈ Icc (-V) 0, ∀ x : sourceBall S k A, x.val ∈ S.baseBall k R →
        ((e.ordinaryFlow hT).connection s).curvatureDerivativeNorm m x ≤ D := by
  let delta := T - max V 0
  let K := B + 1
  let r := (A - R) / (2 * Real.exp (3 * B * T))
  have hmax : max V 0 < T := max_lt hVT hT
  have hdelta : 0 < delta := sub_pos.mpr hmax
  have hK : 0 < K := by dsimp [K]; positivity
  have hr : 0 < r := div_pos (sub_pos.mpr hRA) (by positivity)
  obtain ⟨D, hD, hShi⟩ := P04.local_derivative_estimates 3 m K (K * delta) r
    hK (mul_pos hK hdelta) hr
  refine ⟨D / delta ^ ((m : ℝ) / 2), by positivity, ?_⟩
  intro S k eta e hcompact s hs x hx
  have hstart : s - delta ∈ Icc (-T) 0 := by
    dsimp [delta]
    constructor <;> linarith [hs.1, hs.2, le_max_left V 0]
  have hshift : (fun t : ℝ => t + (s - delta)) '' Icc 0 delta ⊆ Icc (-T) 0 := by
    rintro _ ⟨t, ht, rfl⟩
    constructor <;> dsimp [delta] at * <;>
      linarith [ht.1, ht.2, hs.1, hs.2, le_max_left V 0]
  have hne : (Icc (0 : ℝ) delta).Nontrivial :=
    ⟨0, ⟨le_rfl, hdelta.le⟩, delta, ⟨hdelta.le, le_rfl⟩, hdelta.ne⟩
  let F := (e.ordinaryFlow hT).translate (s - delta) hshift ordConnected_Icc hne
  have hbuffer : Real.exp (3 * B * |s - delta|) * r ≤ (A - R) / 2 := by
    have habs : |s - delta| ≤ T := by
      rw [abs_of_nonpos hstart.2]
      linarith [hstart.1]
    calc
      Real.exp (3 * B * |s - delta|) * r ≤ Real.exp (3 * B * T) * r := by
        gcongr
      _ = (A - R) / 2 := by dsimp [r]; field_simp
  have hc : IsCompact (closure ((F.metric 0).ball x r)) := by
    change IsCompact (closure (((e.ordinaryFlow hT).metric (0 + (s - delta))).ball x r))
    rw [zero_add]
    exact e.ordinaryFlow_isCompact_closure_ball_at hT hcompact hR hRA x hx hstart hbuffer
  have hcurv : ∀ t ∈ Icc 0 delta, ∀ y ∈ (F.metric 0).ball x r,
      (F.connection t).curvatureTensorNorm y ≤ K := by
    intro t ht y _
    exact ((le_abs_self _).trans
      (e.ordinaryFlow_curvature_bound hT _ (hshift ⟨t, ht, rfl⟩) y)).trans
      (by dsimp [K]; linarith)
  have htime : delta ≤ K * delta / K := by rw [mul_div_cancel_left₀ _ hK.ne']
  have hxball : x ∈ (F.metric 0).ball x (r / 2) := by
    simp only [RiemannianMetric.ball, mem_ofPred_eq, RiemannianMetric.edist,
      Manifold.riemannianEDist_self]
    exact ENNReal.ofReal_pos.mpr (half_pos hr)
  have h := hShi (sourceBall S k A) delta hdelta htime F x hc hcurv
    delta ⟨hdelta, le_rfl⟩ x hxball
  change ((e.ordinaryFlow hT).connection (delta + (s - delta))).curvatureDerivativeNorm m x ≤ _ at h
  rwa [show delta + (s - delta) = s by ring] at h

/-- The final-half form used by the initial controlled compactness producers. -/
theorem exists_uniform_curvatureDerivative_bound
    (P04 : RicciFlowCurvatureTheory.{u}) {A R T B : ℝ}
    (hR : 0 < R) (hRA : R < A) (hT : 0 < T) (hB : 0 ≤ B) (m : ℕ) :
    ∃ D : ℝ, 0 < D ∧ ∀ (S : GeneralizedBlowupSequence.{u}) (k : ℕ) (eta : ℝ)
      (e : ControlledBlowupCylinder S k A T B eta),
      IsCompact (closure (S.baseBall k A)) →
      ∀ s ∈ Icc (-T / 2) 0, ∀ x : sourceBall S k A, x.val ∈ S.baseBall k R →
        ((e.ordinaryFlow hT).connection s).curvatureDerivativeNorm m x ≤ D := by
  simpa only [neg_div] using exists_uniform_curvatureDerivative_bound_on_subwindow P04
    hR hRA hT (V := T / 2) (by linarith) hB m

end PoincareMT.ControlledBlowupCylinder
