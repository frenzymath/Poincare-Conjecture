import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Restriction.Convergence
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.FiniteWindow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.ShortGeometry
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Theory

/-! # The short controlled conclusion from a uniform terminal scalar bound -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT

theorem ControlledBlowupCompactness.nonempty_closed_finite_generalizedBlowupConvergence
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀) {T T' : ℝ}
    (hT : 0 < T) (horizon : ENNReal.ofReal T < T₀)
    (hT' : 0 < T') (h : T' < T) :
    Nonempty (GeneralizedBlowupConvergence S (Icc (-T') 0)) := by
  obtain ⟨G⟩ := nonempty_finite_generalizedBlowupConvergence P H hT horizon
  exact ⟨ControlledBlowupRestriction.closedWindow G hT' h⟩

theorem M30CommonBlowupControls.nonempty_short_conclusion_of_uniform_scalar_bound
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu) {D : ℝ}
    (hscalar : ∀ A : ℝ, 0 < A → ∀ᶠ k in atTop, ∀ x ∈ S.baseBall k A,
      (S.flow k).scalar ⟨(S.base k).1, x⟩ ≤ D * S.scale k) :
    Nonempty (RepairedShortControlledBlowupConclusion S) := by
  obtain ⟨T, hT, ⟨HG⟩⟩ := H.exists_geometric_short_controls_of_uniform_scalar_bound P.m04 hscalar
  have hhalf : 0 < T / 2 := by positivity
  have hhorizon : ENNReal.ofReal (T / 2) < ENNReal.ofReal T :=
    (ENNReal.ofReal_lt_ofReal_iff hT).mpr (by linarith)
  exact ⟨{
    backward_time := T / 4
    backward_time_pos := by positivity
    convergence := ControlledBlowupCompactness.nonempty_closed_finite_generalizedBlowupConvergence
      P HG hhalf hhorizon (by positivity : 0 < T / 4) (by linarith) }⟩

end PoincareMT
