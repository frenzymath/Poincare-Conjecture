import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Limit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.FiniteCylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.LiftedLimit

/-! # The actual finite terminal limit and its retained exhaustion -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

theorem finiteTimeRadius_interval_strict_cofinal {T : ℝ} (hT : 0 < T)
    {I : Set ℝ} (hI : IsCompact I) (hIT : I ⊆ Ioc (-T) 0) :
    ∀ᶠ k in atTop, I ⊆ Ioc (-finiteTimeRadius T k) 0 := by
  let f := fun t : ℝ => (t - T) / 2
  have hf : Continuous f := (continuous_id.sub continuous_const).div_const 2
  have hsub : f '' I ⊆ Ioc (-T) 0 := by
    rintro _ ⟨t, ht, rfl⟩
    exact ⟨by dsimp [f]; linarith [(hIT ht).1], by dsimp [f]; linarith [(hIT ht).2]⟩
  filter_upwards [finiteTimeRadius_interval_cofinal hT (hI.image hf) hsub] with k hk t ht
  exact ⟨(hk (mem_image_of_mem f ht)).1.trans_lt (by dsimp [f]; linarith [(hIT ht).1]),
    (hIT ht).2⟩

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)
  (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
  (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : ∀ t ∈ Ioo (-T / 2) (T / 2),
    G.limitCarrier.metricComplete (G.limitFlow.metricAt t))
  (hbound : ∀ t ∈ Ioo (-T / 2) (T / 2), ∀ x,
    (G.limitFlow.flow.connection t).curvatureTensorNorm x ≤ B)
  (heta : Tendsto eta atTop (𝓝 0))

def terminalExhaustion : BlowupExhaustion
    (liftedLimit.{u} (terminalLimit G F hF P04 hB hAr hcompact hcomplete hbound heta)) where
  space := retainedSpace G
  space_open := retainedSpace_open G
  space_connected := retainedSpace_connected G
  space_compactClosure := retainedSpace_compactClosure G
  space_increasing := retainedSpace_monotone G
  space_covers := retainedSpace_covers G
  base_mem := base_mem_retainedSpace G
  time := finiteTimeRadius T
  time_pos := finiteTimeRadius_pos hT
  time_increasing := finiteTimeRadius_monotone hT.le
  time_subset := finiteTimeRadius_interval_subset hT
  time_cofinal := fun _ hI hIJ => finiteTimeRadius_interval_cofinal hT hI hIJ

end PoincareMT.ControlledBlowupCompactness
