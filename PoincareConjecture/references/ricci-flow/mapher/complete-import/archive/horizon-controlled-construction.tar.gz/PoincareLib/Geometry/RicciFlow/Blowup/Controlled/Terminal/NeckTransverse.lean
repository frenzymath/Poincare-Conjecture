import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Curvature.Quadratic
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Geometry.Model

/-!
# Ricci-null directions are transverse to the spheres of a small neck

The universal quadratic Ricci estimate controls the horizontal component of
every null vector. Consequently a nonzero null direction cannot be tangent
to a spherical cross-section of the actual neck.

Reference: Morgan--Tian, Claim 11.7, p. 271, and Lemma A.2, pp. 497--498.
-/

set_option autoImplicit false

open Set
open scoped Manifold ContDiff Bundle

universe u

namespace PoincareMT.EpsilonNeck

theorem exists_null_transverse_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 200 ∧
      ∀ {M : Type u} [TopologicalSpace M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
        [IsManifold (𝓡 3) ∞ M] [MeasurableSpace M] [BorelSpace M]
        [T2Space M] [T3Space M] {g : RiemannianMetric 3 M},
      ∀ (N : EpsilonNeck g) (D : LeviCivitaData g), N.epsilon ≤ epsilon₀ →
      ∀ z ∈ N.cylinderDomain, ∀ v : RoundCylinderTangent z,
        D.ricci (N.coordinate_map z)
          (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) N.coordinate_map z v)
          (mfderiv ((𝓡 2).prod 𝓘(ℝ, ℝ)) (𝓡 3) N.coordinate_map z v) = 0 →
        (49 / 50 : ℝ) * EvolvingRoundCylinderMetric 0 z v v ≤ v.2 ^ 2 ∧
          (v ≠ 0 → v.2 ≠ 0) := by
  obtain ⟨epsilon₀, hpos, hsmall, hcontrol⟩ := exists_ricci_quadratic_control.{u}
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro M _ _ _ _ _ _ _ g N D hN z hz v hnull
  have h := hcontrol N D hN z hz v
  rw [hnull, zero_sub, abs_neg] at h
  have hbound : (49 / 50 : ℝ) * EvolvingRoundCylinderMetric 0 z v v ≤ v.2 ^ 2 := by
    have hh := (le_abs_self _).trans h
    linarith
  refine ⟨hbound, ?_⟩
  intro hv hvzero
  have hpositive : 0 < EvolvingRoundCylinderMetric 0 z v v := by
    rw [← roundCylinderProductMetric_inner]
    exact roundCylinderProductMetric.pos z v hv
  rw [hvzero, zero_pow (by norm_num : 2 ≠ 0)] at hbound
  linarith

end PoincareMT.EpsilonNeck
