import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Metric

/-!
# Retained embeddings on arbitrary controlled time windows

The spatial maps selected by the initial compactness extraction can be
composed with any later controlled cylinder on the same source ball. This
preserves the original basepoint and the exact ordinary pullback metric.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

open ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (k : ℕ) {V B' eta' : ℝ}
  (d : ControlledBlowupCylinder S (idx (G.subsequence k)) (A (G.subsequence k)) V B' eta')

noncomputable def windowRetainedCylinder :
    GeneralizedFlowCylinder (S.flow (idx (G.subsequence k)))
      (liftedSliceCarrier.{u} G.limitCarrier)
      (S.base (idx (G.subsequence k))).1 (S.scale (idx (G.subsequence k)))
      (Icc (-V) 0) (ULift.down ⁻¹' G.exhaustion k) := by
  let f := retainedSourceCoordinate G k
  let c := d.embedding.rebasePartialSource f.toOpenPartialHomeomorph
    (retainedSourceCoordinate_target_subset G k) f.contMDiffOn_toFun f.contMDiffOn_invFun
  exact c.restrict Subset.rfl (by
    change ULift.down ⁻¹' G.exhaustion k ⊆ (retainedSourceCoordinate G k).source
    rw [retainedSourceCoordinate_source])

theorem windowRetainedCylinder_pointMap (s : ℝ) (hs : s ∈ Icc (-V) 0)
    (x : (liftedSliceCarrier.{u} G.limitCarrier).carrier) :
    (windowRetainedCylinder G k d).pointMap s hs x =
      d.embedding.pointMap s hs
        (smallSourceCoordinate S (idx (G.subsequence k)) (hA (G.subsequence k))
          ((G.embedding k).toFun (0, x.down)).2) := rfl

theorem windowRetainedCylinder_base (hzero : (0 : ℝ) ∈ Icc (-V) 0) :
    (windowRetainedCylinder G k d).pointMap 0 hzero (ULift.up G.limitFlow.base) =
      S.base (idx (G.subsequence k)) := by
  rw [windowRetainedCylinder_pointMap]
  have hbase := congrArg Prod.snd (G.base_preserving k)
  change ((G.embedding k).toFun (0, G.limitFlow.base)).2 =
    smallBase S (idx (G.subsequence k)) (hA (G.subsequence k)) at hbase
  rw [hbase, smallSourceCoordinate_apply]
  simp only [smallBase, Equiv.symm_apply_apply]
  exact d.zero_identity hzero _ (base_mem_sourceBall (hA _))

theorem windowRetainedCylinder_pullbackInner (hV : 0 < V)
    (s : ℝ) (hs : s ∈ Icc (-V) 0)
    (x : (liftedSliceCarrier.{u} G.limitCarrier).carrier) (hx : x.down ∈ G.exhaustion k)
    (v w : TangentSpace (𝓡 3) x) :
    (windowRetainedCylinder G k d).pullbackInner s hs x v w =
      ((d.smallFlow (hA (G.subsequence k)) hV).metric s).inner
        (retainedSmallMap G k x)
        (mfderiv (𝓡 3) (𝓡 3) (retainedSmallMap G k) x v)
        (mfderiv (𝓡 3) (𝓡 3) (retainedSmallMap G k) x w) := by
  let f := retainedSourceCoordinate G k
  have hfx : x ∈ f.source := by
    change x ∈ (retainedSourceCoordinate G k).source
    rwa [retainedSourceCoordinate_source]
  have h := d.embedding.rebasePartialSource_pullbackInner
    f.toOpenPartialHomeomorph (retainedSourceCoordinate_target_subset G k)
    f.contMDiffOn_toFun f.contMDiffOn_invFun (sourceBall S _ _).isOpen s hs x hfx v w
  change (windowRetainedCylinder G k d).pullbackInner s hs x v w = _ at h
  rw [h, smallFlow_inner_eq_source_pullback _ _ _ s hs]
  have hsmall := (retainedSmallMap_contMDiffAt G k hx).mdifferentiableAt (by simp)
  have hsource : MDifferentiableAt (𝓡 3) (𝓡 3)
      (smallSourceCoordinate S (idx (G.subsequence k)) (hA (G.subsequence k)))
      (retainedSmallMap G k x) :=
    (smallSourceCoordinate S (idx (G.subsequence k)) (hA (G.subsequence k))).mdifferentiableAt
      (by simp) (by rw [smallSourceCoordinate_source]; trivial)
  have hder := mfderiv_comp x hsource hsmall
  change mfderiv (𝓡 3) (𝓡 3) f.toOpenPartialHomeomorph x = _ at hder
  rw [hder]
  rfl

end PoincareMT.ControlledBlowupCompactness
