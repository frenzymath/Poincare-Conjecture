import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.CanonicalJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.CoordinateSmoothness

/-! # Scalar canonical metric jets through the terminal time -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)

include hF

theorem tendstoUniformlyOn_canonical_scalarJet
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier) (r : ℕ) (a b : Fin 3)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKU : K ⊆ Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target) :
    TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r
        (fun z => G.spatialSpacetimeCoefficients q k z
          (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))
        (Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target))
      (iteratedFDerivWithin ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2
          (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))
        (Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target)) atTop K := by
  let U := Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target
  let f := G.spatialSpacetimeCoefficients q
  let g := fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
    (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2
  let L := NormalizedKappaSolutionSequence.coefficientEval a b
  let P := ContinuousLinearMap.compContinuousMultilinearMapL ℝ
    (fun _ : Fin r => ℝ × EuclideanSpace ℝ (Fin 3))
    (SpacetimeBounds.MetricCoefficient 3) ℝ L
  have hconv := tendstoUniformlyOn_canonical_bilinearJet G F hF P04 hB hAr hcompact
    hcomplete q r hK hKU
  have hscalar := P.uniformContinuous.comp_tendstoUniformlyOn hconv
  have hu : UniqueDiffOn ℝ U := (uniqueDiffOn_Ioc _ _).prod
    (isOpen_extChartAt_target q).uniqueDiffOn
  have hg : ContDiffOn ℝ ∞ g U := F.contDiffOn_pullbackCoefficients_within
    (isOpen_extChartAt_target q) (contMDiffOn_extChartAt_symm (n := ∞) q)
  have hr : (r : ℕ∞ω) ≤ ∞ := WithTop.coe_le_coe.mpr (le_top : (r : ℕ∞) ≤ ⊤)
  have htarget : TendstoUniformlyOn
      (fun k => P ∘ iteratedFDerivWithin ℝ r (f k) U)
      (iteratedFDerivWithin ℝ r (L ∘ g) U) atTop K :=
    hscalar.congr_right fun z hz => by
      rw [L.iteratedFDerivWithin_comp_left (hg z (hKU hz)) hu (hKU hz) hr]
      rfl
  apply htarget.congr
  filter_upwards [eventually_source_contDiffWithinAt_full_domain G q hK hKU] with k hk z hz
  exact (L.iteratedFDerivWithin_comp_left (hk z hz) hu (hKU hz) hr).symm

end PoincareMT.ControlledBlowupCompactness
