import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Curvature.Realization

/-!
# Curvature limits at moving terminal coordinate points

The second bilinear metric jets control the actual scalar curvature and
curvature norm. Vanishing negative curvature gives nonnegative limit
curvature operator. No curvature-convergence premise is added.
Source: Morgan--Tian, Section 5.1, pp. 85--89.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledTerminal

theorem iteratedFDeriv_eq_of_shifted_germ
    {Y : Type*} [NormedAddCommGroup Y] [NormedSpace ℝ Y]
    (F G : EuclideanSpace ℝ (Fin 3) → Y) (x : EuclideanSpace ℝ (Fin 3))
    (h : F =ᶠ[𝓝 0] fun y => G (y + x)) (r : ℕ) :
    iteratedFDeriv ℝ r F 0 = iteratedFDeriv ℝ r G x := by
  have heq := (h.iteratedFDeriv ℝ r).self_of_nhds
  change iteratedFDeriv ℝ r F 0 =
    iteratedFDeriv ℝ r (G ∘ (fun y => y + x)) 0 at heq
  simpa only [zero_add] using
    heq.trans (iteratedFDeriv_comp_add_right (𝕜 := ℝ) (f := G) r x 0)

theorem curvature_of_moving_pullback_jets
    {α : Type*} {l : Filter α} [l.NeBot]
    {M : α → Type*} [∀ k, TopologicalSpace (M k)]
    [∀ k, ChartedSpace (EuclideanSpace ℝ (Fin 3)) (M k)]
    [∀ k, IsManifold (𝓡 3) ∞ (M k)]
    {g : ∀ k, RiemannianMetric 3 (M k)} (D : ∀ k, LeviCivitaData (g k))
    (phi : ∀ k, EuclideanSpace ℝ (Fin 3) → M k)
    {h : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3))} (Dh : LeviCivitaData h)
    (x : α → EuclideanSpace ℝ (Fin 3)) (y : EuclideanSpace ℝ (Fin 3))
    (hphi : ∀ᶠ k in l, ∀ᶠ z in 𝓝 (x k), ContMDiffAt (𝓡 3) (𝓡 3) ∞ (phi k) z ∧
      Function.Injective (mfderiv (𝓡 3) (𝓡 3) (phi k) z))
    (hjets : ∀ r : ℕ, r ≤ 2 →
      Tendsto (fun k => iteratedFDeriv ℝ r ((g k).pullbackCoefficients (phi k)) (x k)) l
        (𝓝 (iteratedFDeriv ℝ r h.euclideanCoefficients y))) :
    Tendsto (fun k => (D k).scalarCurvature (phi k (x k))) l
        (𝓝 (Dh.scalarCurvature y)) ∧
      Tendsto (fun k => (D k).curvatureTensorNorm (phi k (x k))) l
        (𝓝 (Dh.curvatureTensorNorm y)) ∧
      ∀ eta : α → ℝ, Tendsto eta l (𝓝 0) →
        (∀ᶠ k in l, (D k).negativeCurvaturePart (phi k (x k)) ≤ eta k) →
        Dh.NonnegativeCurvatureOperator y := by
  have hreal := hphi.mono fun k hk => exists_shifted_pullback_realization (D k) (phi k) (x k) hk
  obtain ⟨gd, hgd⟩ := hreal.choice
  obtain ⟨hd, hhd, hscalar, hnorm, _hnegative, hnonnegative⟩ :=
    exists_shifted_pullback_realization Dh id y (Eventually.of_forall fun z => by
      refine ⟨contMDiffAt_id, ?_⟩
      rw [mfderiv_id]
      exact Function.injective_id)
  have hid : h.pullbackCoefficients id = h.euclideanCoefficients := by
    ext z v w
    simp +instances [RiemannianMetric.pullbackCoefficients, mfderiv_id,
      RiemannianMetric.euclideanCoefficients]
    rfl
  rw [hid] at hhd
  have hbilinear (r : ℕ) (hr : r ≤ 2) :
      Tendsto (fun k => iteratedFDeriv ℝ r (gd k).1.euclideanCoefficients 0) l
        (𝓝 (iteratedFDeriv ℝ r hd.1.euclideanCoefficients 0)) := by
    rw [iteratedFDeriv_eq_of_shifted_germ _ _ y hhd r]
    apply (hjets r hr).congr'
    filter_upwards [hgd] with k hk
    exact (iteratedFDeriv_eq_of_shifted_germ _ _ (x k) hk.1 r).symm
  let b := (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis
  have hj (r : ℕ) (hr : r ≤ 2) (a c : Fin 3) :
      Tendsto (fun k => iteratedFDeriv ℝ r
        (fun z => (gd k).1.inner z (b a) (b c)) 0) l
        (𝓝 (iteratedFDeriv ℝ r (fun z => hd.1.inner z (b a) (b c)) 0)) :=
    scalar_jets_of_bilinear_jets 0 (b a) (b c) r (hbilinear r hr)
  have hsc := LeviCivitaData.tendsto_scalarCurvature_of_scalar_metric_jets
    (fun k => (gd k).2) hd.2 0 b hj
  have hnm := LeviCivitaData.tendsto_curvatureTensorNorm_of_scalar_metric_jets
    (fun k => (gd k).2) hd.2 0 b hj
  rw [hscalar] at hsc
  rw [hnorm] at hnm
  refine ⟨hsc.congr' (hgd.mono fun _ hk => hk.2.1),
    hnm.congr' (hgd.mono fun _ hk => hk.2.2.1), ?_⟩
  intro eta heta hneg
  apply hnonnegative.mp
  apply LeviCivitaData.nonnegativeCurvatureOperator_of_scalar_metric_jets_of_negativePart
    (fun k => (gd k).2) hd.2 0 b hj heta
  filter_upwards [hgd, hneg] with k hk hnk
  rw [hk.2.2.2.1]
  exact hnk

end PoincareMT.ControlledTerminal
