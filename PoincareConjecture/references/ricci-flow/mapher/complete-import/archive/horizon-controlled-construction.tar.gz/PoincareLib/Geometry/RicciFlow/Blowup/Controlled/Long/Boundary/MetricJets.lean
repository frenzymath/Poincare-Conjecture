import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.TimeJets

/-! # Compact metric-jet convergence to an included backward endpoint -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12

open Set Filter Metric
open scoped Manifold ContDiff Topology

namespace PoincareMT.RicciFlow

/-- Spatial metric jets vary uniformly on compact chart sets at any included
time of a compact interval, including its left endpoint. -/
theorem tendstoUniformlyOn_spatialMetricJets_of_compact_interval
    {n : ℕ} {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    {J : SpacetimeInterval} (hJ : IsCompact J.domain) (F : RicciFlow n M J.domain)
    {U K : Set (EuclideanSpace ℝ (Fin n))} (hU : IsOpen U) (hK : IsCompact K) (hKU : K ⊆ U)
    (e : EuclideanSpace ℝ (Fin n) → M) (he : ContMDiffOn (𝓡 n) (𝓡 n) ∞ e U)
    {t : ℝ} (ht : t ∈ J.domain) (m : ℕ) :
    TendstoUniformlyOn
      (fun s => iteratedFDeriv ℝ m ((F.metric s).pullbackCoefficients e))
      (iteratedFDeriv ℝ m ((F.metric t).pullbackCoefficients e))
      (𝓝[J.domain] t) K := by
  let E := EuclideanSpace ℝ (Fin n)
  let f := fun z : ℝ × E => (F.metric z.1).pullbackCoefficients e z.2
  have hf : ContDiffOn ℝ ∞ f (J.domain ×ˢ U) :=
    F.contDiffOn_pullbackCoefficients_within hU he
  let P := ContinuousMultilinearMap.compContinuousLinearMapL
    (𝕜 := ℝ) (F := E →L[ℝ] E →L[ℝ] ℝ)
    (fun _ : Fin m => ContinuousLinearMap.inr ℝ ℝ E)
  have huniq := (Poincare.Spacetime.Realization.interval_uniqueDiffOn J).prod hU.uniqueDiffOn
  have hm : (m : ℕ∞ω) ≤ ∞ := WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤)
  have hcont : ContinuousOn (fun z : ℝ × E =>
      iteratedFDeriv ℝ m ((F.metric z.1).pullbackCoefficients e) z.2) (J.domain ×ˢ U) := by
    apply (P.continuous.comp_continuousOn (hf.continuousOn_iteratedFDerivWithin hm huniq)).congr
    intro z hz
    exact DeepHorn.iteratedFDeriv_spatial_slice_of_interval J hU f hf hz.1 hz.2 m
  exact ((hJ.prod hK).uniformContinuousOn_of_continuous
    (hcont.mono (prod_mono subset_rfl hKU))).tendstoUniformlyOn ht

/-- An actual closed extension determines the compact-uniform spatial jets
of the old flow as its missing left endpoint is approached. -/
theorem tendstoUniformlyOn_spatialMetricJets_of_closed_extension
    {n : ℕ} {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    {T : ℝ} (hT : 0 < T)
    (F : RicciFlow n M (Ioc (-T) 0)) (G : RicciFlow n M (Icc (-T) 0))
    (hmetric : ∀ t ∈ Ioc (-T) 0, G.metric t = F.metric t)
    {U K : Set (EuclideanSpace ℝ (Fin n))} (hU : IsOpen U) (hK : IsCompact K) (hKU : K ⊆ U)
    (e : EuclideanSpace ℝ (Fin n) → M) (he : ContMDiffOn (𝓡 n) (𝓡 n) ∞ e U) (m : ℕ) :
    TendstoUniformlyOn
      (fun s => iteratedFDeriv ℝ m ((F.metric s).pullbackCoefficients e))
      (iteratedFDeriv ℝ m ((G.metric (-T)).pullbackCoefficients e))
      (𝓝[Ioc (-T) 0] (-T)) K := by
  let J : SpacetimeInterval := ⟨Icc (-T) 0, ordConnected_Icc,
    ⟨-T, ⟨le_rfl, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩⟩
  have hconv := G.tendstoUniformlyOn_spatialMetricJets_of_compact_interval
    (J := J) isCompact_Icc hU hK hKU e he (t := -T) ⟨le_rfl, by linarith⟩ m
  have hconv' : TendstoUniformlyOn
      (fun s => iteratedFDeriv ℝ m ((G.metric s).pullbackCoefficients e))
      (iteratedFDeriv ℝ m ((G.metric (-T)).pullbackCoefficients e))
      (𝓝[Ioc (-T) 0] (-T)) K :=
    fun V hV => (hconv V hV).filter_mono (nhdsWithin_mono _ Ioc_subset_Icc_self)
  apply hconv'.congr
  filter_upwards [self_mem_nhdsWithin] with t ht x _hx
  rw [hmetric t ht]

end PoincareMT.RicciFlow
