import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Ancient.Compact.Stability.Neck.Jets.Parametrization

/-!
# Finite jets of captured varying neck coordinates

Uniform ambient metric jets and ellipticity control every captured neck
chart, even when both the metric and the neck vary. The neck comparison
supplies the source metric jets; the actual local isometry equation then
bounds one additional derivative of the coordinate map.

Reference: Morgan--Tian, Claim 11.6 and Proposition 9.79(3).
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT.MetricSurgery

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem exists_varying_centeredNeckAmbientCoordinates_jet_bound
    {M : Type u} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    {ι : Type*} (g : ι → RiemannianMetric 3 M) (N : ∀ i, EpsilonNeck (g i))
    (hsmall : ∀ i, (N i).epsilon < 1 / 200) (q : M)
    {K : Set M} (hK : IsCompact K) (hKq : K ⊆ (extChartAt (𝓡 3) q).source)
    (r : ℕ) (hr : 1 ≤ r) (horder : ∀ i, r ≤ ⌊(N i).epsilon⁻¹⌋₊)
    {l u b : ℝ} (hl : 0 < l) (hu : 0 < u) (hb : 0 < b)
    (hscalar : ∀ i, l ≤ (N i).connection.scalarCurvature (N i).center ∧
      (N i).connection.scalarCurvature (N i).center ≤ u)
    (hambient : ∃ C : ℝ, ∀ i j, j ≤ r → ∀ y ∈ (extChartAt (𝓡 3) q) '' K,
      ‖iteratedFDeriv ℝ j ((g i).parametrizedCoefficients (extChartAt (𝓡 3) q).symm) y‖ ≤ C)
    (helliptic : ∀ i y, y ∈ (extChartAt (𝓡 3) q) '' K → ∀ v : E,
      b * ‖v‖ ^ 2 ≤ (g i).parametrizedCoefficients (extChartAt (𝓡 3) q).symm y v v) :
    ∃ C : ℝ, 1 ≤ C ∧ ∀ i z,
      z.2 ∈ Ioo (-(N i).epsilon⁻¹) (N i).epsilon⁻¹ → (N i).coordinate_map z ∈ K →
      ∀ j : ℕ, j ≤ r + 1 →
        ‖iteratedFDeriv ℝ j (centeredNeckAmbientCoordinates (N i) q z) 0‖ ≤ C := by
  let c := extChartAt (𝓡 3) q
  let T : Set E := c '' K
  have hT : IsCompact T := hK.image_of_continuousOn ((continuousOn_extChartAt q).mono hKq)
  have hTq : T ⊆ c.target := by
    rintro y ⟨p, hp, rfl⟩
    exact c.map_source (hKq hp)
  let Q := fun i => (N i).connection.scalarCurvature (N i).center
  let B₀ := fun i => (normalizedNeckMetric (N i)).parametrizedCoefficients c.symm
  have hBs (i : ι) (y : E) (hy : y ∈ c.target) : ContDiffAt ℝ ∞ (B₀ i) y :=
    (normalizedNeckMetric (N i)).contDiffAt_parametrizedCoefficients
      ((contMDiffOn_extChartAt_symm (I := 𝓡 3) (n := ∞) q).contMDiffAt
        ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds hy))
  obtain ⟨CB, hCB⟩ := hambient
  have hBj (i : ι) (j : ℕ) (hj : j ≤ r) (y : E) (hy : y ∈ T) :
      ‖iteratedFDeriv ℝ j (B₀ i) y‖ ≤ u * max CB 0 := by
    have heq : B₀ i = fun y => Q i • (g i).parametrizedCoefficients c.symm y := by
      funext y
      ext v w
      rfl
    have hg := (g i).contDiffAt_parametrizedCoefficients
      ((contMDiffOn_extChartAt_symm (I := 𝓡 3) (n := ∞) q).contMDiffAt
        ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds (hTq hy)))
    rw [heq, iteratedFDeriv_const_smul_apply' (hg.of_le (by exact_mod_cast le_top))]
    let : IsBoundedSMul ℝ (E →L[ℝ] E →L[ℝ] ℝ) :=
      NormedSpace.toIsBoundedSMul (𝕜 := ℝ) («E» := E →L[ℝ] E →L[ℝ] ℝ)
    apply (ContinuousMultilinearMap.opNorm_smul_le _ _).trans
    rw [Real.norm_of_nonneg (N i).scalar_center_pos.le]
    exact mul_le_mul (hscalar i).2 ((hCB i j hj y hy).trans (le_max_left _ _))
      (norm_nonneg _) hu.le
  have hBlower (i : ι) (y : E) (hy : y ∈ T) (v : E) :
      (l * b) * ‖v‖ ^ 2 ≤ B₀ i y v v := by
    change (l * b) * ‖v‖ ^ 2 ≤ Q i * (g i).parametrizedCoefficients c.symm y v v
    have hnonneg : 0 ≤ (g i).parametrizedCoefficients c.symm y v v :=
      (mul_nonneg hb.le (sq_nonneg _)).trans (helliptic i y hy v)
    calc
      (l * b) * ‖v‖ ^ 2 = l * (b * ‖v‖ ^ 2) := mul_assoc _ _ _
      _ ≤ l * (g i).parametrizedCoefficients c.symm y v v :=
        mul_le_mul_of_nonneg_left (helliptic i y hy v) hl.le
      _ ≤ Q i * (g i).parametrizedCoefficients c.symm y v v :=
        mul_le_mul_of_nonneg_right (hscalar i).1 hnonneg
  obtain ⟨CA, _, hCA⟩ := exists_normalizedNeck_centered_coefficient_jet_bounds.{u} r
  obtain ⟨C₀, hC₀⟩ := hT.exists_bound_of_continuousOn continuousOn_id
  let Z := Σ i : ι, {z : RoundCylinderSpace //
    z.2 ∈ Ioo (-(N i).epsilon⁻¹) (N i).epsilon⁻¹ ∧ (N i).coordinate_map z ∈ K}
  let f := fun z : Z => centeredNeckAmbientCoordinates (N z.1) q z.2.1
  let A := fun z : Z => (normalizedNeckMetric (N z.1)).parametrizedCoefficients
    (centeredNeckLift (N z.1) z.2.1.1 z.2.1.2)
  let B := fun z : Z => B₀ z.1
  have hmem (z : Z) : 0 ∈ centeredNeckAmbientDomain (N z.1) q z.2.1 :=
    zero_mem_centeredNeckAmbientDomain (N z.1) q z.2.1 z.2.2.1 (hKq z.2.2.2)
  have hmap (z : Z) : f z 0 ∈ T := by
    change centeredNeckAmbientCoordinates (N z.1) q z.2.1 0 ∈ T
    rw [centeredNeckAmbientCoordinates_zero]
    exact mem_image_of_mem c z.2.2.2
  have hf (z : Z) : ∀ᶠ y in 𝓝 (0 : E), ContDiffAt ℝ ∞ (f z) y := by
    filter_upwards [(centeredNeckAmbientDomain_isOpen (N z.1) q z.2.1).mem_nhds (hmem z)]
      with y hy
    exact centeredNeckAmbientCoordinates_contDiffAt (N z.1) q z.2.1 hy
  have hA (z : Z) : ∀ᶠ y in 𝓝 (0 : E), ContDiffAt ℝ ∞ (A z) y := by
    filter_upwards [(centeredNeckDomain_isOpen (N z.1) z.2.1.2).mem_nhds
      (zero_mem_centeredNeckDomain (N z.1) z.2.2.1)] with y hy
    exact (normalizedNeckMetric (N z.1)).contDiffAt_parametrizedCoefficients
      (centeredNeckLift_contMDiffAt (N z.1) z.2.1.1 z.2.1.2 hy)
  have hB (z : Z) : ∀ᶠ y in 𝓝 (f z 0), ContDiffAt ℝ ∞ (B z) y := by
    filter_upwards [(isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds (hTq (hmap z))]
      with y hy
    exact hBs z.1 y hy
  have hsymm (z : Z) : ∀ᶠ y in 𝓝 (f z 0), ∀ v w, B z y v w = B z y w v :=
    Eventually.of_forall fun y v w => (normalizedNeckMetric (N z.1)).symm (c.symm y) _ _
  have hmetric (z : Z) : ∀ᶠ y in 𝓝 (0 : E), ∀ v w,
      A z y v w = B z (f z y) (fderiv ℝ (f z) y v) (fderiv ℝ (f z) y w) := by
    filter_upwards [(centeredNeckAmbientDomain_isOpen (N z.1) q z.2.1).mem_nhds (hmem z)]
      with y hy
    exact centeredNeckAmbientCoordinates_metric (N z.1) q z.2.1 hy
  obtain ⟨C, hC, hbound⟩ := CoordinateTransition.exists_finite_metric_isometry_jet_bound_at
    (A := A) (B := B) (f := f) (fun _z : Z => (0 : E)) hf hA hB r hr
    ⟨CA, fun z j hj => hCA (N z.1) j hj (hj.trans (horder z.1)) z.2.1 z.2.2.1⟩
    ⟨u * max CB 0, fun z j hj => hBj z.1 j hj (f z 0) (hmap z)⟩
    (by norm_num : (0 : ℝ) < 1 / 2) (mul_pos hl hb)
    (fun z v => normalizedNeckMetric_centeredCoefficients_lower
      (N z.1) (hsmall z.1) z.2.1 z.2.2.1 v)
    (fun z v => hBlower z.1 (f z 0) (hmap z) v)
    ⟨C₀, fun z => hC₀ (f z 0) (hmap z)⟩ hsymm hmetric
  exact ⟨C, hC, fun i z hz hKz j hj => hbound ⟨i, z, hz, hKz⟩ j hj⟩

end PoincareMT.MetricSurgery
