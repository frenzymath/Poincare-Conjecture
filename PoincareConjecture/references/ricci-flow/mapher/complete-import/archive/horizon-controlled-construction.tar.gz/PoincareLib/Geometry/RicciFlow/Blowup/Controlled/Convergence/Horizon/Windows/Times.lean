import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.FiniteWindow

/-! # Positive finite windows exhausting an extended backward horizon -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Topology ENNReal

namespace PoincareMT.ControlledBlowupCompactness

theorem finiteTimeRadius_strictMono {T : ℝ} (hT : 0 < T) :
    StrictMono (finiteTimeRadius T) := by
  intro m n hmn
  apply mul_lt_mul_of_pos_left _ hT
  apply (div_lt_div_iff₀ (by positivity) (by positivity)).mpr
  have hmn' : (m : ℝ) < n := by exact_mod_cast hmn
  nlinarith

/-- Every positive extended horizon is exhausted by strictly increasing
finite positive windows, with strict past-boundary room on compact sets. -/
theorem exists_strictly_increasing_horizon_windows
    {T₀ : ℝ≥0∞} (hT₀ : 0 < T₀) :
    ∃ tau : ℕ → ℝ, StrictMono tau ∧ (∀ j, 0 < tau j) ∧
      (∀ j, ENNReal.ofReal (tau j) < T₀) ∧
      ∀ I : Set ℝ, IsCompact I → I ⊆ blowupBackwardInterval T₀ →
        ∀ᶠ j in atTop, I ⊆ Ioc (-tau j) 0 := by
  by_cases htop : T₀ = ⊤
  · subst T₀
    refine ⟨expandingRadius, ?_, expandingRadius_pos, fun _ => ENNReal.ofReal_lt_top, ?_⟩
    · intro m n hmn
      change (m : ℝ) + 1 < (n : ℝ) + 1
      have hmn' : (m : ℝ) < n := by exact_mod_cast hmn
      linarith
    · intro I hI hIJ
      obtain ⟨a, ha⟩ := hI.bddBelow
      have ht : Tendsto expandingRadius atTop atTop :=
        tendsto_atTop_add_const_right atTop 1 tendsto_natCast_atTop_atTop
      filter_upwards [ht.eventually_gt_atTop (-a)] with j hj t htI
      exact ⟨by linarith [ha htI], (hIJ htI).1⟩
  · have hT : 0 < T₀.toReal := ENNReal.toReal_pos hT₀.ne' htop
    refine ⟨finiteTimeRadius T₀.toReal, finiteTimeRadius_strictMono hT,
      finiteTimeRadius_pos hT, ?_, ?_⟩
    · intro j
      conv_rhs => rw [← ENNReal.ofReal_toReal htop]
      exact (ENNReal.ofReal_lt_ofReal_iff hT).mpr (finiteTimeRadius_lt hT j)
    · intro I hI hIJ
      have hdomain : blowupBackwardInterval T₀ = Ioc (-T₀.toReal) 0 := by
        conv_lhs => rw [← ENNReal.ofReal_toReal htop]
        exact blowupBackwardInterval_ofReal_eq hT
      exact finiteTimeRadius_interval_strict_cofinal hT hI (hdomain ▸ hIJ)

end PoincareMT.ControlledBlowupCompactness
