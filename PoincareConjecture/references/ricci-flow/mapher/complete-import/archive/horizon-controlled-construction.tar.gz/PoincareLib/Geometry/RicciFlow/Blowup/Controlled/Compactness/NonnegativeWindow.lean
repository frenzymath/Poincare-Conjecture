import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.GeometricWindow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.PinchingLimit

/-!
# Nonnegative complete finite-window limits

The selected cylinder errors tend to zero. Their actual normalized ordinary
flows therefore have pointed limits with nonnegative curvature operator,
in addition to M07's completeness and the uniform full-curvature bound.
Source: Morgan--Tian, Theorem 11.8, pp. 274--279.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

theorem interiorSequence_limit_nonnegativeCurvatureOperator
    (S : GeneralizedBlowupSequence.{u}) (idx : ℕ → ℕ) (A eta : ℕ → ℝ)
    {T B : ℝ} (hA : ∀ i, 0 < A i) (hT : 0 < T)
    (e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i))
    (heta : Tendsto eta atTop (𝓝 0))
    (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
    (t : ℝ) (ht : t ∈ Ioo (-T / 2) (T / 2)) (x : G.limitCarrier.carrier) :
    (G.limitFlow.flow.connection t).NonnegativeCurvatureOperator x := by
  apply G.nonnegativeCurvatureOperator_of_vanishing_negativePart t ht heta _ x
  exact Eventually.of_forall (fun i y =>
    (e i).smallFlow_negativeCurvaturePart_le (hA i) hT (t + (-T / 2))
      ⟨by linarith [ht.1], by linarith [ht.2]⟩ y)

theorem exists_nonnegative_finite_window_limit_with_compact_balls
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀) {T : ℝ} (hT : 0 < T)
    (horizon : ENNReal.ofReal T < T₀) :
    ∃ B : ℝ, 0 ≤ B ∧ ∃ idx : ℕ → ℕ, StrictMono idx ∧
      ∃ e : ∀ i, ControlledBlowupCylinder S (idx i) (expandingRadius i) T B
        ((expandingRadius i)⁻¹),
      (∀ i, IsCompact (closure (S.baseBall (idx i) (expandingRadius i)))) ∧
      ∃ G : PointedGeometricConvergence
        (interiorSequence S idx expandingRadius (fun i => (expandingRadius i)⁻¹)
          T B expandingRadius_pos hT e),
        (∀ t ∈ Ioo (-T / 2) (T / 2),
          G.limitCarrier.metricComplete (G.limitFlow.metricAt t)) ∧
        (∀ t ∈ Ioo (-T / 2) (T / 2), ∀ x : G.limitCarrier.carrier,
          (G.limitFlow.flow.connection t).curvatureTensorNorm x ≤ B) ∧
        ∀ t ∈ Ioo (-T / 2) (T / 2), ∀ x : G.limitCarrier.carrier,
          (G.limitFlow.flow.connection t).NonnegativeCurvatureOperator x := by
  obtain ⟨B, hB, idx, hidx, e, hcompact, G, hcomplete, hbound⟩ :=
    exists_finite_window_limit_with_compact_balls P H hT horizon
  refine ⟨B, hB, idx, hidx, e, hcompact, G, hcomplete, hbound, ?_⟩
  have heta : Tendsto (fun i => (expandingRadius i)⁻¹) atTop (𝓝 0) :=
    tendsto_inv_atTop_zero.comp
      (tendsto_atTop_add_const_right atTop 1 tendsto_natCast_atTop_atTop)
  exact interiorSequence_limit_nonnegativeCurvatureOperator S idx expandingRadius
    (fun i => (expandingRadius i)⁻¹) expandingRadius_pos hT e heta G

theorem exists_nonnegative_finite_window_limit
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀) {T : ℝ} (hT : 0 < T)
    (horizon : ENNReal.ofReal T < T₀) :
    ∃ B : ℝ, 0 ≤ B ∧ ∃ idx : ℕ → ℕ, StrictMono idx ∧
      ∃ e : ∀ i, ControlledBlowupCylinder S (idx i) (expandingRadius i) T B
        ((expandingRadius i)⁻¹),
      ∃ G : PointedGeometricConvergence
        (interiorSequence S idx expandingRadius (fun i => (expandingRadius i)⁻¹)
          T B expandingRadius_pos hT e),
        (∀ t ∈ Ioo (-T / 2) (T / 2),
          G.limitCarrier.metricComplete (G.limitFlow.metricAt t)) ∧
        (∀ t ∈ Ioo (-T / 2) (T / 2), ∀ x : G.limitCarrier.carrier,
          (G.limitFlow.flow.connection t).curvatureTensorNorm x ≤ B) ∧
        ∀ t ∈ Ioo (-T / 2) (T / 2), ∀ x : G.limitCarrier.carrier,
          (G.limitFlow.flow.connection t).NonnegativeCurvatureOperator x := by
  obtain ⟨B, hB, idx, hidx, e, _, G, hcomplete, hbound, hnonnegative⟩ :=
    exists_nonnegative_finite_window_limit_with_compact_balls P H hT horizon
  exact ⟨B, hB, idx, hidx, e, G, hcomplete, hbound, hnonnegative⟩

end PoincareMT.ControlledBlowupCompactness
