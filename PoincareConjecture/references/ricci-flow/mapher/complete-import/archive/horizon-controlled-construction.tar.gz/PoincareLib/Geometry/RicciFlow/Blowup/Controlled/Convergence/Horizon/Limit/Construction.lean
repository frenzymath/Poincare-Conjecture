import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Limit.Flow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Limit.Sign
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Limit.Completeness
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Limit

/-! # The normalized complete controlled limit on the full backward horizon -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

theorem exists_closed_horizonWindow_of_isCompact {tau : ℕ → ℝ}
    (htau : ∀ j, 0 < tau j) (htmono : Monotone tau)
    {I : Set ℝ} (hI : IsCompact I) (hIsub : I ⊆ horizonOpenTime tau ∪ {0}) :
    ∃ j, I ⊆ Ioc (-tau j) 0 := by
  have hcover : I ⊆ ⋃ j, Ioi (-tau j) := by
    intro t ht
    rcases hIsub ht with ht | ht
    · obtain ⟨j, hj⟩ := mem_iUnion.mp ht
      exact mem_iUnion.mpr ⟨j, hj.1⟩
    · have ht0 := mem_singleton_iff.mp ht
      exact mem_iUnion.mpr ⟨0, by simpa only [ht0, mem_Ioi] using neg_lt_zero.mpr (htau 0)⟩
  obtain ⟨s, hs⟩ := hI.elim_finite_subcover (fun j => Ioi (-tau j)) (fun _ => isOpen_Ioi) hcover
  refine ⟨s.sup id, fun t ht => ?_⟩
  obtain ⟨j, hj, htj⟩ := mem_iUnion₂.mp (hs ht)
  refine ⟨lt_of_le_of_lt (neg_le_neg (htmono (Finset.le_sup (f := id) hj))) htj, ?_⟩
  rcases hIsub ht with ht | ht
  · obtain ⟨i, hi⟩ := mem_iUnion.mp ht
    exact hi.2.le
  · exact (mem_singleton_iff.mp ht).le

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))
  (F₀ : RicciFlow 3 G.limitCarrier.carrier (Ioc (-tau 0 / 2) (tau 0 / 2)))
  (hF₀ : ∀ t ∈ Ioo (-tau 0 / 2) (tau 0 / 2), F₀.metric t = G.limitFlow.metricAt t)
  (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau ∪ {0}))
  (hmatch : ∀ t ∈ Ioc (-tau 0) 0, F.metric t = F₀.metric (t + tau 0 / 2))
  (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
  (htmono : Monotone tau) (hB : ∀ j, 0 ≤ B j)
  {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
  (hjets : ∀ q r K, IsCompact K → K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target →
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ r (horizonSpacetimeCoefficients G q (sigma k)))
      (iteratedFDeriv ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)) atTop K)

def fullHorizonInterior : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau) :=
  Poincare.Geometry.RicciFlow.Harnack.restrictFlow F subset_union_left
    (horizonOpenTime_ordConnected tau) (horizonOpenTime_nontrivial (htau 0))

include hF₀ hmatch P04 hAr hcompact hcomplete htmono hB hsigma hjets

theorem full_horizon_curvatureTensorNorm_bound
    {j : ℕ} {t : ℝ} (ht : t ∈ Ioc (-tau j) 0) (x : G.limitCarrier.carrier) :
    |(F.connection t).curvatureTensorNorm x| ≤ max (B j) (B 0) := by
  rw [abs_of_nonneg (by unfold LeviCivitaData.curvatureTensorNorm; positivity)]
  rcases lt_or_eq_of_le ht.2 with htneg | rfl
  · exact (horizon_curvatureTensorNorm_le G htmono hsigma (fullHorizonInterior G F) hjets
      ⟨ht.1, htneg⟩ x).trans (le_max_left _ _)
  · have hm := hmatch 0 ⟨by linarith [htau 0], le_rfl⟩
    rw [zero_add] at hm
    rw [(F.connection 0).curvatureTensorNorm_eq_of_metric_eq (F₀.connection (tau 0 / 2)) hm x]
    exact (terminal_curvatureTensorNorm_le G F₀ hF₀ P04 (hB 0) hAr hcompact hcomplete
      ⟨by linarith [htau 0], le_rfl⟩ x).trans (le_max_right _ _)

theorem full_horizon_metricComplete
    {t : ℝ} (ht : t ∈ horizonOpenTime tau ∪ {0}) : G.limitCarrier.metricComplete (F.metric t) := by
  let s := -tau 0 / 2
  have hs : s ∈ Ioc (-tau 0) 0 := ⟨by dsimp [s]; linarith [htau 0], by dsimp [s]; linarith [htau 0]⟩
  have href : G.limitCarrier.metricComplete (F.metric s) := by
    rw [hmatch s hs, show s + tau 0 / 2 = 0 by dsimp [s]; ring,
      hF₀ 0 ⟨by linarith [htau 0], by linarith [htau 0]⟩]
    exact hcomplete
  have hsJ : s ∈ horizonOpenTime tau ∪ {0} :=
    Or.inl (mem_iUnion.mpr ⟨0, hs.1, by dsimp [s]; linarith [htau 0]⟩)
  have hI : Icc (min s t) (max s t) ⊆ horizonOpenTime tau ∪ {0} := by
    exact F.interval.uIcc_subset hsJ ht
  obtain ⟨j, hj⟩ := exists_closed_horizonWindow_of_isCompact htau htmono isCompact_Icc hI
  apply F.metricComplete_of_reference_curvature_bound G.limitCarrier G.limitFlow.base hI
    (show s ∈ Icc (min s t) (max s t) from ⟨min_le_left _ _, le_max_left _ _⟩)
    (show t ∈ Icc (min s t) (max s t) from ⟨min_le_right _ _, le_max_right _ _⟩) href
  intro u hu x
  exact (le_abs_self _).trans (full_horizon_curvatureTensorNorm_bound G F₀ hF₀ F hmatch P04 hAr
    hcompact hcomplete htmono hB hsigma hjets (hj hu) x)

def horizonLimit (heta : Tendsto eta atTop (𝓝 0)) : BlowupLimitFlow.{0} (horizonOpenTime tau ∪ {0}) where
  carrier := G.limitCarrier
  connectedSpace := connectedSpace_iff_univ.mpr G.limitCarrier.connected
  base := G.limitFlow.base
  flow := F
  zero_mem := Or.inr (mem_singleton 0)
  scalar_normalized := by
    have hm := hmatch 0 ⟨by linarith [htau 0], le_rfl⟩
    rw [zero_add] at hm
    have hRic : (F.connection 0).scalarCurvature G.limitFlow.base =
        (F₀.connection (tau 0 / 2)).scalarCurvature G.limitFlow.base := by
      have h := (F.connection 0).scalarCurvature_eq_of_local_isometry
        (F₀.connection (tau 0 / 2)) (f := id) isOpen_univ contMDiffOn_id
        (fun y _ v w => by simp only [id_eq, mfderiv_id, ContinuousLinearMap.id_apply, hm])
        (mem_univ G.limitFlow.base)
      simpa only [id_eq] using h
    rw [hRic]
    exact terminal_scalar_normalized G F₀ hF₀ P04 (hB 0) hAr hcompact hcomplete
  complete := fun _ ht => full_horizon_metricComplete G F₀ hF₀ F hmatch P04 hAr hcompact hcomplete
    htmono hB hsigma hjets ht
  nonnegative_curvature_operator := by
    intro t ht x
    rcases ht with ht | ht
    · exact horizon_nonnegativeCurvatureOperator G htmono hsigma (fullHorizonInterior G F) hjets heta ht x
    · have ht0 := mem_singleton_iff.mp ht
      subst t
      have hm := hmatch 0 ⟨by linarith [htau 0], le_rfl⟩
      rw [zero_add] at hm
      apply ((F.connection 0).nonnegativeCurvatureOperator_iff_of_metric_eq
        (F₀.connection (tau 0 / 2)) hm x).mpr
      exact terminal_nonnegativeCurvatureOperator G F₀ hF₀ P04 (hB 0) hAr hcompact hcomplete heta
        ⟨by linarith [htau 0], le_rfl⟩ x
  curvature_locally_bounded_in_time := by
    intro I hI hIsub
    obtain ⟨j, hj⟩ := exists_closed_horizonWindow_of_isCompact htau htmono hI hIsub
    exact ⟨max (B j) (B 0), (hB j).trans (le_max_left _ _), fun t ht x =>
      full_horizon_curvatureTensorNorm_bound G F₀ hF₀ F hmatch P04 hAr hcompact hcomplete htmono hB
        hsigma hjets (hj ht) x⟩

end PoincareMT.ControlledBlowupCompactness
