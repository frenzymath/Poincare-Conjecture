import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Production
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Horizon.Continuation
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Short

/-!
# Controlled generalized-flow blow-up limits

The frozen M04, M06, M07, and dense M29 services produce the exact repaired
M30 theory. The short and long branches share a universal threshold. The
geometric branch retains terminal-time convergence; the long branch retains
finite-scale noncollapse and the actual infinite-horizon ancient solution.

Reference: Morgan--Tian, Theorems 11.1 and 11.8, Proposition 11.10,
pp. 267--279, with the accepted complete-interior compactness correction.
-/

set_option autoImplicit false

open Set Filter
open scoped ENNReal

universe u

namespace PoincareMT

theorem m30ControlledGeneralizedBlowupLimits
    (P : M30ControlledBlowupPredecessors.{u}) :
    RepairedControlledBlowupLimitTheory.{u} := by
  obtain ⟨epsilonS, hSpos, hSsmall, hshort⟩ := P.exists_short_limit_threshold
  obtain ⟨epsilonG, hGpos, _hGsmall, hseed⟩ := P.exists_short_geometric_controls_threshold
  obtain ⟨epsilonE, hEpos, _hEsmall, hextend⟩ := P.exists_finite_extension_threshold
  obtain ⟨epsilonD, hDpos, _hDsmall, hbounded⟩ := P.m29.constants
  let epsilon₀ := min epsilonS (min epsilonG (min epsilonE epsilonD))
  have hpos : 0 < epsilon₀ := lt_min hSpos (lt_min hGpos (lt_min hEpos hDpos))
  have hS : epsilon₀ ≤ epsilonS := min_le_left _ _
  have hG : epsilon₀ ≤ epsilonG := (min_le_right _ _).trans (min_le_left _ _)
  have hE : epsilon₀ ≤ epsilonE :=
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
  have hD : epsilon₀ ≤ epsilonD :=
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _))
  refine {
    geometric_long := fun _ _ H =>
      ControlledBlowupCompactness.nonempty_generalizedBlowupConvergence_of_geometricLongControls P H
    limits := ⟨epsilon₀, hpos, hS.trans hSsmall, ?_, ?_⟩ }
  · intro S epsilon C kappa r₀ mu hepsilon H
    exact hshort S epsilon C kappa r₀ mu (hepsilon.trans hS) H
  · intro S epsilon C kappa r₀ mu T₀ hepsilon H
    have hcommon := H.toM30CommonBlowupControls
    apply ControlledBlowupHorizon.nonempty_long_conclusion_of_finite_extensions P H
      (hbounded epsilon H.epsilon_pos (hepsilon.trans hD) C H.C_pos S ⟨H.branch, H.canonical⟩)
      (hseed S epsilon C kappa r₀ mu (hepsilon.trans hG) hcommon)
    intro sigma hsigma T hT hT₀ G
    obtain ⟨V, B, hTV, hV₀, hB, hcyl⟩ :=
      hextend (S.subsequence sigma hsigma) epsilon C kappa r₀ mu T₀
        (hepsilon.trans hE) (H.subsequence sigma hsigma) T hT G hT₀
    exact ⟨V, B, hTV, hV₀, hB.le, hcyl⟩

end PoincareMT
