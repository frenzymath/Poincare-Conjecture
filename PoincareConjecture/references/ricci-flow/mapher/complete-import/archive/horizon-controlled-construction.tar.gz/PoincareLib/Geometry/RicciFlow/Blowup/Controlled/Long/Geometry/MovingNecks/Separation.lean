import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Geometry.LocalSeparation

/-! # Capturing central spheres around a fixed reference point -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology ENNReal

namespace PoincareMT.ControlledLongGeometry

theorem exists_central_sphere_separating_radius
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    [MeasurableSpace M] [BorelSpace M] [T2Space M] [T3Space M] [ConnectedSpace M]
    (g₀ : RiemannianMetric 3 M) (y : M) :
    ∃ r : ℝ, 0 < r ∧ ∀ (g : RiemannianMetric 3 M) (N : EpsilonNeck g),
      (∀ x ∈ N.central_sphere, (g₀.edist y x).toReal < r) → N.IsSeparating := by
  let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
    ⟨g₀.toRiemannianMetric⟩
  let : IsContinuousRiemannianBundle (EuclideanSpace ℝ (Fin 3))
      (TangentSpace (𝓡 3) : M → Type _) :=
    ⟨⟨g₀.inner, g₀.toContinuousRiemannianMetric.continuous, fun _ _ _ => rfl⟩⟩
  let : EMetricSpace M := EMetricSpace.ofRiemannianMetric (𝓡 3) M
  obtain ⟨U, hU, hy, hcontract⟩ :=
    ControlledTerminal.exists_contractible_open_neighborhood (n := 3) y
  let : ContractibleSpace U := hcontract
  obtain ⟨delta, hdelta, hdeltaU⟩ := EMetric.mem_nhds_iff.mp (hU.mem_nhds hy)
  have hpos : 0 < min delta 1 := lt_min hdelta (by norm_num)
  have hfinite : min delta 1 ≠ ⊤ := ne_of_lt
    ((min_le_right delta 1).trans_lt (by norm_num : (1 : ℝ≥0∞) < ⊤))
  refine ⟨(min delta 1).toReal, ENNReal.toReal_pos hpos.ne' hfinite, ?_⟩
  intro g N hN
  apply N.isSeparating_of_central_sphere_subset_contractible (U := U)
  intro x hx
  apply hdeltaU
  change edist x y < delta
  rw [edist_comm]
  exact ((ENNReal.toReal_lt_toReal (g₀.edist_ne_top y x) hfinite).mp (hN x hx)).trans_le
    (min_le_left _ _)

end PoincareMT.ControlledLongGeometry
