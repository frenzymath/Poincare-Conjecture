import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SpatialBounds
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.ClosedJets
import PoincareLib.Geometry.RicciFlow.AncientKappa.Asymptotic.Compactness.Coordinates.SpacetimeJets

/-!
# Local metric jets from terminal jets and curvature estimates

The Ricci equation propagates the terminal reference jets to a closed
backward interval. Its coordinate evolution then bounds all spacetime jets,
including within-domain derivatives at time zero.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledTerminal

open SpacetimeBounds SpacetimeBounds.Bootstrap

variable {n : ℕ} {M : ℕ → Type*} [∀ k, TopologicalSpace (M k)]
  [∀ k, ChartedSpace (EuclideanSpace ℝ (Fin n)) (M k)]
  [∀ k, IsManifold (𝓡 n) ∞ (M k)]
  {a b : ℝ} (hab : a < b) (F : ∀ k, RicciFlow n (M k) (Icc a b))
  {U : Set (EuclideanSpace ℝ (Fin n))} (hU : IsOpen U)
  (e : ∀ k, EuclideanSpace ℝ (Fin n) → M k)
  (he : ∀ k, ContMDiffOn (𝓡 n) (𝓡 n) ∞ (e k) U)
  (hi : ∀ k x, x ∈ U → (mfderiv (𝓡 n) (𝓡 n) (e k) x).IsInvertible)
  {W : Set (EuclideanSpace ℝ (Fin n))} (hWU : W ⊆ U)
  {alpha beta : ℝ} (halpha : 0 < alpha) (hbeta : 0 ≤ beta)
  (hell : ∀ᶠ k in atTop, ∀ t ∈ Icc a b, ∀ x ∈ W, ∀ v,
    alpha * ‖v‖ ^ 2 ≤ ((F k).metric t).pullbackCoefficients (e k) x v v ∧
      ((F k).metric t).pullbackCoefficients (e k) x v v ≤ beta * ‖v‖ ^ 2)
  (hcurv : ∀ j : ℕ, ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
    ∀ t ∈ Icc a b, ∀ x ∈ W, ((F k).connection t).curvatureDerivativeNorm j (e k x) ≤ C)
  (hterminal : ∀ j : ℕ, ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
    ∀ x ∈ W, ‖iteratedFDeriv ℝ j (((F k).metric b).pullbackCoefficients (e k)) x‖ ≤ C)

include hab hU he hi hWU halpha hbeta hell hcurv hterminal in
theorem eventually_bounded_local_spatial_jets (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ t ∈ Icc a b, ∀ x ∈ W, ∀ j ≤ m,
        ‖iteratedFDeriv ℝ j (((F k).metric t).pullbackCoefficients (e k)) x‖ ≤ C := by
  choose D hD hder using hcurv
  choose Z _hZ href using hterminal
  obtain ⟨C, hC, hbound⟩ := exists_chart_spatial_jet_bound_on_closed_interval
    n m D Z hD hab halpha hbeta
  refine ⟨C, hC, ?_⟩
  filter_upwards [hell,
    (eventually_all_finite (Set.finite_Iic m)).mpr (fun j _ => hder j),
    (eventually_all_finite (Set.finite_Iic m)).mpr (fun j _ => href j)]
    with k hellk hderk hrefk
  exact hbound (F k) Subset.rfl hU (he k) (hi k) W hWU hellk
    (fun j hj => hderk j hj) (show b ∈ Icc a b from ⟨hab.le, le_rfl⟩)
    (fun j hj => hrefk j hj)

include hab hU he hi hWU halpha hbeta hell hcurv hterminal in
theorem eventually_bounded_local_open_spacetime_jets (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ z ∈ Ioo a b ×ˢ W,
        ‖iteratedFDeriv ℝ m
          (fun z => ((F k).metric z.1).pullbackCoefficients (e k) z.2) z‖ ≤ C := by
  let E := EuclideanSpace ℝ (Fin n)
  let f := fun k (z : ℝ × E) => ((F k).metric z.1).pullbackCoefficients (e k) z.2
  have hne : (Ioo a b).Nontrivial := by
    refine ⟨(2 * a + b) / 3, ⟨by linarith, by linarith⟩,
      (a + 2 * b) / 3, ⟨by linarith, by linarith⟩, by linarith⟩
  let Fopen := fun k => Poincare.Geometry.RicciFlow.Harnack.restrictFlow
    (F k) Ioo_subset_Icc_self ordConnected_Ioo hne
  have hf (k : ℕ) : ContDiffOn ℝ ∞ (f k) (Ioo a b ×ˢ U) :=
    (Fopen k).contDiffOn_pullbackCoefficients isOpen_Ioo hU (he k)
  have hrange (k : ℕ) : MapsTo (spatialJet 2 (f k))
      (Ioo a b ×ˢ U) (jetRicciFlowDomain n) := by
    intro z hz
    change ((twoJetProjection n (spatialJet 2 (f k) z)).1).IsInvertible
    rw [twoJetProjection_spatialJet]
    exact ((F k).metric z.1).isInvertible_pullbackCoefficients (hi k z.2 hz.2).injective
  have hevol (k : ℕ) (z : ℝ × E) (hz : z ∈ Ioo a b ×ˢ U) :
      deriv (fun t => f k (t, z.2)) z.1 = jetRicciFlowOperator n (spatialJet 2 (f k) z) := by
    rw [jetRicciFlowOperator, Function.comp_apply, twoJetProjection_spatialJet]
    exact deriv_pullbackCoefficients_eq_ricciFlowOperator (Fopen k)
      isOpen_Ioo hU (he k) (hi k) hz.1 hz.2
  have hall (r : ℕ) : ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ z ∈ Ioo a b ×ˢ W, ∀ j ≤ r,
        ‖iteratedFDeriv ℝ j (fun x => f k (z.1, x)) z.2‖ ≤ C := by
    obtain ⟨C, hC, hbound⟩ := eventually_bounded_local_spatial_jets
      hab F hU e he hi hWU halpha hbeta hell hcurv hterminal r
    exact ⟨C, hC, hbound.mono fun k hk z hz => hk z.1 (Ioo_subset_Icc_self hz.1) z.2 hz.2⟩
  have hspatial (r : ℕ) : ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ z ∈ Ioo a b ×ˢ W, ‖iteratedFDeriv ℝ r (fun x => f k (z.1, x)) z.2‖ ≤ C := by
    obtain ⟨C, hC, hbound⟩ := hall r
    exact ⟨C, hC, hbound.mono fun k hk z hz => hk z hz r le_rfl⟩
  have hbox (r : ℕ) : ∃ Q : Set (Jet E (MetricCoefficient n) (2 + r)),
      IsCompact Q ∧ Q ⊆ (baseProjection 2 r) ⁻¹' jetRicciFlowDomain n ∧
        ∀ᶠ k in atTop, MapsTo (spatialJet (2 + r) (f k)) (Ioo a b ×ˢ W) Q := by
    obtain ⟨C, hC, hbound⟩ := hall (2 + r)
    obtain ⟨Q, hQ, hQU, hbox⟩ := exists_compact_elliptic_jet_box n r halpha C
    refine ⟨Q, hQ, hQU, ?_⟩
    filter_upwards [hbound, hell] with k hk heq z hz
    apply hbox
    · exact (pi_norm_le_iff_of_nonneg hC).mpr (fun j => hk z hz j (by omega))
    · exact fun v => (heq z.1 (Ioo_subset_Icc_self hz.1) z.2 hz.2 v).1
  exact eventuallyBounded_spacetime_jets atTop
    (isOpen_jetRicciFlowDomain n) (contDiffOn_jetRicciFlowOperator n)
    f (fun _ => Ioo a b) (fun _ => U) (fun _ => Ioo a b ×ˢ W)
    hf (fun _ => isOpen_Ioo) (fun _ => hU)
    (fun _ _ hz => ⟨hz.1, hWU hz.2⟩) hrange hevol hspatial hbox m

include hab hU he hi halpha hbeta in
theorem eventually_bounded_local_closed_spacetime_jets
    {x₀ : EuclideanSpace ℝ (Fin n)} {rho : ℝ} (hrho : 0 < rho)
    (hballU : closedBall x₀ rho ⊆ U)
    (hell : ∀ᶠ k in atTop, ∀ t ∈ Icc a b, ∀ x ∈ closedBall x₀ rho, ∀ v,
      alpha * ‖v‖ ^ 2 ≤ ((F k).metric t).pullbackCoefficients (e k) x v v ∧
        ((F k).metric t).pullbackCoefficients (e k) x v v ≤ beta * ‖v‖ ^ 2)
    (hcurv : ∀ j : ℕ, ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ t ∈ Icc a b, ∀ x ∈ closedBall x₀ rho,
        ((F k).connection t).curvatureDerivativeNorm j (e k x) ≤ C)
    (hterminal : ∀ j : ℕ, ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ x ∈ closedBall x₀ rho,
        ‖iteratedFDeriv ℝ j (((F k).metric b).pullbackCoefficients (e k)) x‖ ≤ C)
    (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ z ∈ Icc a b ×ˢ closedBall x₀ rho,
        ‖iteratedFDerivWithin ℝ m
          (fun z => ((F k).metric z.1).pullbackCoefficients (e k) z.2)
          (Icc a b ×ˢ closedBall x₀ rho) z‖ ≤ C := by
  let Ω := Icc a b ×ˢ closedBall x₀ rho
  have hclosed : IsClosed Ω := isClosed_Icc.prod isClosed_closedBall
  have hconvex : Convex ℝ Ω := (convex_Icc a b).prod (convex_closedBall x₀ rho)
  have hinterior : interior Ω = Ioo a b ×ˢ ball x₀ rho := by
    rw [interior_prod_eq, interior_Icc, interior_closedBall _ hrho.ne']
  have hne : (interior Ω).Nonempty := by
    rw [hinterior]
    exact ⟨((a + b) / 2, x₀), ⟨by constructor <;> linarith, mem_ball_self hrho⟩⟩
  obtain ⟨C, hC, hbound⟩ := eventually_bounded_local_open_spacetime_jets
    hab F hU e he hi hballU halpha hbeta hell hcurv hterminal m
  refine ⟨C, hC, hbound.mono ?_⟩
  intro k hk z hz
  apply ControlledConvergence.norm_withinJet_le_of_interior_bound hclosed hconvex hne
    (((F k).contDiffOn_pullbackCoefficients_within hU (he k)).mono
      (prod_mono subset_rfl hballU)) m _ hz
  intro y hy
  rw [hinterior] at hy
  exact hk y ⟨hy.1, ball_subset_closedBall hy.2⟩

end PoincareMT.ControlledTerminal
