import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.CylinderFlow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Geometry
import PoincareLib.Geometry.Riemannian.Curvature.LocalIsometryInvariants
import PoincareLib.Geometry.Riemannian.Curvature.LocalIsometry
import PoincareLib.Geometry.Riemannian.Homothety.Curvature.ContractionTransport

/-!
# Curvature of the normalized ordinary cylinder

The source cylinder is a local isometry into the rescaled actual slice.
Consequently both scalar curvature and the full curvature norm are divided
by the cylinder scale. Source: Morgan--Tian Theorem 11.1, pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.GeneralizedFlowCylinder

open EpochExtension.Spacetime

variable {F : GeneralizedRicciFlowData.{u}} {C : GeneralizedSliceCarrier.{u}}
  {a q : ℝ} {J : SpacetimeInterval} {U : TopologicalSpace.Opens C.carrier}
  (e : GeneralizedFlowCylinder F C a q J.domain U) (hC : Nonempty C.carrier)

/-- The ordinary cylinder metric is the pullback of the actual rescaled slice. -/
theorem ordinaryPullbackFlow_rescaled_inner
    (s : J.domain) (x : U) (v w : TangentSpace (𝓡 3) x) :
    ((e.ordinaryPullbackFlow hC).metric s).inner x v w =
      (rescaledMetric (F.metric (a + s.val / q)) q e.scale_pos).inner
        (rawSpatialMap e s x)
        (mfderiv (𝓡 3) (𝓡 3) (rawSpatialMap e s) x v)
        (mfderiv (𝓡 3) (𝓡 3) (rawSpatialMap e s) x w) := by
  rw [e.ordinaryPullbackFlow_inner hC s s.property x v w]
  have hf := ((e.forward_smooth s.val s.property).contMDiffAt
    (U.isOpen.mem_nhds x.property)).mdifferentiableAt (by simp)
  have hsub : MDifferentiableAt (𝓡 3) (𝓡 3) (Subtype.val : U → C.carrier) x :=
    (contMDiff_subtype_val (n := ∞) x).mdifferentiableAt (by simp)
  have hder := mfderiv_comp x hf hsub
  change mfderiv (𝓡 3) (𝓡 3) (rawSpatialMap e s) x = _ at hder
  rw [hder]
  rfl

/-- The ordinary cylinder scalar is the actual generalized scalar divided by scale. -/
theorem ordinaryPullbackFlow_scalarCurvature (s : ℝ) (hs : s ∈ J.domain) (x : U) :
    ((e.ordinaryPullbackFlow hC).connection s).scalarCurvature x =
      F.scalar (e.pointMap s hs x.val) / q := by
  let D := rescaledMetric_connection (F.metric (a + s / q))
    (F.connection (a + s / q)) q e.scale_pos
  have h := ((e.ordinaryPullbackFlow hC).connection s).scalarCurvature_eq_of_local_isometry
    D isOpen_univ (rawSpatialMap_smooth e ⟨s, hs⟩).contMDiffOn
    (fun y _ v w => e.ordinaryPullbackFlow_rescaled_inner hC ⟨s, hs⟩ y v w) (mem_univ x)
  rw [h, rescaledMetric_scalarCurvature]
  change q⁻¹ * (F.connection (a + s / q)).scalarCurvature (e.forward s hs x.val) = _
  simp only [GeneralizedRicciFlowData.scalar, pointMap, div_eq_mul_inv, mul_comm]

/-- The ordinary cylinder full curvature norm has the same inverse scaling law. -/
theorem ordinaryPullbackFlow_curvatureTensorNorm (s : ℝ) (hs : s ∈ J.domain) (x : U) :
    ((e.ordinaryPullbackFlow hC).connection s).curvatureTensorNorm x =
      F.curvatureNorm (e.pointMap s hs x.val) / q := by
  let g := F.metric (a + s / q)
  let D := rescaledMetric_connection g (F.connection (a + s / q)) q e.scale_pos
  have h := ((e.ordinaryPullbackFlow hC).connection s).curvatureTensorNorm_eq_of_local_isometry
    D isOpen_univ (rawSpatialMap_smooth e ⟨s, hs⟩).contMDiffOn
    (fun y _ v w => e.ordinaryPullbackFlow_rescaled_inner hC ⟨s, hs⟩ y v w) (mem_univ x)
  rw [h]
  have hscale := Homothety.homothety_curvatureTensorNorm_eq g (rescaledMetric g q e.scale_pos)
    (Diffeomorph.refl (𝓡 3) (F.slice (a + s / q)).carrier ∞) q e.scale_pos
    (by intro y v w; simp [rescaledMetric_inner, mfderiv_id])
    (F.connection (a + s / q)) D (rawSpatialMap e ⟨s, hs⟩ x)
  exact hscale

end PoincareMT.GeneralizedFlowCylinder
