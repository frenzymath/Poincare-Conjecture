import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Restriction.Jets

/-! # Generalized convergence on an included shorter backward window -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupRestriction

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

variable {S : GeneralizedBlowupSequence.{u}} {T T' : ℝ}
  (G : GeneralizedBlowupConvergence S (Ioc (-T) 0)) (hT' : 0 < T') (h : T' < T)

theorem closedWindow_pullback_metric_CInfinity
    (q : G.limit.sliceCarrier.carrier) (j r : ℕ)
    (K : Set (ℝ × EuclideanSpace ℝ (Fin 3))) (hK : IsCompact K)
    (hKU : K ⊆ {p | p ∈ blowupMetricChartDomain (closedWindowLimit G.limit hT' h) q ∧
      (extChartAt (𝓡 3) q).symm p.2 ∈ G.exhaustion.space j})
    (epsilon : ℝ) (hepsilon : 0 < epsilon) :
    ∃ N : ℕ, j ≤ N ∧ ∀ k ≥ N,
      K ⊆ Icc (-(closedWindowExhaustion G.exhaustion hT' h).time k) 0 ×ˢ
        (extChartAt (𝓡 3) q).target ∧
      ∀ a b : Fin 3, ∀ p ∈ K,
        ‖iteratedFDerivWithin ℝ r
            (blowupPullbackCoefficient (L := closedWindowLimit G.limit hT' h)
              (closedWindowCylinder G hT' h k) q a b)
            (Icc (-(closedWindowExhaustion G.exhaustion hT' h).time k) 0 ×ˢ
              (extChartAt (𝓡 3) q).target) p -
          iteratedFDerivWithin ℝ r
            ((closedWindowLimit G.limit hT' h).carrier.coordinateCoefficient q
              (fun t x v w => ((closedWindowLimit G.limit hT' h).flow.metric t).inner x v w) a b)
            (blowupMetricChartDomain (closedWindowLimit G.limit hT' h) q) p‖ < epsilon := by
  have hKUold : K ⊆ {p | p ∈ blowupMetricChartDomain G.limit q ∧
      (extChartAt (𝓡 3) q).symm p.2 ∈ G.exhaustion.space j} := by
    intro p hp
    exact ⟨⟨closedWindow_subset h (hKU hp).1.1, (hKU hp).1.2⟩, (hKU hp).2⟩
  obtain ⟨N, hjN, hN⟩ := G.pullback_metric_CInfinity q j r K hK hKUold epsilon hepsilon
  refine ⟨N, hjN, fun k hk => ?_⟩
  have hKtime : K ⊆ Icc (-(closedWindowExhaustion G.exhaustion hT' h).time k) 0 ×ˢ
      (extChartAt (𝓡 3) q).target := by
    intro p hp
    refine ⟨⟨?_, (hKU hp).1.1.2⟩, (hKU hp).1.2⟩
    change -min T' (G.exhaustion.time k) ≤ p.1
    rcases le_total T' (G.exhaustion.time k) with hle | hle
    · rw [min_eq_left hle]
      exact (hKU hp).1.1.1
    · rw [min_eq_right hle]
      exact ((hN k hk).1 hp).1.1
  refine ⟨hKtime, fun a b p hp => ?_⟩
  have hx := G.exhaustion.space_increasing (hjN.trans hk) (hKU hp).2
  have hsource := cylinder_timeRestriction_jet
    (U := ⟨G.exhaustion.space k, G.exhaustion.space_open k⟩) (G.embedding k)
    (lt_min hT' (G.exhaustion.time_pos k)) (G.exhaustion.time_pos k)
    (min_le_right T' (G.exhaustion.time k)) q a b r p (hKtime hp) hx
  have hlimit := closedWindow_limit_jet G.limit hT' h q a b r p (hKU hp).1
  exact (congrArg₂ (fun x y => ‖x - y‖ < epsilon) hsource hlimit).mpr ((hN k hk).2 a b p hp)

/-- Restriction retains the subsequence, spatial exhaustion and all source
maps, with complete included endpoint slices and their within-domain jets. -/
def closedWindow : GeneralizedBlowupConvergence S (Icc (-T') 0) where
  limit := closedWindowLimit G.limit hT' h
  subsequence := G.subsequence
  subsequence_strictMono := G.subsequence_strictMono
  exhaustion := closedWindowExhaustion G.exhaustion hT' h
  embedding := closedWindowCylinder G hT' h
  base_preserving := fun k hzero =>
    G.base_preserving k (closedWindow_time_subset G.exhaustion hT' h k hzero)
  source_balls_in_image := by
    intro A hA
    filter_upwards [G.source_balls_in_image A hA] with k hk x hx
    obtain ⟨y, hy, hzero, heq⟩ := hk x hx
    refine ⟨y, hy, ⟨?_, le_rfl⟩, heq⟩
    exact neg_nonpos.mpr (lt_min hT' (G.exhaustion.time_pos k)).le
  pullback_metric_CInfinity := closedWindow_pullback_metric_CInfinity G hT' h

end PoincareMT.ControlledBlowupRestriction
