import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Coordinates

/-!
# Jets of captured source-neck coordinates in the limit charts

The source manifolds and necks may vary. Their inverse comparison maps enter
the actual pulled-back ambient metrics, so the metric-isometry equation
bounds the transported coordinates without assuming a neck on the limit.

Reference: Morgan--Tian, Claim 11.6 and Proposition 9.79(3).
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.MetricSurgery

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem exists_transported_centered_neck_jet_bound
    {ι : Type*} {X : ι → Type u}
    [∀ i, TopologicalSpace (X i)] [∀ i, ChartedSpace E (X i)]
    [∀ i, IsManifold (𝓡 3) ∞ (X i)]
    {M : Type v} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    (g : ∀ i, RiemannianMetric 3 (X i)) (N : ∀ i, EpsilonNeck (g i))
    (e : ∀ i, OpenPartialHomeomorph (X i) M)
    (he : ∀ i, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e i) (e i).source)
    (hei : ∀ i, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e i).symm (e i).target)
    (hcapture : ∀ i, (N i).carrier ⊆ (e i).source)
    (hsmall : ∀ i, (N i).epsilon < 1 / 200) (q : M)
    {K : Set M} (hK : IsCompact K) (hKq : K ⊆ (extChartAt (𝓡 3) q).source)
    (hKt : ∀ i, K ⊆ (e i).target)
    (r : ℕ) (hr : 1 ≤ r) (horder : ∀ i, r ≤ ⌊(N i).epsilon⁻¹⌋₊)
    {l u b : ℝ} (hl : 0 < l) (hu : 0 < u) (hb : 0 < b)
    (hscalar : ∀ i, l ≤ (N i).connection.scalarCurvature (N i).center ∧
      (N i).connection.scalarCurvature (N i).center ≤ u)
    (hambient : ∃ C : ℝ, ∀ i j, j ≤ r → ∀ y ∈ (extChartAt (𝓡 3) q) '' K,
      ‖iteratedFDeriv ℝ j ((g i).parametrizedCoefficients
        ((e i).symm ∘ (extChartAt (𝓡 3) q).symm)) y‖ ≤ C)
    (helliptic : ∀ i y, y ∈ (extChartAt (𝓡 3) q) '' K → ∀ w : E,
      b * ‖w‖ ^ 2 ≤ (g i).parametrizedCoefficients
        ((e i).symm ∘ (extChartAt (𝓡 3) q).symm) y w w) :
    ∃ C : ℝ, 1 ≤ C ∧ ∀ i z,
      z.2 ∈ Ioo (-(N i).epsilon⁻¹) (N i).epsilon⁻¹ →
      e i ((N i).coordinate_map z) ∈ K → ∀ j : ℕ, j ≤ r + 1 →
        ‖iteratedFDeriv ℝ j
          ((extChartAt (𝓡 3) q) ∘ e i ∘ centeredNeckLift (N i) z.1 z.2) 0‖ ≤ C := by
  let c := extChartAt (𝓡 3) q
  let T : Set E := c '' K
  let V := fun i => c.target ∩ c.symm ⁻¹' (e i).target
  let ψ := fun i => (e i).symm ∘ c.symm
  have hT : IsCompact T := hK.image_of_continuousOn ((continuousOn_extChartAt q).mono hKq)
  have hTV (i : ι) : T ⊆ V i := by
    rintro y ⟨x, hx, rfl⟩
    refine ⟨c.map_source (hKq hx), ?_⟩
    simpa only [mem_preimage, c.left_inv (hKq hx)] using hKt i hx
  have hV (i : ι) : IsOpen (V i) :=
    (continuousOn_extChartAt_symm q).isOpen_inter_preimage
      (isOpen_extChartAt_target q) (e i).open_target
  have hψ (i : ι) (y : E) (hy : y ∈ V i) : ContMDiffAt (𝓡 3) (𝓡 3) ∞ (ψ i) y :=
    ((hei i).contMDiffAt ((e i).open_target.mem_nhds hy.2)).comp y
      ((contMDiffOn_extChartAt_symm (n := ∞) q).contMDiffAt
        ((isOpen_extChartAt_target q).mem_nhds hy.1))
  let Q := fun i => (N i).connection.scalarCurvature (N i).center
  let B₀ := fun i => (normalizedNeckMetric (N i)).parametrizedCoefficients (ψ i)
  obtain ⟨CB, hCB⟩ := hambient
  have hBj (i : ι) (j : ℕ) (hj : j ≤ r) (y : E) (hy : y ∈ T) :
      ‖iteratedFDeriv ℝ j (B₀ i) y‖ ≤ u * max CB 0 := by
    have heq : B₀ i = fun y => Q i • (g i).parametrizedCoefficients (ψ i) y := by
      funext y
      ext w z
      rfl
    have hg := (g i).contDiffAt_parametrizedCoefficients (hψ i y (hTV i hy))
    rw [heq, iteratedFDeriv_const_smul_apply' (hg.of_le (by exact_mod_cast le_top))]
    let : IsBoundedSMul ℝ (E →L[ℝ] E →L[ℝ] ℝ) :=
      NormedSpace.toIsBoundedSMul (𝕜 := ℝ) («E» := E →L[ℝ] E →L[ℝ] ℝ)
    apply (ContinuousMultilinearMap.opNorm_smul_le _ _).trans
    rw [Real.norm_of_nonneg (N i).scalar_center_pos.le]
    exact mul_le_mul (hscalar i).2 ((hCB i j hj y hy).trans (le_max_left _ _))
      (norm_nonneg _) hu.le
  have hBlower (i : ι) (y : E) (hy : y ∈ T) (w : E) :
      (l * b) * ‖w‖ ^ 2 ≤ B₀ i y w w := by
    change (l * b) * ‖w‖ ^ 2 ≤ Q i * (g i).parametrizedCoefficients (ψ i) y w w
    have hnonneg := (mul_nonneg hb.le (sq_nonneg ‖w‖)).trans (helliptic i y hy w)
    calc
      (l * b) * ‖w‖ ^ 2 = l * (b * ‖w‖ ^ 2) := mul_assoc _ _ _
      _ ≤ l * (g i).parametrizedCoefficients (ψ i) y w w :=
        mul_le_mul_of_nonneg_left (helliptic i y hy w) hl.le
      _ ≤ Q i * (g i).parametrizedCoefficients (ψ i) y w w :=
        mul_le_mul_of_nonneg_right (hscalar i).1 hnonneg
  let Z := Σ i : ι, {z : RoundCylinderSpace //
    z.2 ∈ Ioo (-(N i).epsilon⁻¹) (N i).epsilon⁻¹ ∧ e i ((N i).coordinate_map z) ∈ K}
  let a := fun z : Z => centeredNeckLift (N z.1) z.2.1.1 z.2.1.2
  let d := fun z : Z => centeredNeckDomain (N z.1) z.2.1.2
  let f := fun z : Z => c ∘ e z.1 ∘ a z
  let U := fun z : Z => d z ∩ (e z.1 ∘ a z) ⁻¹' c.source
  let A := fun z : Z => (normalizedNeckMetric (N z.1)).parametrizedCoefficients (a z)
  let B := fun z : Z => B₀ z.1
  have hds (z : Z) : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e z.1 ∘ a z) (d z) :=
    (he z.1).comp (fun y hy =>
      (centeredNeckLift_contMDiffAt (N z.1) z.2.1.1 z.2.1.2 hy).contMDiffWithinAt)
      (fun y hy => hcapture z.1 (centeredNeckLift_mem (N z.1) z.2.1.1 z.2.1.2 hy))
  have hU (z : Z) : IsOpen (U z) := (hds z).continuousOn.isOpen_inter_preimage
    (centeredNeckDomain_isOpen (N z.1) z.2.1.2) (isOpen_extChartAt_source q)
  have h0 (z : Z) : (0 : E) ∈ U z := by
    refine ⟨zero_mem_centeredNeckDomain (N z.1) z.2.2.1, ?_⟩
    simpa only [a, Function.comp_apply, mem_preimage, centeredNeckLift_zero] using hKq z.2.2.2
  have hfs (z : Z) (y : E) (hy : y ∈ U z) : ContDiffAt ℝ ∞ (f z) y := by
    apply contMDiffAt_iff_contDiffAt.mp
    have hyc : (e z.1 ∘ a z) y ∈ (extChartAt (𝓡 3) q).source := hy.2
    exact (contMDiffAt_extChartAt' (by simpa only [extChartAt_source] using hyc)).comp y
      ((hds z).contMDiffAt ((centeredNeckDomain_isOpen (N z.1) z.2.1.2).mem_nhds hy.1))
  have hmap (z : Z) : f z 0 ∈ T := by
    simpa only [f, a, Function.comp_apply, centeredNeckLift_zero] using
      mem_image_of_mem c z.2.2.2
  have hmetric (z : Z) : ∀ᶠ y in 𝓝 (0 : E), ∀ w v,
      A z y w v = B z (f z y) (fderiv ℝ (f z) y w) (fderiv ℝ (f z) y v) := by
    filter_upwards [(hU z).mem_nhds (h0 z)] with y hy
    have hfy : f z y ∈ V z.1 := by
      refine ⟨c.map_source hy.2, ?_⟩
      change c.symm (c (e z.1 (a z y))) ∈ (e z.1).target
      have hyc : e z.1 (a z y) ∈ c.source := hy.2
      rw [c.left_inv hyc]
      exact (e z.1).map_source
        (hcapture z.1 (centeredNeckLift_mem (N z.1) z.2.1.1 z.2.1.2 hy.1))
    have hcomp : ψ z.1 ∘ f z =ᶠ[𝓝 y] a z := by
      filter_upwards [(hU z).mem_nhds hy] with w hw
      dsimp only [ψ, f, Function.comp_apply]
      have hwc : e z.1 (a z w) ∈ c.source := hw.2
      rw [c.left_inv hwc, (e z.1).left_inv
        (hcapture z.1 (centeredNeckLift_mem (N z.1) z.2.1.1 z.2.1.2 hw.1))]
    have hh := (normalizedNeckMetric (N z.1)).parametrizedCoefficients_comp_of_eventuallyEq
      ((hψ z.1 (f z y) hfy).mdifferentiableAt (by simp))
      ((hfs z y hy).differentiableAt (by simp)) hcomp
    intro w v
    exact congrArg (fun H : E →L[ℝ] E →L[ℝ] ℝ => H w v) hh.symm
  obtain ⟨CA, _, hCA⟩ := exists_normalizedNeck_centered_coefficient_jet_bounds.{u} r
  obtain ⟨C₀, hC₀⟩ := hT.exists_bound_of_continuousOn continuousOn_id
  obtain ⟨C, hC, hbound⟩ := CoordinateTransition.exists_finite_metric_isometry_jet_bound_at
    (A := A) (B := B) (f := f) (fun _z : Z => (0 : E))
    (fun z => Filter.Eventually.mono ((hU z).mem_nhds (h0 z)) fun y hy => hfs z y hy)
    (fun z => Filter.Eventually.mono ((centeredNeckDomain_isOpen (N z.1) z.2.1.2).mem_nhds
      (zero_mem_centeredNeckDomain (N z.1) z.2.2.1)) fun y hy =>
        (normalizedNeckMetric (N z.1)).contDiffAt_parametrizedCoefficients
          (centeredNeckLift_contMDiffAt (N z.1) z.2.1.1 z.2.1.2 hy))
    (fun z => Filter.Eventually.mono ((hV z.1).mem_nhds (hTV z.1 (hmap z))) fun y hy =>
      (normalizedNeckMetric (N z.1)).contDiffAt_parametrizedCoefficients (hψ z.1 y hy))
    r hr
    ⟨CA, fun z j hj => hCA (N z.1) j hj (hj.trans (horder z.1)) z.2.1 z.2.2.1⟩
    ⟨u * max CB 0, fun z j hj => hBj z.1 j hj (f z 0) (hmap z)⟩
    (by norm_num : (0 : ℝ) < 1 / 2) (mul_pos hl hb)
    (fun z w => normalizedNeckMetric_centeredCoefficients_lower
      (N z.1) (hsmall z.1) z.2.1 z.2.2.1 w)
    (fun z w => hBlower z.1 (f z 0) (hmap z) w)
    ⟨C₀, fun z => hC₀ (f z 0) (hmap z)⟩
    (fun z => Eventually.of_forall fun y w v => (normalizedNeckMetric (N z.1)).symm _ _ _)
    hmetric
  exact ⟨C, hC, fun i z hz hKz j hj => hbound ⟨i, z, hz, hKz⟩ j hj⟩

end PoincareMT.MetricSurgery
