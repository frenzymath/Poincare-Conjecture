import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.CurvatureNorm
import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Terminal.Completeness

/-!
# Completeness of the controlled included endpoint
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal NNReal

universe u

namespace PoincareMT

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space

/-- Curvature control on an actual closed slab propagates completeness to
its right endpoint; the ambient flow domain can include additional times. -/
theorem RicciFlow.metricComplete_of_closed_slab_curvature_bound
    {n : ℕ} (C : FlowCarrier n) {J : Set ℝ} (F : RicciFlow n C.carrier J)
    (p : C.carrier) {a b B : ℝ} (hab : a ≤ b) (hJ : Icc a b ⊆ J)
    (hcomplete : C.metricComplete (F.metric a))
    (hcurv : ∀ t ∈ Icc a b, ∀ x, (F.connection t).curvatureTensorNorm x ≤ B) :
    C.metricComplete (F.metric b) := by
  let d₀ := (C.metricEMetricSpace (F.metric a)).toPseudoEMetricSpace
  let d₁ := (C.metricEMetricSpace (F.metric b)).toPseudoEMetricSpace
  change @CompleteSpace C.carrier d₁.toUniformSpace
  apply Poincare.completeSpace_of_continuous_local_edist_bound d₀ d₁ p hcomplete
  · change @Continuous C.carrier C.carrier C.topologicalSpace C.topologicalSpace id
    exact continuous_id
  · exact fun x => @Poincare.edist_ne_top_of_preconnected C.carrier d₁
      (C.preconnected_metricEMetricSpace (F.metric b)) x p
  · intro R
    let r : ℝ := R + 1
    have hr : 0 < r := by dsimp only [r]; positivity
    let L : ℝ := (n : ℝ) ^ 3 * B
    let Q : ℝ := Real.exp (L * |a - b|)
    refine ⟨Real.toNNReal Q, fun x y hx hy => ?_⟩
    have hRic : ∀ t ∈ Icc a b, ∀ z ∈ (F.metric b).ball p (3 * r),
        ∀ v : C.tangent z,
          |(F.connection t).ricci z v v| ≤ L * (F.metric t).inner z v v := by
      intro t ht z _ v
      have hQ : 0 ≤ (F.metric t).inner z v v := by
        by_cases hv : v = 0
        · subst v; simp
        · exact ((F.metric t).pos z v hv).le
      have hnorm := (F.connection t).abs_ricci_quadratic_le_curvatureTensorNorm z v
      have hdim : Module.finrank ℝ (TangentSpace (𝓡 n) z) = n := finrank_euclideanSpace_fin
      simp only [Fintype.card_fin, hdim] at hnorm
      exact hnorm.trans (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (hcurv t ht z) (by positivity)) hQ)
    have hR : (R : ℝ≥0∞) < ENNReal.ofReal r := by
      rw [← ENNReal.ofReal_coe_nnreal]
      exact ENNReal.ofReal_lt_ofReal_iff hr |>.mpr (by dsimp only [r]; linarith)
    have hmem (z : C.carrier) (hz : d₁.edist z p ≤ R) : z ∈ (F.metric b).ball p r := by
      change d₁.edist p z < ENNReal.ofReal r
      rw [d₁.edist_comm]
      exact hz.trans_lt hR
    exact F.edist_le_exp_mul_of_ricci_bound (convex_Icc a b) hJ p r L hr
      (show b ∈ Icc a b from ⟨hab, le_rfl⟩)
      (show a ∈ Icc a b from ⟨le_rfl, hab⟩) hRic (hmem x hx) (hmem y hy)

namespace ControlledBlowupCompactness

attribute [local instance] FlowCarrier.measurableSpace FlowCarrier.borelSpace
  FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

/-- The actual extended controlled flow is complete at the included endpoint. -/
theorem terminal_metricComplete
    {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
    {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
    {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
    (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
    (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
    (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0)) :
    G.limitCarrier.metricComplete (F.metric (T / 2)) := by
  apply F.metricComplete_of_closed_slab_curvature_bound G.limitCarrier G.limitFlow.base
    (a := 0) (B := B) (by positivity) (fun t ht => ⟨by linarith [ht.1], ht.2⟩)
  · rw [hF 0 ⟨by linarith, by linarith⟩]
    exact hcomplete
  · exact fun t ht x => terminal_curvatureTensorNorm_le G F hF P04 hB hAr hcompact
      hcomplete ht x

end ControlledBlowupCompactness
end PoincareMT
