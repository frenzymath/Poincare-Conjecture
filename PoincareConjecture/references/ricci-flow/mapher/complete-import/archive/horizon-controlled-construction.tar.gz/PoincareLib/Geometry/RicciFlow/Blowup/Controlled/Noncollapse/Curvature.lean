import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Curvature.SpacetimeJets
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Curvature.TerminalJets

/-!
# Full-curvature convergence on compact spacetime sets

The actual normalized source curvature norm is continuous in the converging
metric jets. This includes moving times through the terminal endpoint and
gives the uniform strict bound needed for parabolic noncollapse inheritance.

Reference: Morgan--Tian, Theorem 11.8, pp. 272--278.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable
attribute [local instance] normedAddCommGroupTangentSpaceVectorSpace
  normedSpaceTangentSpaceVectorSpace

variable {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
  (G : GeneralizedBlowupConvergence S J.domain)

/-- Actual normalized full curvature converges at moving spacetime points
in a compact coordinate set, along every cofinal source subsequence. -/
theorem tendsto_normalizedSource_curvature_norm_in_chart
    (p : G.limit.carrier.carrier) {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))}
    (hK : IsCompact K) (hKc : K ⊆ J.domain ×ˢ (extChartAt (𝓡 3) p).target)
    {z : ℕ → ℝ × EuclideanSpace ℝ (Fin 3)} {y : ℝ × EuclideanSpace ℝ (Fin 3)}
    (hz : ∀ k, z k ∈ K) (hy : y ∈ K) (hzy : Tendsto z atTop (𝓝 y))
    {σ : ℕ → ℕ} (hσ : Tendsto σ atTop atTop)
    (ht : ∀ k, (z k).1 ∈ Icc (-G.exhaustion.time (σ k)) 0) :
    Tendsto (fun k => (G.normalizedSourceConnection (σ k) (z k).1).curvatureTensorNorm
      ((G.embedding (σ k)).forward (z k).1 (ht k) ((extChartAt (𝓡 3) p).symm (z k).2))) atTop
      (𝓝 ((G.limit.flow.connection y.1).curvatureTensorNorm ((extChartAt (𝓡 3) p).symm y.2))) := by
  let c := extChartAt (𝓡 3) p
  obtain ⟨g, D, V, hVo, hyV, _, heq⟩ := G.limit.carrier.exists_local_coordinate_realization
    (G.limit.flow.metric y.1) p y.1 y.2 (hKc hy).2
  have hg := Filter.Eventually.mono (hVo.mem_nhds hyV) heq
  have hc : ContinuousOn c.symm c.target :=
    (contMDiffOn_extChartAt_symm (I := 𝓡 3) (n := ∞) p).continuousOn
  have hcoord : ContinuousOn (fun w : ℝ × EuclideanSpace ℝ (Fin 3) => c.symm w.2) K :=
    hc.comp continuous_snd.continuousOn (fun w hw => (hKc hw).2)
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset (hK.image_of_continuousOn hcoord)
  let φ := fun k => (G.embedding (σ k)).forward (z k).1 (ht k) ∘ c.symm
  have hφ : ∀ᶠ k in atTop, ∀ᶠ v in 𝓝 (z k).2,
      ContMDiffAt (𝓡 3) (𝓡 3) ∞ (φ k) v ∧
        Function.Injective (mfderiv (𝓡 3) (𝓡 3) (φ k) v) := by
    filter_upwards [hσ.eventually (eventually_ge_atTop j)] with k hk
    let W := c.target ∩ c.symm ⁻¹' G.exhaustion.space (σ k)
    have hW : IsOpen W := hc.isOpen_inter_preimage (isOpen_extChartAt_target p)
      (G.exhaustion.space_open (σ k))
    have hzW : (z k).2 ∈ W := ⟨(hKc (hz k)).2,
      G.exhaustion.space_increasing hk (hj (mem_image_of_mem _ (hz k)))⟩
    filter_upwards [hW.mem_nhds hzW] with v hv
    have hcv : ContMDiffAt (𝓡 3) (𝓡 3) ∞ c.symm v :=
      (contMDiffWithinAt_extChartAt_symm_target (n := ∞) p hv.1).contMDiffAt
        (extChartAt_target_mem_nhds' hv.1)
    have he := ((G.embedding (σ k)).forward_smooth (z k).1 (ht k)).contMDiffAt
      ((G.exhaustion.space_open (σ k)).mem_nhds hv.2)
    refine ⟨he.comp v hcv, ?_⟩
    change Function.Injective
      (mfderiv (𝓡 3) (𝓡 3) ((G.embedding (σ k)).forward (z k).1 (ht k) ∘ c.symm) v)
    rw [mfderiv_comp v (he.mdifferentiableAt (by simp)) (hcv.mdifferentiableAt (by simp))]
    have hi : (mfderiv (𝓡 3) (𝓡 3) c.symm v).IsInvertible := by
      simpa only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] using
        isInvertible_mfderivWithin_extChartAt_symm hv.1
    exact ((G.embedding (σ k)).forward_mfderiv_bijective (G.exhaustion.space_open (σ k))
      (z k).1 (ht k) hv.2).injective.comp hi.injective
  have hjets (r : ℕ) (_hr : r ≤ 2) (a b : Fin 3) :
      Tendsto (fun k => iteratedFDeriv ℝ r (fun v =>
        (G.normalizedSourceMetric (σ k) (z k).1).pullbackCoefficients (φ k) v
          (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) (z k).2)
        atTop (𝓝 (iteratedFDeriv ℝ r (fun v => g.inner v
          (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) y.2)) := by
    rw [G.limit.carrier.iteratedFDeriv_coordinateCoefficient_eq_of_eventuallyEq
      p (fun _ v a b => (G.limit.flow.metric y.1).inner v a b) y.1 y.2 g hg r a b]
    exact G.tendsto_normalizedSourceMetric_chart_jets p hK hKc hz hy hzy hσ ht r a b
  have hconv := LeviCivitaData.tendsto_curvatureTensorNorm_of_moving_scalar_pullback_jets
    (fun k => G.normalizedSourceConnection (σ k) (z k).1) φ D (fun k => (z k).2) y.2 hφ hjets
  rw [G.limit.carrier.curvatureTensorNorm_eq_of_coordinate_germ
    (G.limit.flow.metric y.1) (G.limit.flow.connection y.1) p y.1 y.2 (hKc hy).2 g D hg] at hconv
  exact hconv

/-- Actual normalized source full curvature converges along every
convergent sequence of retained spacetime points. -/
theorem tendsto_normalizedSource_curvature_norm
    {z : ℕ → ℝ × G.limit.carrier.carrier} {y : ℝ × G.limit.carrier.carrier}
    (hz : ∀ k, (z k).1 ∈ J.domain) (hy : y.1 ∈ J.domain)
    (hzy : Tendsto z atTop (𝓝 y)) {σ : ℕ → ℕ} (hσ : Tendsto σ atTop atTop)
    (ht : ∀ k, (z k).1 ∈ Icc (-G.exhaustion.time (σ k)) 0) :
    Tendsto (fun k => (G.normalizedSourceConnection (σ k) (z k).1).curvatureTensorNorm
      ((G.embedding (σ k)).forward (z k).1 (ht k) (z k).2)) atTop
      (𝓝 ((G.limit.flow.connection y.1).curvatureTensorNorm y.2)) := by
  classical
  let c := extChartAt (𝓡 3) y.2
  have hyc : y.2 ∈ c.source := mem_extChartAt_source y.2
  have hevent : ∀ᶠ k in atTop, (z k).2 ∈ c.source :=
    (continuousAt_snd.tendsto.comp hzy).eventually (extChartAt_source_mem_nhds y.2)
  let w := fun k => if (z k).2 ∈ c.source then ((z k).1, c (z k).2) else (0, c y.2)
  have hw : Tendsto w atTop (𝓝 (y.1, c y.2)) := by
    have hh := (continuousAt_fst.prodMk
      ((continuousAt_extChartAt (I := 𝓡 3) y.2).comp continuousAt_snd)).tendsto.comp hzy
    apply hh.congr'
    filter_upwards [hevent] with k hk
    change ((z k).1, c (z k).2) = w k
    exact (if_pos hk).symm
  let K := insert (y.1, c y.2) (range w)
  have hK : IsCompact K := hw.isCompact_insert_range
  have hKc : K ⊆ J.domain ×ˢ c.target := by
    rintro v (rfl | ⟨k, rfl⟩)
    · exact ⟨hy, c.map_source hyc⟩
    · by_cases hk : (z k).2 ∈ c.source
      · simpa only [w, if_pos hk, mem_prod] using And.intro (hz k) (c.map_source hk)
      · simpa only [w, if_neg hk, mem_prod] using And.intro G.limit.zero_mem (c.map_source hyc)
  have hwt (k : ℕ) : (w k).1 ∈ Icc (-G.exhaustion.time (σ k)) 0 := by
    by_cases hk : (z k).2 ∈ c.source
    · simpa only [w, if_pos hk] using ht k
    · simpa only [w, if_neg hk] using G.zero_mem_cylinder (σ k)
  have hc := G.tendsto_normalizedSource_curvature_norm_in_chart y.2 hK hKc
    (fun k => mem_insert_of_mem _ (mem_range_self k)) (mem_insert _ _) hw hσ hwt
  rw [c.left_inv hyc] at hc
  apply hc.congr'
  filter_upwards [hevent] with k hk
  have heq (v : ℝ × EuclideanSpace ℝ (Fin 3))
      (hv : v.1 ∈ Icc (-G.exhaustion.time (σ k)) 0)
      (heq : v = ((z k).1, c (z k).2)) :
      (G.normalizedSourceConnection (σ k) v.1).curvatureTensorNorm
        ((G.embedding (σ k)).forward v.1 hv (c.symm v.2)) =
      (G.normalizedSourceConnection (σ k) (z k).1).curvatureTensorNorm
        ((G.embedding (σ k)).forward (z k).1 (ht k) (z k).2) := by
    subst v
    exact congrArg (fun x => (G.normalizedSourceConnection (σ k) (z k).1).curvatureTensorNorm
      ((G.embedding (σ k)).forward (z k).1 (ht k) x)) (c.left_inv hk)
  exact heq (w k) (hwt k) (by simp only [w, if_pos hk])

/-- A strict full-curvature upper bound transfers uniformly on every compact
subset of the actual limiting spacetime. -/
theorem eventually_normalizedSource_curvature_norm_lt_on_compact
    {K : Set (ℝ × G.limit.carrier.carrier)} (hK : IsCompact K)
    (hKJ : ∀ z ∈ K, z.1 ∈ J.domain) {B : ℝ}
    (hB : ∀ z ∈ K, (G.limit.flow.connection z.1).curvatureTensorNorm z.2 < B) :
    ∀ᶠ k in atTop, ∀ z ∈ K, ∀ ht : z.1 ∈ Icc (-G.exhaustion.time k) 0,
      (G.normalizedSourceConnection k z.1).curvatureTensorNorm
        ((G.embedding k).forward z.1 ht z.2) < B := by
  classical
  by_contra h
  have hf : ∃ᶠ k in atTop, ∃ z ∈ K, ∃ ht : z.1 ∈ Icc (-G.exhaustion.time k) 0,
      B ≤ (G.normalizedSourceConnection k z.1).curvatureTensorNorm
        ((G.embedding k).forward z.1 ht z.2) := by
    simpa only [not_forall, not_lt, exists_prop] using (not_eventually.mp h)
  obtain ⟨σ, hσ, hbad⟩ := extraction_of_frequently_atTop hf
  choose z hz ht hzb using hbad
  obtain ⟨y, hy, τ, hτ, hzy⟩ := hK.tendsto_subseq hz
  have hc := G.tendsto_normalizedSource_curvature_norm (fun k => hKJ _ (hz (τ k)))
    (hKJ _ hy) hzy (hσ.tendsto_atTop.comp hτ.tendsto_atTop) (fun k => ht (τ k))
  obtain ⟨k, hk⟩ := (hc.eventually (Iio_mem_nhds (hB y hy))).exists
  exact (not_lt_of_ge (hzb (τ k))) hk

end PoincareMT.GeneralizedBlowupConvergence
