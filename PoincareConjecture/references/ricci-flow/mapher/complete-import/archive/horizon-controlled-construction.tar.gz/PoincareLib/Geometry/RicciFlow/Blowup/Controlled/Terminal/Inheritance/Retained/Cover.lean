import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Retained.Necks
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Retained.TimeNeighborhood
import PoincareLib.Geometry.Riemannian.Compactness.IntrinsicMetric

/-!
# A common nearby-neck cover at all retained times

Every point above the fixed normalized scalar cutoff has an actual small
neck nearby. Both its scalar ratio and its distance from the selected point
use one constant chosen before the time and point.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledTerminal

theorem inverse_sqrt_half_le_twice {R : ℝ} (hR : 0 < R) :
    (R / 2) ^ (-1 / 2 : ℝ) ≤ 2 * R ^ (-1 / 2 : ℝ) := by
  have htwo : (2 : ℝ) ^ (-1 / 2 : ℝ) = (Real.sqrt 2)⁻¹ := by
    rw [neg_div, Real.rpow_neg (by norm_num), ← Real.sqrt_eq_rpow]
  rw [Real.div_rpow hR.le (by norm_num), htwo, div_inv_eq_mul]
  have hroot : Real.sqrt 2 ≤ 2 := Real.sqrt_le_iff.mpr ⟨by norm_num, by norm_num⟩
  calc
    R ^ (-1 / 2 : ℝ) * Real.sqrt 2 ≤ R ^ (-1 / 2 : ℝ) * 2 :=
      mul_le_mul_of_nonneg_left hroot (Real.rpow_nonneg hR.le (-1 / 2 : ℝ))
    _ = 2 * R ^ (-1 / 2 : ℝ) := mul_comm _ _

end PoincareMT.ControlledTerminal

namespace PoincareMT.M30CommonBlowupControls

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem retained_neck_scalar_and_center_control
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu T : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (hNC : ¬ IsCompact (univ : Set G.limit.carrier.carrier))
    (hsmall : epsilon < 1 / 200)
    (hround : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold)
    {epsilon' : ℝ} (haccuracy : epsilon < epsilon') (hepsilon' : epsilon' < 1 / 2) :
    ∀ t ∈ Ioc (-T) 0, ∀ x : G.limit.carrier.carrier,
      4 < (G.limit.flow.connection t).scalarCurvature x →
      ∃ N : EpsilonNeck (G.limit.flow.metric t),
        N.epsilon = epsilon' ∧ N.connection = G.limit.flow.connection t ∧
        ((G.limit.flow.metric t).edist x N.center).toReal ≤
          (4 * max C 1) * (G.limit.flow.connection t).scalarCurvature x ^ (-1 / 2 : ℝ) ∧
        (G.limit.flow.connection t).scalarCurvature x ≤
          (4 * max C 1) * (G.limit.flow.connection t).scalarCurvature N.center := by
  intro t ht x hx
  have hxpos : 0 < (G.limit.flow.connection t).scalarCurvature x :=
    (by norm_num : (0 : ℝ) < 4).trans hx
  obtain ⟨a, hat, hI, hpositive⟩ := G.limit.exists_left_scalar_positive_interval ht x hxpos
  have hT : 0 < T := by linarith [ht.1, ht.2]
  let J : SpacetimeInterval := ⟨Ioc (-T) 0, ordConnected_Ioc,
    ⟨-T / 2, ⟨by linarith, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩⟩
  obtain ⟨N, hNe, hND, hNr, hNc⟩ := H.exists_nearby_neck_at_retained_time
    (J := J) G hNC hsmall hround haccuracy hepsilon' hat ht.2 hI x hpositive hx
  let g := G.limit.flow.metric t
  let : ConnectedSpace G.limit.carrier.carrier := G.limit.connectedSpace
  let : MetricSpace G.limit.carrier.carrier := g.toMetricSpace
  have hdist : (g.edist x N.center).toReal ≤
      2 * max C 1 * ((G.limit.flow.connection t).scalarCurvature x / 2) ^ (-1 / 2 : ℝ) := by
    rw [← g.toMetricSpace_ball] at hNc
    have hh := Metric.mem_closedBall.mp (Metric.closure_ball_subset_closedBall hNc)
    simpa only [dist_comm, RiemannianMetric.toMetricSpace_dist] using hh
  have hC : 0 < max C 1 := lt_max_of_lt_right zero_lt_one
  refine ⟨N, hNe, hND, ?_, ?_⟩
  · apply hdist.trans
    have hh := mul_le_mul_of_nonneg_left (ControlledTerminal.inverse_sqrt_half_le_twice hxpos)
      (by positivity : 0 ≤ 2 * max C 1)
    nlinarith
  · have hc : 0 < (G.limit.flow.connection t).scalarCurvature N.center :=
      hND ▸ N.scalar_center_pos
    exact hNr.trans (mul_le_mul_of_nonneg_right (by nlinarith) hc.le)

end PoincareMT.M30CommonBlowupControls
