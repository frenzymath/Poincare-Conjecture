import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Construction
import PoincareLib.Geometry.Manifold.OpenEmbedding
import PoincareLib.Geometry.Manifold.RegularLevel.OpenInclusion

/-! # Coordinate-ball realizations of the complete boundary metric -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledBlowupBoundary

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space

variable {n : ℕ} (C : FlowCarrier n)

def chartMap (q : C.carrier) (U : Opens (EuclideanSpace ℝ (Fin n))) : U → C.carrier :=
  fun x => (extChartAt (𝓡 n) q).symm x

theorem chartMap_isLocalDiffeomorph (q : C.carrier)
    (U : Opens (EuclideanSpace ℝ (Fin n))) (hU : (U : Set _) ⊆ (extChartAt (𝓡 n) q).target) :
    IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (chartMap C q U) := by
  let d : PartialDiffeomorph (𝓡 n) (𝓡 n) C.carrier (EuclideanSpace ℝ (Fin n)) ∞ :=
    { toPartialEquiv := (chartAt (EuclideanSpace ℝ (Fin n)) q).toPartialEquiv
      open_source := (chartAt (EuclideanSpace ℝ (Fin n)) q).open_source
      open_target := (chartAt (EuclideanSpace ℝ (Fin n)) q).open_target
      contMDiffOn_toFun := contMDiffOn_chart
      contMDiffOn_invFun := contMDiffOn_chart_symm }
  intro x
  have hx : (x : EuclideanSpace ℝ (Fin n)) ∈ d.target := by
    simpa only [extChartAt_target, modelWithCornersSelf_coe,
      modelWithCornersSelf_coe_symm, preimage_id, range_id, inter_univ] using hU x.property
  exact (Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 n) U x).comp (𝓡 n)
    C.carrier (d.symm.isLocalDiffeomorphAt (𝓡 n) (𝓡 n) ∞ hx)

theorem chartMap_mfderiv (q : C.carrier)
    (U : Opens (EuclideanSpace ℝ (Fin n))) (hU : (U : Set _) ⊆ (extChartAt (𝓡 n) q).target) (x : U) :
    mfderiv (𝓡 n) (𝓡 n) (chartMap C q U) x =
      mfderiv (𝓡 n) (𝓡 n) (extChartAt (𝓡 n) q).symm (x : EuclideanSpace ℝ (Fin n)) := by
  have hc := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q (hU x.property)).contMDiffAt
    (extChartAt_target_mem_nhds' (hU x.property))
  exact Poincare.Geometry.Manifold.RegularLevel.mfderiv_opens_restrict U
    (extChartAt (𝓡 n) q).symm (x := x) (hc.mdifferentiableAt (by simp))

/-- Retain the local extensions realizing the boundary, including their
agreement with the old metric family on the overlapping time interval. -/
theorem exists_complete_boundary_metric_with_retained_chart_extensions
    (p : C.carrier) {T : ℝ} (hT : 0 < T)
    (g : ℝ → C.metric) (hcomplete : C.metricComplete (g 0))
    (hext : ∀ q : C.carrier, ∃ rho V : ℝ, 0 < rho ∧ T < V ∧
      ball (extChartAt (𝓡 n) q q) rho ⊆ (extChartAt (𝓡 n) q).target ∧
      let U : Opens (EuclideanSpace ℝ (Fin n)) := ⟨ball (extChartAt (𝓡 n) q q) rho, isOpen_ball⟩
      ∃ F : RicciFlow n U (Icc (-V) 0),
        (∀ t ∈ Icc (-V) 0, ∀ x : U, (F.connection t).NonnegativeCurvatureOperator x) ∧
        ∀ t ∈ Ioc (-T) 0, ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
          (F.metric t).inner x v w = (g t).pullbackCoefficients (extChartAt (𝓡 n) q).symm x v w) :
    ∃ gBoundary : C.metric,
      C.metricComplete gBoundary ∧
      (∀ y, gBoundary.leviCivitaData.NonnegativeCurvatureOperator y) ∧
      (∀ y v, (g 0).inner y v v ≤ gBoundary.inner y v v) ∧
      ∀ q : C.carrier, ∃ rho V : ℝ, 0 < rho ∧ T < V ∧
        ball (extChartAt (𝓡 n) q q) rho ⊆ (extChartAt (𝓡 n) q).target ∧
        let U : Opens (EuclideanSpace ℝ (Fin n)) := ⟨ball (extChartAt (𝓡 n) q q) rho, isOpen_ball⟩
        ∃ F : RicciFlow n U (Icc (-V) 0),
          (∀ t ∈ Icc (-V) 0, ∀ x : U, (F.connection t).NonnegativeCurvatureOperator x) ∧
          (∀ t ∈ Ioc (-T) 0, ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
            (F.metric t).inner x v w = (g t).pullbackCoefficients (extChartAt (𝓡 n) q).symm x v w) ∧
          ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
            (F.metric (-T)).inner x v w = gBoundary.pullbackCoefficients (extChartAt (𝓡 n) q).symm x v w := by
  classical
  choose rho V hrho hV hchart F hnonnegative hpres using hext
  let U (q : C.carrier) : Opens (EuclideanSpace ℝ (Fin n)) :=
    ⟨ball (extChartAt (𝓡 n) q q) (rho q), isOpen_ball⟩
  let maps := fun q => chartMap C q (U q)
  have hmaps : ∀ q, IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (maps q) :=
    fun q => chartMap_isLocalDiffeomorph C q (U q) (hchart q)
  have hcover : ∀ y, ∃ q x, maps q x = y := by
    intro y
    refine ⟨y, ⟨extChartAt (𝓡 n) y y, mem_ball_self (hrho y)⟩, ?_⟩
    exact (extChartAt (𝓡 n) y).left_inv (mem_extChartAt_source y)
  have hpres' : ∀ q, ∀ t ∈ Ioc (-T) 0, ∀ (x : U q) (a b : TangentSpace (𝓡 n) x),
      ((F q).metric t).inner x a b = (g t).inner (maps q x)
        (mfderiv (𝓡 n) (𝓡 n) (maps q) x a) (mfderiv (𝓡 n) (𝓡 n) (maps q) x b) := by
    intro q t ht x a b
    rw [show mfderiv (𝓡 n) (𝓡 n) (maps q) x = _ from chartMap_mfderiv C q (U q) (hchart q) x]
    exact hpres q t ht x a b
  obtain ⟨gBoundary, hc, hn, hle, hboundary, _⟩ := exists_complete_boundary_metric C p hT V hV F g hcomplete
    maps hmaps hcover hpres' hnonnegative
  refine ⟨gBoundary, hc, hn, hle, ?_⟩
  intro q
  refine ⟨rho q, V q, hrho q, hV q, hchart q, F q, hnonnegative q, hpres q, ?_⟩
  intro x a b
  have hz := hboundary q x a b
  rw [show mfderiv (𝓡 n) (𝓡 n) (maps q) x = _ from chartMap_mfderiv C q (U q) (hchart q) x] at hz
  exact hz

theorem exists_complete_boundary_metric_of_chart_extensions
    (p : C.carrier) {T : ℝ} (hT : 0 < T)
    (g : ℝ → C.metric) (hcomplete : C.metricComplete (g 0))
    (hext : ∀ q : C.carrier, ∃ rho V : ℝ, 0 < rho ∧ T < V ∧
      ball (extChartAt (𝓡 n) q q) rho ⊆ (extChartAt (𝓡 n) q).target ∧
      let U : Opens (EuclideanSpace ℝ (Fin n)) := ⟨ball (extChartAt (𝓡 n) q q) rho, isOpen_ball⟩
      ∃ F : RicciFlow n U (Icc (-V) 0),
        (∀ t ∈ Icc (-V) 0, ∀ x : U, (F.connection t).NonnegativeCurvatureOperator x) ∧
        ∀ t ∈ Ioc (-T) 0, ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
          (F.metric t).inner x v w = (g t).pullbackCoefficients (extChartAt (𝓡 n) q).symm x v w) :
    ∃ gBoundary : C.metric,
      C.metricComplete gBoundary ∧
      (∀ y, gBoundary.leviCivitaData.NonnegativeCurvatureOperator y) ∧
      (∀ y v, (g 0).inner y v v ≤ gBoundary.inner y v v) ∧
      ∀ q : C.carrier, ∃ rho d : ℝ, 0 < rho ∧ 0 < d ∧
        ball (extChartAt (𝓡 n) q q) rho ⊆ (extChartAt (𝓡 n) q).target ∧
        let U : Opens (EuclideanSpace ℝ (Fin n)) := ⟨ball (extChartAt (𝓡 n) q q) rho, isOpen_ball⟩
        ∃ H : RicciFlow n U (Icc (-d) 0),
          (∀ t ∈ Icc (-d) 0, ∀ x : U, (H.connection t).NonnegativeCurvatureOperator x) ∧
          ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
            (H.metric 0).inner x v w = gBoundary.pullbackCoefficients (extChartAt (𝓡 n) q).symm x v w := by
  obtain ⟨gBoundary, hc, hn, hle, hretained⟩ :=
    exists_complete_boundary_metric_with_retained_chart_extensions C p hT g hcomplete hext
  refine ⟨gBoundary, hc, hn, hle, ?_⟩
  intro q
  obtain ⟨rho, V, hrho, hV, hchart, F, hF, _, hboundary⟩ := hretained q
  refine ⟨rho, V - T, hrho, sub_pos.mpr hV, hchart,
    localBackwardFlow hT hV F,
    fun _ ht x => localBackwardFlow_nonnegativeCurvatureOperator hT hV F hF ht x, ?_⟩
  intro x a b
  rw [localBackwardFlow_metric_zero]
  exact hboundary x a b

end PoincareMT.ControlledBlowupBoundary
