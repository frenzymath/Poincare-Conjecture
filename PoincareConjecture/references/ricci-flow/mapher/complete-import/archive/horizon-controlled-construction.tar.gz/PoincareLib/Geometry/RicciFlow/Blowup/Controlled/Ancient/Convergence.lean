import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Ancient.Identification
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Noncollapse.Inheritance

/-!
# Ancient identification of controlled generalized-flow limits

Source slab noncollapse passes to the actual convergent limit. At infinite
horizon, terminal scalar normalization propagates nonflatness to every past
time, giving the ancient certificate with the same metric and connection.

Reference: Morgan--Tian, Theorem 11.8, pp. 272 and 278--279.
-/

set_option autoImplicit false

open scoped ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

/-- Infinite-horizon long controls identify the actual limit as an ancient
kappa-solution, using only the frozen curvature service for nonflatness. -/
theorem nonempty_m30AncientKappaIdentification_of_longControls
    (hC : RicciFlowCurvatureTheory.{u}) {S : GeneralizedBlowupSequence.{u}}
    (G : GeneralizedBlowupConvergence S (blowupBackwardInterval ⊤))
    {epsilon C kappa r₀ mu : ℝ}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu ⊤) :
    Nonempty (M30AncientKappaIdentification G.limit kappa) :=
  G.limit.nonempty_m30AncientKappaIdentification hC H.kappa_pos
    (G.noncollapsed_of_longControls H)

end PoincareMT.GeneralizedBlowupConvergence
