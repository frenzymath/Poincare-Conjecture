import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Cylinders.Neighborhood
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.Cylinders.SpatialGluing

/-!
# Common cylinders from pointwise worldline survival

Compatible trajectories through every point of a compact terminal source region
produce a single cylinder on that region. Local spatial neighborhoods are
constructed from the original adapted boxes before applying compact gluing.
Reference: Morgan--Tian, Theorem 11.1, pp. 268-271.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT.GeneralizedFlowCylinder

/-- Pointwise compatible survival supplies a common cylinder on a compact
terminal source, with each of its trajectories equal to the prescribed one. -/
theorem exists_on_compact_of_singletons
    {F : GeneralizedRicciFlowData.{u}} {origin scale a : ℝ}
    {K : Set (F.slice origin).carrier} (hK : IsCompact K) (hne : K.Nonempty)
    (ha : a ≤ 0)
    (w : ∀ x : K, GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc a 0) {x.1})
    (hw0 : ∀ x : K, (w x).pointMap 0 ⟨ha, le_rfl⟩ x.1 = (⟨origin, x.1⟩ : F.point)) :
    ∃ n : GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc a 0) K,
      (∀ x ∈ K, n.pointMap 0 ⟨ha, le_rfl⟩ x = (⟨origin, x⟩ : F.point)) ∧
      ∀ (x : K) s (hs : s ∈ Icc a 0), n.pointMap s hs x.1 = (w x).pointMap s hs x.1 := by
  classical
  choose V hV hxV n hn htraj using fun x : K =>
    (w x).exists_neighborhood_of_singleton ha (hw0 x)
  obtain ⟨d, hd⟩ := exists_glued_on_compact isCompact_Icc ordConnected_Icc
    ⟨ha, le_rfl⟩ V hV n hn hK hne (fun x hx => ⟨⟨x, hx⟩, hxV ⟨x, hx⟩⟩)
  refine ⟨d, ?_, ?_⟩
  · intro x hx
    exact (hd ⟨x, hx⟩ 0 ⟨ha, le_rfl⟩ x hx (hxV ⟨x, hx⟩)).trans
      (hn ⟨x, hx⟩ x (hxV ⟨x, hx⟩))
  · intro x s hs
    exact (hd x s hs x.1 x.2 (hxV x)).trans (htraj x s hs)

/-- A pointwise spacetime estimate on surviving trajectories passes to the
common cylinder on the compact source without changing its time interval. -/
theorem exists_on_compact_of_singletons_preserving
    {F : GeneralizedRicciFlowData.{u}} {origin scale a : ℝ}
    {K : Set (F.slice origin).carrier} (hK : IsCompact K) (hne : K.Nonempty)
    (ha : a ≤ 0)
    (w : ∀ x : K, GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc a 0) {x.1})
    (hw0 : ∀ x : K, (w x).pointMap 0 ⟨ha, le_rfl⟩ x.1 = (⟨origin, x.1⟩ : F.point))
    (P : ℝ → (F.slice origin).carrier → F.point → Prop)
    (hP : ∀ (x : K) s (hs : s ∈ Icc a 0), P s x.1 ((w x).pointMap s hs x.1)) :
    ∃ n : GeneralizedFlowCylinder F (F.slice origin) origin scale (Icc a 0) K,
      (∀ x ∈ K, n.pointMap 0 ⟨ha, le_rfl⟩ x = (⟨origin, x⟩ : F.point)) ∧
      ∀ s (hs : s ∈ Icc a 0) x, x ∈ K → P s x (n.pointMap s hs x) := by
  obtain ⟨n, hn, htraj⟩ := exists_on_compact_of_singletons hK hne ha w hw0
  refine ⟨n, hn, ?_⟩
  intro s hs x hx
  rw [htraj ⟨x, hx⟩ s hs]
  exact hP ⟨x, hx⟩ s hs

end PoincareMT.GeneralizedFlowCylinder
