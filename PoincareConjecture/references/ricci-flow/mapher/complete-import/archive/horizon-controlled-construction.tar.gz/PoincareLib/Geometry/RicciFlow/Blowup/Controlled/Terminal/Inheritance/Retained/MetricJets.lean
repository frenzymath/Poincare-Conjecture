import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Curvature.ScalarCompact
import PoincareLib.Geometry.RicciFlow.AncientKappa.Asymptotic.Compactness.Coordinates.BilinearJetConvergence

/-!
# Metric jets at moving retained times

Compact-uniform spacetime convergence gives full bilinear spatial jets at
any sequence of retained times approaching one fixed limit time. The maps
and source metrics are the actual generalized convergence data.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxHeartbeats 1200000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable

variable {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
  (G : GeneralizedBlowupConvergence S J.domain)
  {idx : ℕ → ℕ} (hidx : Tendsto idx atTop atTop)
  {s : ℕ → ℝ} {t : ℝ} {I : Set ℝ} (hI : IsCompact I) (hIJ : I ⊆ J.domain)
  (hsI : ∀ k, s k ∈ I) (htI : t ∈ I) (hst : Tendsto s atTop (𝓝 t))
  (hs : ∀ k, s k ∈ Icc (-G.exhaustion.time (idx k)) 0)

include hidx hI hIJ hsI htI hst

private theorem tendstoUniformlyOn_movingSourceMetric_entry_jets
    (q : G.limit.carrier.carrier) {K : Set (EuclideanSpace ℝ (Fin 3))}
    (hK : IsCompact K) (hKc : K ⊆ (extChartAt (𝓡 3) q).target)
    (m : ℕ) (a b : Fin 3) :
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m (fun z => (G.normalizedSourceMetric (idx k) (s k)).pullbackCoefficients
        ((G.embedding (idx k)).forward (s k) (hs k) ∘ (extChartAt (𝓡 3) q).symm) z
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)))
      (iteratedFDeriv ℝ m (fun z => (G.limit.flow.metric t).pullbackCoefficients
        (extChartAt (𝓡 3) q).symm z (EuclideanSpace.basisFun (Fin 3) ℝ a)
          (EuclideanSpace.basisFun (Fin 3) ℝ b))) atTop K := by
  apply Metric.tendstoUniformlyOn_iff.mpr
  intro delta hdelta
  by_contra h
  have hbad : ∃ᶠ k in atTop, ∃ x ∈ K, delta ≤ dist
      (iteratedFDeriv ℝ m (fun z => (G.limit.flow.metric t).pullbackCoefficients
        (extChartAt (𝓡 3) q).symm z (EuclideanSpace.basisFun (Fin 3) ℝ a)
          (EuclideanSpace.basisFun (Fin 3) ℝ b)) x)
      (iteratedFDeriv ℝ m (fun z => (G.normalizedSourceMetric (idx k) (s k)).pullbackCoefficients
        ((G.embedding (idx k)).forward (s k) (hs k) ∘ (extChartAt (𝓡 3) q).symm) z
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) x) := by
    simpa only [not_forall, not_lt, exists_prop] using not_eventually.mp h
  obtain ⟨sigma, hsigma, hbad⟩ := extraction_of_frequently_atTop hbad
  choose x hx hbad using hbad
  obtain ⟨y, hy, tau, htau, hxy⟩ := hK.tendsto_subseq hx
  have hsource := G.tendsto_normalizedSourceMetric_chart_jets q (hI.prod hK)
    (fun z hz => ⟨hIJ hz.1, hKc hz.2⟩)
    (fun k => ⟨hsI (sigma (tau k)), hx (tau k)⟩) ⟨htI, hy⟩
    ((hst.comp (hsigma.tendsto_atTop.comp htau.tendsto_atTop)).prodMk_nhds hxy)
    (hidx.comp (hsigma.tendsto_atTop.comp htau.tendsto_atTop))
    (fun k => hs (sigma (tau k))) m a b
  have hcont : ContinuousOn (iteratedFDeriv ℝ m (fun z =>
      (G.limit.flow.metric t).pullbackCoefficients (extChartAt (𝓡 3) q).symm z
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))) K := by
    intro z hz
    exact ((G.limit.carrier.contDiffAt_coordinateCoefficient_metric
      (G.limit.flow.metric t) q a b t z (hKc hz)).continuousAt_iteratedFDeriv
        (WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤))).continuousWithinAt
  have hlimit := (hcont y hy).tendsto.comp (tendsto_nhdsWithin_iff.mpr
    ⟨hxy, Eventually.of_forall fun k => hx (tau k)⟩)
  have herr := hlimit.dist hsource
  simp only [dist_self] at herr
  obtain ⟨k, hk⟩ := (herr.eventually (Iio_mem_nhds hdelta)).exists
  exact (not_lt_of_ge (hbad (tau k))) hk

theorem tendstoUniformlyOn_movingSourceMetric_bilinear_jets
    (q : G.limit.carrier.carrier) {K : Set (EuclideanSpace ℝ (Fin 3))}
    (hK : IsCompact K) (hKc : K ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((G.normalizedSourceMetric (idx k) (s k)).pullbackCoefficients
        ((G.embedding (idx k)).forward (s k) (hs k) ∘ (extChartAt (𝓡 3) q).symm)))
      (iteratedFDeriv ℝ m ((G.limit.flow.metric t).pullbackCoefficients
        (extChartAt (𝓡 3) q).symm)) atTop K := by
  have hc := (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset (hK.image_of_continuousOn hc)
  apply Poincare.Analysis.Calculus.tendstoUniformlyOn_bilinear_jets_of_basis_entries
  · filter_upwards [hidx.eventually (eventually_ge_atTop j)] with k hk z hz
    have he := ((G.embedding (idx k)).forward_smooth (s k) (hs k)).contMDiffAt
      ((G.exhaustion.space_open (idx k)).mem_nhds
        (G.exhaustion.space_increasing hk (hj (mem_image_of_mem _ hz))))
    have hc := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q (hKc hz)).contMDiffAt
      (extChartAt_target_mem_nhds' (hKc hz))
    exact (G.normalizedSourceMetric (idx k) (s k)).contDiffAt_pullbackCoefficients (he.comp z hc)
  · intro z hz
    exact ((G.limit.flow.metric t).contDiffOn_chartCoefficients q).contDiffAt
      ((isOpen_extChartAt_target q).mem_nhds (hKc hz))
  · exact fun a b => G.tendstoUniformlyOn_movingSourceMetric_entry_jets
      hidx hI hIJ hsI htI hst hs q hK hKc m a b

omit hI in
theorem tendstoUniformlyOn_movingSource_scalar
    {K : Set G.limit.carrier.carrier} (hK : IsCompact K) :
    TendstoUniformlyOn
      (fun k y => (G.normalizedSourceConnection (idx k) (s k)).scalarCurvature
        ((G.embedding (idx k)).forward (s k) (hs k) y))
      (G.limit.flow.connection t).scalarCurvature atTop K := by
  apply Metric.tendstoUniformlyOn_iff.mpr
  intro delta hdelta
  by_contra h
  have hbad := not_eventually.mp h
  simp only [not_forall, not_lt, exists_prop] at hbad
  obtain ⟨sigma, hsigma, hbad⟩ := extraction_of_frequently_atTop hbad
  choose x hx hbad using hbad
  obtain ⟨y, hy, tau, htau, hxy⟩ := hK.tendsto_subseq hx
  have hsource := G.tendsto_normalizedSource_scalar
    (fun k => hIJ (hsI (sigma (tau k)))) (hIJ htI)
    ((hst.comp (hsigma.tendsto_atTop.comp htau.tendsto_atTop)).prodMk_nhds hxy)
    (hidx.comp (hsigma.tendsto_atTop.comp htau.tendsto_atTop))
    (fun k => hs (sigma (tau k)))
  have hlimit := (G.limit.flow.connection t).continuous_scalarCurvature.tendsto y |>.comp hxy
  have herr := hlimit.dist hsource
  simp only [dist_self] at herr
  obtain ⟨k, hk⟩ := (herr.eventually (Iio_mem_nhds hdelta)).exists
  exact (not_lt_of_ge (hbad (tau k))) hk

end PoincareMT.GeneralizedBlowupConvergence
