import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Geometry.Triangle
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Separation.Segment
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Separation.Diameter

/-!
# Opposite neck exits in large triangles

Two minimizing sides of a large triangle cannot leave a sufficiently small
neck through the same half-neck slice. First-exit times and the orientation
are constructed from the actual curves and neck coordinates.

Reference: Morgan--Tian, Claim 11.14, in the proof of Claim 11.13.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle

namespace PoincareMT.EpsilonNeck

variable {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
  [IsManifold (𝓡 3) ∞ M] [MeasurableSpace M] [BorelSpace M]
  [T2Space M] [T3Space M] {g : RiemannianMetric 3 M}

/-- Points on the same actual coordinate sphere have uniformly bounded
ambient distance at the neck scale. -/
theorem toReal_edist_le_two_pi_mul_scale_of_axis_eq (N : EpsilonNeck g)
    {x y : M} (hx : x ∈ N.carrier) (hy : y ∈ N.carrier)
    (haxis : (N.coordinate_inverse x).2 = (N.coordinate_inverse y).2) :
    (g.edist x y).toReal ≤ 2 * Real.pi * N.scale := by
  have hscalePos := N.scale_pos
  have hcoord := N.coordinate_inverse_mem x hx
  have hfirst : N.coordinate_map
      ((N.coordinate_inverse x).1, (N.coordinate_inverse x).2) = x :=
    N.coordinate_map_coordinate_inverse hx
  have hsecond : N.coordinate_map
      ((N.coordinate_inverse y).1, (N.coordinate_inverse x).2) = y := by
    rw [haxis]
    exact N.coordinate_map_coordinate_inverse hy
  have hdist := N.edist_coordinate_map_slice_le
    (N.coordinate_inverse x).1 (N.coordinate_inverse y).1 hcoord.2
  rw [hfirst, hsecond] at hdist
  have hupper : N.scale * Real.sqrt (1 + N.epsilon) * Real.sqrt 2 * Real.pi ≤
      2 * Real.pi * N.scale := by
    have hs : Real.sqrt (1 + N.epsilon) * Real.sqrt 2 ≤ 2 := by
      have hsq : (Real.sqrt (1 + N.epsilon) * Real.sqrt 2) ^ 2 =
          (1 + N.epsilon) * 2 := by
        rw [mul_pow, Real.sq_sqrt (by linarith [N.epsilon_pos]),
          Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)]
      nlinarith [N.epsilon_lt_half,
        mul_nonneg (Real.sqrt_nonneg (1 + N.epsilon)) (Real.sqrt_nonneg 2)]
    have hm := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left hs N.scale_pos.le) Real.pi_pos.le
    nlinarith
  have he := hdist.trans (ENNReal.ofReal_le_ofReal hupper)
  exact (ENNReal.toReal_mono ENNReal.ofReal_ne_top he).trans_eq
    (ENNReal.toReal_ofReal (by positivity))

/-- Large triangle endpoints force opposite half-neck exits. The hypothesis
on the endpoints says only that the actual curves leave the compact slab;
no orientation or exit data is supplied. -/
theorem exists_opposite_half_neck_exits_of_large_triangle
    [ConnectedSpace M] (N : EpsilonNeck g) (D : LeviCivitaData g)
    (hcomplete : MetricComplete g) (hsec : D.NonnegativeSectionalCurvature)
    (hsmall : N.epsilon ≤ 1 / (400 * Real.pi))
    {γ σ : ℝ → M} {p : M} {a b d : ℝ} (hd : 0 < d)
    (ha : d ≤ a) (hb : d ≤ b) (ha' : a ≤ 3 * d / 2) (hb' : b ≤ 3 * d / 2)
    (hfar : d ≤ (g.edist (γ a) (σ b)).toReal)
    (hγ : g.IsGeodesicOn γ (Icc 0 a)) (hσ : g.IsGeodesicOn σ (Icc 0 b))
    (hγ0 : γ 0 = p) (hσ0 : σ 0 = p)
    (hγspeed : ∀ s ∈ Icc 0 a,
      g.tangentNorm (γ s) (mfderiv 𝓘(ℝ, ℝ) (𝓡 3) γ s 1) = 1)
    (hσspeed : ∀ s ∈ Icc 0 b,
      g.tangentNorm (σ s) (mfderiv 𝓘(ℝ, ℝ) (𝓡 3) σ s 1) = 1)
    (hγmin : ∀ s ∈ Icc 0 a, ∀ t ∈ Icc 0 a,
      g.edist (γ s) (γ t) = ENNReal.ofReal |s - t|)
    (hσmin : ∀ s ∈ Icc 0 b, ∀ t ∈ Icc 0 b,
      g.edist (σ s) (σ t) = ENNReal.ofReal |s - t|)
    (hp : p ∈ N.carrier) (hpaxis : |(N.coordinate_inverse p).2| ≤ 1)
    (hγout : γ a ∉ N.coordinate_map ''
      (univ ×ˢ Icc (-N.epsilon⁻¹ / 2) (N.epsilon⁻¹ / 2)))
    (hσout : σ b ∉ N.coordinate_map ''
      (univ ×ˢ Icc (-N.epsilon⁻¹ / 2) (N.epsilon⁻¹ / 2))) :
    ∃ r ∈ Ioc 0 a, ∃ t ∈ Ioc 0 b,
      MapsTo γ (Icc 0 r) N.carrier ∧ MapsTo σ (Icc 0 t) N.carrier ∧
      (((N.coordinate_inverse (γ r)).2 = -(N.epsilon⁻¹ / 2) ∧
          (N.coordinate_inverse (σ t)).2 = N.epsilon⁻¹ / 2) ∨
        ((N.coordinate_inverse (γ r)).2 = N.epsilon⁻¹ / 2 ∧
          (N.coordinate_inverse (σ t)).2 = -(N.epsilon⁻¹ / 2))) ∧
      MapsTo γ (Ico 0 r) (N.region (-N.epsilon⁻¹ / 2) (N.epsilon⁻¹ / 2)) ∧
      MapsTo σ (Ico 0 t) (N.region (-N.epsilon⁻¹ / 2) (N.epsilon⁻¹ / 2)) := by
  have hepsilonPos := N.epsilon_pos
  have hsmall' : N.epsilon ≤ 1 / 4 := by
    have h := (le_div_iff₀ (by positivity : 0 < 400 * Real.pi)).mp hsmall
    nlinarith [Real.two_le_pi, N.epsilon_pos]
  obtain ⟨r, hr, hrlong, hrN, hraxis, hrbefore⟩ :=
    N.exists_long_initial_segment_to_half_neck (hd.le.trans ha) hsmall' hγ hγspeed
      (hγ0.symm ▸ hp) (hγ0.symm ▸ hpaxis) hγout
  obtain ⟨t, ht, htlong, htN, htaxis, htbefore⟩ :=
    N.exists_long_initial_segment_to_half_neck (hd.le.trans hb) hsmall' hσ hσspeed
      (hσ0.symm ▸ hp) (hσ0.symm ▸ hpaxis) hσout
  have hne : (N.coordinate_inverse (γ r)).2 ≠ (N.coordinate_inverse (σ t)).2 := by
    intro heq
    have hdist := N.toReal_edist_le_two_pi_mul_scale_of_axis_eq
      (hrN ⟨hr.1.le, le_rfl⟩) (htN ⟨ht.1.le, le_rfl⟩) heq
    have hscale : 2 * Real.pi * N.scale ≤ N.scale / (200 * N.epsilon) := by
      apply (le_div_iff₀ (by positivity : 0 < 200 * N.epsilon)).mpr
      have he := (le_div_iff₀ (by positivity : 0 < 400 * Real.pi)).mp hsmall
      have hs := mul_le_mul_of_nonneg_right he N.scale_pos.le
      nlinarith
    have hrbound : (g.edist (γ r) (σ t)).toReal ≤ r / 2 := by
      have := hdist.trans hscale
      have heq : N.scale / (200 * N.epsilon) =
          (N.scale / (100 * N.epsilon)) / 2 := by ring
      rw [heq] at this
      linarith
    have htbound : (g.edist (γ r) (σ t)).toReal ≤ t / 2 := by
      have := hdist.trans hscale
      have heq : N.scale / (200 * N.epsilon) =
          (N.scale / (100 * N.epsilon)) / 2 := by ring
      rw [heq] at this
      linarith
    have hv : (g.edist (γ r) (σ t)).toReal ^ 2 ≤ r * t / 4 := by
      have hm := mul_le_mul hrbound htbound ENNReal.toReal_nonneg
        (div_nonneg hr.1.le (by norm_num : (0 : ℝ) ≤ 2))
      nlinarith
    exact (not_le_of_gt (g.transverse_chord_sq_gt_of_large_triangle D hcomplete hsec
      hd ha hb ha' hb' hfar hγ hσ hγ0 hσ0 hγspeed hσspeed hγmin hσmin hr ht)) hv
  refine ⟨r, hr, t, ht, hrN, htN, ?_, hrbefore, htbefore⟩
  have hhalf : 0 ≤ N.epsilon⁻¹ / 2 := by positivity
  rcases (abs_eq hhalf).mp hraxis with hraxis | hraxis <;>
    rcases (abs_eq hhalf).mp htaxis with htaxis | htaxis
  · exact False.elim (hne (hraxis.trans htaxis.symm))
  · exact Or.inr ⟨hraxis, htaxis⟩
  · exact Or.inl ⟨hraxis, htaxis⟩
  · exact False.elim (hne (hraxis.trans htaxis.symm))

end PoincareMT.EpsilonNeck
