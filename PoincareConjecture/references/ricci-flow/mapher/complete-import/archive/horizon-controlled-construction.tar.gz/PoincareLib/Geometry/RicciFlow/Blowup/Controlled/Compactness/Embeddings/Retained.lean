import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Source

/-!
# Retained generalized cylinders of a pointed interior limit

The fixed spatial embeddings at the compactness reference time are composed
with the actual controlled cylinders. The resulting generalized embeddings
are defined through terminal time zero and preserve the original basepoint.
Source: Morgan--Tian, Theorem 11.8, pp. 274--279.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

open ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

private noncomputable def retainedSmallCoordinate (k : ℕ) :
    PartialDiffeomorph (𝓡 3) (𝓡 3) G.limitCarrier.carrier
      (componentCarrier S (idx (G.subsequence k)) (hA (G.subsequence k))).shrink.carrier ∞ := by
  have ht : (0 : ℝ) ∈ Ioo (-T / 2) (T / 2) := ⟨by linarith [hT], by linarith [hT]⟩
  let f := (G.embedding k).spatialHomeomorph (G.exhaustion_open k) ht
  exact {
    toPartialEquiv := f.toPartialEquiv
    open_source := f.open_source
    open_target := f.open_target
    contMDiffOn_toFun := fun x hx =>
      ((G.embedding k).spatialMap_contMDiffAt (G.exhaustion_open k) ht hx).contMDiffWithinAt
    contMDiffOn_invFun := by
      rintro _ ⟨x, hx, rfl⟩
      exact ((G.embedding k).spatialInverse_contMDiffAt
        (G.exhaustion_open k) ht hx).contMDiffWithinAt }

noncomputable def retainedSourceCoordinate (k : ℕ) :
    PartialDiffeomorph (𝓡 3) (𝓡 3) (liftedSliceCarrier.{u} G.limitCarrier).carrier
      ((S.flow (idx (G.subsequence k))).slice (S.base (idx (G.subsequence k))).1).carrier ∞ :=
  ((Poincare.Manifold.uliftDiffeomorph (𝓡 3) G.limitCarrier.carrier).toPartialDiffeomorph.trans
    (retainedSmallCoordinate G k)).trans
      (smallSourceCoordinate S (idx (G.subsequence k)) (hA (G.subsequence k)))

theorem retainedSourceCoordinate_apply (k : ℕ)
    (x : (liftedSliceCarrier.{u} G.limitCarrier).carrier) :
    retainedSourceCoordinate G k x =
      smallSourceCoordinate S (idx (G.subsequence k)) (hA (G.subsequence k))
        ((G.embedding k).toFun (0, x.down)).2 := rfl

theorem retainedSourceCoordinate_source (k : ℕ) :
    (retainedSourceCoordinate G k).source =
      ULift.down ⁻¹' G.exhaustion k := by
  ext x
  change ((x ∈ univ ∧ x.down ∈ G.exhaustion k) ∧
    _ ∈ (smallSourceCoordinate S (idx (G.subsequence k)) (hA (G.subsequence k))).source) ↔ _
  rw [smallSourceCoordinate_source]
  simp

theorem retainedSourceCoordinate_target_subset (k : ℕ) :
    (retainedSourceCoordinate G k).target ⊆ S.baseBall (idx (G.subsequence k)) (A (G.subsequence k)) := by
  intro x hx
  exact smallSourceCoordinate_target_subset S _ _ hx.1

noncomputable def retainedCylinder (k : ℕ) :
    GeneralizedFlowCylinder (S.flow (idx (G.subsequence k)))
      (liftedSliceCarrier.{u} G.limitCarrier)
      (S.base (idx (G.subsequence k))).1 (S.scale (idx (G.subsequence k)))
      (Icc (-T) 0) (ULift.down ⁻¹' G.exhaustion k) := by
  let f := retainedSourceCoordinate G k
  let d := (e (G.subsequence k)).embedding.rebasePartialSource f.toOpenPartialHomeomorph
    (retainedSourceCoordinate_target_subset G k) f.contMDiffOn_toFun f.contMDiffOn_invFun
  exact d.restrict Subset.rfl (by
    change ULift.down ⁻¹' G.exhaustion k ⊆ (retainedSourceCoordinate G k).source
    rw [retainedSourceCoordinate_source])

theorem retainedCylinder_pointMap (k : ℕ) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (x : (liftedSliceCarrier.{u} G.limitCarrier).carrier) :
    (retainedCylinder G k).pointMap s hs x =
      (e (G.subsequence k)).embedding.pointMap s hs
        (smallSourceCoordinate S (idx (G.subsequence k)) (hA (G.subsequence k))
          ((G.embedding k).toFun (0, x.down)).2) := rfl

theorem retainedCylinder_base (k : ℕ) (hzero : (0 : ℝ) ∈ Icc (-T) 0) :
    (retainedCylinder G k).pointMap 0 hzero (ULift.up G.limitFlow.base) =
      S.base (idx (G.subsequence k)) := by
  rw [retainedCylinder_pointMap]
  have hbase := congrArg Prod.snd (G.base_preserving k)
  change ((G.embedding k).toFun (0, G.limitFlow.base)).2 =
    smallBase S (idx (G.subsequence k)) (hA (G.subsequence k)) at hbase
  rw [hbase, smallSourceCoordinate_apply]
  simp only [smallBase, Equiv.symm_apply_apply]
  exact (e (G.subsequence k)).zero_identity hzero _ (base_mem_sourceBall (hA _))

end PoincareMT.ControlledBlowupCompactness
