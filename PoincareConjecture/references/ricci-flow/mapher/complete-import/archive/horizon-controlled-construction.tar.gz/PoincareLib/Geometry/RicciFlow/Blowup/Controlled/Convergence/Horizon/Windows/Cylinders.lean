import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.GeometricWindow
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.Worldlines.Uniqueness

/-! # Compatible controlled cylinders on different finite horizons -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T T' B B' eta eta' : ℝ}

/-- Normalized cylinders based at the same terminal ball have identical
worldlines on every common time, by uniqueness of the generalized flow. -/
theorem pointMap_eq_on_common_time
    (e : ControlledBlowupCylinder S k A T B eta)
    (d : ControlledBlowupCylinder S k A T' B' eta')
    (hT : 0 < T) (hT' : 0 < T')
    (s : ℝ) (hs : s ∈ Icc (-T) 0) (hs' : s ∈ Icc (-T') 0)
    (x : ((S.flow k).slice (S.base k).1).carrier) (hx : x ∈ S.baseBall k A) :
    e.embedding.pointMap s hs x = d.embedding.pointMap s hs' x := by
  exact e.embedding.pointMap_eq_on_overlap d.embedding ordConnected_Icc ordConnected_Icc
    hx hx (show (0 : ℝ) ∈ Icc (-T) 0 from ⟨by linarith, le_rfl⟩)
    (show (0 : ℝ) ∈ Icc (-T') 0 from ⟨by linarith, le_rfl⟩)
    ((e.zero_identity _ x hx).trans (d.zero_identity _ x hx).symm) s hs hs'

/-- The actual spatial pullback forms are independent of the horizon used
to produce their cylinder, on the overlap of the two time intervals. -/
theorem pullbackInner_eq_on_common_time
    (e : ControlledBlowupCylinder S k A T B eta)
    (d : ControlledBlowupCylinder S k A T' B' eta')
    (hT : 0 < T) (hT' : 0 < T')
    (s : ℝ) (hs : s ∈ Icc (-T) 0) (hs' : s ∈ Icc (-T') 0)
    (x : ((S.flow k).slice (S.base k).1).carrier) (hx : x ∈ S.baseBall k A)
    (v w : TangentSpace (𝓡 3) x) :
    e.embedding.pullbackInner s hs x v w = d.embedding.pullbackInner s hs' x v w := by
  have heq : e.embedding.forward s hs =ᶠ[𝓝 x] d.embedding.forward s hs' := by
    filter_upwards [(sourceBall S k A).isOpen.mem_nhds hx] with y hy
    exact eq_of_heq (Sigma.mk.inj_iff.mp (e.pointMap_eq_on_common_time d hT hT' s hs hs' y hy)).2
  have hd := heq.mfderiv_eq (I := 𝓡 3) (I' := 𝓡 3)
  unfold GeneralizedFlowCylinder.pullbackInner
  rw [heq.self_of_nhds, hd]

/-- The ordinary metric itself agrees; both sides are the actual normalized
pullback, and no auxiliary compatibility certificate is required. -/
theorem ordinaryFlow_metric_eq_on_common_time
    (e : ControlledBlowupCylinder S k A T B eta)
    (d : ControlledBlowupCylinder S k A T' B' eta')
    (hT : 0 < T) (hT' : 0 < T')
    (s : ℝ) (hs : s ∈ Icc (-T) 0) (hs' : s ∈ Icc (-T') 0) :
    (e.ordinaryFlow hT).metric s = (d.ordinaryFlow hT').metric s := by
  have hi : ((e.ordinaryFlow hT).metric s).inner = ((d.ordinaryFlow hT').metric s).inner := by
    funext x
    ext v w
    rw [e.ordinaryFlow_inner hT s hs, d.ordinaryFlow_inner hT' s hs']
    exact e.pullbackInner_eq_on_common_time d hT hT' s hs hs' x.val x.property _ _
  have hext (g h : RiemannianMetric 3 (sourceBall S k A))
      (heq : g.inner = h.inner) : g = h := by
    cases g
    cases h
    congr
  exact hext _ _ hi

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

/-- Connected-component restriction and universe shrinking retain the
exact horizon-independent metric equality. -/
theorem smallFlow_metric_eq_on_common_time
    (e : ControlledBlowupCylinder S k A T B eta)
    (d : ControlledBlowupCylinder S k A T' B' eta')
    (hA : 0 < A) (hT : 0 < T) (hT' : 0 < T')
    (s : ℝ) (hs : s ∈ Icc (-T) 0) (hs' : s ∈ Icc (-T') 0) :
    (e.smallFlow hA hT).metric s = (d.smallFlow hA hT').metric s := by
  have heq := e.ordinaryFlow_metric_eq_on_common_time d hT hT' s hs hs'
  dsimp only [smallFlow, componentFlow, RicciFlow.shrink, RicciFlow.pullbackDiffeomorph,
    RicciFlow.restrictComponent, RicciFlow.restrictToOpen, RicciFlow.pullbackWithConnection]
  rw [heq]

end PoincareMT.ControlledBlowupCylinder
