import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Curvature.TerminalJets
import PoincareLib.Geometry.RicciFlow.AncientKappa.Asymptotic.Compactness.Coordinates.BilinearJetConvergence

/-! # Full spatial terminal jets for retained generalized convergence maps -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space

variable {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
  (G : GeneralizedBlowupConvergence S J.domain)

private theorem tendstoUniformlyOn_zeroSourceMetric_entry_jets
    (q : G.limit.carrier.carrier) {K : Set (EuclideanSpace ℝ (Fin 3))}
    (hK : IsCompact K) (hKc : K ⊆ (extChartAt (𝓡 3) q).target)
    (m : ℕ) (a b : Fin 3) :
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m (fun z => (G.zeroSourceMetric k).pullbackCoefficients
        (G.zeroSliceEmbedding k ∘ (extChartAt (𝓡 3) q).symm) z
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)))
      (iteratedFDeriv ℝ m (fun z => (G.limit.flow.metric 0).pullbackCoefficients
        (extChartAt (𝓡 3) q).symm z (EuclideanSpace.basisFun (Fin 3) ℝ a)
          (EuclideanSpace.basisFun (Fin 3) ℝ b))) atTop K := by
  apply Metric.tendstoUniformlyOn_iff.mpr
  intro delta hdelta
  by_contra h
  have hbad : ∃ᶠ k in atTop, ∃ x ∈ K, delta ≤ dist
      (iteratedFDeriv ℝ m (fun z => (G.limit.flow.metric 0).pullbackCoefficients
        (extChartAt (𝓡 3) q).symm z (EuclideanSpace.basisFun (Fin 3) ℝ a)
          (EuclideanSpace.basisFun (Fin 3) ℝ b)) x)
      (iteratedFDeriv ℝ m (fun z => (G.zeroSourceMetric k).pullbackCoefficients
        (G.zeroSliceEmbedding k ∘ (extChartAt (𝓡 3) q).symm) z
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) x) := by
    simpa only [not_forall, not_lt, exists_prop] using not_eventually.mp h
  obtain ⟨sigma, hsigma, hbad⟩ := extraction_of_frequently_atTop hbad
  choose x hx hbad using hbad
  obtain ⟨y, hy, tau, htau, hxy⟩ := hK.tendsto_subseq hx
  have hsource := G.tendsto_zeroSourceMetric_chart_jets q hK hKc
    (fun k => hx (tau k)) hy hxy (hsigma.tendsto_atTop.comp htau.tendsto_atTop) m a b
  have hcont : ContinuousOn (iteratedFDeriv ℝ m (fun z =>
      (G.limit.flow.metric 0).pullbackCoefficients (extChartAt (𝓡 3) q).symm z
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))) K := by
    intro z hz
    exact ((G.limit.carrier.contDiffAt_coordinateCoefficient_metric
      (G.limit.flow.metric 0) q a b 0 z (hKc hz)).continuousAt_iteratedFDeriv
        (WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤))).continuousWithinAt
  have hlimit := (hcont y hy).tendsto.comp (tendsto_nhdsWithin_iff.mpr
    ⟨hxy, Eventually.of_forall fun k => hx (tau k)⟩)
  have herr := hlimit.dist hsource
  simp only [dist_self] at herr
  obtain ⟨k, hk⟩ := (herr.eventually (Iio_mem_nhds hdelta)).exists
  exact (not_lt_of_ge (hbad (tau k))) hk

theorem tendstoUniformlyOn_zeroSourceMetric_bilinear_jets
    (q : G.limit.carrier.carrier) {K : Set (EuclideanSpace ℝ (Fin 3))}
    (hK : IsCompact K) (hKc : K ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((G.zeroSourceMetric k).pullbackCoefficients
        (G.zeroSliceEmbedding k ∘ (extChartAt (𝓡 3) q).symm)))
      (iteratedFDeriv ℝ m ((G.limit.flow.metric 0).pullbackCoefficients
        (extChartAt (𝓡 3) q).symm)) atTop K := by
  have hc := (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset (hK.image_of_continuousOn hc)
  apply Poincare.Analysis.Calculus.tendstoUniformlyOn_bilinear_jets_of_basis_entries
  · filter_upwards [eventually_ge_atTop j] with k hk z hz
    have he := (G.zeroSliceEmbedding_smooth k).contMDiffAt
      ((G.exhaustion.space_open k).mem_nhds
        (G.exhaustion.space_increasing hk (hj (mem_image_of_mem _ hz))))
    have hc := (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q (hKc hz)).contMDiffAt
      (extChartAt_target_mem_nhds' (hKc hz))
    exact (G.zeroSourceMetric k).contDiffAt_pullbackCoefficients (he.comp z hc)
  · intro z hz
    exact ((G.limit.flow.metric 0).contDiffOn_chartCoefficients q).contDiffAt
      ((isOpen_extChartAt_target q).mem_nhds (hKc hz))
  · exact fun a b => G.tendstoUniformlyOn_zeroSourceMetric_entry_jets q hK hKc m a b

end PoincareMT.GeneralizedBlowupConvergence
