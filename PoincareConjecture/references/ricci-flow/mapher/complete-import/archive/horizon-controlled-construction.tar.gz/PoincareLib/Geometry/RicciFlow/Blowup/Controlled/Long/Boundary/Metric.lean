import PoincareLib.Geometry.Riemannian.Metric.Gluing.Descent
import PoincareLib.Geometry.RicciFlow.Basic
import Mathlib.Topology.Instances.Real.Lemmas

/-! # The boundary metric determined by compatible local backward flows -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledBlowupBoundary

variable {n : ℕ} {ι : Type*} {U : ι → Type*} {M : Type*}
  [∀ i, TopologicalSpace (U i)] [TopologicalSpace M]
  [∀ i, ChartedSpace (EuclideanSpace ℝ (Fin n)) (U i)]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M]
  [∀ i, IsManifold (𝓡 n) ∞ (U i)] [IsManifold (𝓡 n) ∞ M]
  {T : ℝ} (hT : 0 < T) (V : ι → ℝ) (hV : ∀ i, T < V i)
  (F : ∀ i, RicciFlow n (U i) (Icc (-V i) 0))
  (g : ℝ → RiemannianMetric n M) (q : ∀ i, U i → M)
  (hpres : ∀ i, ∀ t ∈ Ioc (-T) 0, ∀ (x : U i) (a b : TangentSpace (𝓡 n) x),
    ((F i).metric t).inner x a b = (g t).inner (q i x)
      (mfderiv (𝓡 n) (𝓡 n) (q i) x a) (mfderiv (𝓡 n) (𝓡 n) (q i) x b))

include hT hV hpres

theorem local_boundary_metric_compatible
    (i j : ι) (x : U i) (y : U j) (hxy : q i x = q j y)
    (a b : TangentSpace (𝓡 n) x) (c d : TangentSpace (𝓡 n) y)
    (hac : mfderiv (𝓡 n) (𝓡 n) (q i) x a = mfderiv (𝓡 n) (𝓡 n) (q j) y c)
    (hbd : mfderiv (𝓡 n) (𝓡 n) (q i) x b = mfderiv (𝓡 n) (𝓡 n) (q j) y d) :
    ((F i).metric (-T)).inner x a b = ((F j).metric (-T)).inner y c d := by
  have heq : EqOn (fun t => ((F i).metric t).inner x a b)
      (fun t => ((F j).metric t).inner y c d) (Ioc (-T) 0) := by
    intro t ht
    dsimp only
    rw [hpres i t ht x a b, hpres j t ht y c d]
    rw [hxy]
    exact congrArg₂ (fun v w : EuclideanSpace ℝ (Fin n) => (g t).inner (q j y) v w) hac hbd
  have hcont (i : ι) (x : U i) (a b : TangentSpace (𝓡 n) x) :
      ContinuousOn (fun t => ((F i).metric t).inner x a b) (Icc (-T) 0) := by
    intro t ht
    exact ((F i).equation t ⟨(neg_le_neg (hV i).le).trans ht.1, ht.2⟩ x a b).continuousWithinAt.mono
      (Icc_subset_Icc (neg_le_neg (hV i).le) le_rfl)
  apply heq.of_subset_closure (hcont i x a b) (hcont j y c d) Ioc_subset_Icc_self
    (by rw [closure_Ioc (by linarith : -T ≠ 0)])
  exact ⟨le_rfl, by linarith⟩

/-- Agreement with one old flow fixes all overlaps at the missing backward
endpoint, and hence determines one smooth metric on the original carrier. -/
theorem exists_boundary_metric
    (hq : ∀ i, IsLocalDiffeomorph (𝓡 n) (𝓡 n) ∞ (q i))
    (hcover : ∀ y, ∃ i x, q i x = y) :
    ∃ gBoundary : RiemannianMetric n M,
      ∀ i (x : U i) (a b : TangentSpace (𝓡 n) x),
        ((F i).metric (-T)).inner x a b = gBoundary.inner (q i x)
          (mfderiv (𝓡 n) (𝓡 n) (q i) x a) (mfderiv (𝓡 n) (𝓡 n) (q i) x b) := by
  obtain ⟨gBoundary, hBoundary, _⟩ := Poincare.Gluing.exists_unique_metric_of_covering_local_diffeomorphisms
    (fun i => (F i).metric (-T)) q hq hcover (local_boundary_metric_compatible hT V hV F g q hpres)
  exact ⟨gBoundary, hBoundary⟩

end PoincareMT.ControlledBlowupBoundary
