import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.MetricJets

/-!
# Eventual bounds for moving neck coordinates

Only a tail of each comparison sequence needs bounded ambient jets and
ellipticity. A finite compact chart cover then controls the whole captured
neck, even when its location and coordinate map depend on the sequence.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000

open Set Filter
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.TerminalNeck

open MetricSurgery
local notation "E" => EuclideanSpace ℝ (Fin 3)

variable {X : ℕ → Type u}
  [∀ k, TopologicalSpace (X k)] [∀ k, ChartedSpace E (X k)]
  [∀ k, IsManifold (𝓡 3) ∞ (X k)]
  {M : Type v} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]

theorem eventually_small_transported_neck_errors_of_eventual_chart_bounds
    (g : ∀ k, RiemannianMetric 3 (X k)) (h : RiemannianMetric 3 M)
    (N : ∀ k, EpsilonNeck (g k)) (e : ∀ k, OpenPartialHomeomorph (X k) M)
    (he : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source)
    (hei : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k).symm (e k).target)
    (hcapture : ∀ k, (N k).carrier ⊆ (e k).source)
    {U : Set M} (hU : IsOpen U) (hUt : ∀ k, U ⊆ (e k).target)
    (hsmall : ∀ k, (N k).epsilon < 1 / 200) (q : M)
    {K : Set M} (hK : IsCompact K) (hKU : K ⊆ U)
    (hKq : K ⊆ (extChartAt (𝓡 3) q).source)
    (r : ℕ) (hr : 1 ≤ r) (horder : ∀ k, r ≤ ⌊(N k).epsilon⁻¹⌋₊)
    {l u : ℝ} (hl : 0 < l) (hu : 0 < u)
    (hscalar : ∀ k, l ≤ (N k).connection.scalarCurvature (N k).center ∧
      (N k).connection.scalarCurvature (N k).center ≤ u)
    (hambient : ∃ C : ℝ, ∀ᶠ k in atTop, ∀ j, j ≤ r →
      ∀ y ∈ (extChartAt (𝓡 3) q) '' K,
        ‖iteratedFDeriv ℝ j ((g k).parametrizedCoefficients
          ((e k).symm ∘ (extChartAt (𝓡 3) q).symm)) y‖ ≤ C)
    (helliptic : ∃ b : ℝ, 0 < b ∧ ∀ᶠ k in atTop,
      ∀ y ∈ (extChartAt (𝓡 3) q) '' K, ∀ w : E,
        b * ‖w‖ ^ 2 ≤ (g k).parametrizedCoefficients
          ((e k).symm ∘ (extChartAt (𝓡 3) q).symm) y w w)
    (hjet : ∀ j, j ≤ r → TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ j (fun y =>
        (g k).parametrizedCoefficients ((e k).symm ∘ (extChartAt (𝓡 3) q).symm) y -
        h.parametrizedCoefficients (extChartAt (𝓡 3) q).symm y))
      (fun _ => 0) atTop ((extChartAt (𝓡 3) q) '' K))
    {η : ℝ} (hη : 0 < η) :
    ∀ᶠ k in atTop, ∀ z : RoundCylinderSpace,
      z.2 ∈ Ioo (-(N k).epsilon⁻¹) (N k).epsilon⁻¹ →
      e k ((N k).coordinate_map z) ∈ K → ∀ j : ℕ, j ≤ r →
        ‖iteratedFDeriv ℝ j (fun p =>
          (g k).parametrizedCoefficients (centeredNeckLift (N k) z.1 z.2) p -
          h.parametrizedCoefficients (e k ∘ centeredNeckLift (N k) z.1 z.2) p) 0‖ ≤ η := by
  obtain ⟨C, hC⟩ := hambient
  obtain ⟨b, hb, hbnd⟩ := helliptic
  obtain ⟨a, ha⟩ := eventually_atTop.mp (hC.and hbnd)
  have htail := eventually_small_transported_neck_metric_errors_on_chart
    (fun k => g (k + a)) h (fun k => N (k + a)) (fun k => e (k + a))
    (fun k => he (k + a)) (fun k => hei (k + a)) (fun k => hcapture (k + a))
    hU (fun k => hUt (k + a)) (fun k => hsmall (k + a)) q hK hKU hKq
    r hr (fun k => horder (k + a)) hl hu hb (fun k => hscalar (k + a))
    ⟨C, fun k => (ha (k + a) (Nat.le_add_left a k)).1⟩
    (fun k => (ha (k + a) (Nat.le_add_left a k)).2)
    (fun j hj => (hjet j hj).seq_tendstoUniformlyOn (fun k => k + a)
      (tendsto_add_atTop_nat a)) hη
  obtain ⟨b', hb'⟩ := eventually_atTop.mp htail
  refine eventually_atTop.mpr ⟨b' + a, fun k hk => ?_⟩
  have hka : a ≤ k := by omega
  have hh := hb' (k - a) (by omega)
  exact (Nat.sub_add_cancel hka) ▸ hh

theorem eventually_small_transported_neck_errors_of_finite_chart_cover
    (g : ∀ k, RiemannianMetric 3 (X k)) (h : RiemannianMetric 3 M)
    (N : ∀ k, EpsilonNeck (g k)) (e : ∀ k, OpenPartialHomeomorph (X k) M)
    (he : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source)
    (hei : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k).symm (e k).target)
    (hcapture : ∀ k, (N k).carrier ⊆ (e k).source)
    {U A : Set M} (hU : IsOpen U) (hUt : ∀ k, U ⊆ (e k).target)
    (himage : ∀ k, e k '' (N k).carrier ⊆ A)
    (hsmall : ∀ k, (N k).epsilon < 1 / 200)
    {ι : Type*} (s : Finset ι) (q : ι → M) (K : ι → Set M)
    (hK : ∀ i ∈ s, IsCompact (K i) ∧ K i ⊆ U ∩ (extChartAt (𝓡 3) (q i)).source)
    (hcover : ∀ x ∈ A, ∃ i ∈ s, x ∈ K i)
    (r : ℕ) (hr : 1 ≤ r) (horder : ∀ k, r ≤ ⌊(N k).epsilon⁻¹⌋₊)
    {l u : ℝ} (hl : 0 < l) (hu : 0 < u)
    (hscalar : ∀ k, l ≤ (N k).connection.scalarCurvature (N k).center ∧
      (N k).connection.scalarCurvature (N k).center ≤ u)
    (hambient : ∀ i ∈ s, ∃ C : ℝ, ∀ᶠ k in atTop, ∀ j, j ≤ r →
      ∀ y ∈ (extChartAt (𝓡 3) (q i)) '' K i,
        ‖iteratedFDeriv ℝ j ((g k).parametrizedCoefficients
          ((e k).symm ∘ (extChartAt (𝓡 3) (q i)).symm)) y‖ ≤ C)
    (helliptic : ∀ i ∈ s, ∃ b : ℝ, 0 < b ∧ ∀ᶠ k in atTop,
      ∀ y ∈ (extChartAt (𝓡 3) (q i)) '' K i, ∀ w : E,
        b * ‖w‖ ^ 2 ≤ (g k).parametrizedCoefficients
          ((e k).symm ∘ (extChartAt (𝓡 3) (q i)).symm) y w w)
    (hjet : ∀ i ∈ s, ∀ j, j ≤ r → TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ j (fun y =>
        (g k).parametrizedCoefficients ((e k).symm ∘ (extChartAt (𝓡 3) (q i)).symm) y -
        h.parametrizedCoefficients (extChartAt (𝓡 3) (q i)).symm y))
      (fun _ => 0) atTop ((extChartAt (𝓡 3) (q i)) '' K i))
    {η : ℝ} (hη : 0 < η) :
    ∀ᶠ k in atTop, ∀ z : RoundCylinderSpace,
      z.2 ∈ Ioo (-(N k).epsilon⁻¹) (N k).epsilon⁻¹ → ∀ j : ℕ, j ≤ r →
        ‖iteratedFDeriv ℝ j (fun p =>
          (g k).parametrizedCoefficients (centeredNeckLift (N k) z.1 z.2) p -
          h.parametrizedCoefficients (e k ∘ centeredNeckLift (N k) z.1 z.2) p) 0‖ ≤ η := by
  have hlocal (i : ι) (hi : i ∈ s) :=
    eventually_small_transported_neck_errors_of_eventual_chart_bounds
      g h N e he hei hcapture hU hUt hsmall (q i) (hK i hi).1
      (fun _ hx => ((hK i hi).2 hx).1) (fun _ hx => ((hK i hi).2 hx).2)
      r hr horder hl hu hscalar (hambient i hi) (helliptic i hi) (hjet i hi) hη
  have hall := (eventually_all_finite s.finite_toSet).mpr hlocal
  filter_upwards [hall] with k hk z hz j hj
  have hzA := himage k (mem_image_of_mem (e k)
    (neck_coordinate_mem (N k) z ⟨mem_univ _, hz⟩))
  obtain ⟨i, hi, hzi⟩ := hcover _ hzA
  exact hk i hi z hz hzi j hj

end PoincareMT.TerminalNeck
