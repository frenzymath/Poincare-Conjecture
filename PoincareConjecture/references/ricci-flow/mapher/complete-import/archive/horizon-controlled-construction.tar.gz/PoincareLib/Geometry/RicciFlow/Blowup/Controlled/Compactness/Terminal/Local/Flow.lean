import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Bounds
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Curvature
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Ellipticity
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Limit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Metric
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.ReferenceBounds
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Derivatives

/-!
# Backward local flows from controlled source cylinders

Terminal convergence supplies the reference jets and ellipticity. The actual
source curvature estimates and Ricci equation then give closed spacetime
compactness, preserving the prescribed terminal metric and nonnegative
curvature through zero. Source: Morgan--Tian, Claim 11.5, p. 270.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.ControlledTerminal

open ControlledBlowupCylinder

theorem exists_local_backward_flow_on_subwindow
    (P04 : RicciFlowCurvatureTheory.{u})
    {S : GeneralizedBlowupSequence.{u}} {sigma : ℕ → ℕ} {eta : ℕ → ℝ}
    {L : Type v} [TopologicalSpace L] [ChartedSpace (EuclideanSpace ℝ (Fin 3)) L]
    [IsManifold (𝓡 3) ∞ L] (g : RiemannianMetric 3 L) (q : L)
    {rho R A T T' B : ℝ} (hrho : 0 < rho) (hR : 0 < R) (hRA : R < A)
    (hT : 0 < T) (hT' : 0 < T') (hT'T : T' < T) (hB : 0 ≤ B)
    (hchart : closedBall (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target)
    (cyl : ∀ k, ControlledBlowupCylinder S (sigma k) A T B (eta k))
    (Phi : ∀ k, PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
      (sourceBall S (sigma k) A) ∞)
    (hcompact : ∀ k, IsCompact (closure (S.baseBall (sigma k) A)))
    (hsource : ∀ k, (Phi k).source = ball (extChartAt (𝓡 3) q q) (2 * rho))
    (hcapture : ∀ k z, z ∈ (Phi k).source → (Phi k z).val ∈ S.baseBall (sigma k) R)
    (hconv : ∀ m, TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((((cyl k).ordinaryFlow hT).metric 0).pullbackCoefficients (Phi k)))
      (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm))
      atTop (closedBall (extChartAt (𝓡 3) q q) rho))
    (heta : Tendsto eta atTop (𝓝 0)) :
    let U : Opens (EuclideanSpace ℝ (Fin 3)) := ⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩
    ∃ tau : ℕ → ℕ, StrictMono tau ∧
      ∃ (b : ℝ × EuclideanSpace ℝ (Fin 3) →
        EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ)
        (F : RicciFlow 3 U (Icc (-T') 0)),
        ContDiffOn ℝ ∞ b (Icc (-T') 0 ×ˢ closedBall (extChartAt (𝓡 3) q q) rho) ∧
        (∀ t ∈ Icc (-T') 0, ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
          (F.metric t).inner x v w = b (t, x) v w) ∧
        (∀ (x : U) (v w : TangentSpace (𝓡 3) x),
          (F.metric 0).inner x v w =
            g.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w) ∧
        (∀ t ∈ Icc (-T') 0, ∀ x : U,
          (F.connection t).NonnegativeCurvatureOperator x) ∧
        ∀ m, TendstoUniformlyOn
          (fun k => iteratedFDerivWithin ℝ m
            (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
              (((cyl (tau k)).ordinaryFlow hT).metric z.1).pullbackCoefficients (Phi (tau k)) z.2)
            (Icc (-T') 0 ×ˢ closedBall (extChartAt (𝓡 3) q q) rho))
          (iteratedFDerivWithin ℝ m b
            (Icc (-T') 0 ×ˢ closedBall (extChartAt (𝓡 3) q q) rho))
          atTop (Icc (-T') 0 ×ˢ closedBall (extChartAt (𝓡 3) q q) rho) := by
  let E := EuclideanSpace ℝ (Fin 3)
  let x₀ := extChartAt (𝓡 3) q q
  let U : Opens E := ⟨ball x₀ rho, isOpen_ball⟩
  let W := closedBall x₀ rho
  let V := ball x₀ (2 * rho)
  have hWV : W ⊆ V := closedBall_subset_ball (by linarith)
  have hWPhi (k : ℕ) : W ⊆ (Phi k).source := by rw [hsource k]; exact hWV
  have hUPhi (k : ℕ) : (U : Set E) ⊆ (Phi k).source := ball_subset_closedBall.trans (hWPhi k)
  have hhalf : Icc (-T') 0 ⊆ Icc (-T) 0 := fun _ ht => ⟨by linarith [ht.1], ht.2⟩
  have hab : -T' < (0 : ℝ) := by linarith
  have hne : (Icc (-T') (0 : ℝ)).Nontrivial :=
    ⟨-T', ⟨le_rfl, hab.le⟩, 0, ⟨hab.le, le_rfl⟩, hab.ne⟩
  let Fseq (k : ℕ) := Poincare.Geometry.RicciFlow.Harnack.restrictFlow
    ((cyl k).ordinaryFlow hT) hhalf ordConnected_Icc hne
  let Fchart (k : ℕ) := (Fseq k).pullbackToPartialChart (Phi k) U (hUPhi k)
  let bseq (k : ℕ) (z : ℝ × E) := ((Fseq k).metric z.1).pullbackCoefficients (Phi k) z.2
  have he (k : ℕ) : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (Phi k) V := by
    simpa only [hsource k] using (Phi k).contMDiffOn_toFun
  have hi (k : ℕ) (x : E) (hx : x ∈ V) :
      (mfderiv (𝓡 3) (𝓡 3) (Phi k) x).IsInvertible := by
    have hd : IsLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞ (Phi k) x :=
      ⟨Phi k, by rw [hsource k]; exact hx, Set.eqOn_refl _ _⟩
    exact ⟨hd.mfderivToContinuousLinearEquiv (by simp), hd.mfderivToContinuousLinearEquiv_coe (by simp)⟩
  have hseq (k : ℕ) : ContDiffOn ℝ ∞ (bseq k) (Icc (-T') 0 ×ˢ W) :=
    ((Fseq k).contDiffOn_pullbackCoefficients_within isOpen_ball (he k)).mono
      (prod_mono subset_rfl hWV)
  have hcoeff (k : ℕ) (t : ℝ) (_ht : t ∈ Icc (-T') 0)
      (x : U) (v w : TangentSpace (𝓡 3) x) :
      ((Fchart k).metric t).inner x v w = bseq k (t, x) v w :=
    (Fseq k).pullbackToPartialChart_inner (Phi k) U (hUPhi k) t x v w
  obtain ⟨alpha, beta, halpha, hbeta, href⟩ :=
    eventually_elliptic_terminal_reference_coefficients g q
      (fun k => ((Fseq k).metric 0).pullbackCoefficients (Phi k))
      (isCompact_closedBall _ _) hchart hconv
  have hell : ∀ᶠ k in atTop, ∀ t ∈ Icc (-T') 0, ∀ x ∈ W, ∀ v,
      (Real.exp (-6 * B * T) * alpha) * ‖v‖ ^ 2 ≤ bseq k (t, x) v v ∧
        bseq k (t, x) v v ≤ (Real.exp (6 * B * T) * beta) * ‖v‖ ^ 2 := by
    filter_upwards [href] with k hk t ht x hx v
    exact (cyl k).ordinaryFlow_chart_ellipticity hT hB (Phi k) x (hk x hx) t (hhalf ht) v
  have hcurv (m : ℕ) : ∃ D : ℝ, 0 ≤ D ∧ ∀ᶠ k in atTop,
      ∀ t ∈ Icc (-T') 0, ∀ x ∈ W,
        ((Fseq k).connection t).curvatureDerivativeNorm m (Phi k x) ≤ D := by
    obtain ⟨D, hD, hder⟩ := exists_uniform_curvatureDerivative_bound_on_subwindow
      P04 hR hRA hT hT'T hB m
    exact ⟨D, hD.le, Eventually.of_forall fun k t ht x hx =>
      hder S (sigma k) (eta k) (cyl k) (hcompact k) t ht (Phi k x)
        (hcapture k x (hWPhi k hx))⟩
  have hrefjets (m : ℕ) : ∃ D : ℝ, 0 ≤ D ∧ ∀ᶠ k in atTop, ∀ x ∈ W,
      ‖iteratedFDeriv ℝ m (((Fseq k).metric 0).pullbackCoefficients (Phi k)) x‖ ≤ D :=
    eventually_bounded_terminal_reference_jets g q _ (isCompact_closedBall _ _) hchart hconv m
  have hbound := eventually_bounded_local_closed_spacetime_jets hab Fseq isOpen_ball
    (fun k => Phi k) he hi (by positivity : 0 < Real.exp (-6 * B * T) * alpha)
    (by positivity : 0 ≤ Real.exp (6 * B * T) * beta) hrho hWV hell hcurv hrefjets
  let gU := partialChartMetric (inverseMetricChart q) U
    (show (U : Set E) ⊆ (inverseMetricChart q).source from ball_subset_closedBall.trans hchart) g
  have hterminal (x : U) (v w : TangentSpace (𝓡 3) x) :
      Tendsto (fun k => ((Fchart k).metric 0).inner x v w) atTop (𝓝 (gU.inner x v w)) := by
    have hp := AncientCompactness.tendsto_of_compact_zero_jets
      (fun k => ((Fseq k).metric 0).pullbackCoefficients (Phi k))
      (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm) W
      (fun K _ hK => (hconv 0).mono hK) (ball_subset_closedBall x.property)
    have heval := ((ContinuousLinearMap.apply ℝ ℝ (show E from w)).continuous.tendsto _).comp
      (((ContinuousLinearMap.apply ℝ (E →L[ℝ] ℝ) (show E from v)).continuous.tendsto _).comp hp)
    simp only [Fchart, RicciFlow.pullbackToPartialChart_inner, gU, partialChartMetric_inner]
    exact heval
  obtain ⟨tau, htau, b, F, hb, hF, hterminalF, hjets⟩ :=
    exists_local_flow_with_terminal_metric hab hrho U Subset.rfl Fchart bseq hseq hcoeff hbound
      (by positivity : 0 < Real.exp (-6 * B * T) * alpha)
      (hell.mono fun k hk t ht x hx v => (hk t ht x (ball_subset_closedBall hx) v).1) gU hterminal
  have hnegative : ∀ᶠ k in atTop, ∀ t ∈ Icc (-T') 0, ∀ x : U,
      ((Fchart (tau k)).connection t).negativeCurvaturePart x ≤ eta (tau k) := by
    apply Eventually.of_forall
    intro k t ht x
    rw [LeviCivitaData.negativeCurvaturePart_eq_of_local_isometry
      ((Fchart (tau k)).connection t) ((Fseq (tau k)).connection t) isOpen_univ
      (partialChartMap_isLocalDiffeomorph (Phi (tau k)) U (hUPhi (tau k))).contMDiff.contMDiffOn
      (fun _ _ _ _ => rfl) (mem_univ x)]
    exact (cyl (tau k)).ordinaryFlow_negativeCurvaturePart_le hT t (hhalf ht) _
  have hnonneg := nonnegativeCurvatureOperator_of_local_closed_slab_jets hab hrho U Subset.rfl
    (fun k => Fchart (tau k)) F (fun k => bseq (tau k)) b (fun k => hseq (tau k)) hb
    (fun k => hcoeff (tau k)) hF hjets (heta.comp htau.tendsto_atTop) hnegative
  refine ⟨tau, htau, b, F, hb, hF, ?_, hnonneg, hjets⟩
  intro x v w
  exact (hterminalF x v w).trans (partialChartMetric_inner _ _ _ g x v w)

/-- The original final-half interface for terminal compactness. -/
theorem exists_local_backward_flow_of_cylinder_sequence
    (P04 : RicciFlowCurvatureTheory.{u})
    {S : GeneralizedBlowupSequence.{u}} {sigma : ℕ → ℕ} {eta : ℕ → ℝ}
    {L : Type v} [TopologicalSpace L] [ChartedSpace (EuclideanSpace ℝ (Fin 3)) L]
    [IsManifold (𝓡 3) ∞ L] (g : RiemannianMetric 3 L) (q : L)
    {rho R A T B : ℝ} (hrho : 0 < rho) (hR : 0 < R) (hRA : R < A)
    (hT : 0 < T) (hB : 0 ≤ B)
    (hchart : closedBall (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target)
    (cyl : ∀ k, ControlledBlowupCylinder S (sigma k) A T B (eta k))
    (Phi : ∀ k, PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
      (sourceBall S (sigma k) A) ∞)
    (hcompact : ∀ k, IsCompact (closure (S.baseBall (sigma k) A)))
    (hsource : ∀ k, (Phi k).source = ball (extChartAt (𝓡 3) q q) (2 * rho))
    (hcapture : ∀ k z, z ∈ (Phi k).source → (Phi k z).val ∈ S.baseBall (sigma k) R)
    (hconv : ∀ m, TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((((cyl k).ordinaryFlow hT).metric 0).pullbackCoefficients (Phi k)))
      (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm))
      atTop (closedBall (extChartAt (𝓡 3) q q) rho))
    (heta : Tendsto eta atTop (𝓝 0)) :
    let U : Opens (EuclideanSpace ℝ (Fin 3)) := ⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩
    ∃ tau : ℕ → ℕ, StrictMono tau ∧
      ∃ (b : ℝ × EuclideanSpace ℝ (Fin 3) →
        EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ)
        (F : RicciFlow 3 U (Icc (-T / 2) 0)),
        ContDiffOn ℝ ∞ b (Icc (-T / 2) 0 ×ˢ closedBall (extChartAt (𝓡 3) q q) rho) ∧
        (∀ t ∈ Icc (-T / 2) 0, ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
          (F.metric t).inner x v w = b (t, x) v w) ∧
        (∀ (x : U) (v w : TangentSpace (𝓡 3) x),
          (F.metric 0).inner x v w =
            g.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w) ∧
        (∀ t ∈ Icc (-T / 2) 0, ∀ x : U,
          (F.connection t).NonnegativeCurvatureOperator x) ∧
        ∀ m, TendstoUniformlyOn
          (fun k => iteratedFDerivWithin ℝ m
            (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
              (((cyl (tau k)).ordinaryFlow hT).metric z.1).pullbackCoefficients (Phi (tau k)) z.2)
            (Icc (-T / 2) 0 ×ˢ closedBall (extChartAt (𝓡 3) q q) rho))
          (iteratedFDerivWithin ℝ m b
            (Icc (-T / 2) 0 ×ˢ closedBall (extChartAt (𝓡 3) q q) rho))
          atTop (Icc (-T / 2) 0 ×ˢ closedBall (extChartAt (𝓡 3) q q) rho) := by
  dsimp only
  rw [neg_div]
  exact exists_local_backward_flow_on_subwindow P04 g q hrho hR hRA
    hT (T' := T / 2) (half_pos hT) (by linarith) hB hchart cyl Phi hcompact hsource hcapture
    hconv heta

end PoincareMT.ControlledTerminal
