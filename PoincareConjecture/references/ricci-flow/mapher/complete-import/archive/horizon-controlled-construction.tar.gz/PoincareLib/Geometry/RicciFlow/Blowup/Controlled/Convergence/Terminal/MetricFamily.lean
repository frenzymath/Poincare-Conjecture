import PoincareLib.Geometry.RicciFlow.AncientKappa.Compactness.Coordinates.FlowRealization

/-!
# Metric families from positive coefficients on a finite time interval
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.RiemannianMetric

/-- Smooth positive coefficients realize a metric family on any nonempty
time set and any open coordinate domain. -/
theorem exists_smoothFamily_of_coefficients_on_timeSet
    {n : ℕ} {J : Set ℝ} (hJ : J.Nonempty)
    (U : Opens (EuclideanSpace ℝ (Fin n)))
    (B : ℝ × EuclideanSpace ℝ (Fin n) →
      EuclideanSpace ℝ (Fin n) →L[ℝ] EuclideanSpace ℝ (Fin n) →L[ℝ] ℝ)
    (hB : ContDiffOn ℝ ∞ B (J ×ˢ (U : Set (EuclideanSpace ℝ (Fin n)))))
    (hsymm : ∀ t ∈ J, ∀ x ∈ U, ∀ v w, B (t, x) v w = B (t, x) w v)
    (hlower : ∀ t ∈ J, ∀ x ∈ U, ∃ c : ℝ, 0 < c ∧
      ∀ v, c * ‖v‖ ^ 2 ≤ B (t, x) v v) :
    ∃ g : ℝ → RiemannianMetric n U, IsSmoothFamilyOn g J ∧
      ∀ t ∈ J, ∀ (x : U) (v w : TangentSpace (𝓡 n) x),
        (g t).inner x v w = B (t, x) v w := by
  classical
  obtain ⟨t₀, ht₀⟩ := hJ
  let time : ℝ → ℝ := fun t => if t ∈ J then t else t₀
  have htime (t : ℝ) : time t ∈ J := by dsimp [time]; split_ifs with ht <;> assumption
  have hslice (t : ℝ) (ht : t ∈ J) :
      ContDiffOn ℝ ∞ (fun x => B (t, x)) U :=
    hB.comp (contDiff_const.prodMk contDiff_id).contDiffOn (fun x hx => ⟨ht, hx⟩)
  have hex (t : ℝ) : ∃ g : RiemannianMetric n U,
      ∀ (x : U) (v w : TangentSpace (𝓡 n) x), g.inner x v w = B (time t, x) v w := by
    apply exists_of_coordinate_limit U (fun _ x => B (time t, x)) (fun x => B (time t, x))
      (hslice _ (htime t))
    · exact fun _ x hx => hsymm _ (htime t) x hx
    · exact fun _ _ _ _ => tendsto_const_nhds
    · intro x hx
      obtain ⟨c, hc, hbound⟩ := hlower _ (htime t) x hx
      exact ⟨c, hc, Eventually.of_forall fun _ => hbound⟩
  choose g hg using hex
  have hcoeff (t : ℝ) (ht : t ∈ J) (x : U) (v w : TangentSpace (𝓡 n) x) :
      (g t).inner x v w = B (t, x) v w := by
    simpa only [time, if_pos ht] using hg t x v w
  refine ⟨g, ?_, hcoeff⟩
  apply isSmoothFamilyOn_of_constant_chart (fun x y => by simp [Opens.chartAt_eq]) g
    (fun p => B (p.1, p.2)) ?_ hcoeff
  have hmap : ContMDiff (𝓘(ℝ, ℝ).prod (𝓡 n))
      𝓘(ℝ, ℝ × EuclideanSpace ℝ (Fin n)) ∞
      (fun p : ℝ × U => (p.1, (p.2 : EuclideanSpace ℝ (Fin n)))) :=
    contMDiff_fst.prodMk_space (contMDiff_subtype_val.comp contMDiff_snd)
  exact hB.contMDiffOn.comp hmap.contMDiffOn (fun p hp => ⟨hp.1, p.2.property⟩)

end PoincareMT.RiemannianMetric
