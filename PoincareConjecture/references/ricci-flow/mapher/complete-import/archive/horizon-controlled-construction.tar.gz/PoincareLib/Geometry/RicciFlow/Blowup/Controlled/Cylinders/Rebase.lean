import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.Cylinders.Clock
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.NeckTransfer
import PoincareLib.Geometry.RicciFlow.Generalized.Noncollapse.Cylinder.BallTopology

/-!
# Rebasing a cylinder on a later source slice

The actual inverse slice chart returns an open region in any slice image to
the original cylinder source. Changing the clock then makes that slice the
new terminal slice, with its exact identity map. This supplies source balls
for noncollapsing at arbitrary times of controlled blowup limits.

Reference: Morgan--Tian, Theorems 11.1 and 11.8, pp. 267-278.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Function
open scoped Manifold ContDiff Topology

universe u

namespace PoincareMT.GeneralizedFlowCylinder

/-- Rebase on any open subset of an actual slice image, retaining the exact
original trajectories after an arbitrary positive change of scale. -/
theorem exists_on_slice_image_subset
    {F : GeneralizedRicciFlowData.{u}} {C : GeneralizedSliceCarrier.{u}}
    {origin scale : ℝ} {I J : Set ℝ} {U : Set C.carrier}
    (d : GeneralizedFlowCylinder F C origin scale I U) (hU : IsOpen U)
    {b : ℝ} (hb : b ∈ I) {newScale : ℝ} (hscale : 0 < newScale)
    (hJ : ∀ s ∈ J, b + s * scale / newScale ∈ I)
    {W : Set (F.slice (origin + b / scale)).carrier} (hW : IsOpen W)
    (hcover : W ⊆ d.forward b hb '' U) :
    ∃ n : GeneralizedFlowCylinder F (F.slice (origin + b / scale))
        (origin + b / scale) newScale J W,
      (∀ hzero x, x ∈ W → n.pointMap 0 hzero x =
        (⟨origin + b / scale, x⟩ : F.point)) ∧
      ∀ s (hs : s ∈ J) x, x ∈ W → n.pointMap s hs x =
        d.pointMap (b + s * scale / newScale) (hJ s hs) (d.inverse b hb x) := by
  let e := d.sliceHomeomorph hU b hb
  let f := e.symm.restrOpen W hW
  have hsource : W ⊆ f.source := fun x hx => ⟨hcover hx, hx⟩
  have htarget : f.target ⊆ U := fun _ hx => hx.1
  have hf : ContMDiffOn (𝓡 3) (𝓡 3) ∞ f f.source :=
    (d.inverse_smooth b hb).mono inter_subset_left
  have hfi : ContMDiffOn (𝓡 3) (𝓡 3) ∞ f.symm f.target :=
    (d.forward_smooth b hb).mono htarget
  let raw := (d.rebasePartialSource f htarget hf hfi).restrict Subset.rfl hsource
  have hclock (s : ℝ) : (origin + b / scale + s / newScale - origin) * scale =
      b + s * scale / newScale := by
    field_simp [d.scale_pos.ne', hscale.ne']
    ring
  have hclock_mem (s : ℝ) (hs : s ∈ J) :
      (origin + b / scale + s / newScale - origin) * scale ∈ I := by
    rw [hclock]
    exact hJ s hs
  let n := raw.reclock (origin + b / scale) newScale hscale hclock_mem
  have hn (s : ℝ) (hs : s ∈ J) (x : (F.slice (origin + b / scale)).carrier) :
      n.pointMap s hs x = d.pointMap (b + s * scale / newScale) (hJ s hs)
        (d.inverse b hb x) := by
    rw [reclock_pointMap]
    change d.pointMap _ _ (d.inverse b hb x) = _
    congr 1
    exact hclock s
  refine ⟨n, ?_, fun s hs x _ => hn s hs x⟩
  intro hzero x hx
  rw [hn]
  simp only [zero_mul, zero_div, add_zero]
  exact congrArg (fun y => (⟨origin + b / scale, y⟩ : F.point))
    (d.right_inverse b hb (hcover hx))

/-- An actual source ball contained in a later slice image carries the
scale-one backward cylinder required by generalized noncollapsing. -/
theorem exists_on_slice_ball
    {F : GeneralizedRicciFlowData.{u}} {C : GeneralizedSliceCarrier.{u}}
    {origin scale : ℝ} {I : Set ℝ} {U : Set C.carrier}
    (d : GeneralizedFlowCylinder F C origin scale I U) (hU : IsOpen U)
    {b : ℝ} (hb : b ∈ I) (p : C.carrier) (r : ℝ)
    (htime : ∀ s ∈ Ioc (-r ^ 2) 0, b + scale * s ∈ I)
    (hcover : (F.metric (origin + b / scale)).ball (d.forward b hb p) r ⊆
      d.forward b hb '' U) :
    Ioc (origin + b / scale - r ^ 2) (origin + b / scale) ⊆ F.interval ∧
    ∃ n : GeneralizedFlowCylinder F (F.slice (origin + b / scale))
        (origin + b / scale) 1 (Ioc (-r ^ 2) 0)
        ((F.metric (origin + b / scale)).ball (d.forward b hb p) r),
      (∀ hzero x, x ∈ (F.metric (origin + b / scale)).ball (d.forward b hb p) r →
        n.pointMap 0 hzero x = (⟨origin + b / scale, x⟩ : F.point)) ∧
      ∀ s (hs : s ∈ Ioc (-r ^ 2) 0) x,
        x ∈ (F.metric (origin + b / scale)).ball (d.forward b hb p) r →
        n.pointMap s hs x = d.pointMap (b + scale * s) (htime s hs) (d.inverse b hb x) := by
  have hJ (s : ℝ) (hs : s ∈ Ioc (-r ^ 2) 0) : b + s * scale / 1 ∈ I := by
    simpa only [div_one, mul_comm] using htime s hs
  obtain ⟨n, hn0, hn⟩ := d.exists_on_slice_image_subset hU hb zero_lt_one hJ
    (RicciFlowAnalysis.initial_ball_isOpen _ _ _) hcover
  refine ⟨?_, n, hn0, ?_⟩
  · intro t ht
    have hs : t - (origin + b / scale) ∈ Ioc (-r ^ 2) 0 :=
      ⟨by linarith [ht.1], by linarith [ht.2]⟩
    have hh := (F.slice_nonempty_iff _).mp
      ⟨n.forward (t - (origin + b / scale)) hs (d.forward b hb p)⟩
    simpa only [div_one, add_sub_cancel] using hh
  · intro s hs x hx
    simpa only [div_one, mul_comm] using hn s hs x hx

/-- In the original normalized units, a backward interval of length
`rho ^ 2` produces the physical source-ball cylinder of radius
`rho / sqrt scale`. -/
theorem exists_on_normalized_slice_ball
    {F : GeneralizedRicciFlowData.{u}} {C : GeneralizedSliceCarrier.{u}}
    {origin scale : ℝ} {I : Set ℝ} {U : Set C.carrier}
    (d : GeneralizedFlowCylinder F C origin scale I U) (hU : IsOpen U)
    {b : ℝ} (hb : b ∈ I) (p : C.carrier) (rho : ℝ)
    (htime : Ioc (b - rho ^ 2) b ⊆ I)
    (hcover : (F.metric (origin + b / scale)).ball (d.forward b hb p)
        (rho / Real.sqrt scale) ⊆ d.forward b hb '' U) :
    Ioc (origin + b / scale - (rho / Real.sqrt scale) ^ 2)
        (origin + b / scale) ⊆ F.interval ∧
    ∃ n : GeneralizedFlowCylinder F (F.slice (origin + b / scale))
        (origin + b / scale) 1 (Ioc (-(rho / Real.sqrt scale) ^ 2) 0)
        ((F.metric (origin + b / scale)).ball (d.forward b hb p) (rho / Real.sqrt scale)),
      (∀ hzero x, x ∈ (F.metric (origin + b / scale)).ball (d.forward b hb p)
          (rho / Real.sqrt scale) →
        n.pointMap 0 hzero x = (⟨origin + b / scale, x⟩ : F.point)) ∧
      ∀ s (hs : s ∈ Ioc (-(rho / Real.sqrt scale) ^ 2) 0) x,
        x ∈ (F.metric (origin + b / scale)).ball (d.forward b hb p) (rho / Real.sqrt scale) →
        ∃ h : b + scale * s ∈ I,
          n.pointMap s hs x = d.pointMap (b + scale * s) h (d.inverse b hb x) := by
  have hsq : (rho / Real.sqrt scale) ^ 2 * scale = rho ^ 2 := by
    rw [div_pow, Real.sq_sqrt d.scale_pos.le]
    exact div_mul_cancel₀ _ d.scale_pos.ne'
  have hJ (s : ℝ) (hs : s ∈ Ioc (-(rho / Real.sqrt scale) ^ 2) 0) :
      b + scale * s ∈ I := by
    apply htime
    constructor
    · have hh := mul_lt_mul_of_pos_right hs.1 d.scale_pos
      nlinarith [hsq]
    · exact add_le_of_nonpos_right (mul_nonpos_of_nonneg_of_nonpos d.scale_pos.le hs.2)
  obtain ⟨hI, n, hn0, hn⟩ := d.exists_on_slice_ball hU hb p (rho / Real.sqrt scale) hJ hcover
  exact ⟨hI, n, hn0, fun s hs x hx => ⟨hJ s hs, hn s hs x hx⟩⟩

end PoincareMT.GeneralizedFlowCylinder
