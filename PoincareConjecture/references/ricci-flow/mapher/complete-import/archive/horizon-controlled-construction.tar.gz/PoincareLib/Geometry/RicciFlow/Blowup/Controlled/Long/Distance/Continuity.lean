import PoincareLib.Geometry.RicciFlow.MetricComparison
import PoincareLib.Geometry.Riemannian.Distance.Basic

/-! # Distance continuity on closed Ricci-flow time sets -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledLongDistance

variable {n : ℕ} {M : Type*} [TopologicalSpace M] [T3Space M] [PreconnectedSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
  {J I : Set ℝ} (F : RicciFlow n M J)

theorem toReal_edist_le_exp_mul_of_global_ricci_bound
    (hI : Convex ℝ I) (hIJ : I ⊆ J) (K : ℝ)
    (hRic : ∀ t ∈ I, ∀ x : M, ∀ v : TangentSpace (𝓡 n) x,
      |(F.connection t).ricci x v v| ≤ K * (F.metric t).inner x v v)
    {s t : ℝ} (hs : s ∈ I) (ht : t ∈ I) (p x : M) :
    ((F.metric t).edist p x).toReal ≤
      Real.exp (K * |t - s|) * ((F.metric s).edist p x).toReal := by
  let r := ((F.metric s).edist p x).toReal + 1
  have hr : 0 < r := by dsimp [r]; positivity
  have hp : p ∈ (F.metric s).ball p r := by
    change (F.metric s).edist p p < ENNReal.ofReal r
    simpa only [RiemannianMetric.edist, Manifold.riemannianEDist_self]
      using ENNReal.ofReal_pos.mpr hr
  have hx : x ∈ (F.metric s).ball p r := by
    change (F.metric s).edist p x < ENNReal.ofReal r
    rw [← ENNReal.ofReal_toReal ((F.metric s).edist_ne_top p x)]
    exact (ENNReal.ofReal_lt_ofReal_iff hr).mpr (by dsimp [r]; linarith)
  have h := F.edist_le_exp_mul_of_ricci_bound hI hIJ p r K hr hs ht
    (fun t ht z _ v => hRic t ht z v) hp hx
  have hfinite : ENNReal.ofReal (Real.exp (K * |t - s|)) *
      (F.metric s).edist p x ≠ ⊤ :=
    ENNReal.mul_ne_top ENNReal.ofReal_ne_top ((F.metric s).edist_ne_top p x)
  simpa only [ENNReal.toReal_mul, ENNReal.toReal_ofReal (Real.exp_nonneg _)]
    using ENNReal.toReal_mono hfinite h

theorem continuousOn_toReal_edist_of_global_ricci_bound
    (hI : Convex ℝ I) (hIJ : I ⊆ J) (K : ℝ)
    (hRic : ∀ t ∈ I, ∀ x : M, ∀ v : TangentSpace (𝓡 n) x,
      |(F.connection t).ricci x v v| ≤ K * (F.metric t).inner x v v)
    (p x : M) : ContinuousOn (fun t => ((F.metric t).edist p x).toReal) I := by
  intro a ha
  let d := ((F.metric a).edist p x).toReal
  let c : ℝ → ℝ := fun t => Real.exp (K * |t - a|)
  have hc : Continuous c := by dsimp [c]; fun_prop
  have hclim : Tendsto c (𝓝[I] a) (𝓝 (1 : ℝ)) := by
    simpa only [c, sub_self, abs_zero, mul_zero, Real.exp_zero] using
      hc.continuousAt.continuousWithinAt.tendsto (s := I) (x := a)
  have hlo : Tendsto (fun t => d / c t) (𝓝[I] a) (𝓝 d) := by
    have hh := (tendsto_const_nhds (x := d) (f := 𝓝[I] a)).div hclim
      (by norm_num : (1 : ℝ) ≠ 0)
    change Tendsto (fun t => d / c t) (𝓝[I] a) (𝓝 (d / 1)) at hh
    simpa only [div_one] using hh
  have hhi : Tendsto (fun t => c t * d) (𝓝[I] a) (𝓝 d) := by
    simpa only [one_mul] using hclim.mul_const d
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' hlo hhi ?_ ?_
  · filter_upwards [self_mem_nhdsWithin] with t ht
    apply (div_le_iff₀ (Real.exp_pos _)).mpr
    have h := toReal_edist_le_exp_mul_of_global_ricci_bound F hI hIJ K hRic ht ha p x
    simpa only [abs_sub_comm a t, mul_comm, c, d] using h
  · filter_upwards [self_mem_nhdsWithin] with t ht
    exact toReal_edist_le_exp_mul_of_global_ricci_bound F hI hIJ K hRic ha ht p x

end PoincareMT.ControlledLongDistance
