import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.JetPositivity
import PoincareLib.Geometry.RicciFlow.Compactness.Convergence.Curvature.MovingJets
import PoincareLib.Geometry.RicciFlow.AncientKappa.Asymptotic.Inheritance.Scalar

/-!
# Curvature of locally realized pullback metric germs
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 800000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.LeviCivitaData

attribute [local instance] normedAddCommGroupTangentSpaceVectorSpace
  normedSpaceTangentSpaceVectorSpace

/-- An actual local pullback admits a Euclidean metric germ retaining its
scalar curvature and negative curvature part at the chosen point. -/
theorem exists_pullback_curvature_germ
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {g : RiemannianMetric 3 M} (D : LeviCivitaData g)
    (φ : EuclideanSpace ℝ (Fin 3) → M) (p : EuclideanSpace ℝ (Fin 3))
    (hφ : ∀ᶠ y in 𝓝 p, ContMDiffAt (𝓡 3) (𝓡 3) ∞ φ y ∧
      Function.Injective (mfderiv (𝓡 3) (𝓡 3) φ y)) :
    ∃ gd : Σ h : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3)), LeviCivitaData h,
      (gd.1.euclideanCoefficients =ᶠ[𝓝 p] g.pullbackCoefficients φ) ∧
      gd.2.scalarCurvature p = D.scalarCurvature (φ p) ∧
      gd.2.negativeCurvaturePart p = D.negativeCurvaturePart (φ p) := by
  obtain ⟨U, hUφ, hUo, hpU⟩ := mem_nhds_iff.mp hφ
  have hpos : ∀ y ∈ U, ∀ v, v ≠ 0 → 0 < g.pullbackCoefficients φ y v v := by
    intro y hy v hv
    apply g.pos (φ y)
    intro hz
    apply hv
    apply (hUφ hy).2
    rw [map_zero]
    convert! hz using 1
  obtain ⟨h, Dh, W, hWo, hpW, hWU, heq⟩ := RiemannianMetric.exists_local_realization hUo hpU
    (g.pullbackCoefficients φ)
    (fun y hy => (g.contDiffAt_pullbackCoefficients (hUφ hy).1).contDiffWithinAt)
    (fun y _ v w => g.symm _ _ _) hpos
  have hs : ContMDiffOn (𝓡 3) (𝓡 3) ∞ φ W :=
    fun y hy => (hUφ (hWU hy)).1.contMDiffWithinAt
  have hi : ∀ y ∈ W, ∀ v w : TangentSpace (𝓡 3) y,
      h.inner y v w = g.inner (φ y) (mfderiv (𝓡 3) (𝓡 3) φ y v)
        (mfderiv (𝓡 3) (𝓡 3) φ y w) := fun y hy v w => congrArg (fun B => B v w) (heq y hy)
  exact ⟨⟨h, Dh⟩, Filter.Eventually.mono (hWo.mem_nhds hpW) heq,
    Dh.scalarCurvature_eq_of_local_isometry D hWo hs hi hpW,
    Dh.negativeCurvaturePart_eq_of_local_isometry D hWo hs hi hpW⟩

/-- Scalar curvature converges under genuine local pullback second jets. -/
theorem tendsto_scalarCurvature_of_scalar_pullback_jets
    {M : ℕ → Type*} [∀ k, TopologicalSpace (M k)]
    [∀ k, ChartedSpace (EuclideanSpace ℝ (Fin 3)) (M k)]
    [∀ k, IsManifold (𝓡 3) ∞ (M k)]
    {g : ∀ k, RiemannianMetric 3 (M k)} (D : ∀ k, LeviCivitaData (g k))
    (φ : ∀ k, EuclideanSpace ℝ (Fin 3) → M k)
    {h : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3))} (Dh : LeviCivitaData h)
    (p : EuclideanSpace ℝ (Fin 3))
    (hφ : ∀ᶠ k in atTop, ∀ᶠ y in 𝓝 p, ContMDiffAt (𝓡 3) (𝓡 3) ∞ (φ k) y ∧
      Function.Injective (mfderiv (𝓡 3) (𝓡 3) (φ k) y))
    (hjets : ∀ r : ℕ, r ≤ 2 → ∀ a b : Fin 3,
      Tendsto (fun k => iteratedFDeriv ℝ r (fun y =>
        (g k).pullbackCoefficients (φ k) y (EuclideanSpace.basisFun (Fin 3) ℝ a)
          (EuclideanSpace.basisFun (Fin 3) ℝ b)) p) atTop
        (𝓝 (iteratedFDeriv ℝ r (fun y => h.inner y (EuclideanSpace.basisFun (Fin 3) ℝ a)
          (EuclideanSpace.basisFun (Fin 3) ℝ b)) p))) :
    Tendsto (fun k => (D k).scalarCurvature (φ k p)) atTop (𝓝 (Dh.scalarCurvature p)) := by
  have hreal := hφ.mono fun k hk => exists_pullback_curvature_germ (D k) (φ k) p hk
  obtain ⟨gd, hgd⟩ := hreal.choice
  have hj (r : ℕ) (hr : r ≤ 2) (a b : Fin 3) :
      Tendsto (fun k => iteratedFDeriv ℝ r (fun y =>
        (gd k).1.inner y (EuclideanSpace.basisFun (Fin 3) ℝ a)
          (EuclideanSpace.basisFun (Fin 3) ℝ b)) p) atTop
        (𝓝 (iteratedFDeriv ℝ r (fun y => h.inner y (EuclideanSpace.basisFun (Fin 3) ℝ a)
          (EuclideanSpace.basisFun (Fin 3) ℝ b)) p)) := by
    apply (hjets r hr a b).congr'
    filter_upwards [hgd] with k hk
    have hs := hk.1.mono fun y hy => congrArg (fun B : EuclideanSpace ℝ (Fin 3) →L[ℝ]
        EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ =>
      B (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) hy
    exact (Filter.EventuallyEq.iteratedFDeriv ℝ hs r).self_of_nhds.symm
  have hlim := tendsto_scalarCurvature_of_scalar_metric_jets (fun k => (gd k).2)
    Dh p (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis hj
  exact hlim.congr' (hgd.mono fun k hk => hk.2.1)

/-- A vanishing source pinching error yields nonnegative limit curvature
under actual local pullback second jets. -/
theorem nonnegativeCurvatureOperator_of_scalar_pullback_jets
    {M : ℕ → Type*} [∀ k, TopologicalSpace (M k)]
    [∀ k, ChartedSpace (EuclideanSpace ℝ (Fin 3)) (M k)]
    [∀ k, IsManifold (𝓡 3) ∞ (M k)]
    {g : ∀ k, RiemannianMetric 3 (M k)} (D : ∀ k, LeviCivitaData (g k))
    (φ : ∀ k, EuclideanSpace ℝ (Fin 3) → M k)
    {h : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3))} (Dh : LeviCivitaData h)
    (p : EuclideanSpace ℝ (Fin 3))
    (hφ : ∀ᶠ k in atTop, ∀ᶠ y in 𝓝 p, ContMDiffAt (𝓡 3) (𝓡 3) ∞ (φ k) y ∧
      Function.Injective (mfderiv (𝓡 3) (𝓡 3) (φ k) y))
    (hjets : ∀ r : ℕ, r ≤ 2 → ∀ a b : Fin 3,
      Tendsto (fun k => iteratedFDeriv ℝ r (fun y =>
        (g k).pullbackCoefficients (φ k) y (EuclideanSpace.basisFun (Fin 3) ℝ a)
          (EuclideanSpace.basisFun (Fin 3) ℝ b)) p) atTop
        (𝓝 (iteratedFDeriv ℝ r (fun y => h.inner y (EuclideanSpace.basisFun (Fin 3) ℝ a)
          (EuclideanSpace.basisFun (Fin 3) ℝ b)) p)))
    {eta : ℕ → ℝ} (heta : Tendsto eta atTop (𝓝 0))
    (hneg : ∀ᶠ k in atTop, (D k).negativeCurvaturePart (φ k p) ≤ eta k) :
    Dh.NonnegativeCurvatureOperator p := by
  have hreal := hφ.mono fun k hk => exists_pullback_curvature_germ (D k) (φ k) p hk
  obtain ⟨gd, hgd⟩ := hreal.choice
  refine nonnegativeCurvatureOperator_of_scalar_metric_jets_of_negativePart
    (fun k => (gd k).2) Dh p (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis ?_ heta ?_
  · intro r hr a b
    apply (hjets r hr a b).congr'
    filter_upwards [hgd] with k hk
    have hs := hk.1.mono fun y hy => congrArg (fun B : EuclideanSpace ℝ (Fin 3) →L[ℝ]
        EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ =>
      B (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) hy
    exact (Filter.EventuallyEq.iteratedFDeriv ℝ hs r).self_of_nhds.symm
  · filter_upwards [hgd, hneg] with k hk hn
    rw [hk.2.2]
    exact hn

end PoincareMT.LeviCivitaData
