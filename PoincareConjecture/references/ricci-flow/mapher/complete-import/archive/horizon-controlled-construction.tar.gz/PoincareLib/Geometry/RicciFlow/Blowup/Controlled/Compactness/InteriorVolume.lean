import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.TerminalBalls
import PoincareLib.Geometry.RicciFlow.AncientKappa.Asymptotic.Compactness.Calibration

/-!
# Noncollapse at interior reference times

The exact terminal volume and uniform curvature bound give a positive volume
bound at every fixed interior time, with explicit radius and volume factors.
Source: Morgan--Tian, Theorem 5.15, p. 92, and Theorem 11.1, pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set MeasureTheory
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

/-- The terminal measure is bounded by the earlier metric measure with the
cube of the length distortion, on the actual terminal intrinsic ball. -/
theorem ordinaryFlow_terminal_volume_le (e : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (hT : 0 < T) {s : ℝ} (hs : s ∈ Icc (-T) 0) (r : ℝ) :
    ((e.ordinaryFlow hT).metric 0).volumeMeasure
        (((e.ordinaryFlow hT).metric 0).ball (sourceBase S k hA) r) ≤
      ENNReal.ofReal (Real.exp (3 * B * |s|)) ^ 3 *
        ((e.ordinaryFlow hT).metric s).volumeMeasure
          (((e.ordinaryFlow hT).metric s).ball (sourceBase S k hA)
            (Real.exp (3 * B * |s|) * r)) := by
  let F := e.ordinaryFlow hT
  let E := OpenPartialHomeomorph.refl (sourceBall S k A)
  have hzero : (0 : ℝ) ∈ Icc (-T) 0 := ⟨by linarith, le_rfl⟩
  have hv := (F.metric s).volumeMeasure_image_le_of_tangentNorm_le (F.metric 0)
    E isOpen_univ (subset_refl _) contMDiff_id.contMDiffOn
    (Real.exp_pos (3 * B * |s|))
    (fun x _ v => by
      change (F.metric 0).tangentNorm x (mfderiv (𝓡 3) (𝓡 3) id x v) ≤ _
      simpa [F, mfderiv_id] using
        e.ordinaryFlow_tangentNorm_le hT x v hs hzero)
    (RicciFlowAnalysis.initial_ball_isOpen (F.metric 0) (sourceBase S k hA) r).measurableSet
    (subset_univ _)
  have hE : (E : sourceBall S k A → sourceBall S k A) = id := rfl
  rw [hE, image_id] at hv
  apply hv.trans
  apply mul_le_mul_right
  apply measure_mono
  apply RiemannianMetric.ball_subset_ball_of_tangentNorm_le _ _ _ _ _ (Real.exp_pos _)
  intro x _ v
  simpa only [sub_zero] using e.ordinaryFlow_tangentNorm_le hT x v hzero hs

/-- The normalized terminal lower bound transfers to an interior ball. -/
theorem ordinaryFlow_interior_volume_lower
    (e : ControlledBlowupCylinder S k A T B eta) (hA : 0 < A) (hT : 0 < T)
    {s r v : ℝ} (hs : s ∈ Icc (-T) 0) (hrA : r ≤ A)
    (hvolume : ENNReal.ofReal (v / (Real.sqrt (S.scale k)) ^ 3) ≤
      calibratedMetricVolume ((S.flow k).metric (S.base k).1) (S.baseBall k r)) :
    ENNReal.ofReal (v / Real.exp (3 * B * |s|) ^ 3) ≤
      ((e.ordinaryFlow hT).metric s).volumeMeasure
        (((e.ordinaryFlow hT).metric s).ball (sourceBase S k hA)
          (Real.exp (3 * B * |s|) * r)) := by
  have hsqrt : 0 < Real.sqrt (S.scale k) := Real.sqrt_pos.mpr (S.base_scalar_pos k)
  rw [calibratedMetricVolume_eq_volumeMeasure] at hvolume
  have hterminal : ENNReal.ofReal v ≤ ((e.ordinaryFlow hT).metric 0).volumeMeasure
      (((e.ordinaryFlow hT).metric 0).ball (sourceBase S k hA) r) := by
    rw [e.ordinaryFlow_terminal_volume_ball hA hT hrA, rescaledMetric_volumeMeasure,
      Measure.smul_apply, smul_eq_mul]
    have hm := mul_le_mul_right hvolume (ENNReal.ofReal (Real.sqrt (S.scale k) ^ 3))
    rw [← ENNReal.ofReal_mul (pow_nonneg hsqrt.le 3),
      mul_div_cancel₀ _ (pow_ne_zero 3 hsqrt.ne')] at hm
    simpa only [ENNReal.ofReal_pow hsqrt.le] using hm
  have h := hterminal.trans (e.ordinaryFlow_terminal_volume_le hA hT hs r)
  rw [ENNReal.ofReal_div_of_pos (pow_pos (Real.exp_pos _) 3), ENNReal.ofReal_pow
    (Real.exp_nonneg _) ]
  exact (ENNReal.div_le_iff (pow_ne_zero _ (ENNReal.ofReal_pos.mpr (Real.exp_pos _)).ne')
    (ENNReal.pow_ne_top ENNReal.ofReal_ne_top)).mpr (by simpa only [mul_comm] using h)

end PoincareMT.ControlledBlowupCylinder
