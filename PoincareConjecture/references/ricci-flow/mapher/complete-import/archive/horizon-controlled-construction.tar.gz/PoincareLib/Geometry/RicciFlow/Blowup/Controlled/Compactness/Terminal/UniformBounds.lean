import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Curvature.Inheritance

/-!
# Radius-independent terminal bounds on the selected source sequence

A global scalar bound on the complete terminal limit, together with actual
ball coverage and compact-uniform scalar convergence, gives one bound before
all source radii. This is the quantifier needed for a common backward time.
Source: Morgan--Tian, Claim 11.5 and the proof of Claim 11.7, pp. 270--271.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.ControlledTerminal

theorem eventually_uniform_source_scalar_bound
    {S : GeneralizedBlowupSequence.{u}} {sigma : ℕ → ℕ}
    {M : Type v} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    {g : RiemannianMetric 3 M} (D : LeviCivitaData g)
    (E : ℕ → Set M) (hEK : ∀ j, IsCompact (closure (E j)))
    (f : ∀ k, M → S.terminalComponent (sigma k))
    (hcover : ∀ A : ℝ, 0 < A → ∃ j, ∀ᶠ k in atTop,
      (S.terminalComponentMetric (sigma k)).ball (S.terminalComponentBase (sigma k)) A ⊆
        f k '' E j)
    (hscalar : ∀ K : Set M, IsCompact K → TendstoUniformlyOn
      (fun k x => (S.terminalComponentConnection (sigma k)).scalarCurvature (f k x))
      D.scalarCurvature atTop K)
    {B : ℝ} (hbound : ∀ x, D.scalarCurvature x ≤ B) :
    ∀ A : ℝ, 0 < A → ∀ᶠ k in atTop, ∀ x ∈ S.baseBall (sigma k) A,
      (S.flow (sigma k)).scalar ⟨(S.base (sigma k)).1, x⟩ ≤ (B + 1) * S.scale (sigma k) := by
  intro A hA
  obtain ⟨j, hj⟩ := hcover A hA
  filter_upwards [hj, Metric.tendstoUniformlyOn_iff.mp
    (hscalar (closure (E j)) (hEK j)) 1 zero_lt_one] with k hk hclose x hx
  rw [← S.terminalComponentMetric_image_ball] at hx
  obtain ⟨y, hy, rfl⟩ := hx
  obtain ⟨z, hz, hzy⟩ := hk hy
  have hdist := hclose z (subset_closure hz)
  rw [Real.dist_eq, abs_sub_comm] at hdist
  have hupper : (S.terminalComponentConnection (sigma k)).scalarCurvature (f k z) ≤ B + 1 := by
    linarith [(abs_lt.mp hdist).2, hbound z]
  rw [hzy, S.terminalComponentConnection_scalarCurvature,
    S.normalizedTerminalConnection_scalarCurvature] at hupper
  have hscale : 0 < S.scale (sigma k) := S.base_scalar_pos (sigma k)
  have hh := mul_le_mul_of_nonneg_left hupper hscale.le
  rw [← mul_assoc, mul_inv_cancel₀ hscale.ne', one_mul] at hh
  change ((S.flow (sigma k)).connection (S.base (sigma k)).1).scalarCurvature y.val ≤ _
  exact hh.trans_eq (mul_comm _ _)

end PoincareMT.ControlledTerminal
