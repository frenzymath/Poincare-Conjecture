import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Embeddings
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.ReferenceJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Coefficients
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Coverage

/-! # Exact coefficients and terminal coverage for retained horizon embeddings -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold
  normedAddCommGroupTangentSpaceVectorSpace normedSpaceTangentSpaceVectorSpace

open ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

theorem windowRetainedCylinder_chart_inner (k : ℕ) {V B' eta' : ℝ}
    (d : ControlledBlowupCylinder S (idx (G.subsequence k)) (A (G.subsequence k)) V B' eta')
    (hV : 0 < V) (s : ℝ) (hs : s ∈ Icc (-V) 0)
    (q : (liftedSliceCarrier.{u} G.limitCarrier).carrier)
    (z : EuclideanSpace ℝ (Fin 3)) (hz : z ∈ (extChartAt (𝓡 3) q).target)
    (hx : ((extChartAt (𝓡 3) q).symm z).down ∈ G.exhaustion k)
    (v w : EuclideanSpace ℝ (Fin 3)) :
    (windowRetainedCylinder G k d).pullbackInner s hs ((extChartAt (𝓡 3) q).symm z)
      (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z v)
      (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z w) =
      ((d.smallFlow (hA (G.subsequence k)) hV).metric s).pullbackCoefficients
        (G.referenceChartMap q.down k 0) z v w := by
  rw [windowRetainedCylinder_pullbackInner G k d hV s hs _ hx]
  have hchart := ((contMDiffOn_extChartAt_symm (n := ∞) q).contMDiffAt
    ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds hz)).mdifferentiableAt (by simp)
  have hmap := (retainedSmallMap_contMDiffAt G k hx).mdifferentiableAt (by simp)
  have hder := mfderiv_comp z hmap hchart
  have hderv := congrArg (fun L => L v) hder
  have hderw := congrArg (fun L => L w) hder
  change _ = mfderiv (𝓡 3) (𝓡 3) (retainedSmallMap G k) ((extChartAt (𝓡 3) q).symm z)
    (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z v) at hderv
  change _ = mfderiv (𝓡 3) (𝓡 3) (retainedSmallMap G k) ((extChartAt (𝓡 3) q).symm z)
    (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z w) at hderw
  rw [← hderv, ← hderw]
  rfl

theorem windowRetainedCylinder_eventually_covers_baseBall
    (hAr : Tendsto A atTop atTop)
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    {r : ℝ} (hr : 0 < r) :
    ∀ᶠ k in atTop, ∀ V B' eta' : ℝ,
      ∀ d : ControlledBlowupCylinder S (idx (G.subsequence k)) (A (G.subsequence k)) V B' eta',
      ∀ hzero : (0 : ℝ) ∈ Icc (-V) 0, ∀ x ∈ S.baseBall (idx (G.subsequence k)) r,
        ∃ y ∈ (ULift.down ⁻¹' G.exhaustion k),
          (windowRetainedCylinder G k d).pointMap 0 hzero y =
            (⟨(S.base (idx (G.subsequence k))).1, x⟩ : (S.flow (idx (G.subsequence k))).point) := by
  filter_upwards [eventually_baseBall_subset_retainedSource_image G hAr hcomplete hr]
    with k hk V B' eta' d hzero x hx
  obtain ⟨y, hy, rfl⟩ := hk hx
  refine ⟨y, hy, ?_⟩
  change d.embedding.pointMap 0 hzero (retainedSourceCoordinate G k y) = _
  apply d.zero_identity hzero
  apply retainedSourceCoordinate_target_subset G k
  apply (retainedSourceCoordinate G k).map_source
  rwa [retainedSourceCoordinate_source]

end PoincareMT.ControlledBlowupCompactness
