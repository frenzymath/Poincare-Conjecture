import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Source
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.TerminalBalls

/-!
# Terminal balls in the small source coordinates

The based component and universe transport preserve entire centered balls.
The cylinder curvature bound transports those balls to its interior reference
time. Source: Morgan--Tian, Theorem 11.8, pp. 274--279.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

open ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

theorem smallSourceCoordinate_image_ball
    (e : ControlledBlowupCylinder S k A T B eta) (hA : 0 < A) (hT : 0 < T)
    (s r : ℝ) :
    smallSourceCoordinate S k hA ''
        ((e.smallFlow hA hT).metric s).ball (smallBase S k hA) r =
      Subtype.val '' ((e.ordinaryFlow hT).metric s).ball (sourceBase S k hA) r := by
  let C := componentCarrier S k hA
  calc
    _ = (Subtype.val : sourceBall S k A → _) ''
        ((Subtype.val : C.carrier → sourceBall S k A) ''
          ((equivShrink C.carrier).symm ''
            ((e.smallFlow hA hT).metric s).ball (smallBase S k hA) r)) := by
      rw [image_image, image_image]
      rfl
    _ = (Subtype.val : sourceBall S k A → _) ''
        ((Subtype.val : C.carrier → sourceBall S k A) ''
          ((e.componentFlow hA hT).metric s).ball (componentBase S k hA) r) := by
      apply congrArg (Set.image (Subtype.val : sourceBall S k A → _))
      apply congrArg (Set.image (Subtype.val : C.carrier → sourceBall S k A))
      simpa only [C, smallFlow, smallBase, Equiv.symm_apply_apply] using
        (e.componentFlow hA hT).shrink_image_ball s (smallBase S k hA) r
    _ = _ := by
      rw [RiemannianMetric.image_ball_subtype_val isClosed_connectedComponent
        ((e.ordinaryFlow hT).metric s) ((e.componentFlow hA hT).metric s)
        (fun _ _ _ => rfl)]
      rfl

theorem smallSourceCoordinate_terminal_image_ball
    (e : ControlledBlowupCylinder S k A T B eta) (hA : 0 < A) (hT : 0 < T)
    {r : ℝ} (hrA : r ≤ A) :
    smallSourceCoordinate S k hA ''
        ((e.smallFlow hA hT).metric 0).ball (smallBase S k hA) r = S.baseBall k r := by
  rw [smallSourceCoordinate_image_ball, e.ordinaryFlow_terminal_image_ball hA hT hrA]

theorem smallFlow_ball_subset_other_time
    (e : ControlledBlowupCylinder S k A T B eta) (hA : 0 < A) (hT : 0 < T)
    {s t : ℝ} (hs : s ∈ Icc (-T) 0) (ht : t ∈ Icc (-T) 0) (r : ℝ) :
    ((e.smallFlow hA hT).metric s).ball (smallBase S k hA) r ⊆
      ((e.smallFlow hA hT).metric t).ball (smallBase S k hA)
        (Real.exp (3 * B * |t - s|) * r) := by
  have hdist (x y : sourceBall S k A) :
      ((e.ordinaryFlow hT).metric t).edist x y ≤
        ENNReal.ofReal (Real.exp (3 * B * |t - s|)) *
          ((e.ordinaryFlow hT).metric s).edist x y := by
    apply RiemannianMetric.edist_le_mul_of_tangentNorm_mfderiv_le _ _
      contMDiff_id (Real.exp_pos _) _ x y
    intro z v
    simpa using
      e.ordinaryFlow_tangentNorm_le hT z v hs ht
  intro x hx
  change ((e.componentFlow hA hT).shrink.metric s).edist _ _ < _ at hx
  change ((e.componentFlow hA hT).shrink.metric t).edist _ _ < _
  rw [RicciFlow.shrink_edist] at hx ⊢
  change (((e.ordinaryFlow hT).restrictComponent (sourceBase S k hA)).metric s).edist _ _ < _ at hx
  change (((e.ordinaryFlow hT).restrictComponent (sourceBase S k hA)).metric t).edist _ _ < _
  rw [RicciFlow.restrictComponent_edist] at hx ⊢
  rw [ENNReal.ofReal_mul (Real.exp_nonneg _)]
  exact (hdist _ _).trans_lt
    (ENNReal.mul_lt_mul_right (ENNReal.ofReal_pos.mpr (Real.exp_pos _)).ne'
      ENNReal.ofReal_ne_top hx)

end PoincareMT.ControlledBlowupCompactness
