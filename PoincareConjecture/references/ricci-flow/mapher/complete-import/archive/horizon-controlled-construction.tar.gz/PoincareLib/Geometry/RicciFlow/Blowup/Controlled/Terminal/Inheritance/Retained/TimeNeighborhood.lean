import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Curvature.Positive

/-! # Positive scalar curvature on a left neighborhood of a retained time -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.BlowupLimitFlow

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space

theorem exists_left_scalar_positive_interval
    {T : ℝ} (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    {t : ℝ} (ht : t ∈ Ioc (-T) 0) (x : L.carrier.carrier)
    (hx : 0 < (L.flow.connection t).scalarCurvature x) :
    ∃ a : ℝ, a < t ∧ Icc a t ⊆ Ioc (-T) 0 ∧
      ∀ s ∈ Icc a t, 0 < (L.flow.connection s).scalarCurvature x := by
  let b := (-T + t) / 2
  have hb : -T < b ∧ b < t := by dsimp [b]; constructor <;> linarith [ht.1]
  have hI : Icc b t ⊆ Ioc (-T) 0 := fun s hs => ⟨hb.1.trans_le hs.1, hs.2.trans ht.2⟩
  have hc : ContinuousWithinAt (fun s => (L.flow.connection s).scalarCurvature x)
      (Icc b t) t := by
    have hscalar := L.flow.contMDiffOn_scalarCurvature.continuousOn
    have hm : ContinuousWithinAt (fun s : ℝ => (s, x)) (Icc b t) t :=
      continuousWithinAt_id.prodMk continuousWithinAt_const
    exact ContinuousWithinAt.comp
      (g := fun z : ℝ × L.carrier.carrier => (L.flow.connection z.1).scalarCurvature z.2)
      (f := fun s : ℝ => (s, x)) (hscalar (t, x) ⟨ht, mem_univ _⟩) hm
      (fun s hs => ⟨hI hs, mem_univ _⟩)
  have hp : ∀ᶠ s in 𝓝[Icc b t] t, 0 < (L.flow.connection s).scalarCurvature x :=
    hc.tendsto.eventually (Ioi_mem_nhds hx)
  obtain ⟨V, hV, hVP⟩ := mem_nhdsWithin_iff_exists_mem_nhds_inter.mp hp
  obtain ⟨r, hr, hrV⟩ := Metric.mem_nhds_iff.mp hV
  let a := max b (t - r / 2)
  have ha : a < t := max_lt hb.2 (by linarith)
  have hab : b ≤ a := le_max_left _ _
  refine ⟨a, ha, (fun s hs => hI ⟨hab.trans hs.1, hs.2⟩), ?_⟩
  intro s hs
  apply hVP
  refine ⟨hrV ?_, ⟨hab.trans hs.1, hs.2⟩⟩
  simp only [Metric.mem_ball, Real.dist_eq, abs_of_nonpos (sub_nonpos.mpr hs.2)]
  have hlo : t - r / 2 ≤ s := (le_max_right b (t - r / 2)).trans hs.1
  linarith

end PoincareMT.BlowupLimitFlow
