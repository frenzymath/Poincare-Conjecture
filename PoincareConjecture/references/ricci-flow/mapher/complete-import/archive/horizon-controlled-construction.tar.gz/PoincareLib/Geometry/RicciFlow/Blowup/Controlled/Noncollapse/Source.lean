import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Data
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Slabs.Embedding
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.Worldlines.Uniqueness

/-!
# Source noncollapse on the actual convergence embeddings

The finite-horizon slab and the convergence embedding have the same clock.
Their trajectories agree at zero and hence on their common interval. Compact
limit sets have terminal images in one fixed normalized source ball, so the
original long controls supply noncollapse at every retained image point.

Reference: Morgan--Tian, Theorem 11.8, pp. 272--278.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space

variable {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
  (G : GeneralizedBlowupConvergence S (blowupBackwardInterval T₀))

/-- Original finite-slab noncollapse holds at the actual convergence-image
points on every compact limit region. -/
theorem eventually_source_noncollapsed_of_longControls
    {epsilon C kappa r₀ mu : ℝ}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    {T : ℝ} (hT : 0 < T) (hT₀ : ENNReal.ofReal T < T₀)
    {P : Set G.limit.carrier.carrier} (hP : IsCompact P) :
    ∀ᶠ k in atTop, ∀ p ∈ P, ∀ s ∈ Ioc (-T) 0,
      ∀ hs : s ∈ Icc (-G.exhaustion.time k) 0,
        GeneralizedKappaNoncollapsedAt (S.flow (G.subsequence k))
          ((G.embedding k).pointMap s hs p) kappa r₀ := by
  obtain ⟨A, hA, himage⟩ := G.exists_eventually_image_compact_subset_baseBall hP
  filter_upwards [himage,
    G.subsequence_strictMono.tendsto_atTop.eventually (H.slabs T hT hT₀ A hA)]
    with k hk hslab p hp s hs hse
  obtain ⟨E⟩ := hslab
  let x := G.zeroSliceEmbedding k p
  have hx : x ∈ S.baseBall (G.subsequence k) A := hk.2 (mem_image_of_mem _ hp)
  have hpU : p ∈ G.exhaustion.space k := by
    simpa only [G.zeroSliceEmbedding_source] using hk.1 hp
  have hzero : (0 : ℝ) ∈ Ioc (-T) 0 := ⟨by linarith, le_rfl⟩
  have hstart : (G.embedding k).pointMap 0 (G.zero_mem_cylinder k) p =
      E.embedding.pointMap 0 hzero x := by
    rw [E.zero_identity hzero x hx]
    exact (G.embedding k).zeroSliceHomeomorph_pointMap
      (G.exhaustion.space_open k) (G.zero_mem_cylinder k) p
  have heq := (G.embedding k).pointMap_eq_on_overlap E.embedding
    ordConnected_Icc ordConnected_Ioc hpU hx (G.zero_mem_cylinder k) hzero hstart s hse hs
  rw [heq]
  exact E.noncollapsed s hs x hx

end PoincareMT.GeneralizedBlowupConvergence
