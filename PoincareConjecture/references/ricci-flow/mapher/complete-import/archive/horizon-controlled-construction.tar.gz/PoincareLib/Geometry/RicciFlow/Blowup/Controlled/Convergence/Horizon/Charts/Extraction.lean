import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.SequenceJets
import PoincareLib.Analysis.Calculus.SmoothCompactness.Eventual

/-! # Common smooth extraction on the full open backward horizon -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder Poincare.Analysis.Calculus

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

def horizonOpenTime (tau : ℕ → ℝ) : Set ℝ := ⋃ j, Ioo (-tau j) 0

theorem horizonOpenTime_isOpen (tau : ℕ → ℝ) : IsOpen (horizonOpenTime tau) :=
  isOpen_iUnion fun _ => isOpen_Ioo

theorem exists_horizonWindow_of_isCompact {tau : ℕ → ℝ} (htmono : Monotone tau)
    {I : Set ℝ} (hI : IsCompact I) (hIh : I ⊆ horizonOpenTime tau) :
    ∃ j, I ⊆ Ioo (-tau j) 0 := by
  obtain ⟨s, hs⟩ := hI.elim_finite_subcover (fun j => Ioo (-tau j) 0)
    (fun _ => isOpen_Ioo) hIh
  refine ⟨s.sup id, fun t ht => ?_⟩
  obtain ⟨i, hi, hti⟩ := mem_iUnion₂.mp (hs ht)
  exact ⟨lt_of_le_of_lt (neg_le_neg (htmono (Finset.le_sup (f := id) hi))) hti.1, hti.2⟩

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

theorem horizonSpacetimeCoefficients_locallyEventuallyContDiff
    (htmono : Monotone tau) (q : G.limitCarrier.carrier) :
    LocallyEventuallyContDiff (horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target)
      (horizonSpacetimeCoefficients G q) := by
  intro K hK hKsub
  obtain ⟨j, hj⟩ := exists_horizonWindow_of_isCompact htmono (hK.image continuous_fst)
    (by rintro _ ⟨z, hz, rfl⟩; exact (hKsub hz).1)
  have hspace : Prod.snd '' K ⊆ (extChartAt (𝓡 3) q).target := by
    rintro _ ⟨z, hz, rfl⟩
    exact (hKsub hz).2
  have hc : ContinuousOn (extChartAt (𝓡 3) q).symm (Prod.snd '' K) :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hspace
  obtain ⟨j₀, hj₀⟩ := G.exists_exhaustion_superset
    ((hK.image continuous_snd).image_of_continuousOn hc)
  filter_upwards [G.subsequence_strictMono.tendsto_atTop.eventually_ge_atTop j,
    eventually_ge_atTop j₀] with k hk hk₀
  let W := (extChartAt (𝓡 3) q).target ∩
    (extChartAt (𝓡 3) q).symm ⁻¹' G.exhaustion k
  have hW : IsOpen W :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
      (isOpen_extChartAt_target q) (G.exhaustion_open k)
  have hzero : -tau 0 / 2 < 0 ∧ 0 < tau 0 / 2 := ⟨by linarith [htau 0], by linarith [htau 0]⟩
  have he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap q k 0) W :=
    fun x hx => (G.referenceChartMap_contMDiffAt q k hzero hx.1 hx.2).contMDiffWithinAt
  have hne : (Ioo (-tau (G.subsequence k)) 0).Nontrivial :=
    ⟨-tau (G.subsequence k) / 3, ⟨by linarith [htau (G.subsequence k)], by linarith [htau (G.subsequence k)]⟩,
      -2 * tau (G.subsequence k) / 3,
      ⟨by linarith [htau (G.subsequence k)], by linarith [htau (G.subsequence k)]⟩,
      by linarith [htau (G.subsequence k)]⟩
  let F := Poincare.Geometry.RicciFlow.Harnack.restrictFlow
    (horizonSourceFlow hA htau e (G.subsequence k)) Ioo_subset_Icc_self ordConnected_Ioo hne
  refine ⟨Ioo (-tau (G.subsequence k)) 0 ×ˢ W, isOpen_Ioo.prod hW, ?_,
    F.contDiffOn_pullbackCoefficients isOpen_Ioo hW he⟩
  intro z hz
  have ht := hj (mem_image_of_mem _ hz)
  exact ⟨⟨lt_of_le_of_lt (neg_le_neg (htmono hk)) ht.1, ht.2⟩,
    hspace (mem_image_of_mem _ hz), G.exhaustion_monotone hk₀
      (hj₀ (mem_image_of_mem _ (mem_image_of_mem _ hz)))⟩

theorem horizonSpacetimeCoefficients_eventuallyBoundedJets
    (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (htmono : StrictMono tau) (hB : ∀ j, 0 ≤ B j) (q : G.limitCarrier.carrier)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKsub : K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    ∃ C : ℝ, ∀ᶠ k in atTop, ∀ z ∈ K,
      ‖iteratedFDeriv ℝ m (horizonSpacetimeCoefficients G q k) z‖ ≤ C := by
  obtain ⟨j, hj⟩ := exists_horizonWindow_of_isCompact htmono.monotone (hK.image continuous_fst)
    (by rintro _ ⟨z, hz, rfl⟩; exact (hKsub hz).1)
  have hTV : tau 0 / 2 ≤ tau j := by
    have h := htmono.monotone (Nat.zero_le j)
    linarith [htau 0]
  obtain ⟨C, _, hbound⟩ := exists_eventually_horizon_spacetime_jet_bound
    G P04 hAr hcompact hcomplete htmono.monotone hB hTV (htmono (Nat.lt_succ_self j))
    q (hK.image continuous_snd) (by rintro _ ⟨z, hz, rfl⟩; exact (hKsub hz).2) m
  exact ⟨C, hbound.mono fun k hk z hz => hk z.1 (hj (mem_image_of_mem _ hz))
    z.2 (mem_image_of_mem _ hz)⟩

/-- One further subsequence converges smoothly throughout every past window
in a prescribed countable family of retained charts. -/
theorem exists_horizon_common_chart_extraction
    (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (htmono : StrictMono tau) (hB : ∀ j, 0 ≤ B j) (q : ℕ → G.limitCarrier.carrier) :
    ∃ sigma : ℕ → ℕ, StrictMono sigma ∧
      ∃ f : ℕ → ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3,
      (∀ i, ContDiffOn ℝ ∞ (f i) (horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target)) ∧
      ∀ i m K, IsCompact K → K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) (q i)).target →
        TendstoUniformlyOn
          (fun k => iteratedFDeriv ℝ m (horizonSpacetimeCoefficients G (q i) (sigma k)))
          (iteratedFDeriv ℝ m (f i)) atTop K :=
  exists_common_smoothSubsequenceExtraction_finiteDimensional_of_locallyEventuallyContDiff
    (fun i => (horizonOpenTime_isOpen tau).prod (isOpen_extChartAt_target (q i)))
    (fun i => horizonSpacetimeCoefficients G (q i))
    (fun i => horizonSpacetimeCoefficients_locallyEventuallyContDiff G htmono.monotone (q i))
    (fun i K hK hKsub m => horizonSpacetimeCoefficients_eventuallyBoundedJets
      G P04 hAr hcompact hcomplete htmono hB (q i) hK hKsub m)

end PoincareMT.ControlledBlowupCompactness
