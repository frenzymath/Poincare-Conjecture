import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.ReferenceBounds
import PoincareLib.Geometry.Riemannian.Coordinates.ParametrizedCoefficients

/-! # Finite chart controls from the actual comparison metric convergence -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

open Set Filter Metric
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.ControlledTerminal

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem reference_controls_of_comparison_metric_convergence
    {X : ℕ → Type u} [∀ k, TopologicalSpace (X k)] [∀ k, ChartedSpace E (X k)]
    [∀ k, IsManifold (𝓡 3) ∞ (X k)]
    {M : Type v} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    (g : RiemannianMetric 3 M) (h : ∀ k, RiemannianMetric 3 (X k))
    (e : ∀ k, OpenPartialHomeomorph M (X k))
    (he : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source)
    {U : Set M} (hUe : ∀ k, U ⊆ (e k).source)
    (q : M) {K : Set M} (hK : IsCompact K)
    (hKU : K ⊆ U ∩ (extChartAt (𝓡 3) q).source)
    (hconv : ∀ m, TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((h k).parametrizedCoefficients
        (e k ∘ (extChartAt (𝓡 3) q).symm)))
      (iteratedFDeriv ℝ m (g.parametrizedCoefficients (extChartAt (𝓡 3) q).symm))
      atTop ((extChartAt (𝓡 3) q) '' K)) (r : ℕ) :
    (∃ C : ℝ, ∀ᶠ k in atTop, ∀ j, j ≤ r → ∀ y ∈ (extChartAt (𝓡 3) q) '' K,
      ‖iteratedFDeriv ℝ j ((h k).parametrizedCoefficients
        (e k ∘ (extChartAt (𝓡 3) q).symm)) y‖ ≤ C) ∧
    (∃ b : ℝ, 0 < b ∧ ∀ᶠ k in atTop, ∀ y ∈ (extChartAt (𝓡 3) q) '' K, ∀ w : E,
      b * ‖w‖ ^ 2 ≤ (h k).parametrizedCoefficients
        (e k ∘ (extChartAt (𝓡 3) q).symm) y w w) ∧
    ∀ j, TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ j (fun y =>
        (h k).parametrizedCoefficients (e k ∘ (extChartAt (𝓡 3) q).symm) y -
        g.parametrizedCoefficients (extChartAt (𝓡 3) q).symm y))
      (fun _ => 0) atTop ((extChartAt (𝓡 3) q) '' K) := by
  let c := extChartAt (𝓡 3) q
  let J := c '' K
  let B := fun k => (h k).parametrizedCoefficients (e k ∘ c.symm)
  have hJ : IsCompact J := hK.image_of_continuousOn
    ((continuousOn_extChartAt q).mono (fun _ hx => (hKU hx).2))
  have hJc : J ⊆ c.target := by
    rintro _ ⟨x, hx, rfl⟩
    exact c.map_source (hKU hx).2
  have hJU : ∀ y ∈ J, c.symm y ∈ U := by
    rintro _ ⟨x, hx, rfl⟩
    rw [c.left_inv (hKU hx).2]
    exact (hKU hx).1
  have hbound (m : ℕ) := eventually_bounded_terminal_reference_jets g q B hJ hJc hconv m
  choose C hC hbnd using hbound
  have hfinite : ∀ᶠ k in atTop, ∀ j ∈ Iic r, ∀ y ∈ J,
      ‖iteratedFDeriv ℝ j (B k) y‖ ≤ C j :=
    (eventually_all_finite (finite_Iic r)).mpr (fun j _ => hbnd j)
  refine ⟨⟨∑ j ∈ Finset.range (r + 1), C j, ?_⟩, ?_, ?_⟩
  · filter_upwards [hfinite] with k hk j hj y hy
    exact (hk j hj y hy).trans
      (Finset.single_le_sum (fun j _ => hC j) (Finset.mem_range.mpr (by omega)))
  · obtain ⟨alpha, _beta, ha, _hb, hell⟩ :=
      eventually_elliptic_terminal_reference_coefficients g q B hJ hJc hconv
    exact ⟨alpha, ha, hell.mono fun k hk y hy w => (hk y hy w).1⟩
  · intro j
    rw [Metric.tendstoUniformlyOn_iff]
    intro d hd
    filter_upwards [Metric.tendstoUniformlyOn_iff.mp (hconv j) d hd] with k hk y hy
    have hc : ContMDiffAt (𝓡 3) (𝓡 3) ∞ c.symm y :=
      (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q (hJc hy)).contMDiffAt
        (extChartAt_target_mem_nhds' (hJc hy))
    have hec : ContMDiffAt (𝓡 3) (𝓡 3) ∞ (e k ∘ c.symm) y :=
      ((he k).contMDiffAt ((e k).open_source.mem_nhds (hUe k (hJU y hy)))).comp y hc
    have hB : ContDiffAt ℝ ∞ (B k) y := (h k).contDiffAt_parametrizedCoefficients hec
    have hg := g.contDiffAt_parametrizedCoefficients hc
    rw [dist_eq_norm, zero_sub, norm_neg,
      fun_iteratedFDeriv_sub_apply (hB.of_le (by exact_mod_cast le_top))
        (hg.of_le (by exact_mod_cast le_top))]
    have hh := hk y hy
    rw [dist_eq_norm, norm_sub_rev] at hh
    exact hh

end PoincareMT.ControlledTerminal
