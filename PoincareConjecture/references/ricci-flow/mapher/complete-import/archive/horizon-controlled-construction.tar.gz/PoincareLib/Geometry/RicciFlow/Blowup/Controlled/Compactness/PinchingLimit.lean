import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.JetPositivity

/-!
# Vanishing negative curvature in pointed limits

The actual source curvature error transfers to each local coordinate
realization. M07's second metric jets then yield nonnegative curvature
operator at every point and every interior time of the pointed limit.
Source: Morgan--Tian, Theorem 11.1, pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT

private theorem bilinear_eq_of_basis
    {B B' : EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ}
    (h : ∀ a b : Fin 3, B (EuclideanSpace.basisFun (Fin 3) ℝ a)
      (EuclideanSpace.basisFun (Fin 3) ℝ b) =
        B' (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) :
    B = B' := by
  apply ContinuousLinearMap.coe_injective
  apply (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis.ext
  intro a
  apply ContinuousLinearMap.coe_injective
  apply (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis.ext
  exact h a

namespace SmoothSpacetimeEmbedding

theorem negativeCurvaturePart_eq_of_coordinate_germ
    {T' T : ℝ} {C D : FlowCarrier 3}
    {F : BasedFlow 3 T' T C} {G : BasedFlow 3 T' T D} {U : Set C.carrier}
    (e : SmoothSpacetimeEmbedding F G (Ioo T' T ×ˢ U))
    (hU : @IsOpen C.carrier C.topologicalSpace U)
    (q : C.carrier) (p : ℝ × EuclideanSpace ℝ (Fin 3))
    (ht : p.1 ∈ Ioo T' T)
    (hp :
      letI : TopologicalSpace C.carrier := C.topologicalSpace
      letI : ChartedSpace (EuclideanSpace ℝ (Fin 3)) C.carrier := C.chartedSpace
      p.2 ∈ (extChartAt (𝓡 3) q).target ∧ (extChartAt (𝓡 3) q).symm p.2 ∈ U)
    (gE : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3))) (DE : LeviCivitaData gE)
    (h : ∀ᶠ x in 𝓝 p.2, ∀ a b : Fin 3,
      gE.euclideanCoefficients x (EuclideanSpace.basisFun (Fin 3) ℝ a)
        (EuclideanSpace.basisFun (Fin 3) ℝ b) =
      C.coordinateCoefficient q (pullbackInnerValue F G e) a b (p.1, x)) :
    letI : TopologicalSpace C.carrier := C.topologicalSpace
    letI : ChartedSpace (EuclideanSpace ℝ (Fin 3)) C.carrier := C.chartedSpace
    letI : IsManifold (𝓡 3) ∞ C.carrier := C.isManifold
    letI : TopologicalSpace D.carrier := D.topologicalSpace
    letI : ChartedSpace (EuclideanSpace ℝ (Fin 3)) D.carrier := D.chartedSpace
    letI : IsManifold (𝓡 3) ∞ D.carrier := D.isManifold
    DE.negativeCurvaturePart p.2 = (G.flow.connection p.1).negativeCurvaturePart
      ((e.toFun (p.1, (extChartAt (𝓡 3) q).symm p.2)).2) := by
  let : TopologicalSpace C.carrier := C.topologicalSpace
  let : ChartedSpace (EuclideanSpace ℝ (Fin 3)) C.carrier := C.chartedSpace
  let : IsManifold (𝓡 3) ∞ C.carrier := C.isManifold
  let : TopologicalSpace D.carrier := D.topologicalSpace
  let : ChartedSpace (EuclideanSpace ℝ (Fin 3)) D.carrier := D.chartedSpace
  let : IsManifold (𝓡 3) ∞ D.carrier := D.isManifold
  let c := extChartAt (𝓡 3) q
  let f : C.carrier → D.carrier := fun y => (e.toFun (p.1, y)).2
  let W := c.target ∩ c.symm ⁻¹' U
  have hW : IsOpen W :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
      (isOpen_extChartAt_target q) hU
  have hc (x : EuclideanSpace ℝ (Fin 3)) (hx : x ∈ W) :
      ContMDiffAt (𝓡 3) (𝓡 3) ∞ c.symm x :=
    (contMDiffWithinAt_extChartAt_symm_target (n := ∞) q hx.1).contMDiffAt
      (extChartAt_target_mem_nhds' hx.1)
  have hf (x : EuclideanSpace ℝ (Fin 3)) (hx : x ∈ W) :
      ContMDiffAt (𝓡 3) (𝓡 3) ∞ f (c.symm x) :=
    e.spatialMap_contMDiffAt hU ht hx.2
  have hderiv (x : EuclideanSpace ℝ (Fin 3)) (hx : x ∈ W) :
      mfderiv (𝓡 3) (𝓡 3) (f ∘ c.symm) x =
        (mfderiv (𝓡 3) (𝓡 3) f (c.symm x)).comp
          (mfderiv (𝓡 3) (𝓡 3) c.symm x) :=
    mfderiv_comp x ((hf x hx).mdifferentiableAt (by simp))
      ((hc x hx).mdifferentiableAt (by simp))
  obtain ⟨V, hV, hVo, hpV⟩ := mem_nhds_iff.mp (inter_mem (hW.mem_nhds hp) h)
  apply DE.negativeCurvaturePart_eq_of_local_isometry (G.flow.connection p.1) hVo
    (fun x hx => ((hf x (hV hx).1).comp x (hc x (hV hx).1)).contMDiffWithinAt)
    (x := p.2) (hx := hpV)
  intro x hx
  have hcoeff := (hV hx).2
  have hB : gE.euclideanCoefficients x =
      (G.metricAt p.1).pullbackCoefficients (f ∘ c.symm) x := by
    apply bilinear_eq_of_basis
    intro a b
    rw [hcoeff a b]
    change _ = (G.metricAt p.1).inner (f (c.symm x))
      (mfderiv (𝓡 3) (𝓡 3) (f ∘ c.symm) x (EuclideanSpace.basisFun (Fin 3) ℝ a))
      (mfderiv (𝓡 3) (𝓡 3) (f ∘ c.symm) x (EuclideanSpace.basisFun (Fin 3) ℝ b))
    rw [hderiv x (hV hx).1]
    rfl
  intro u v
  exact congrArg (fun B => B u v) hB

end SmoothSpacetimeEmbedding

namespace PointedGeometricConvergence

theorem nonnegativeCurvatureOperator_of_vanishing_negativePart_at_embedding
    {T' T : ℝ} {S : PointedFlowSequence 3 T' T}
    (G : PointedGeometricConvergence S) (t : ℝ) (ht : t ∈ Ioo T' T)
    (x : G.limitCarrier.carrier) {eta : ℕ → ℝ} (heta : Tendsto eta atTop (𝓝 0))
    (hneg : ∀ᶠ k : ℕ in atTop,
      let C := S.carrier (G.subsequence k)
      letI : TopologicalSpace C.carrier := C.topologicalSpace
      letI : ChartedSpace (EuclideanSpace ℝ (Fin 3)) C.carrier := C.chartedSpace
      letI : IsManifold (𝓡 3) ∞ C.carrier := C.isManifold
      ((S.flow (G.subsequence k)).flow.connection t).negativeCurvaturePart
        ((G.embedding k).toFun (t, x)).2 ≤ eta k) :
    letI : TopologicalSpace G.limitCarrier.carrier := G.limitCarrier.topologicalSpace
    letI : ChartedSpace (EuclideanSpace ℝ (Fin 3)) G.limitCarrier.carrier :=
      G.limitCarrier.chartedSpace
    letI : IsManifold (𝓡 3) ∞ G.limitCarrier.carrier := G.limitCarrier.isManifold
    (G.limitFlow.flow.connection t).NonnegativeCurvatureOperator x := by
  classical
  let : TopologicalSpace G.limitCarrier.carrier := G.limitCarrier.topologicalSpace
  let : ChartedSpace (EuclideanSpace ℝ (Fin 3)) G.limitCarrier.carrier :=
    G.limitCarrier.chartedSpace
  let : IsManifold (𝓡 3) ∞ G.limitCarrier.carrier := G.limitCarrier.isManifold
  let c := extChartAt (𝓡 3) x
  let p := c x
  have hp : p ∈ c.target := c.map_source (mem_extChartAt_source x)
  have hcx : (extChartAt (𝓡 3) x).symm p = x := c.left_inv (mem_extChartAt_source x)
  obtain ⟨g, D, V, hVo, hpV, _, heq⟩ := G.limitCarrier.exists_local_coordinate_realization
    (G.limitFlow.metricAt t) x t p hp
  have hg : ∀ᶠ y in 𝓝 p, ∀ a b : Fin 3,
      g.euclideanCoefficients y (EuclideanSpace.basisFun (Fin 3) ℝ a)
        (EuclideanSpace.basisFun (Fin 3) ℝ b) =
      G.limitCarrier.coordinateCoefficient x
        (fun _ y v w => G.limitCarrier.metricInner (G.limitFlow.metricAt t) y v w)
        a b (t, y) := Filter.Eventually.mono (hVo.mem_nhds hpV) heq
  have hreal : ∀ᶠ k : ℕ in atTop,
      ∃ gd : Σ g : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3)), LeviCivitaData g,
        ∀ᶠ y in 𝓝 p, ∀ a b : Fin 3,
          gd.1.euclideanCoefficients y (EuclideanSpace.basisFun (Fin 3) ℝ a)
            (EuclideanSpace.basisFun (Fin 3) ℝ b) =
          G.limitCarrier.coordinateCoefficient x
            (pullbackInnerValue G.limitFlow (S.flow (G.subsequence k)) (G.embedding k))
            a b (t, y) := by
    filter_upwards [G.eventually_exists_local_coordinate_realization x (t, p) ht hp]
      with k hk
    obtain ⟨gk, Dk, Vk, hVko, hpVk, heqk⟩ := hk
    exact ⟨⟨gk, Dk⟩, Filter.Eventually.mono (hVko.mem_nhds hpVk) heqk⟩
  obtain ⟨gd, hgd⟩ := hreal.choice
  have hnegE : ∀ᶠ k in atTop, (gd k).2.negativeCurvaturePart p ≤ eta k := by
    obtain ⟨j, hj⟩ := G.exists_exhaustion_superset (isCompact_singleton (x := x))
    filter_upwards [hgd, hneg, eventually_ge_atTop j] with k hk hnk hjk
    rw [(G.embedding k).negativeCurvaturePart_eq_of_coordinate_germ
      (G.exhaustion_open k) x (t, p) ht
      ⟨hp, by rw [hcx]; exact G.exhaustion_monotone hjk (hj (mem_singleton x))⟩
      (gd k).1 (gd k).2 hk, hcx]
    exact hnk
  have hlim := LeviCivitaData.nonnegativeCurvatureOperator_of_scalar_metric_jets_of_negativePart
    (l := atTop) (fun k => (gd k).2) D p (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis (by
      intro r _ a b
      simp only [OrthonormalBasis.coe_toBasis]
      erw [G.limitCarrier.iteratedFDeriv_coordinateCoefficient_eq_of_eventuallyEq
        x _ t p g hg r a b]
      apply (G.tendsto_coordinate_spatial_metricJet x r a b (t, p) ht hp).congr'
      filter_upwards [hgd] with k hk
      exact (G.limitCarrier.iteratedFDeriv_coordinateCoefficient_eq_of_eventuallyEq
        x _ t p (gd k).1 hk r a b).symm) heta hnegE
  simpa only [hcx] using
    (G.limitCarrier.nonnegativeCurvatureOperator_iff_of_coordinate_germ
      (G.limitFlow.metricAt t) (G.limitFlow.flow.connection t) x t p hp g D hg).1 hlim

theorem nonnegativeCurvatureOperator_of_vanishing_negativePart
    {T' T : ℝ} {S : PointedFlowSequence 3 T' T}
    (G : PointedGeometricConvergence S) (t : ℝ) (ht : t ∈ Ioo T' T)
    {eta : ℕ → ℝ} (heta : Tendsto eta atTop (𝓝 0))
    (hneg : ∀ᶠ k : ℕ in atTop,
      let C := S.carrier k
      letI : TopologicalSpace C.carrier := C.topologicalSpace
      letI : ChartedSpace (EuclideanSpace ℝ (Fin 3)) C.carrier := C.chartedSpace
      letI : IsManifold (𝓡 3) ∞ C.carrier := C.isManifold
      ∀ x : C.carrier, ((S.flow k).flow.connection t).negativeCurvaturePart x ≤ eta k) :
    letI : TopologicalSpace G.limitCarrier.carrier := G.limitCarrier.topologicalSpace
    letI : ChartedSpace (EuclideanSpace ℝ (Fin 3)) G.limitCarrier.carrier :=
      G.limitCarrier.chartedSpace
    letI : IsManifold (𝓡 3) ∞ G.limitCarrier.carrier := G.limitCarrier.isManifold
    ∀ x : G.limitCarrier.carrier,
      (G.limitFlow.flow.connection t).NonnegativeCurvatureOperator x := by
  intro x
  apply G.nonnegativeCurvatureOperator_of_vanishing_negativePart_at_embedding t ht x
    (heta.comp G.subsequence_strictMono.tendsto_atTop)
  filter_upwards [G.subsequence_strictMono.tendsto_atTop.eventually hneg] with k hk
  exact hk _

end PointedGeometricConvergence

end PoincareMT
