import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Source

/-! # Universe transport of an actual controlled blow-up limit -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

noncomputable def liftedLimit {J : Set ℝ} (L : BlowupLimitFlow.{0} J) :
    BlowupLimitFlow.{u} J where
  carrier := liftedCarrier L.carrier
  connectedSpace := connectedSpace_iff_univ.mpr (liftedCarrier L.carrier).connected
  base := ULift.up L.base
  flow := L.flow.ulift
  zero_mem := L.zero_mem
  scalar_normalized := by
    rw [RicciFlow.ulift_scalarCurvature]
    exact L.scalar_normalized
  complete := by
    intro t ht
    exact (L.flow.ulift_metricComplete_iff t).mpr (L.complete t ht)
  nonnegative_curvature_operator := by
    intro t ht x
    exact (L.flow.ulift_nonnegativeCurvatureOperator_iff t x).mpr
      (L.nonnegative_curvature_operator t ht x.down)
  curvature_locally_bounded_in_time := by
    intro I hI hIJ
    obtain ⟨B, hB, hb⟩ := L.curvature_locally_bounded_in_time I hI hIJ
    refine ⟨B, hB, fun t ht x => ?_⟩
    rw [RicciFlow.ulift_curvatureTensorNorm]
    exact hb t ht x.down

theorem liftedLimit_sliceCarrier {J : Set ℝ} (L : BlowupLimitFlow.{0} J) :
    (liftedLimit.{u} L).sliceCarrier = liftedSliceCarrier.{u} L.carrier := rfl

end PoincareMT.ControlledBlowupCompactness
