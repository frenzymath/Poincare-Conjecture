import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Metric
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NullPlane
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NullPullback
import PoincareLib.Geometry.RicciFlow.Lift
import Mathlib.Topology.LocallyConstant.Basic

/-!
# Terminal Ricci nullity from local backward flows

Each coordinate neighborhood has its own backward lifetime. Spatial nullity
propagation on these actual flows makes the Ricci kernel of the prescribed
terminal metric locally constant, hence constant on a connected carrier.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledTerminal

open RicciFlow.Splitting

attribute [local instance] RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

theorem ricciNullity_eq_on_small_positive_slice
    (hC : RicciFlowCurvatureTheory.{u})
    {E : Type} [TopologicalSpace E] [T2Space E] [ConnectedSpace E]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) E] [IsManifold (𝓡 3) ∞ E]
    {a b : ℝ} (hab : a < b) (F : RicciFlow 3 E (Icc a b))
    (hoperator : ∀ t ∈ Icc a b, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    {t : ℝ} (ht : t ∈ Ioc a b) (x y : E) :
    ricciNullity (F.connection t) x = ricciNullity (F.connection t) y := by
  let e := Poincare.Manifold.uliftDiffeomorph (𝓡 3) E
  let G : RicciFlow 3 (ULift.{u} E) (Icc a b) := F.ulift
  let : ConnectedSpace (ULift.{u} E) := Homeomorph.ulift.connectedSpace_iff.mpr inferInstance
  have hnull (z : ULift.{u} E) :
      ricciNullity (G.connection t) z = ricciNullity (F.connection t) z.down :=
    ricciNullity_eq_of_local_metric_pullback (G.connection t) (F.connection t)
      e.isLocalDiffeomorph (fun _ _ _ => rfl) z
  have heq := ricciNullity_eq_on_positive_slice hC hab G
    (fun s hs z v w => (G.connection s).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
      z ((F.ulift_nonnegativeCurvatureOperator_iff s z).mpr (hoperator s hs z.down)) v w)
    ht (ULift.up x) (ULift.up y)
  exact (hnull (ULift.up x)).symm.trans (heq.trans (hnull (ULift.up y)))

variable {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
  {g : RiemannianMetric 3 M}

theorem terminalChartFlow_metric_pullback (q : M)
    (U : Opens (EuclideanSpace ℝ (Fin 3)))
    (hU : (U : Set (EuclideanSpace ℝ (Fin 3))) ⊆ (extChartAt (𝓡 3) q).target)
    {J : Set ℝ} (F : RicciFlow 3 U J) (t : ℝ)
    (hF : ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
      (F.metric t).inner x v w =
        g.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w) :
    ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
      (F.metric t).inner x v w = g.inner ((extChartAt (𝓡 3) q).symm x)
        (mfderiv (𝓡 3) (𝓡 3) (fun y : U => (extChartAt (𝓡 3) q).symm y) x v)
        (mfderiv (𝓡 3) (𝓡 3) (fun y : U => (extChartAt (𝓡 3) q).symm y) x w) := by
  intro x v w
  exact (hF x v w).trans
    (partialChartMetric_inner (inverseMetricChart q) U hU g x v w).symm

theorem ricciNullity_eq_on_terminal_chart (hC : RicciFlowCurvatureTheory.{u})
    (D : LeviCivitaData g) (q : M) {rho T : ℝ} (hrho : 0 < rho) (hT : 0 < T)
    (hchart : ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target)
    (F : RicciFlow 3 (⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩ : Opens _)
      (Icc (-T) 0))
    (hoperator : ∀ t ∈ Icc (-T) 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    (hmetric : ∀ x v w, (F.metric 0).inner x v w =
      g.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w)
    (x : M) (hx : x ∈ (extChartAt (𝓡 3) q).source)
    (hball : extChartAt (𝓡 3) q x ∈ ball (extChartAt (𝓡 3) q q) rho) :
    ricciNullity D x = ricciNullity D q := by
  let U : Opens (EuclideanSpace ℝ (Fin 3)) :=
    ⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩
  let : ConnectedSpace U := isConnected_iff_connectedSpace.mp
    ((convex_ball _ _).isConnected ⟨_, mem_ball_self hrho⟩)
  let y : U := ⟨extChartAt (𝓡 3) q x, hball⟩
  let z : U := ⟨extChartAt (𝓡 3) q q, mem_ball_self hrho⟩
  have hlocal := partialChartMap_isLocalDiffeomorph (inverseMetricChart q) U hchart
  have hpull := terminalChartFlow_metric_pullback q U hchart F 0 hmetric
  have hy := ricciNullity_eq_of_local_metric_pullback (F.connection 0) D hlocal hpull y
  have hz := ricciNullity_eq_of_local_metric_pullback (F.connection 0) D hlocal hpull z
  have hsame := ricciNullity_eq_on_small_positive_slice hC (by linarith : -T < (0 : ℝ)) F
    hoperator (show (0 : ℝ) ∈ Ioc (-T) 0 from ⟨by linarith, le_rfl⟩) y z
  have hy' : ricciNullity (F.connection 0) y = ricciNullity D x := by
    change ricciNullity (F.connection 0) y =
      ricciNullity D ((extChartAt (𝓡 3) q).symm (extChartAt (𝓡 3) q x)) at hy
    simpa only [(extChartAt (𝓡 3) q).left_inv hx] using hy
  have hz' : ricciNullity (F.connection 0) z = ricciNullity D q := by
    change ricciNullity (F.connection 0) z =
      ricciNullity D ((extChartAt (𝓡 3) q).symm (extChartAt (𝓡 3) q q)) at hz
    simpa only [extChartAt_to_inv] using hz
  exact hy'.symm.trans (hsame.trans hz')

variable (hflow : ∀ q : M, ∃ rho T : ℝ, 0 < rho ∧ 0 < T ∧
  ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target ∧
  ∃ F : RicciFlow 3 (⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩ : Opens _) (Icc (-T) 0),
    (∀ t ∈ Icc (-T) 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x) ∧
    ∀ x v w, (F.metric 0).inner x v w =
      g.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w)

include hflow in
theorem isLocallyConstant_ricciNullity_of_local_backward_flows
    (hC : RicciFlowCurvatureTheory.{u}) (D : LeviCivitaData g) :
    IsLocallyConstant (ricciNullity D) := by
  apply (IsLocallyConstant.iff_eventually_eq _).mpr
  intro q
  obtain ⟨rho, T, hrho, hT, hchart, F, hoperator, hmetric⟩ := hflow q
  have hball : ∀ᶠ x in 𝓝 q,
      extChartAt (𝓡 3) q x ∈ ball (extChartAt (𝓡 3) q q) rho :=
    (continuousAt_extChartAt (I := 𝓡 3) q).eventually (ball_mem_nhds _ hrho)
  filter_upwards [extChartAt_source_mem_nhds (I := 𝓡 3) q, hball] with x hx hxball
  exact ricciNullity_eq_on_terminal_chart hC D q hrho hT hchart F hoperator hmetric x hx hxball

include hflow in
theorem ricciNullity_eq_of_local_backward_flows [PreconnectedSpace M]
    (hC : RicciFlowCurvatureTheory.{u}) (D : LeviCivitaData g) (x y : M) :
    ricciNullity D x = ricciNullity D y :=
  (isLocallyConstant_ricciNullity_of_local_backward_flows hflow hC D).apply_eq_of_preconnectedSpace x y

end PoincareMT.ControlledTerminal
