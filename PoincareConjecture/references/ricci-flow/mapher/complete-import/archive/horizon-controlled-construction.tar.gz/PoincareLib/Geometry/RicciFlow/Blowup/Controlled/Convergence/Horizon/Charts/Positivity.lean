import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Charts.Extraction

/-! # Positivity and symmetry of the extracted horizon coefficients -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

private theorem pullbackCoefficients_symmetric
    {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    (g : RiemannianMetric 3 M) (f : EuclideanSpace ℝ (Fin 3) → M)
    (x v w : EuclideanSpace ℝ (Fin 3)) :
    g.pullbackCoefficients f x v w = g.pullbackCoefficients f x w v := by
  exact g.symm (f x) (mfderiv (𝓡 3) (𝓡 3) f x v) (mfderiv (𝓡 3) (𝓡 3) f x w)

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

theorem horizon_limit_positive
    (htmono : Monotone tau) (hB : ∀ j, 0 ≤ B j)
    (q : G.limitCarrier.carrier) {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    {f : ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3}
    (hpoint : ∀ z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target,
      Tendsto (fun k => horizonSpacetimeCoefficients G q (sigma k) z) atTop (𝓝 (f z)))
    {t : ℝ} (ht : t ∈ horizonOpenTime tau)
    {x : EuclideanSpace ℝ (Fin 3)} (hx : x ∈ (extChartAt (𝓡 3) q).target) :
    ∃ a : ℝ, 0 < a ∧ ∀ v, a * ‖v‖ ^ 2 ≤ f (t, x) v v := by
  obtain ⟨j, hj⟩ := mem_iUnion.mp ht
  obtain ⟨a, _, ha, _, hell⟩ := exists_eventually_horizon_ellipticity
    G htmono hB j q isCompact_singleton (singleton_subset_iff.mpr hx)
  refine ⟨a, ha, fun v => ?_⟩
  have heval : Continuous (fun D : SpacetimeBounds.MetricCoefficient 3 => D v v) :=
    (continuous_id.clm_apply continuous_const).clm_apply continuous_const
  apply ge_of_tendsto ((heval.tendsto _).comp (hpoint (t, x) ⟨ht, hx⟩))
  exact (hsigma.tendsto_atTop.eventually hell).mono fun k hk =>
    (hk t (Ioo_subset_Icc_self hj) x (mem_singleton x) v).1

theorem horizon_limit_symmetric
    (q : G.limitCarrier.carrier) {sigma : ℕ → ℕ}
    {f : ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3}
    (hpoint : ∀ z ∈ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target,
      Tendsto (fun k => horizonSpacetimeCoefficients G q (sigma k) z) atTop (𝓝 (f z)))
    {t : ℝ} (ht : t ∈ horizonOpenTime tau)
    {x : EuclideanSpace ℝ (Fin 3)} (hx : x ∈ (extChartAt (𝓡 3) q).target)
    (v w : EuclideanSpace ℝ (Fin 3)) : f (t, x) v w = f (t, x) w v := by
  have heval (a b : EuclideanSpace ℝ (Fin 3)) :
      Continuous (fun D : SpacetimeBounds.MetricCoefficient 3 => D a b) :=
    (continuous_id.clm_apply continuous_const).clm_apply continuous_const
  have hsym (k : ℕ) : horizonSpacetimeCoefficients G q (sigma k) (t, x) v w =
      horizonSpacetimeCoefficients G q (sigma k) (t, x) w v := by
    exact pullbackCoefficients_symmetric _ _ x v w
  have hleft : Tendsto (fun k => horizonSpacetimeCoefficients G q (sigma k) (t, x) v w)
      atTop (𝓝 (f (t, x) v w)) := (heval v w).tendsto _ |>.comp (hpoint (t, x) ⟨ht, hx⟩)
  have hright : Tendsto (fun k => horizonSpacetimeCoefficients G q (sigma k) (t, x) w v)
      atTop (𝓝 (f (t, x) w v)) := (heval w v).tendsto _ |>.comp (hpoint (t, x) ⟨ht, hx⟩)
  exact tendsto_nhds_unique hleft (hright.congr fun k => (hsym k).symm)

end PoincareMT.ControlledBlowupCompactness
