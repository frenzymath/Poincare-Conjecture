import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Charts
import PoincareLib.Geometry.RicciFlow.Compactness.Coordinates.Ellipticity

/-!
# Uniform ellipticity of the terminal normal charts

Jacobi comparison bounds the pullback metrics on a fixed smaller ball in
every retained terminal normal chart. The constants are independent of the
sequence index and the chart center in the prescribed terminal ball.
Reference: Morgan--Tian Theorem 5.6, pp. 86-87, and Claim 11.5, p. 270.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem eventually_uniform_terminal_elliptic_normal_charts
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {A : ℝ} (hA : 0 < A) :
    ∃ R rho : ℝ, 0 < rho ∧ 2 * rho < R ∧ ∀ᶠ k : ℕ in atTop,
      ∀ p ∈ S.baseBall k A,
      ∃ L : EuclideanSpace ℝ (Fin 3) ≃L[ℝ] EuclideanSpace ℝ (Fin 3),
      ∃ Phi : PartialDiffeomorph (𝓡 3) (𝓡 3)
          (EuclideanSpace ℝ (Fin 3)) ((S.flow k).slice (S.base k).1).carrier ∞,
        Phi.source = Metric.ball 0 R ∧
        Phi.target = (S.normalizedTerminalMetric k).ball p R ∧ Phi 0 = p ∧
        (∀ v w, (S.normalizedTerminalMetric k).pullbackCoefficients
          (extChartAt (𝓡 3) p).symm (extChartAt (𝓡 3) p p) (L v) (L w) = inner ℝ v w) ∧
        HasFDerivAt (fun w => extChartAt (𝓡 3) p (Phi w)) L.toContinuousLinearMap 0 ∧
        (∀ w ∈ Metric.ball 0 R, (S.normalizedTerminalMetric k).IsGeodesicOn
          (fun t => Phi (t • w)) {t : ℝ | t • w ∈ Metric.ball 0 R}) ∧
        (∀ w ∈ Metric.ball 0 R,
          (S.normalizedTerminalMetric k).edist p (Phi w) = ENNReal.ofReal ‖w‖) ∧
        ∀ x ∈ Metric.closedBall 0 (2 * rho), ∀ v,
          (1 / 4 : ℝ) * ‖v‖ ^ 2 ≤ (S.normalizedTerminalMetric k).pullbackCoefficients Phi x v v ∧
          (S.normalizedTerminalMetric k).pullbackCoefficients Phi x v v ≤ (9 / 4 : ℝ) * ‖v‖ ^ 2 := by
  obtain ⟨R, hR, hcharts⟩ := H.eventually_uniform_terminal_normal_charts P04 hbound A hA
  obtain ⟨K, _, hcurv⟩ := H.eventually_normalized_terminal_curvature_bound P04 hbound
    (A + R) (by positivity)
  obtain ⟨rho, hrho, hrhoR, hsmall⟩ :=
    RiemannianMetric.exists_uniform_radial_comparison_radius hR K
  refine ⟨R, rho, hrho, hrhoR, ?_⟩
  filter_upwards [hcharts, hcurv] with k hkcharts hkcurv p hp
  obtain ⟨L, Phi, hsource, htarget, hzero, hL, hderiv, hgeo, hdist⟩ := hkcharts p hp
  let g := S.normalizedTerminalMetric k
  let : Bundle.RiemannianBundle
      (TangentSpace (𝓡 3) : ((S.flow k).slice (S.base k).1).carrier → Type _) :=
    ⟨g.toRiemannianMetric⟩
  have he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ Phi (Metric.ball 0 R) := by
    simpa only [hsource] using Phi.contMDiffOn
  have hnorm := g.pullbackCoefficients_zero_of_orthonormal p
    (he.contMDiffAt (Metric.isOpen_ball.mem_nhds (Metric.mem_ball_self hR)))
    hzero hderiv hL
  have hcontain : g.ball p R ⊆ S.baseBall k (A + R) := by
    intro q hq
    rw [← S.normalizedTerminalMetric_ball]
    change g.edist (S.base k).2 q < ENNReal.ofReal (A + R)
    rw [ENNReal.ofReal_add hA.le hR.le]
    have hp' : p ∈ g.ball (S.base k).2 A := by
      rwa [S.normalizedTerminalMetric_ball]
    exact Manifold.riemannianEDist_triangle.trans_lt (ENNReal.add_lt_add hp' hq)
  have hradial (v : EuclideanSpace ℝ (Fin 3)) (hv : v ∈ Metric.ball 0 R) :
      g.IsGeodesicOn (fun t : ℝ => Phi (t • v)) {t : ℝ | t • v ∈ Metric.ball 0 R} ∧
      ∀ t ∈ Icc (0 : ℝ) 1,
        g.tangentNorm (Phi (t • v))
          (mfderiv 𝓘(ℝ, ℝ) (𝓡 3) (fun s : ℝ => Phi (s • v)) t 1) = ‖v‖ ∧
        g.edist p (Phi (t • v)) ≤ ENNReal.ofReal ‖v‖ * ENNReal.ofReal t := by
    refine ⟨hgeo v hv, ?_⟩
    intro t ht
    refine ⟨g.tangentNorm_radial_of_normalized_exponential p L hzero hL hderiv hgeo hv ht, ?_⟩
    have htv : t • v ∈ Metric.ball 0 R := by
      rw [Metric.mem_ball, dist_zero_right, norm_smul, Real.norm_of_nonneg ht.1]
      exact (mul_le_mul_of_nonneg_right ht.2 (norm_nonneg v)).trans_lt
        (by simpa only [one_mul, Metric.mem_ball, dist_zero_right] using hv)
    rw [hdist _ htv, norm_smul, Real.norm_of_nonneg ht.1, ENNReal.ofReal_mul ht.1, mul_comm]
  have hb := g.radial_exponential_uniform_bounds (S.normalizedTerminalConnection k)
    hrhoR hsmall he hnorm hradial (fun q hq => hkcurv q (hcontain hq))
  exact ⟨L, Phi, hsource, htarget, hzero, hL, hderiv, hgeo, hdist,
    fun x hx v => ((hb x hx).2 v).2⟩

end PoincareMT.M30CommonBlowupControls
