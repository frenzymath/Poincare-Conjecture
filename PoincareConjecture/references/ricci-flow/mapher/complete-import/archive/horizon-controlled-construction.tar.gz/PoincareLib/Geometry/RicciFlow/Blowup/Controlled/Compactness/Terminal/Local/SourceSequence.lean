import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Neighborhood
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Cylinders

/-!
# Selected controlled source sequences near a terminal point

The fixed-ball cylinder estimate and the actual terminal embeddings select a
single subsequence with a common local time interval and vanishing pinching
error. All retained charts still use the original terminal embeddings.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.M30CommonBlowupControls

open ControlledBlowupCylinder

theorem exists_local_source_sequence
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    {L : Type v} [TopologicalSpace L] [ChartedSpace (EuclideanSpace ℝ (Fin 3)) L]
    [IsManifold (𝓡 3) ∞ L]
    (E : ℕ → Set L) (hE : ∀ j, IsOpen (E j)) (hEmono : Monotone E)
    (hEcover : ⋃ j, E j = univ) (f : ∀ k, L → S.terminalComponent (sigma k))
    (hemb : ∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x))
    (hlocal : ∀ k, IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k))
    (himage : ∀ K : Set L, IsCompact K → ∃ R : ℝ, 0 < R ∧
      ∀ᶠ k in atTop, ∀ x ∈ K, (f k x).val ∈ S.baseBall (sigma k) R)
    (q : L) :
    ∃ rho R A T B : ℝ, 0 < rho ∧ 0 < R ∧ R < A ∧ 0 < T ∧ 0 < B ∧
      closedBall (extChartAt (𝓡 3) q q) (2 * rho) ⊆ (extChartAt (𝓡 3) q).target ∧
      ∃ tau : ℕ → ℕ, StrictMono tau ∧
        ∃ cyl : ∀ i, ControlledBlowupCylinder S (sigma (tau i)) A T B (((i : ℝ) + 1)⁻¹),
        ∃ Phi : ∀ i, PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
          (sourceBall S (sigma (tau i)) A) ∞,
          (∀ i, IsCompact (closure (S.baseBall (sigma (tau i)) A))) ∧
          (∀ i, (Phi i).source = ball (extChartAt (𝓡 3) q q) (2 * rho)) ∧
          (∀ i z, z ∈ (Phi i).source →
            (Phi i z).val = (f (tau i) ((extChartAt (𝓡 3) q).symm z)).val ∧
              (Phi i z).val ∈ S.baseBall (sigma (tau i)) R) ∧
          ∀ (hT : 0 < T) i z, z ∈ (Phi i).source →
            (((cyl i).ordinaryFlow hT).metric 0).pullbackCoefficients (Phi i) z =
              (S.terminalComponentMetric (sigma (tau i))).pullbackCoefficients
                (f (tau i) ∘ (extChartAt (𝓡 3) q).symm) z := by
  obtain ⟨rho, R, hrho, hR, hchart, hcharts⟩ :=
    ControlledTerminal.exists_captured_terminal_partial_charts sigma E hE hEmono hEcover
      f hemb hlocal himage q
  let A := R + 1
  have hA : 0 < A := by dsimp [A]; linarith
  have hRA : R < A := by dsimp [A]; linarith
  obtain ⟨T, B, hT, hB, hcyl⟩ := H.eventually_controlled_cylinders_on_fixed_ball P04 hbound A hA
  have hcapture := hcharts A hRA.le
  have hcompact := hsigma.tendsto_atTop.eventually (H.balls_compact A hA)
  let Q (i k : ℕ) : Prop :=
    IsCompact (closure (S.baseBall (sigma k) A)) ∧
      Nonempty (ControlledBlowupCylinder S (sigma k) A T B (((i : ℝ) + 1)⁻¹)) ∧
      ∃ Phi : PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
          (sourceBall S (sigma k) A) ∞,
        Phi.source = ball (extChartAt (𝓡 3) q q) (2 * rho) ∧
        (∀ z ∈ Phi.source,
          (Phi z).val = (f k ((extChartAt (𝓡 3) q).symm z)).val ∧
            (Phi z).val ∈ S.baseBall (sigma k) R) ∧
        ∀ (T B eta : ℝ) (cyl : ControlledBlowupCylinder S (sigma k) A T B eta)
          (hT : 0 < T), ∀ z ∈ Phi.source,
          ((cyl.ordinaryFlow hT).metric 0).pullbackCoefficients Phi z =
            (S.terminalComponentMetric (sigma k)).pullbackCoefficients
              (f k ∘ (extChartAt (𝓡 3) q).symm) z
  have hQ (i : ℕ) : ∀ᶠ k in atTop, Q i k :=
    hcompact.and ((hsigma.tendsto_atTop.eventually
      (hcyl (((i : ℝ) + 1)⁻¹) (by positivity))).and hcapture)
  obtain ⟨tau, htau, hselect⟩ := Poincare.exists_strictMono_forall_le_of_eventually hQ
  let cyl (i : ℕ) := Classical.choice (hselect i i le_rfl).2.1
  let Phi (i : ℕ) := (hselect i i le_rfl).2.2.choose
  have hPhi (i : ℕ) := (hselect i i le_rfl).2.2.choose_spec
  refine ⟨rho, R, A, T, B, hrho, hR, hRA, hT, hB, hchart,
    tau, htau, cyl, Phi, fun i => (hselect i i le_rfl).1,
    fun i => (hPhi i).1, fun i => (hPhi i).2.1, ?_⟩
  intro hT' i z hz
  exact (hPhi i).2.2 T B _ (cyl i) hT' z hz

end PoincareMT.M30CommonBlowupControls
