import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Data
import PoincareLib.Geometry.RicciFlow.Curvature.Theory
import PoincareLib.Geometry.Riemannian.Curvature.LocalIsometryInvariants
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.RegularLimit.ScalarComparison

/-!
# Scalar estimates along compatible worldlines

The box-time bound in the primitive M30 controls is transported to the
actual rescaled cylinder clock. Scalar normalization removes the blow-up
scale from its quadratic derivative bound. The guarded comparison is the
temporal part of Morgan--Tian Lemma 11.2, pp. 268--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.GeneralizedFlowCylinder

variable {F : GeneralizedRicciFlowData.{u}} {C : GeneralizedSliceCarrier.{u}}
  {origin scale : ℝ} {I : Set ℝ} {U : Set C.carrier}

/-- Near every time, the scalar of a compatible cylinder is the scalar
of one actual flow box in its original time coordinate. -/
theorem scalar_eq_box_near
    (e : GeneralizedFlowCylinder F C origin scale I U)
    {x : C.carrier} (hx : x ∈ U) {s : ℝ} (hs : s ∈ I)
    {f : ℝ → ℝ} (hf : ∀ t (ht : t ∈ I), f t = F.scalar (e.pointMap t ht x)) :
    ∃ b, ∃ y : (F.box b).carrier.carrier, ∃ delta : ℝ, 0 < delta ∧
      ∀ t (_ht : t ∈ I), |t - s| < delta →
        origin + t / scale ∈ (F.box b).interval ∧
        f t = ((F.box b).flow.connection (origin + t / scale)).scalarCurvature y := by
  obtain ⟨b, y, delta, hdelta, hbox⟩ := e.vertical_compatibility s hs x hx
  refine ⟨b, y, delta, hdelta, ?_⟩
  intro t ht hnear
  obtain ⟨hb, heq⟩ := hbox t ht hnear
  refine ⟨hb, ?_⟩
  rw [hf t ht]
  change (F.connection (origin + t / scale)).scalarCurvature (e.forward t ht x) = _
  rw [heq]
  exact (((F.box b).flow.connection _).scalarCurvature_eq_of_local_isometry
    (F.connection _) isOpen_univ ((F.box b).forward_smooth _ hb).contMDiffOn
    (fun z _ v w => ((F.box b).metric_pullback _ hb z v w).symm) (mem_univ y)).symm

theorem scalar_continuousOn
    (e : GeneralizedFlowCylinder F C origin scale I U)
    (P04 : RicciFlowCurvatureTheory.{u})
    {x : C.carrier} (hx : x ∈ U) {f : ℝ → ℝ}
    (hf : ∀ t (ht : t ∈ I), f t = F.scalar (e.pointMap t ht x)) :
    ContinuousOn f I := by
  intro s hs
  obtain ⟨b, y, delta, hdelta, hbox⟩ := e.scalar_eq_box_near hx hs hf
  let J := I ∩ {t : ℝ | |t - s| < delta}
  have hsJ : s ∈ J := ⟨hs, by simpa using hdelta⟩
  have hJ : J ∈ 𝓝[I] s := by
    apply inter_mem self_mem_nhdsWithin
    apply nhdsWithin_le_nhds
    exact (isOpen_lt (continuous_id.sub continuous_const).abs continuous_const).mem_nhds
      (by simpa using hdelta)
  have hmaps : MapsTo (fun t : ℝ => (origin + t / scale, y)) J
      ((F.box b).interval ×ˢ univ) := fun t ht => ⟨(hbox t ht.1 ht.2).1, mem_univ y⟩
  have hc := (P04.scalar_regular 3 _ _ (F.box b).flow).continuousOn.comp
    (((continuous_const.add (continuous_id.div_const scale)).prodMk
      continuous_const).continuousOn) hmaps
  have hfc : ContinuousOn f J := hc.congr (fun t ht => (hbox t ht.1 ht.2).2)
  exact (hfc s hsJ).mono_of_mem_nhdsWithin hJ

end PoincareMT.GeneralizedFlowCylinder

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

/-- The primitive guarded box derivative estimate uses the normalized time
variable of the given cylinder, including its time endpoints. -/
theorem cylinder_scalar_derivative_bound
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (k : ℕ) {I : Set ℝ} {U : Set ((S.flow k).slice (S.base k).1).carrier}
    (e : GeneralizedFlowCylinder (S.flow k) ((S.flow k).slice (S.base k).1)
      (S.base k).1 (S.scale k) I U)
    {x : ((S.flow k).slice (S.base k).1).carrier} (hx : x ∈ U)
    {f : ℝ → ℝ}
    (hf : ∀ t (ht : t ∈ I), f t = (S.flow k).scalar (e.pointMap t ht x))
    {s : ℝ} (hs : s ∈ I) (hszero : s ≤ 0) (hhigh : 4 * S.scale k ≤ f s) :
    ∃ d : ℝ, HasDerivWithinAt f d I s ∧
      |d| ≤ H.analytic_constant * f s ^ 2 / S.scale k := by
  obtain ⟨b, y, delta, hdelta, hbox⟩ := e.scalar_eq_box_near hx hs hf
  let J := I ∩ {t : ℝ | |t - s| < delta}
  have hsJ : s ∈ J := ⟨hs, by simpa using hdelta⟩
  have hJ : J ∈ 𝓝[I] s := by
    apply inter_mem self_mem_nhdsWithin
    apply nhdsWithin_le_nhds
    exact (isOpen_lt (continuous_id.sub continuous_const).abs continuous_const).mem_nhds
      (by simpa using hdelta)
  have hmaps : MapsTo (fun t : ℝ => (S.base k).1 + t / S.scale k) J
      ((S.flow k).box b).interval := fun t ht => (hbox t ht.1 ht.2).1
  have heq : EqOn f
      ((fun t => (((S.flow k).box b).flow.connection t).scalarCurvature y) ∘
        (fun t => (S.base k).1 + t / S.scale k)) J :=
    fun t ht => (hbox t ht.1 ht.2).2
  have hscale : 0 < S.scale k := S.base_scalar_pos k
  obtain ⟨d, hd, hbound⟩ := H.scalar_time_derivative_bound k b _ (hmaps hsJ)
    (by have := div_nonpos_of_nonpos_of_nonneg hszero hscale.le; linarith)
    y (by simpa only [heq hsJ, Function.comp_apply] using hhigh)
  have hclock : HasDerivWithinAt (fun t : ℝ => (S.base k).1 + t / S.scale k)
      (1 / S.scale k) J s := by
    simpa only [id_eq] using
      (((hasDerivAt_id s).div_const (S.scale k)).const_add (S.base k).1).hasDerivWithinAt
        (s := J)
  refine ⟨d * (1 / S.scale k),
    ((hd.comp s hclock hmaps).congr heq (heq hsJ)).mono_of_mem_nhdsWithin hJ, ?_⟩
  have hvalue := heq hsJ
  dsimp only [Function.comp_apply] at hvalue
  rw [← hvalue] at hbound
  rw [abs_mul, abs_of_pos (by positivity : 0 < 1 / S.scale k)]
  simpa only [div_eq_mul_inv, one_mul] using
    mul_le_mul_of_nonneg_right hbound (by positivity : 0 ≤ (S.scale k)⁻¹)

/-- Rescaling both scalar curvature and time cancels the original scale. -/
theorem normalized_cylinder_scalar_derivative_bound
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (k : ℕ) {I : Set ℝ} {U : Set ((S.flow k).slice (S.base k).1).carrier}
    (e : GeneralizedFlowCylinder (S.flow k) ((S.flow k).slice (S.base k).1)
      (S.base k).1 (S.scale k) I U)
    {x : ((S.flow k).slice (S.base k).1).carrier} (hx : x ∈ U)
    {f : ℝ → ℝ}
    (hf : ∀ t (ht : t ∈ I), f t = (S.flow k).scalar (e.pointMap t ht x))
    {s : ℝ} (hs : s ∈ I) (hszero : s ≤ 0) (hhigh : 4 ≤ f s / S.scale k) :
    ∃ d : ℝ, HasDerivWithinAt (fun t => f t / S.scale k) d I s ∧
      |d| ≤ H.analytic_constant * (f s / S.scale k) ^ 2 := by
  have hscale : 0 < S.scale k := S.base_scalar_pos k
  obtain ⟨d, hd, hb⟩ := H.cylinder_scalar_derivative_bound k e hx hf hs hszero
    ((le_div_iff₀ hscale).mp hhigh)
  refine ⟨d / S.scale k, hd.div_const _, ?_⟩
  rw [abs_div, abs_of_pos hscale]
  calc
    |d| / S.scale k ≤ (H.analytic_constant * f s ^ 2 / S.scale k) / S.scale k :=
      div_le_div_of_nonneg_right hb hscale.le
    _ = H.analytic_constant * (f s / S.scale k) ^ 2 := by ring

/-- A terminal normalized scalar bound persists on a short backward
interval. The derivative estimate is used only above the original guard. -/
theorem cylinder_scalar_lt_two_mul
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u})
    (k : ℕ) {I : Set ℝ} {U : Set ((S.flow k).slice (S.base k).1).carrier}
    (e : GeneralizedFlowCylinder (S.flow k) ((S.flow k).slice (S.base k).1)
      (S.base k).1 (S.scale k) I U)
    {x : ((S.flow k).slice (S.base k).1).carrier} (hx : x ∈ U)
    {f : ℝ → ℝ}
    (hf : ∀ t (ht : t ∈ I), f t = (S.flow k).scalar (e.pointMap t ht x))
    {T K : ℝ} (hK : 4 ≤ K) (hI : Icc (-T) 0 ⊆ I)
    (hzero : f 0 < K * S.scale k)
    (hshort : T < 1 / (4 * (H.analytic_constant + 1) * K)) :
    ∀ s ∈ Icc (-T) 0, f s < (2 * K) * S.scale k := by
  have hscale : 0 < S.scale k := S.base_scalar_pos k
  have hcont : ContinuousOn (fun t => f t / S.scale k) (Icc (-T) 0) :=
    ((e.scalar_continuousOn P04 hx hf).mono hI).div_const _
  have hder : ∀ t ∈ Ioo (-T) 0, 4 ≤ f t / S.scale k →
      ∃ d, HasDerivAt (fun s => f s / S.scale k) d t ∧
        |d| ≤ H.analytic_constant * (f t / S.scale k) ^ 2 := by
    intro t ht hhigh
    obtain ⟨d, hd, hb⟩ := H.normalized_cylinder_scalar_derivative_bound k e hx hf
      (hI ⟨ht.1.le, ht.2.le⟩) ht.2.le hhigh
    refine ⟨d, (hd.mono hI).hasDerivAt ?_, hb⟩
    exact mem_of_superset (isOpen_Ioo.mem_nhds ht) Ioo_subset_Icc_self
  have hbound := SingularRegularLimit.scalar_lt_two_mul_of_short_interval_backward
    H.analytic_constant_pos.le (by norm_num : (0 : ℝ) < 4) hK hcont
    ((div_lt_iff₀ hscale).mpr hzero) hder (by simpa using hshort)
  intro s hs
  exact (div_lt_iff₀ hscale).mp (hbound s hs)

end PoincareMT.M30CommonBlowupControls
