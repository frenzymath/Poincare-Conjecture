import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Geometry
import PoincareLib.Geometry.RicciFlow.TimeTranslation

/-! # Local backward flows ending at the finite boundary metric -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledBlowupBoundary

variable {n : ℕ} {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
  {T V : ℝ} (hT : 0 < T) (hV : T < V) (F : RicciFlow n M (Icc (-V) 0))

/-- Recenter the local extension at the old backward endpoint. Its new
terminal metric is exactly the metric used in boundary descent. -/
def localBackwardFlow : RicciFlow n M (Icc (-(V - T)) 0) :=
  F.translate (-T) (by
    rintro _ ⟨t, ht, rfl⟩
    exact ⟨by linarith [ht.1], by linarith [ht.2]⟩)
    ordConnected_Icc ⟨-(V - T), ⟨le_rfl, by linarith⟩,
      0, ⟨by linarith, le_rfl⟩, by linarith⟩

theorem localBackwardFlow_metric_zero : (localBackwardFlow hT hV F).metric 0 = F.metric (-T) := by
  change F.metric (0 + -T) = F.metric (-T)
  rw [zero_add]

theorem localBackwardFlow_nonnegativeCurvatureOperator
    (hpos : ∀ t ∈ Icc (-V) 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    {s : ℝ} (hs : s ∈ Icc (-(V - T)) 0) (x : M) :
    ((localBackwardFlow hT hV F).connection s).NonnegativeCurvatureOperator x :=
  hpos (s + -T) ⟨by linarith [hs.1], by linarith [hs.2]⟩ x

end PoincareMT.ControlledBlowupBoundary
