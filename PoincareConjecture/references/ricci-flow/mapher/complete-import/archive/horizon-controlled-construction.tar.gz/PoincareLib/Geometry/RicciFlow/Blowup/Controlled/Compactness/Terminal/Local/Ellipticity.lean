import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.TerminalMetric

/-!
# Ellipticity on actual controlled cylinder charts

The uniform cylinder curvature bound propagates terminal quadratic-form
bounds through the finite backward interval, in the same source chart.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

theorem ordinaryFlow_chart_ellipticity
    {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta alpha beta : ℝ}
    (cyl : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T) (hB : 0 ≤ B)
    (f : EuclideanSpace ℝ (Fin 3) → sourceBall S k A)
    (x : EuclideanSpace ℝ (Fin 3))
    (href : ∀ v, alpha * ‖v‖ ^ 2 ≤ ((cyl.ordinaryFlow hT).metric 0).pullbackCoefficients f x v v ∧
      ((cyl.ordinaryFlow hT).metric 0).pullbackCoefficients f x v v ≤ beta * ‖v‖ ^ 2)
    (s : ℝ) (hs : s ∈ Icc (-T) 0) (v : EuclideanSpace ℝ (Fin 3)) :
    (Real.exp (-6 * B * T) * alpha) * ‖v‖ ^ 2 ≤
        ((cyl.ordinaryFlow hT).metric s).pullbackCoefficients f x v v ∧
      ((cyl.ordinaryFlow hT).metric s).pullbackCoefficients f x v v ≤
        (Real.exp (6 * B * T) * beta) * ‖v‖ ^ 2 := by
  let F := cyl.ordinaryFlow hT
  let w := mfderiv (𝓡 3) (𝓡 3) f x v
  have hnonneg (t : ℝ) : 0 ≤ (F.metric t).inner (f x) w w := by
    by_cases hw : w = 0
    · simp [hw]
    · exact ((F.metric t).pos _ _ hw).le
  have hRic : ∀ t ∈ Icc (-T) 0,
      |(F.connection t).ricci (f x) w w| ≤ (3 * B) * (F.metric t).inner (f x) w w := by
    intro t ht
    exact (RicciFlowAnalysis.abs_ricci_le_curvatureTensorNorm
      (F.connection t) (f x) w).trans
        (mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_left
            ((le_abs_self _).trans (cyl.ordinaryFlow_curvature_bound hT t ht (f x)))
            (by norm_num)) (hnonneg t))
  have hzero : (0 : ℝ) ∈ Icc (-T) 0 := ⟨by linarith, le_rfl⟩
  have hc := F.metric_inner_self_exp_bounds (convex_Icc (-T) 0) Subset.rfl
    (f x) w (3 * B) hRic hzero hs
  have hdist : |s - 0| ≤ T := by rw [sub_zero, abs_of_nonpos hs.2]; linarith [hs.1]
  have hrefv := href v
  change alpha * ‖v‖ ^ 2 ≤ (F.metric 0).inner (f x) w w ∧
    (F.metric 0).inner (f x) w w ≤ beta * ‖v‖ ^ 2 at hrefv
  change _ ≤ (F.metric s).inner (f x) w w ∧ (F.metric s).inner (f x) w w ≤ _
  constructor
  · calc
      _ = Real.exp (-6 * B * T) * (alpha * ‖v‖ ^ 2) := mul_assoc _ _ _
      _ ≤ Real.exp (-6 * B * T) * (F.metric 0).inner (f x) w w :=
        mul_le_mul_of_nonneg_left hrefv.1 (Real.exp_nonneg _)
      _ ≤ Real.exp (-(2 * (3 * B)) * |s - 0|) * (F.metric 0).inner (f x) w w := by
        apply mul_le_mul_of_nonneg_right _ (hnonneg 0)
        apply Real.exp_le_exp.mpr
        nlinarith [mul_le_mul_of_nonneg_left hdist hB]
      _ ≤ _ := hc.1
  · calc
      _ ≤ Real.exp (2 * (3 * B) * |s - 0|) * (F.metric 0).inner (f x) w w := hc.2
      _ ≤ Real.exp (6 * B * T) * (F.metric 0).inner (f x) w w := by
        apply mul_le_mul_of_nonneg_right _ (hnonneg 0)
        apply Real.exp_le_exp.mpr
        nlinarith [mul_le_mul_of_nonneg_left hdist hB]
      _ ≤ Real.exp (6 * B * T) * (beta * ‖v‖ ^ 2) :=
        mul_le_mul_of_nonneg_left hrefv.2 (Real.exp_nonneg _)
      _ = _ := (mul_assoc _ _ _).symm

end PoincareMT.ControlledBlowupCylinder
