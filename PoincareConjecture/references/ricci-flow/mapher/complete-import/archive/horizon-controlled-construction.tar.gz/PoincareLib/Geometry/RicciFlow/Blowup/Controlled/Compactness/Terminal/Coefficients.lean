import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.CountableCharts
import PoincareLib.Geometry.RicciFlow.Compactness.GeometricLimit.SourceCharts.Coefficients
import PoincareLib.Analysis.Calculus.SmoothCompactness.LinearPrecompose
import PoincareLib.Analysis.Calculus.SmoothCompactness.LocalConvergence

/-!
# Coefficients in the terminal component charts

Restriction to the based component preserves the actual pulled-back metric.
The coordinate dilation then multiplies its coefficients by the square of
the radius, preserving positive lower bounds and all local derivative bounds.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter Metric Poincare.Gluing Poincare.Analysis.Calculus
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.NormalChartCover

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A R rho a b : ℝ} {N : ℕ}
  (C : NormalChartCover (fun _ => S.normalizedTerminalMetric k)
    (S.base k).2 (-1) 1 A R rho a b N)

local instance : Nonempty (ball (0 : EuclideanSpace ℝ (Fin 3)) 1) := ⟨⟨0, by simp⟩⟩

theorem componentUnitBallMap_pullbackCoefficients
    (hrho : 0 < rho) (hrhoR : rho / 2 ≤ R) (i : Fin (N + 1))
    {x : EuclideanSpace ℝ (Fin 3)} (hx : x ∈ ball 0 1) :
    (S.terminalComponentMetric k).pullbackCoefficients
        (ChartDistance.chartParametrization (fun _ : ℕ => ball 0 1)
          (fun _ => isOpen_ball) (i := 0) (C.componentUnitBallMap hrho hrhoR i)) x =
      (rho / 2) ^ 2 • (S.normalizedTerminalMetric k).pullbackCoefficients
        (C.chart i) ((rho / 2) • x) := by
  let := (isOpen_ball (x := (0 : EuclideanSpace ℝ (Fin 3)))
    (ε := 1)).isOpenEmbedding_subtypeVal.singletonChartedSpace
  let U := fun _ : ℕ => ball (0 : EuclideanSpace ℝ (Fin 3)) 1
  let hU : ∀ i, IsOpen (U i) := fun _ => isOpen_ball
  let p := ChartDistance.chartParametrization U hU (i := 0)
    (C.componentUnitBallMap hrho hrhoR i)
  let q := ChartDistance.chartParametrization U hU (i := 0) (C.unitBallMap i)
  have hp : ContMDiffAt (𝓡 3) (𝓡 3) ∞ p x :=
    (ChartDistance.contMDiffOn_chartParametrization U hU
      (C.componentUnitBallMap_isLocalDiffeomorph hrho hrhoR i).contMDiff).contMDiffAt
        (isOpen_ball.mem_nhds hx)
  have heq : (Subtype.val : S.terminalComponent k → _) ∘ p = q := rfl
  have hderiv := mfderiv_comp x
    ((Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 3)
      (S.terminalComponent k)).contMDiff.mdifferentiable (by simp) (p x))
    (hp.mdifferentiableAt (by simp))
  rw [heq] at hderiv
  have heqcoeff : (S.terminalComponentMetric k).pullbackCoefficients p x =
      (S.normalizedTerminalMetric k).pullbackCoefficients q x := by
    ext v w
    change (S.normalizedTerminalMetric k).inner (p x).val
      (mfderiv (𝓡 3) (𝓡 3) (Subtype.val : S.terminalComponent k → _) (p x)
        (mfderiv (𝓡 3) (𝓡 3) p x v))
      (mfderiv (𝓡 3) (𝓡 3) (Subtype.val : S.terminalComponent k → _) (p x)
        (mfderiv (𝓡 3) (𝓡 3) p x w)) =
      (S.normalizedTerminalMetric k).inner (q x)
        (mfderiv (𝓡 3) (𝓡 3) q x v) (mfderiv (𝓡 3) (𝓡 3) q x w)
    rw [hderiv]
    rfl
  change (S.terminalComponentMetric k).pullbackCoefficients p x = _
  rw [heqcoeff]
  ext v w
  exact C.unitBallMap_pullbackCoefficients hrho hrhoR i 0 hx v w

theorem componentUnitBallMap_lower_coefficients
    (hrho : 0 < rho) (hrhoR : rho / 2 ≤ R) (i : Fin (N + 1))
    {x : EuclideanSpace ℝ (Fin 3)} (hx : x ∈ ball 0 1)
    (v : EuclideanSpace ℝ (Fin 3)) :
    (a * (rho / 2) ^ 2) * ‖v‖ ^ 2 ≤
      (S.terminalComponentMetric k).pullbackCoefficients
        (ChartDistance.chartParametrization (fun _ : ℕ => ball 0 1)
          (fun _ => isOpen_ball) (i := 0) (C.componentUnitBallMap hrho hrhoR i)) x v v := by
  rw [C.componentUnitBallMap_pullbackCoefficients hrho hrhoR i hx]
  have hx' : (rho / 2) • x ∈ closedBall 0 (2 * rho) :=
    (ball_subset_closedBall.trans (closedBall_subset_closedBall (by linarith)))
      (rescale_mem_half_ball hrho ⟨x, hx⟩)
  have h := mul_le_mul_of_nonneg_left
    (C.coefficients i 0 (by constructor <;> norm_num) _ hx' v).1 (sq_nonneg (rho / 2))
  simpa only [smul_apply, smul_eq_mul, mul_left_comm, mul_assoc] using h

end PoincareMT.NormalChartCover

namespace PoincareMT.ControlledTerminal

variable {S : GeneralizedBlowupSequence.{u}} {sigma : ℕ → ℕ}
  {R rho : ℕ → ℝ} {N : ℕ → ℕ}
  (cover : ∀ k j, j ≤ k → NormalChartCover
    (fun _ => S.normalizedTerminalMetric (sigma k)) (S.base (sigma k)).2
    (-1) 1 ((j : ℝ) + 1) (R j) (rho j) (1 / 4) (9 / 4) (N j))
  (hrho : ∀ j, 0 < rho j) (hrhoR : ∀ j, rho j / 2 ≤ R j)

local instance : Nonempty (ball (0 : EuclideanSpace ℝ (Fin 3)) 1) := ⟨⟨0, by simp⟩⟩

theorem chartMap_eventually_lower_coefficients (i : ℕ) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ k in atTop,
      ∀ x ∈ ball (0 : EuclideanSpace ℝ (Fin 3)) 1, ∀ v,
        c * ‖v‖ ^ 2 ≤ (S.terminalComponentMetric (sigma k)).pullbackCoefficients
          (ChartDistance.chartParametrization (fun _ : ℕ => ball 0 1)
            (fun _ => isOpen_ball) (i := i) (chartMap cover hrho hrhoR k i)) x v v := by
  let j := (Nat.unpair i).1
  refine ⟨(1 / 4) * (rho j / 2) ^ 2,
    mul_pos (by norm_num) (sq_pos_of_pos (half_pos (hrho j))), ?_⟩
  filter_upwards [eventually_ge_atTop j] with k hk x hx v
  rw [chartMap_of_le cover hrho hrhoR k i hk]
  exact (cover k j hk).componentUnitBallMap_lower_coefficients (hrho j) (hrhoR j) _ hx v

theorem chartMap_eventually_bounded_derivatives (i : ℕ)
    (hraw : ∀ m : ℕ, ∃ B : ℝ, ∀ᶠ k in atTop,
      ∀ (hk : (Nat.unpair i).1 ≤ k) (l : Fin (N (Nat.unpair i).1 + 1)),
        ∀ x ∈ closedBall (0 : EuclideanSpace ℝ (Fin 3)) (rho (Nat.unpair i).1),
          ‖iteratedFDeriv ℝ m ((S.normalizedTerminalMetric (sigma k)).pullbackCoefficients
            ((cover k (Nat.unpair i).1 hk).chart l)) x‖ ≤ B) :
    LocallyEventuallyBoundedDerivatives (ball (0 : EuclideanSpace ℝ (Fin 3)) 1)
      (fun k => (S.terminalComponentMetric (sigma k)).pullbackCoefficients
        (ChartDistance.chartParametrization (fun _ : ℕ => ball 0 1)
          (fun _ => isOpen_ball) (i := i) (chartMap cover hrho hrhoR k i))) := by
  let j := (Nat.unpair i).1
  let L : EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) :=
    (rho j / 2) • ContinuousLinearMap.id ℝ _
  let rawStage := fun k j (hjk : j ≤ k) =>
    (S.normalizedTerminalMetric (sigma k)).pullbackCoefficients
      ((cover k j hjk).chart
        ⟨(Nat.unpair i).2 % (N j + 1), Nat.mod_lt _ (Nat.succ_pos _)⟩)
  let raw := fun k => rawStage k (min j k) (min_le_right _ _)
  have hstage (k : ℕ) (hk : j ≤ k) : raw k = rawStage k j hk := by
    change rawStage k (min j k) _ = rawStage k j hk
    congr 1
    exact min_eq_left hk
  have heq (k : ℕ) (hk : j ≤ k) : EqOn
      ((S.terminalComponentMetric (sigma k)).pullbackCoefficients
        (ChartDistance.chartParametrization (fun _ : ℕ => ball 0 1)
          (fun _ => isOpen_ball) (i := i) (chartMap cover hrho hrhoR k i)))
      (fun x => (rho j / 2) ^ 2 • raw k (L x)) (ball 0 1) := by
    intro x hx
    rw [chartMap_of_le cover hrho hrhoR k i hk, hstage k hk]
    exact (cover k j hk).componentUnitBallMap_pullbackCoefficients (hrho j) (hrhoR j) _ hx
  have hsmooth (k : ℕ) (hk : j ≤ k) (x : EuclideanSpace ℝ (Fin 3))
      (hx : x ∈ ball 0 1) : ContDiffAt ℝ ∞ (raw k) (L x) := by
    rw [hstage k hk]
    apply (S.normalizedTerminalMetric (sigma k)).contDiffAt_pullbackCoefficients
    apply (cover k j hk).chart _ |>.contMDiffOn.contMDiffAt
    apply (cover k j hk).chart _ |>.open_source.mem_nhds
    rw [(cover k j hk).source]
    exact (ball_subset_ball (hrhoR j)) (NormalChartCover.rescale_mem_half_ball (hrho j) ⟨x, hx⟩)
  intro K _hK hKU m
  obtain ⟨B, hB⟩ := hraw m
  refine ⟨‖(rho j / 2) ^ 2‖ * (B * ∏ _ : Fin m, ‖L‖), ?_⟩
  filter_upwards [hB, eventually_ge_atTop j] with k hkB hk x hx
  rw [eqOn_iteratedFDeriv_of_isOpen isOpen_ball (heq k hk) m (hKU hx)]
  have hcomp : ContDiffAt ℝ ∞ (raw k ∘ L) x :=
    (hsmooth k hk x (hKU hx)).comp x L.contDiff.contDiffAt
  change ‖iteratedFDeriv ℝ m (fun x => (rho j / 2) ^ 2 • (raw k ∘ L) x) x‖ ≤ _
  rw [iteratedFDeriv_const_smul_apply' (i := m) (a := (rho j / 2) ^ 2)
    (hcomp.of_le (by exact_mod_cast le_top))]
  let : IsBoundedSMul ℝ
      (EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ) :=
    NormedSpace.toIsBoundedSMul (𝕜 := ℝ)
      (E := EuclideanSpace ℝ (Fin 3) →L[ℝ] EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ)
  apply (ContinuousMultilinearMap.opNorm_smul_le _ _).trans
  rw [iteratedFDeriv_comp_continuousLinearMap_of_contDiffAt L
    (hsmooth k hk x (hKU hx)) m]
  apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
  apply ((iteratedFDeriv ℝ m (raw k) (L x)).norm_compContinuousLinearMap_le
    (fun _ : Fin m => L)).trans
  apply mul_le_mul_of_nonneg_right _ (Finset.prod_nonneg fun _ _ => norm_nonneg _)
  rw [hstage k hk]
  apply hkB hk
  exact ball_subset_closedBall ((ball_subset_ball (half_le_self (hrho j).le))
    (NormalChartCover.rescale_mem_half_ball (hrho j) ⟨x, hKU hx⟩))

end PoincareMT.ControlledTerminal
