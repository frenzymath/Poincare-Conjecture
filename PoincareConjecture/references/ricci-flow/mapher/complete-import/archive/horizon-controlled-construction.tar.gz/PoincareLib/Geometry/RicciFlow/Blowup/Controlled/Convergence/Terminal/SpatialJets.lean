import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Jets

/-!
# Actual spatial source jets through the terminal slice
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)
  (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
  (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))

include hF P04 hB hAr hcompact hcomplete

/-- The closed spacetime source jets restrict to ordinary scalar spatial
jets at every fixed point, including at the final time. -/
theorem tendsto_terminal_spatial_pullbackJet
    (q : G.limitCarrier.carrier) {p : EuclideanSpace ℝ (Fin 3)}
    (hp : p ∈ (extChartAt (𝓡 3) q).target) {t : ℝ} (ht : t ∈ Icc 0 (T / 2))
    (r : ℕ) (a b : Fin 3) :
    Tendsto (fun k => iteratedFDeriv ℝ r (fun x =>
      ((terminalSourceFlow G k).metric t).pullbackCoefficients
        (G.referenceChartMap q k 0) x
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) p)
      atTop (𝓝 (iteratedFDeriv ℝ r (fun x =>
        (F.metric t).pullbackCoefficients (extChartAt (𝓡 3) q).symm x
          (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b)) p)) := by
  let E := EuclideanSpace ℝ (Fin 3)
  let f := fun k => G.spatialSpacetimeCoefficients q k
  let g := fun z : ℝ × E => (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2
  obtain ⟨ε, hε, hεc⟩ := Metric.mem_nhds_iff.mp
    ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds hp)
  let ρ := ε / 2
  have hρ : 0 < ρ := by dsimp only [ρ]; positivity
  have hchart : closedBall p ρ ⊆ (extChartAt (𝓡 3) q).target :=
    (closedBall_subset_ball (by dsimp only [ρ]; linarith)).trans hεc
  have hpball : p ∈ ball p ρ := mem_ball_self hρ
  have hg : ContDiffOn ℝ ∞ g (Icc 0 (T / 2) ×ˢ closedBall p ρ) :=
    (F.contDiffOn_pullbackCoefficients_within (isOpen_extChartAt_target q)
      (contMDiffOn_extChartAt_symm (n := ∞) q)).mono
        (prod_mono (fun _ ht => ⟨by linarith [ht.1], ht.2⟩) hchart)
  have hf := eventually_source_contDiffOn_closed_slab G q (isCompact_closedBall p ρ) hchart
  have hjet := tendstoUniformlyOn_terminal_bilinearJet_on_closedBall G F hF
    P04 hB hAr hcompact hcomplete q hρ hchart r
  let R := ContinuousMultilinearMap.compContinuousLinearMapL
    (𝕜 := ℝ) (F := E →L[ℝ] E →L[ℝ] ℝ)
    (fun _ : Fin r => ContinuousLinearMap.inr ℝ ℝ E)
  have hrestricted := R.continuous.continuousAt.tendsto.comp
    (hjet.tendsto_at (x := (t, p)) ⟨ht, mem_closedBall_self hρ.le⟩)
  have hspatial : Tendsto (fun k => iteratedFDeriv ℝ r (fun x => f k (t, x)) p)
      atTop (𝓝 (iteratedFDeriv ℝ r (fun x => g (t, x)) p)) := by
    have htarget := ControlledConvergence.iteratedFDeriv_spatial_slice_of_closed_slab
      (show 0 < T / 2 by linarith) hρ g hg ht hpball r
    change iteratedFDeriv ℝ r (fun x => g (t, x)) p =
      R (iteratedFDerivWithin ℝ r g (Icc 0 (T / 2) ×ˢ closedBall p ρ) (t, p)) at htarget
    rw [← htarget] at hrestricted
    apply hrestricted.congr'
    filter_upwards [hf] with k hk
    exact (ControlledConvergence.iteratedFDeriv_spatial_slice_of_closed_slab
      (show 0 < T / 2 by linarith) hρ (f k) hk ht hpball r).symm
  have hsmoothg : ContDiffAt ℝ ∞ (fun x => g (t, x)) p := by
    have hslice : ContDiffOn ℝ ∞ (fun x => g (t, x)) (closedBall p ρ) :=
      hg.comp (contDiff_const.prodMk contDiff_id).contDiffOn (fun x hx => ⟨ht, hx⟩)
    exact hslice.contDiffAt
      (mem_of_superset (isOpen_ball.mem_nhds hpball) ball_subset_closedBall)
  have hr : (r : ℕ∞ω) ≤ ∞ := WithTop.coe_le_coe.mpr (le_top : (r : ℕ∞) ≤ ⊤)
  let L := NormalizedKappaSolutionSequence.coefficientEval a b
  have hscalar := L.continuous_postcomp_continuousMultilinearMap
    |>.continuousAt.tendsto.comp hspatial
  rw [← L.iteratedFDeriv_comp_left hsmoothg hr] at hscalar
  apply hscalar.congr'
  filter_upwards [hf] with k hk
  have hslice : ContDiffOn ℝ ∞ (fun x => f k (t, x)) (closedBall p ρ) :=
    hk.comp (contDiff_const.prodMk contDiff_id).contDiffOn (fun x hx => ⟨ht, hx⟩)
  have hsmoothf := hslice.contDiffAt
    (mem_of_superset (isOpen_ball.mem_nhds hpball) ball_subset_closedBall)
  exact (L.iteratedFDeriv_comp_left hsmoothf hr).symm

end PoincareMT.ControlledBlowupCompactness
