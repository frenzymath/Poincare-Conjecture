import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.InteriorVolume
import PoincareLib.Geometry.RicciFlow.Compactness.LocalControl
import PoincareLib.Geometry.RicciFlow.Compactness.Volume

/-!
# Pointed compactness hypotheses on a controlled finite window

Expanding actual cylinder balls, their compact closures, and the primitive
terminal volume bound supply every hypothesis of the frozen M07 service.
Source: Morgan--Tian, Theorem 5.15, p. 92, and Theorem 11.1, pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter MeasureTheory
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

/-- The actual normalized, based Type-0 flows recentered at the slab midpoint. -/
noncomputable def interiorSequence
    (S : GeneralizedBlowupSequence.{u}) (idx : ℕ → ℕ) (A eta : ℕ → ℝ)
    (T B : ℝ) (hA : ∀ i, 0 < A i) (hT : 0 < T)
    (e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)) :
    PointedFlowSequence 3 (-T / 2) (T / 2) where
  carrier i := (componentCarrier S (idx i) (hA i)).shrink
  flow i := {
    base := smallBase S (idx i) (hA i)
    flow := ((e i).smallFlow (hA i) hT).translate (-T / 2)
      (by rintro _ ⟨t, ht, rfl⟩; exact ⟨by linarith [ht.1], by linarith [ht.2]⟩)
      ordConnected_Ioo
      (by refine ⟨-T / 4, ⟨by linarith, by linarith⟩, 0,
        ⟨by linarith, by linarith⟩, by linarith⟩)
    volumeMeasure := (componentCarrier S (idx i) (hA i)).shrink.metricHausdorffVolume
      (((e i).smallFlow (hA i) hT).metric (-T / 2))
    spacetimeVectorField := fun _ _ => (1, 0)
    spacetimeVectorField_time := fun _ _ => rfl
    spacetimeVectorField_spatial_zero := fun _ _ => rfl }

/-- Every frozen M07 premise is a consequence of the actual selected
cylinders and the original terminal geometric controls. -/
theorem exists_pointedCompactnessHypotheses
    (S : GeneralizedBlowupSequence.{u}) (idx : ℕ → ℕ) (A eta : ℕ → ℝ)
    {T B rho v : ℝ} (hA : ∀ i, 0 < A i) (hT : 0 < T) (hB : 0 ≤ B)
    (e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i))
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hrho : 0 < rho) (hv : 0 < v)
    (hvolume : ∀ᶠ i in atTop,
      ENNReal.ofReal (v / Real.sqrt (S.scale (idx i)) ^ 3) ≤
        calibratedMetricVolume ((S.flow (idx i)).metric (S.base (idx i)).1)
          (S.baseBall (idx i) rho)) :
    ∃ H : PointedRicciFlowCompactnessHypotheses 3 (-T / 2) (T / 2),
      H.sequence = interiorSequence S idx A eta T B hA hT e := by
  let D := interiorSequence S idx A eta T B hA hT e
  have hmid : (-T / 2) ∈ Icc (-T) 0 := ⟨by linarith, by linarith⟩
  have hshift {t : ℝ} (ht : t ∈ Ioo (-T / 2) (T / 2)) :
      t + (-T / 2) ∈ Icc (-T) 0 := ⟨by linarith [ht.1], by linarith [ht.2]⟩
  have hcurv (i : ℕ) (t : ℝ) (ht : t ∈ Ioo (-T / 2) (T / 2))
      (x : (D.carrier i).carrier) :
      (((D.flow i).flow.connection t).curvatureTensorNorm x) ≤ B :=
    (le_abs_self _).trans ((e i).smallFlow_curvature_bound (hA i) hT _ (hshift ht) x)
  have hnoncollapse : ∃ r κ : ℝ, 0 < r ∧ 0 < κ ∧ ∀ᶠ i in atTop,
      ENNReal.ofReal (κ * r ^ 3) ≤ (D.flow i).zeroBallVolume r := by
    let C := Real.exp (3 * B * |(-T / 2)|)
    let r := C * rho
    let nu := v / C ^ 3
    let κ := nu / r ^ 3
    have hC : 0 < C := Real.exp_pos _
    have hr : 0 < r := mul_pos hC hrho
    have hnu : 0 < nu := div_pos hv (pow_pos hC 3)
    have hkappa : 0 < κ := div_pos hnu (pow_pos hr 3)
    have hcal : 0 < (euclideanVolumeCalibration 3).toReal :=
      ENNReal.toReal_pos (euclideanVolumeCalibration_pos 3).ne'
        (euclideanVolumeCalibration_ne_top 3)
    refine ⟨r, κ / (euclideanVolumeCalibration 3).toReal, hr, div_pos hkappa hcal, ?_⟩
    filter_upwards [hvolume, hAr.eventually_ge_atTop rho] with i hi hAi
    have hvol := (e i).ordinaryFlow_interior_volume_lower (hA i) hT hmid hAi hi
    have hsmall : ENNReal.ofReal (κ * r ^ 3) ≤
        (((e i).smallFlow (hA i) hT).metric (-T / 2)).volumeMeasure
          ((((e i).smallFlow (hA i) hT).metric (-T / 2)).ball
            (smallBase S (idx i) (hA i)) r) := by
      rw [(e i).smallFlow_volumeMeasure_ball]
      dsimp only [κ]
      rw [div_mul_cancel₀ _ (pow_ne_zero 3 hr.ne')]
      exact hvol
    have hh := calibrated_noncollapse_to_hausdorff
      (componentCarrier S (idx i) (hA i)).shrink
      (((e i).smallFlow (hA i) hT).metric (-T / 2))
      ((((e i).smallFlow (hA i) hT).metric (-T / 2)).ball
        (smallBase S (idx i) (hA i)) r) hkappa hr
      (by simpa only [calibratedMetricVolume_eq_volumeMeasure] using hsmall)
    simpa only [D, interiorSequence, BasedFlow.zeroBallVolume, BasedFlow.zeroBall,
      FlowCarrier.metricBall, RicciFlow.translate, zero_add] using hh
  refine ⟨{
    time_bounds := ⟨by linarith, by linarith⟩
    sequence := D
    volume_compatibility := ?_
    zero_time_ball_compact := ?_
    spacetime_control := ?_
    all_time_curvature_control := ?_
    noncollapsing := hnoncollapse }, rfl⟩
  · intro i
    change _ = (componentCarrier S (idx i) (hA i)).shrink.metricHausdorffVolume
      (((e i).smallFlow (hA i) hT).metric (0 + (-T / 2)))
    rw [zero_add]
    rfl
  · intro r _
    filter_upwards [hAr.eventually_ge_atTop (2 * (Real.exp (3 * B * |(-T / 2)|) * r))]
      with i hi
    have hc := (e i).smallFlow_isCompact_closure_ball (hA i) hT (hcompact i) hmid
      (show Real.exp (3 * B * |(-T / 2)|) * r ≤ A i / 2 by linarith)
    simpa only [D, interiorSequence, BasedFlow.zeroBall, FlowCarrier.metricBall,
      RicciFlow.translate, zero_add] using hc
  · intro r _ I _ _ _ hI
    refine ⟨B, hB, Eventually.of_forall (fun i => ?_)⟩
    exact ⟨SmoothSpacetimeEmbedding.refl (D.flow i) (I ×ˢ (D.flow i).zeroBall r),
      fun _ _ => rfl, hB, fun t ht x _ => hcurv i t (hI ht) x⟩
  · intro r _
    exact ⟨B, hB, Eventually.of_forall (fun i _ _ t ht x _ => hcurv i t ht x)⟩

end PoincareMT.ControlledBlowupCompactness
