import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Neck
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Ancient.Compact.Stability.Neck.Jets.CenteredError

/-!
# Neck transport through captured comparison coordinates

The source neck may vary with the approximating metric. Its actual coordinate
map is transported through a smooth partial homeomorphism, and finite
normalized metric errors construct a neck for the target metric.

Reference: Morgan--Tian, Claim 11.6 and Proposition 9.79(3).
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.EpsilonNeck

open MetricSurgery

local notation "E" => EuclideanSpace ℝ (Fin 3)
local notation "IC" => ModelWithCorners.prod (𝓡 2) 𝓘(ℝ, ℝ)

theorem exists_transported_neck_tolerance
    {δ ε : ℝ} (hδ : 0 < δ) (hδε : δ < ε) (hε : ε < 1 / 2) :
    ∃ η : ℝ, 0 < η ∧
      ∀ (X : Type u) [TopologicalSpace X] [ChartedSpace E X] [IsManifold (𝓡 3) ∞ X]
        (M : Type v) [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M],
      ∀ (g : RiemannianMetric 3 X) (h : RiemannianMetric 3 M)
        (N : EpsilonNeck g), N.epsilon = δ →
      ∀ e : OpenPartialHomeomorph X M,
        ContMDiffOn (𝓡 3) (𝓡 3) ∞ e e.source →
        ContMDiffOn (𝓡 3) (𝓡 3) ∞ e.symm e.target →
        N.carrier ⊆ e.source →
      ∀ D : LeviCivitaData h, 0 < D.scalarCurvature (e N.center) →
      (∀ z : RoundCylinderSpace, z.2 ∈ Ioo (-ε⁻¹) ε⁻¹ → ∀ j, j ≤ ⌊ε⁻¹⌋₊ →
        ‖iteratedFDeriv ℝ j (fun p =>
          D.scalarCurvature (e N.center) • h.parametrizedCoefficients
            (e ∘ centeredNeckLift N z.1 z.2) p -
          N.connection.scalarCurvature N.center • g.parametrizedCoefficients
            (centeredNeckLift N z.1 z.2) p) 0‖ ≤ η) →
      ∃ N' : EpsilonNeck h, N'.epsilon = ε ∧ N'.center = e N.center ∧
        N'.connection = D ∧ N'.central_sphere = e '' N.central_sphere ∧
        N'.carrier = e '' N.region (-ε⁻¹) ε⁻¹ := by
  obtain ⟨η, hη, htolerance⟩ := TerminalNeck.exists_staticCylinder_comparison_tolerance hδ hδε
  obtain ⟨C, hC, hcoeff⟩ := exists_cylinder_coefficient_jet_constant ⌊ε⁻¹⌋₊
  refine ⟨η / C, div_pos hη hC, ?_⟩
  intro X _ _ _ M _ _ _ g h N hN e he hei hcapture D hR hjet
  have hNε : N.epsilon ≤ ε := hN.trans_le hδε.le
  have hεpos : 0 < ε := hδ.trans hδε
  let f := (N.restrictedCoordinate (δ := ε)).trans e
  have hsource : f.source = univ ×ˢ Ioo (-ε⁻¹) ε⁻¹ := by
    change (N.restrictedCoordinate (δ := ε)).source ∩
      (N.restrictedCoordinate (δ := ε)) ⁻¹' e.source = _
    rw [N.restrictedCoordinate_source hNε]
    apply inter_eq_left.mpr
    intro z hz
    exact hcapture (N.coordinate_map_mem
      ⟨hz.1, DeepHorn.neckInterval_subset N.epsilon_pos hNε hz.2⟩)
  have hfs : ContMDiffOn IC (𝓡 3) ∞ f (univ ×ˢ Ioo (-ε⁻¹) ε⁻¹) := by
    apply he.comp (N.coordinate_map_smooth.mono
      (prod_mono subset_rfl (DeepHorn.neckInterval_subset N.epsilon_pos hNε)))
    intro z hz
    exact hcapture (N.coordinate_map_mem
      ⟨hz.1, DeepHorn.neckInterval_subset N.epsilon_pos hNε hz.2⟩)
  have hfis : ContMDiffOn (𝓡 3) IC ∞ f.symm f.target := by
    apply N.coordinate_inverse_smooth.comp (hei.mono inter_subset_left)
    intro y hy
    exact hy.2.1
  have htarget : f.target = e '' N.region (-ε⁻¹) ε⁻¹ := by
    rw [← N.restrictedCoordinate_target (δ := ε)]
    ext y
    constructor
    · intro hy
      exact ⟨e.symm y, hy.2, e.right_inv hy.1⟩
    · rintro ⟨x, hx, rfl⟩
      have hxsource : x ∈ e.source := hcapture hx.1
      refine ⟨e.map_source hxsource, ?_⟩
      change e.symm (e x) ∈ (N.restrictedCoordinate (δ := ε)).target
      simpa only [e.left_inv hxsource] using hx
  have hcentral : f '' (univ ×ˢ ({0} : Set ℝ)) = e '' N.central_sphere := by
    rw [N.central_sphere_eq, image_image]
    rfl
  have hcenter : e N.center ∈ f '' (univ ×ˢ ({0} : Set ℝ)) := by
    rw [hcentral]
    exact mem_image_of_mem e N.center_on_central_sphere
  have hcentralSubset : f '' (univ ×ˢ ({0} : Set ℝ)) ⊆ f.target := by
    rintro _ ⟨z, hz, rfl⟩
    apply f.map_source
    rw [hsource]
    refine ⟨hz.1, ?_⟩
    have hz0 : z.2 = 0 := hz.2
    rw [hz0]
    exact ⟨neg_neg_of_pos (inv_pos.mpr hεpos), inv_pos.mpr hεpos⟩
  let Q := D.scalarCurvature (e N.center)
  let q := N.connection.scalarCurvature N.center
  let B₁ : RoundCylinderTwoTensor := fun z v w => Q * roundCylinderPullback h f z v w
  let B₀ : RoundCylinderTwoTensor := fun z v w => q * roundCylinderPullback g N.coordinate_map z v w
  have hpow : N.scale⁻¹ ^ 2 = q := by
    rw [N.scale_eq_scalar, neg_div, Real.rpow_neg N.scalar_center_pos.le, inv_inv,
      ← Real.rpow_natCast, ← Real.rpow_mul N.scalar_center_pos.le]
    norm_num [q]
  have hclose₀ : RoundCylinderClose δ 0 B₀ := by
    simpa only [B₀, q, hpow, hN] using N.metric_comparison.close
  have hclose : RoundCylinderClose ε 0 B₁ := by
    apply htolerance B₀ B₁ hclose₀ (roundCylinderTensorSmoothOn_smul_pullback h hfs Q)
    intro z hz j hj a b
    have hzold : z.2 ∈ Ioo (-N.epsilon⁻¹) N.epsilon⁻¹ :=
      DeepHorn.neckInterval_subset N.epsilon_pos hNε hz
    have hp := centeredCylinderMetric_scalar_pullback_germ h f Q z.1 z.2
      (isOpen_univ.prod isOpen_Ioo) ⟨mem_univ _, hz⟩ hfs
    have hp₀ := centeredCylinderMetric_scalar_pullback_germ g N.coordinate_map q z.1 z.2
      N.cylinderDomain_open ⟨mem_univ _, hzold⟩ N.coordinate_map_smooth
    have heq : (fun p : E => centeredCylinderMetric B₁ z.1 z.2 p -
        centeredCylinderMetric B₀ z.1 z.2 p) =ᶠ[𝓝 0] fun p =>
        Q • h.parametrizedCoefficients (e ∘ centeredNeckLift N z.1 z.2) p -
        q • g.parametrizedCoefficients (centeredNeckLift N z.1 z.2) p := hp.sub hp₀
    have hNf := centeredNeckLift_contMDiffAt N z.1 z.2 (zero_mem_centeredNeckDomain N hzold)
    have hes := he.contMDiffAt (e.open_source.mem_nhds
      (hcapture (N.coordinate_map_mem ⟨mem_univ _, hzold⟩)))
    have hes' : ContMDiffAt (𝓡 3) (𝓡 3) ∞ e (centeredNeckLift N z.1 z.2 0) := by
      simpa only [centeredNeckLift_zero] using hes
    have hs₁ := h.contDiffAt_parametrizedCoefficients (hes'.comp (0 : E) hNf)
    have hs₀ := g.contDiffAt_parametrizedCoefficients hNf
    have hs : ContDiffAt ℝ ∞ (fun p : E => centeredCylinderMetric B₁ z.1 z.2 p -
        centeredCylinderMetric B₀ z.1 z.2 p) 0 :=
      ((hs₁.const_smul Q).sub (hs₀.const_smul q)).congr_of_eventuallyEq heq
    have hjets : ∀ k ≤ ⌊ε⁻¹⌋₊, ‖iteratedFDeriv ℝ k (fun p : E =>
        centeredCylinderMetric B₁ z.1 z.2 p - centeredCylinderMetric B₀ z.1 z.2 p) 0‖ ≤ η / C := by
      intro k hk
      rw [(heq.iteratedFDeriv (𝕜 := ℝ) k).eq_of_nhds]
      exact hjet z hz k hk
    have hb := hcoeff B₁ B₀ z.1 z.2 hs (η / C) (div_pos hη hC).le hjets j hj a b
    simpa only [mul_div_cancel₀ _ hC.ne'] using hb
  have hpowQ : (Q ^ (-1 / 2 : ℝ))⁻¹ ^ 2 = Q := by
    rw [neg_div, Real.rpow_neg hR.le, inv_inv, ← Real.rpow_natCast, ← Real.rpow_mul hR.le]
    norm_num [Q]
  let N' : EpsilonNeck h := {
    epsilon := ε
    epsilon_pos := hεpos
    epsilon_lt_half := hε
    scale := Q ^ (-1 / 2 : ℝ)
    scale_pos := Real.rpow_pos_of_pos hR _
    center := e N.center
    connection := D
    scalar_center_pos := hR
    scale_eq_scalar := rfl
    carrier := f.target
    carrier_open := f.open_target
    coordinate := neckDomainCoordinates f hsource
    coordinate_map := f
    coordinate_map_eq := fun _ => rfl
    coordinate_map_smooth := hfs
    coordinate_inverse := f.symm
    coordinate_inverse_mem := fun _ hx => neckDomainCoordinates_inverse_mem f hsource hx
    coordinate_inverse_left := neckDomainCoordinates_inverse_left f hsource
    coordinate_inverse_right := neckDomainCoordinates_inverse_right f hsource
    coordinate_inverse_smooth := hfis
    central_sphere := f '' (univ ×ˢ ({0} : Set ℝ))
    central_sphere_eq := rfl
    center_on_central_sphere := hcenter
    central_sphere_subset := hcentralSubset
    metric_comparison := ⟨by simpa only [hpowQ] using hclose⟩ }
  exact ⟨N', rfl, rfl, rfl, hcentral, htarget⟩

end PoincareMT.EpsilonNeck
