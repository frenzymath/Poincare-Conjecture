import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.Cylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Limit

/-! # Actual expanding-time ordinary sources with fixed-window bounds -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} (hA : ∀ i, 0 < A i) (htau : ∀ j, 0 < tau j)
  (e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i))

def horizonSourceFlow (i : ℕ) : RicciFlow 3
    (componentCarrier S (idx i) (hA i)).shrink.carrier (Icc (-tau i) 0) :=
  (e i i le_rfl).smallFlow (hA i) (htau i)

/-- A longer chosen cylinder agrees exactly with each of its separately
controlled earlier windows. -/
theorem horizonSourceFlow_metric_eq
    (htmono : Monotone tau) (i j : ℕ) (hji : j ≤ i)
    (s : ℝ) (hs : s ∈ Icc (-tau j) 0) :
    (horizonSourceFlow hA htau e i).metric s =
      ((e i j hji).smallFlow (hA i) (htau j)).metric s :=
  (e i i le_rfl).smallFlow_metric_eq_on_common_time (e i j hji) (hA i) (htau i)
    (htau j) s ⟨(neg_le_neg (htmono hji)).trans hs.1, hs.2⟩ hs

/-- Curvature on every fixed slab is bounded by its own fixed constant,
independently of the selected source's larger horizon. -/
theorem horizonSourceFlow_curvature_bound
    (htmono : Monotone tau) (i j : ℕ) (hji : j ≤ i)
    (s : ℝ) (hs : s ∈ Icc (-tau j) 0)
    (x : (componentCarrier S (idx i) (hA i)).shrink.carrier) :
    |((horizonSourceFlow hA htau e i).connection s).curvatureTensorNorm x| ≤ B j := by
  rw [((horizonSourceFlow hA htau e i).connection s).curvatureTensorNorm_eq_of_metric_eq
    (((e i j hji).smallFlow (hA i) (htau j)).connection s)
    (horizonSourceFlow_metric_eq hA htau e htmono i j hji s hs) x]
  exact (e i j hji).smallFlow_curvature_bound (hA i) (htau j) s hs x

/-- The terminal source metric is fixed across every horizon choice. -/
theorem horizonSourceFlow_terminal_metric (i : ℕ) :
    (horizonSourceFlow hA htau e i).metric 0 =
      ((e i 0 (Nat.zero_le i)).smallFlow (hA i) (htau 0)).metric 0 :=
  (e i i le_rfl).smallFlow_metric_eq_on_common_time (e i 0 (Nat.zero_le i)) (hA i)
    (htau i) (htau 0) 0 ⟨by linarith [htau i], le_rfl⟩ ⟨by linarith [htau 0], le_rfl⟩

end PoincareMT.ControlledBlowupCompactness
