import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Charts
import PoincareLib.Geometry.Manifold.InverseFunction.LocalDiffeomorph
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Slabs.Embedding
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Curvature.TerminalJets

/-! # Retained limit charts into the original controlled source balls -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A : ℝ}
  (hA : 0 < A) {U : Set (EuclideanSpace ℝ (Fin 3))}
  (phi : EuclideanSpace ℝ (Fin 3) → ((S.flow k).slice (S.base k).1).carrier)
  (hball : ∀ z ∈ U, phi z ∈ S.baseBall k A)

def retainedBallParametrization (z : EuclideanSpace ℝ (Fin 3)) : sourceBall S k A := by
  classical
  exact if hz : z ∈ U then ⟨phi z, hball z hz⟩ else ⟨(S.base k).2, base_mem_sourceBall hA⟩

theorem retainedBallParametrization_val {z : EuclideanSpace ℝ (Fin 3)} (hz : z ∈ U) :
    (retainedBallParametrization hA phi hball z).val = phi z := by
  simp only [retainedBallParametrization, dif_pos hz]

theorem retainedBallParametrization_isLocalDiffeomorphOn
    (hU : IsOpen U) (hphi : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ phi U) :
    IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (retainedBallParametrization hA phi hball) U := by
  intro x
  let f := retainedBallParametrization hA phi hball
  have hi := Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 3) (sourceBall S k A) (f x)
  have hval : (f x).val = phi x := retainedBallParametrization_val hA phi hball x.property
  have hinv : IsLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞ hi.localInverse (phi x) := by
    rw [← hval]
    exact hi.localInverse_isLocalDiffeomorphAt
  apply ((hphi x).comp (𝓡 3) _ hinv).congr_of_eventuallyEq
  have hright : ∀ᶠ y in 𝓝 (phi x), (hi.localInverse y).val = y := by
    rw [← hval]
    exact hi.localInverse_eventuallyEq_right
  filter_upwards [hU.mem_nhds x.property,
    (hphi x).contMDiffAt.continuousAt.tendsto.eventually hright] with y hy hyeq
  exact Subtype.ext ((retainedBallParametrization_val hA phi hball hy).trans hyeq.symm)

def retainedBallPartialChart (hU : IsOpen U)
    (hphi : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ phi U) (hinj : InjOn phi U) :
    PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3)) (sourceBall S k A) ∞ :=
  AncientCompactness.partialDiffeomorphOfInjOn hU (retainedBallParametrization hA phi hball)
    (by
      intro x hx y hy hxy
      apply hinj hx hy
      simpa only [retainedBallParametrization_val hA phi hball hx,
        retainedBallParametrization_val hA phi hball hy] using congrArg Subtype.val hxy)
    (retainedBallParametrization_isLocalDiffeomorphOn hA phi hball hU hphi)

theorem retainedBallParametrization_terminal_coefficients
    (hU : IsOpen U) (hphi : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ phi U)
    {T B eta : ℝ} (cyl : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    {z : EuclideanSpace ℝ (Fin 3)} (hz : z ∈ U) :
    ((cyl.ordinaryFlow hT).metric 0).pullbackCoefficients
        (retainedBallParametrization hA phi hball) z =
      (S.normalizedTerminalMetric k).pullbackCoefficients phi z := by
  let f := retainedBallParametrization hA phi hball
  have hf := retainedBallParametrization_isLocalDiffeomorphOn hA phi hball hU hphi ⟨z, hz⟩
  have hfeq : ((Subtype.val : sourceBall S k A → _) ∘ f) =ᶠ[𝓝 z] phi :=
    Filter.mem_of_superset (hU.mem_nhds hz)
      (fun x hx => retainedBallParametrization_val hA phi hball hx)
  have hdf := hfeq.mfderiv_eq (I := 𝓡 3) (I' := 𝓡 3)
  rw [mfderiv_comp z ((contMDiff_subtype_val (n := ∞)).mdifferentiable (by simp) (f z))
    (hf.mdifferentiableAt (by simp))] at hdf
  ext v w
  change ((cyl.ordinaryFlow hT).metric 0).inner (f z)
    (mfderiv (𝓡 3) (𝓡 3) f z v) (mfderiv (𝓡 3) (𝓡 3) f z w) = _
  rw [cyl.ordinaryFlow_terminal_inner hT]
  change (S.normalizedTerminalMetric k).inner (f z).val
    (((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) (f z)).comp
      (mfderiv (𝓡 3) (𝓡 3) f z)) v)
    (((mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) (f z)).comp
      (mfderiv (𝓡 3) (𝓡 3) f z)) w) = _
  rw [hdf, retainedBallParametrization_val hA phi hball hz]
  rfl

end PoincareMT.ControlledBlowupCylinder

namespace PoincareMT.GeneralizedBlowupConvergence

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_captured_source_partial_charts
    {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
    (G : GeneralizedBlowupConvergence S J.domain) (q : G.limit.carrier.carrier) :
    ∃ rho R : ℝ, 0 < rho ∧ 0 < R ∧
      closedBall (extChartAt (𝓡 3) q q) (2 * rho) ⊆ (extChartAt (𝓡 3) q).target ∧
      ∀ A : ℝ, R ≤ A → ∀ᶠ k in atTop,
        ∃ Phi : PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
          (sourceBall S (G.subsequence k) A) ∞,
          Phi.source = ball (extChartAt (𝓡 3) q q) (2 * rho) ∧
          (∀ z ∈ Phi.source, (Phi z).val = G.zeroSliceEmbedding k ((extChartAt (𝓡 3) q).symm z) ∧
            (Phi z).val ∈ S.baseBall (G.subsequence k) R) ∧
          ∀ T B eta (cyl : ControlledBlowupCylinder S (G.subsequence k) A T B eta)
            (hT : 0 < T), ∀ z ∈ Phi.source,
            ((cyl.ordinaryFlow hT).metric 0).pullbackCoefficients Phi z =
              (G.zeroSourceMetric k).pullbackCoefficients
                (G.zeroSliceEmbedding k ∘ (extChartAt (𝓡 3) q).symm) z := by
  let c := extChartAt (𝓡 3) q
  obtain ⟨r, hr, hrc⟩ := Metric.mem_nhds_iff.mp
    ((isOpen_extChartAt_target (I := 𝓡 3) q).mem_nhds (mem_extChartAt_target q))
  let rho := r / 4
  have hrho : 0 < rho := by dsimp [rho]; positivity
  let K := closedBall (c q) (2 * rho)
  let U := ball (c q) (2 * rho)
  have hKc : K ⊆ c.target :=
    (closedBall_subset_ball (by dsimp [rho]; linarith : 2 * rho < r)).trans hrc
  have hcompact : IsCompact (c.symm '' K) :=
    (isCompact_closedBall _ _).image_of_continuousOn ((continuousOn_extChartAt_symm q).mono hKc)
  obtain ⟨R, hR, himage⟩ := G.exists_eventually_image_compact_subset_baseBall hcompact
  refine ⟨rho, R, hrho, hR, hKc, fun A hRA => ?_⟩
  have hA : 0 < A := hR.trans_le hRA
  filter_upwards [himage] with k hk
  have hUE : ∀ z ∈ U, c.symm z ∈ G.exhaustion.space k := by
    intro z hz
    simpa only [G.zeroSliceEmbedding_source] using hk.1 (mem_image_of_mem _ (ball_subset_closedBall hz))
  let phi := G.zeroSliceEmbedding k ∘ c.symm
  have hphi : IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ phi U := by
    apply Poincare.isLocalDiffeomorphOn_of_contMDiffOn_bijective_mfderiv isOpen_ball
    · exact (G.zeroSliceEmbedding_smooth k).comp
        ((contMDiffOn_extChartAt_symm q).mono (ball_subset_closedBall.trans hKc)) hUE
    · intro z hz
      have hc := ((contMDiffOn_extChartAt_symm (n := ∞) q) z
        (hKc (ball_subset_closedBall hz))).contMDiffAt
          ((isOpen_extChartAt_target q).mem_nhds (hKc (ball_subset_closedBall hz)))
      have he := (G.zeroSliceEmbedding_smooth k).contMDiffAt
        ((G.exhaustion.space_open k).mem_nhds (hUE z hz))
      have hi : (mfderiv (𝓡 3) (𝓡 3) c.symm z).IsInvertible := by
        simpa only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] using
          isInvertible_mfderivWithin_extChartAt_symm (I := 𝓡 3) (hKc (ball_subset_closedBall hz))
      rw [mfderiv_comp z (he.mdifferentiableAt (by simp)) (hc.mdifferentiableAt (by simp))]
      exact (G.zeroSliceEmbedding_mfderiv_bijective k (hUE z hz)).comp hi.bijective
  have hinj : InjOn phi U := by
    intro z hz w hw hzw
    apply c.symm.injOn (hKc (ball_subset_closedBall hz)) (hKc (ball_subset_closedBall hw))
    exact (G.zeroSliceEmbedding k).injOn (by simpa using hUE z hz) (by simpa using hUE w hw) hzw
  have hballR : ∀ z ∈ U, phi z ∈ S.baseBall (G.subsequence k) R :=
    fun z hz => hk.2 (mem_image_of_mem _ (mem_image_of_mem _ (ball_subset_closedBall hz)))
  have hballA : ∀ z ∈ U, phi z ∈ S.baseBall (G.subsequence k) A := by
    intro z hz
    have hh := hballR z hz
    rw [← S.normalizedTerminalMetric_ball] at hh ⊢
    exact hh.trans_le (ENNReal.ofReal_le_ofReal hRA)
  let Phi := retainedBallPartialChart hA phi hballA isOpen_ball hphi hinj
  refine ⟨Phi, rfl, ?_, ?_⟩
  · intro z hz
    have heq := retainedBallParametrization_val hA phi hballA hz
    exact ⟨heq, heq ▸ hballR z hz⟩
  · intro T B eta cyl hT z hz
    exact retainedBallParametrization_terminal_coefficients hA phi hballA isOpen_ball hphi cyl hT hz

end PoincareMT.GeneralizedBlowupConvergence
