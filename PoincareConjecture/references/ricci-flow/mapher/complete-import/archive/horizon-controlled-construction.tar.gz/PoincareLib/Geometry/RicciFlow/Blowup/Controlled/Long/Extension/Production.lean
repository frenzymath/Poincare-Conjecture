import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.ClosedLimit
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.Necks.Cover
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Common.Cylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.MetricTransport
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Retained.CompactBound
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.ScalarBound

/-!
# Common backward extensions from the frozen predecessors

The actual old-time neck cover gives uniform scalar bounds on compact sets.
Local source extensions construct a complete closed boundary. Captured necks
pass to that boundary, whose global scalar bound fixes one source extension
duration before its radius and pinching tolerance are chosen.

Reference: Morgan--Tian, Proposition 11.10 and Corollary 11.16,
published edition, pp. 272--278.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.M30ControlledBlowupPredecessors

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem exists_finite_extension_threshold (P : M30ControlledBlowupPredecessors.{u}) :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 400 ∧
      ∀ (S : GeneralizedBlowupSequence.{u}) (epsilon C kappa r₀ mu : ℝ) (T₀ : ℝ≥0∞),
        epsilon ≤ epsilon₀ → ∀ H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀,
        ∀ T : ℝ, 0 < T → ∀ G : GeneralizedBlowupConvergence S (Ioc (-T) 0),
          ENNReal.ofReal T < T₀ →
          ∃ V B : ℝ, T < V ∧ ENNReal.ofReal V < T₀ ∧ 0 < B ∧
            ∀ A : ℝ, 0 < A → ∀ eta : ℝ, 0 < eta → ∀ᶠ k in atTop,
              Nonempty (ControlledBlowupCylinder S (G.subsequence k) A V B eta) := by
  classical
  obtain ⟨epsilonK, hKpos, hKsmall, hcompact⟩ := P.exists_uniform_compact_scalar_bound_threshold
  obtain ⟨epsilonB, hBpos, hBsmall, hglobal⟩ :=
    ControlledTerminal.exists_universal_local_backward_scalar_bound_threshold_without_normalization.{u, u}
  let epsilon₀ := min epsilonK (min SingularRegularLimit.RoundComparison.roundComparisonThreshold
    (min (1 / 1000) (epsilonB / 3)))
  have hpos : 0 < epsilon₀ := lt_min hKpos
    (lt_min SingularRegularLimit.RoundComparison.roundComparisonThreshold_pos
      (lt_min (by norm_num) (by positivity)))
  have hsmall : epsilon₀ ≤ 1 / 400 := (min_le_left _ _).trans hKsmall
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro S epsilon C kappa r₀ mu T₀ hepsilon H T hT G horizon
  have heK : epsilon ≤ epsilonK := hepsilon.trans (min_le_left _ _)
  have heround : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold :=
    hepsilon.trans ((min_le_right _ _).trans (min_le_left _ _))
  have henumeric : epsilon ≤ 1 / 1000 := hepsilon.trans
    ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _)))
  have heB : 3 * epsilon ≤ epsilonB := by
    have hh := hepsilon.trans
      ((min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _)))
    linarith
  have hcompact' : ∀ K : Set G.limit.carrier.carrier, IsCompact K →
      ∃ B : ℝ, ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
        (G.limit.flow.connection t).scalarCurvature x ≤ B := by
    intro K hK
    obtain ⟨B, _, hb⟩ := hcompact S epsilon C kappa r₀ mu heK
      H.toM30CommonBlowupControls T hT G K hK
    exact ⟨B, hb⟩
  obtain ⟨F, hmetric, hcomplete, hnonnegative, hlocal⟩ :=
    G.exists_complete_closed_extension_of_compact_scalar_bounds hT P.m04 H horizon hcompact'
  let : ConnectedSpace G.limit.carrier.carrier := G.limit.connectedSpace
  have hleft : -T ∈ Icc (-T) (0 : ℝ) := ⟨le_rfl, by linarith⟩
  have hboundary : ∃ B : ℝ, ∀ x, (F.connection (-T)).scalarCurvature x ≤ B := by
    by_cases hNC : IsCompact (univ : Set G.limit.carrier.carrier)
    · obtain ⟨B, _, hb⟩ := F.exists_scalar_upper_bound_on_compact P.m04 isCompact_Icc hNC
      exact ⟨B, fun x => hb (-T) hleft x (mem_univ x)⟩
    · have hcover := ControlledBlowupBoundary.neck_cover_at_left_endpoint
        P.m04 hT F (hcomplete (-T) hleft) hnonnegative
        (delta := 2 * epsilon) (epsilon := 3 * epsilon) (C := 4 * max C 1) (cutoff := 4)
        (by positivity [H.epsilon_pos]) (by linarith) (by linarith [H.epsilon_pos])
        (heB.trans_lt hBsmall) (by positivity) (by norm_num) (by
          intro t ht x hx
          obtain ⟨N, he, _, hd, hr⟩ := H.toM30CommonBlowupControls.retained_neck_control_on_closed_extension
            G F hmetric hNC (by linarith) heround
            (epsilon' := 2 * epsilon) (by linarith [H.epsilon_pos]) (by linarith)
            t ht x hx
          exact ⟨N, he, hd, hr⟩)
      obtain ⟨B, _, hb⟩ := hglobal G.limit.carrier.carrier P.m04 (F.metric (-T))
        (F.connection (-T)) (hcomplete (-T) hleft) (hnonnegative (-T) hleft) hlocal
        (3 * epsilon) (2 * (4 * max C 1)) 4 (by positivity [H.epsilon_pos]) heB
        (by positivity) (by
          intro x
          rcases hcover x with hx | ⟨N, he, _, hr⟩
          · exact Or.inl hx
          · exact Or.inr ⟨N, he, hr⟩)
      exact ⟨B, hb⟩
  obtain ⟨B, hb⟩ := hboundary
  exact G.exists_common_controlled_source_extension_of_closed_boundary_bound hT P.m04 H horizon
    F hmetric hb

end PoincareMT.M30ControlledBlowupPredecessors
