import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.FrameLowerBound
import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.CurvatureControl.Cylinders.CurvatureLimit

/-!
# Nonnegative curvature from vanishing pinching errors

Actual second metric jets pass the curvature quadratic form to the limit.
The finite-frame lower bound makes a vanishing negative-curvature error
sufficient; exact positivity of the source metrics is unnecessary.
Source: Morgan--Tian, Theorem 11.1, pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology BigOperators

namespace PoincareMT.LeviCivitaData

attribute [local instance] normedAddCommGroupTangentSpaceVectorSpace
  normedSpaceTangentSpaceVectorSpace

theorem nonnegativeCurvatureOperator_of_scalar_metric_jets_of_negativePart
    {α : Type*} {l : Filter α} [l.NeBot]
    {gseq : α → RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3))}
    {g : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3))}
    (Dseq : ∀ a, LeviCivitaData (gseq a)) (D : LeviCivitaData g)
    (x : EuclideanSpace ℝ (Fin 3))
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (b : Module.Basis ι ℝ (EuclideanSpace ℝ (Fin 3)))
    (h : ∀ r : ℕ, r ≤ 2 → ∀ a c : ι,
      Tendsto (fun i => iteratedFDeriv ℝ r
        (fun y => (gseq i).inner y (b a) (b c)) x) l
        (𝓝 (iteratedFDeriv ℝ r (fun y => g.inner y (b a) (b c)) x)))
    {eta : α → ℝ} (heta : Tendsto eta l (𝓝 0))
    (hneg : ∀ᶠ i in l, (Dseq i).negativeCurvaturePart x ≤ eta i) :
    D.NonnegativeCurvatureOperator x := by
  classical
  obtain ⟨hzero, hone, htwo⟩ :=
    RiemannianMetric.tendsto_euclideanCoefficients_of_scalar_jets x b h
  intro A _
  let e := g.orthonormalBasis x
  let Q (g' : RiemannianMetric 3 (EuclideanSpace ℝ (Fin 3))) :=
    ∑ a, ∑ b, ∑ c, ∑ d, A a b * A c d *
      (g'.inner x (e a) (e c) * g'.inner x (e b) (e d) -
        g'.inner x (e a) (e d) * g'.inner x (e b) (e c))
  have hinner (u v : EuclideanSpace ℝ (Fin 3)) :
      Tendsto (fun i => (gseq i).inner x u v) l (𝓝 (g.inner x u v)) := by
    have hev : Continuous (fun q : EuclideanSpace ℝ (Fin 3) →L[ℝ]
        EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ => q u v) := by fun_prop
    exact hev.continuousAt.tendsto.comp hzero
  have hQ : Tendsto (fun i => Q (gseq i)) l (𝓝 (Q g)) := by
    apply tendsto_finsetSum
    intro a _
    apply tendsto_finsetSum
    intro b _
    apply tendsto_finsetSum
    intro c _
    apply tendsto_finsetSum
    intro d _
    exact tendsto_const_nhds.mul (((hinner (e a) (e c)).mul (hinner (e b) (e d))).sub
      ((hinner (e a) (e d)).mul (hinner (e b) (e c))))
  have hlower : Tendsto (fun i => -(eta i) * Q (gseq i)) l (𝓝 0) := by
    simpa only [neg_zero, zero_mul] using heta.neg.mul hQ
  have hquad : Tendsto (fun i => ∑ a, ∑ b, ∑ c, ∑ d,
      A a b * A c d * (Dseq i).curvatureTensor x (e a) (e b) (e c) (e d)) l
      (𝓝 (D.curvatureOperatorQuadratic x A)) := by
    unfold curvatureOperatorQuadratic
    apply tendsto_finsetSum
    intro a _
    apply tendsto_finsetSum
    intro b _
    apply tendsto_finsetSum
    intro c _
    apply tendsto_finsetSum
    intro d _
    exact tendsto_const_nhds.mul (tendsto_curvatureTensor_of_metric_jets Dseq D x
      (e a) (e b) (e c) (e d) hzero hone htwo)
  apply le_of_tendsto_of_tendsto hlower hquad
  filter_upwards [hneg] with i hi
  exact (Dseq i).curvature_quadratic_lower_bound_of_negativePart x hi e A

end PoincareMT.LeviCivitaData
