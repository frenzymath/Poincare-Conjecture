import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Parallel
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Positive
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.CoverBound
import PoincareLib.Geometry.Riemannian.Curvature.IntrinsicCalculus

/-!
# A common terminal scalar bound from local backward flows

Captured canonical neighborhoods supply an actual small neck whose central
scalar controls the chosen point, or the point already lies below a fixed
cutoff. A single universal accuracy works for both the positive sectional
branch and the branch with a locally parallel Ricci-null line.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.ControlledTerminal

open RicciFlow.Splitting

theorem exists_universal_local_backward_scalar_bound_threshold_without_normalization :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ < 1 / 2 ∧
      ∀ (M : Type v) [TopologicalSpace M] [T2Space M] [T3Space M] [ConnectedSpace M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
        [MeasurableSpace M] [BorelSpace M],
      ∀ (_hC : RicciFlowCurvatureTheory.{u}) (g : RiemannianMetric 3 M)
        (D : LeviCivitaData g),
        MetricComplete g → (∀ x, D.NonnegativeCurvatureOperator x) →
        (∀ q : M, ∃ rho T : ℝ, 0 < rho ∧ 0 < T ∧
          ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target ∧
          ∃ F : RicciFlow 3
            (⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩ : Opens _) (Icc (-T) 0),
            (∀ t ∈ Icc (-T) 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x) ∧
            ∀ x v w, (F.metric 0).inner x v w =
              g.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w) →
      ∀ epsilon C cutoff : ℝ, 0 < epsilon → epsilon ≤ epsilon₀ → 0 ≤ C →
        (∀ x : M, D.scalarCurvature x ≤ cutoff ∨
          ∃ N : EpsilonNeck g, N.epsilon = epsilon ∧
            D.scalarCurvature x ≤ C * D.scalarCurvature N.center) →
        ∃ B : ℝ, 0 < B ∧ ∀ x : M, D.scalarCurvature x ≤ B := by
  obtain ⟨epsilonP, hP, hhalf, hscale⟩ :=
    RiemannianMetric.exists_universal_neck_scale_lower_bound.{v}
  obtain ⟨epsilonN, hN, _, hnull⟩ := exists_local_null_neck_scalar_bound_threshold.{v}
  refine ⟨min epsilonP epsilonN, lt_min hP hN,
    (min_le_left _ _).trans_lt hhalf, ?_⟩
  intro M _ _ _ _ _ _ _ _ hC g D hcomplete hoperator hflow
    epsilon C cutoff hepsilon hsmall hCnonneg hcover
  by_cases hnonpos : ∀ x : M, D.scalarCurvature x ≤ 0
  · exact ⟨1, zero_lt_one, fun x => (hnonpos x).trans zero_le_one⟩
  push Not at hnonpos
  obtain ⟨p, hp⟩ := hnonpos
  have hnonflat : D.curvatureTensorNorm p ≠ 0 := by
    intro hz
    have hbound := D.scalarCurvature_le_curvatureTensorNorm_sharp p
    rw [hz] at hbound
    norm_num at hbound
    exact (not_lt_of_ge hbound) hp
  have hD := D.intrinsicCurvatureTensorCalculus
  rcases strictlyPositive_or_ricciNullity_one_of_nonflat_local_backward_flows hflow hC D hD
      hoperator p hnonflat with hpositive | hdim
  · obtain ⟨rho, hrho, hneck⟩ := hscale M g D hcomplete hpositive epsilon hepsilon
      (hsmall.trans (min_le_left _ _))
    refine ⟨max 1 (max cutoff (C * (1 / rho ^ 2))),
      lt_of_lt_of_le zero_lt_one (le_max_left _ _), ?_⟩
    intro x
    rcases hcover x with hx | ⟨N, heq, hx⟩
    · exact hx.trans ((le_max_left _ _).trans (le_max_right _ _))
    · have hcenter := N.scalar_center_le_of_scale_lower D hrho (hneck N heq)
      exact (hx.trans (mul_le_mul_of_nonneg_left hcenter hCnonneg)).trans
        ((le_max_right _ _).trans (le_max_right _ _))
  · by_cases hhigh : ∃ x : M, cutoff < D.scalarCurvature x
    · obtain ⟨x, hx⟩ := hhigh
      obtain ⟨N, heq, _⟩ := (hcover x).resolve_left (not_le.mpr hx)
      exact hnull M g D hcomplete hdim
        (exists_local_parallel_unit_null_section_of_local_backward_flows hflow hC D hD hdim)
        N (heq.trans_le (hsmall.trans (min_le_right _ _)))
    · refine ⟨max 1 cutoff, lt_of_lt_of_le zero_lt_one (le_max_left _ _), fun x => ?_⟩
      exact (le_of_not_gt fun hx => hhigh ⟨x, hx⟩).trans (le_max_right _ _)

/-- The normalized terminal interface retained for the short-branch producer. -/
theorem exists_universal_local_backward_scalar_bound_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ < 1 / 2 ∧
      ∀ (M : Type v) [TopologicalSpace M] [T2Space M] [T3Space M] [ConnectedSpace M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
        [MeasurableSpace M] [BorelSpace M],
      ∀ (_hC : RicciFlowCurvatureTheory.{u}) (g : RiemannianMetric 3 M)
        (D : LeviCivitaData g),
        MetricComplete g → (∀ x, D.NonnegativeCurvatureOperator x) →
      ∀ p : M, D.scalarCurvature p = 1 →
        (∀ q : M, ∃ rho T : ℝ, 0 < rho ∧ 0 < T ∧
          ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target ∧
          ∃ F : RicciFlow 3
            (⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩ : Opens _) (Icc (-T) 0),
            (∀ t ∈ Icc (-T) 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x) ∧
            ∀ x v w, (F.metric 0).inner x v w =
              g.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w) →
      ∀ epsilon C cutoff : ℝ, 0 < epsilon → epsilon ≤ epsilon₀ → 0 ≤ C →
        (∀ x : M, D.scalarCurvature x ≤ cutoff ∨
          ∃ N : EpsilonNeck g, N.epsilon = epsilon ∧
            D.scalarCurvature x ≤ C * D.scalarCurvature N.center) →
        ∃ B : ℝ, 0 < B ∧ ∀ x : M, D.scalarCurvature x ≤ B := by
  obtain ⟨epsilon₀, hpos, hsmall, hbound⟩ :=
    exists_universal_local_backward_scalar_bound_threshold_without_normalization.{u, v}
  exact ⟨epsilon₀, hpos, hsmall, fun M _ _ _ _ _ _ _ _ hC g D hc ho _ _ hf =>
    hbound M hC g D hc ho hf⟩

end PoincareMT.ControlledTerminal
