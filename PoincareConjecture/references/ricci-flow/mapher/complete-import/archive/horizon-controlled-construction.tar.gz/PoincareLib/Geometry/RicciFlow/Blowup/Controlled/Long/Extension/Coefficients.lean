import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.SliceMaps
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Curvature.SpacetimeJets
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.Worldlines.Uniqueness

/-! # Exact retained coefficients throughout overlapping source cylinders -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space

theorem controlledCylinder_chart_coefficient_eq
    {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
    (G : GeneralizedBlowupConvergence S J.domain) (k : ℕ)
    {A V B eta : ℝ} (cyl : ControlledBlowupCylinder S (G.subsequence k) A V B eta)
    (hV : 0 < V) (q : G.limit.carrier.carrier)
    (Phi : PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
      (sourceBall S (G.subsequence k) A) ∞)
    (hPhi : ∀ z ∈ Phi.source,
      (Phi z).val = G.zeroSliceEmbedding k ((extChartAt (𝓡 3) q).symm z))
    {t : ℝ} (htc : t ∈ Icc (-V) 0) (htg : t ∈ Icc (-G.exhaustion.time k) 0)
    {z : EuclideanSpace ℝ (Fin 3)} (hz : z ∈ Phi.source)
    (hzc : z ∈ (extChartAt (𝓡 3) q).target)
    (hze : (extChartAt (𝓡 3) q).symm z ∈ G.exhaustion.space k) (a b : Fin 3) :
    (((cyl.ordinaryFlow hV).metric t).pullbackCoefficients Phi z)
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b) =
      blowupPullbackCoefficient (G.embedding k) q a b (t, z) := by
  let c := extChartAt (𝓡 3) q
  let W := Phi.source ∩ (c.target ∩ c.symm ⁻¹' G.exhaustion.space k)
  have hW : IsOpen W := Phi.open_source.inter
    ((continuousOn_extChartAt_symm q).isOpen_inter_preimage
      (isOpen_extChartAt_target q) (G.exhaustion.space_open k))
  have hzW : z ∈ W := ⟨hz, hzc, hze⟩
  have heq : cyl.sliceMap t htc ∘ Phi =ᶠ[𝓝 z]
      (G.embedding k).forward t htg ∘ c.symm := by
    filter_upwards [hW.mem_nhds hzW] with w hw
    have hzero : (0 : ℝ) ∈ Icc (-V) 0 := ⟨by linarith, le_rfl⟩
    have hstart : (G.embedding k).pointMap 0 (G.zero_mem_cylinder k) (c.symm w) =
        cyl.embedding.pointMap 0 hzero (Phi w).val := by
      rw [cyl.zero_identity hzero _ (Phi w).property,
        (G.embedding k).zeroSliceHomeomorph_pointMap (G.exhaustion.space_open k), hPhi w hw.1]
      rfl
    have hsame := (G.embedding k).pointMap_eq_on_overlap cyl.embedding
      ordConnected_Icc ordConnected_Icc hw.2.2 (Phi w).property
      (G.zero_mem_cylinder k) hzero hstart t htg htc
    exact (eq_of_heq (Sigma.mk.inj_iff.mp hsame).2).symm
  have hcoeff : ((cyl.ordinaryFlow hV).metric t).pullbackCoefficients Phi z =
      (G.normalizedSourceMetric k t).pullbackCoefficients
        ((G.embedding k).forward t htg ∘ c.symm) z := by
    rw [← cyl.sliceMap_pullback_coefficients hV t htc Phi
      ((Phi.isLocalDiffeomorphAt (𝓡 3) (𝓡 3) ∞ hz).mdifferentiableAt (by simp))]
    ext v w
    change (G.normalizedSourceMetric k t).inner _
      (mfderiv (𝓡 3) (𝓡 3) (cyl.sliceMap t htc ∘ Phi) z v)
      (mfderiv (𝓡 3) (𝓡 3) (cyl.sliceMap t htc ∘ Phi) z w) = _
    rw [heq.mfderiv_eq, heq.self_of_nhds]
    rfl
  rw [hcoeff]
  exact G.normalizedSourceMetric_chart_coefficient_eq q k t htg hzc hze a b

theorem controlledCylinder_chart_entry_tendsto
    {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
    (G : GeneralizedBlowupConvergence S J.domain)
    {sigma : ℕ → ℕ} (hsigma : Tendsto sigma atTop atTop)
    {A V B : ℝ} {eta : ℕ → ℝ}
    (cyl : ∀ k, ControlledBlowupCylinder S (G.subsequence (sigma k)) A V B (eta k))
    (hV : 0 < V) (q : G.limit.carrier.carrier)
    (Phi : ∀ k, PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
      (sourceBall S (G.subsequence (sigma k)) A) ∞)
    (hPhi : ∀ k z, z ∈ (Phi k).source →
      (Phi k z).val = G.zeroSliceEmbedding (sigma k) ((extChartAt (𝓡 3) q).symm z))
    {t : ℝ} (ht : t ∈ J.domain) (htV : t ∈ Icc (-V) 0)
    {z : EuclideanSpace ℝ (Fin 3)} (hz : ∀ k, z ∈ (Phi k).source)
    (hzc : z ∈ (extChartAt (𝓡 3) q).target) (a b : Fin 3) :
    Tendsto (fun k => (((cyl k).ordinaryFlow hV).metric t).pullbackCoefficients (Phi k) z
      (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))
      atTop (𝓝 ((G.limit.flow.metric t).pullbackCoefficients (extChartAt (𝓡 3) q).symm z
        (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))) := by
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset
    (isCompact_singleton : IsCompact {(extChartAt (𝓡 3) q).symm z})
  have hdom : {(t, z)} ⊆ {p | p ∈ blowupMetricChartDomain G.limit q ∧
      (extChartAt (𝓡 3) q).symm p.2 ∈ G.exhaustion.space j} := by
    rintro p rfl
    exact ⟨⟨ht, hzc⟩, hj (mem_singleton _)⟩
  apply Metric.tendsto_nhds.mpr
  intro delta hdelta
  obtain ⟨N, hjN, hN⟩ := G.pullback_metric_CInfinity q j 0 {(t, z)} isCompact_singleton
    hdom delta hdelta
  filter_upwards [hsigma.eventually_ge_atTop N] with k hk
  have htime := (hN (sigma k) hk).1 (mem_singleton (t, z))
  have hze := G.exhaustion.space_increasing (hjN.trans hk) (hj (mem_singleton _))
  rw [G.controlledCylinder_chart_coefficient_eq (sigma k) (cyl k) hV q (Phi k)
    (hPhi k) htV htime.1 (hz k) hzc hze a b]
  have h := (hN (sigma k) hk).2 a b (t, z) (mem_singleton _)
  rw [← dist_eq_norm, dist_iteratedFDerivWithin_zero] at h
  exact h

end PoincareMT.GeneralizedBlowupConvergence
