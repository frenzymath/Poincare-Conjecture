import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.Source
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Windows.SpacetimeJets

/-! # Uniform jets of the actual expanding-horizon source sequence -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))

def horizonSpacetimeCoefficients (q : G.limitCarrier.carrier) (k : ℕ)
    (z : ℝ × EuclideanSpace ℝ (Fin 3)) : SpacetimeBounds.MetricCoefficient 3 :=
  ((horizonSourceFlow hA htau e (G.subsequence k)).metric z.1).pullbackCoefficients
    (G.referenceChartMap q k 0) z.2

theorem horizonSpacetimeCoefficients_eventuallyEq_window
    (htmono : Monotone tau) (q : G.limitCarrier.carrier)
    {k j : ℕ} (hji : j ≤ G.subsequence k)
    {z : ℝ × EuclideanSpace ℝ (Fin 3)} (hz : z.1 ∈ Ioo (-tau j) 0) :
    horizonSpacetimeCoefficients G q k =ᶠ[𝓝 z]
      fun w => (((e (G.subsequence k) j hji).smallFlow (hA _) (htau j)).metric w.1).pullbackCoefficients
        (G.referenceChartMap q k 0) w.2 := by
  filter_upwards [(isOpen_Ioo.prod isOpen_univ).mem_nhds
    (show z ∈ Ioo (-tau j) 0 ×ˢ (Set.univ : Set (EuclideanSpace ℝ (Fin 3))) from
      ⟨hz, mem_univ _⟩)] with w hw
  unfold horizonSpacetimeCoefficients
  rw [horizonSourceFlow_metric_eq hA htau e htmono (G.subsequence k) j hji w.1
    (Ioo_subset_Icc_self hw.1)]

/-- Every fixed smaller time window has all mixed derivative bounds for the
actual expanding-time source, in the retained charts of its initial limit. -/
theorem exists_eventually_horizon_spacetime_jet_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (htmono : Monotone tau) (hB : ∀ j, 0 ≤ B j)
    {j : ℕ} {V : ℝ} (hTV : tau 0 / 2 ≤ V) (hVU : V < tau j)
    (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop,
      ∀ s ∈ Ioo (-V) 0, ∀ x ∈ K,
        ‖iteratedFDeriv ℝ m (horizonSpacetimeCoefficients G q k) (s, x)‖ ≤ C := by
  obtain ⟨C, hC, hbound⟩ := exists_eventually_reference_window_spacetime_jet_bound
    G P04 hAr hcompact hcomplete hTV hVU (hB j) q hK hKc m
  refine ⟨C, hC, ?_⟩
  filter_upwards [hbound, G.subsequence_strictMono.tendsto_atTop.eventually_ge_atTop j]
    with k hk hkj s hs x hx
  have heq := horizonSpacetimeCoefficients_eventuallyEq_window G htmono q hkj
    (z := (s, x)) (show s ∈ Ioo (-tau j) 0 from ⟨by linarith [hs.1], hs.2⟩)
  rw [(heq.iteratedFDeriv ℝ m).self_of_nhds]
  exact hk (eta _) (e _ j hkj) s hs x hx

theorem exists_eventually_horizon_ellipticity
    (htmono : Monotone tau) (hB : ∀ j, 0 ≤ B j) (j : ℕ)
    (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) :
    ∃ a b : ℝ, 0 < a ∧ 0 < b ∧ ∀ᶠ k in atTop,
      ∀ s ∈ Icc (-tau j) 0, ∀ x ∈ K, ∀ v,
        a * ‖v‖ ^ 2 ≤ horizonSpacetimeCoefficients G q k (s, x) v v ∧
        horizonSpacetimeCoefficients G q k (s, x) v v ≤ b * ‖v‖ ^ 2 := by
  have hTV : tau 0 / 2 ≤ tau j := by
    have h := htmono (Nat.zero_le j)
    linarith [htau 0]
  obtain ⟨a, b, ha, hb, hell⟩ := exists_eventually_reference_window_ellipticity
    G hTV (le_refl (tau j)) (hB j) q hK hKc
  refine ⟨a, b, ha, hb, ?_⟩
  filter_upwards [hell, G.subsequence_strictMono.tendsto_atTop.eventually_ge_atTop j]
    with k hk hkj s hs x hx v
  unfold horizonSpacetimeCoefficients
  rw [horizonSourceFlow_metric_eq hA htau e htmono (G.subsequence k) j hkj s hs]
  exact hk (eta _) (e _ j hkj) s hs x hx v

end PoincareMT.ControlledBlowupCompactness
