import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Sequence.Alternatives
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Sequence.ExtractionStage

/-!
# Terminal scalar control by actual small necks

The frozen dense canonical neighborhoods pass to the extracted complete
terminal metric. Each high-curvature point uses a separate compact connected
comparison stage containing the basepoint and its full canonical neighborhood.
No common backward lifetime or terminal canonical hypothesis is assumed.

Reference: Morgan--Tian, Claims 11.6 and 11.7, pp. 270--271.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1800000
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Topology Bundle

universe u v

namespace PoincareMT.M30CommonBlowupControls

local notation "E3" => EuclideanSpace ℝ (Fin 3)

theorem terminal_neck_scalar_control_of_metric_extraction
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    (hsmall : epsilon < 1 / 200)
    (hround : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold)
    {epsilon' : ℝ} (haccuracy : epsilon < epsilon') (hepsilon' : epsilon' < 1 / 2)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    {M : Type v} [TopologicalSpace M] [T2Space M] [T3Space M]
    [ChartedSpace E3 M] [IsManifold (𝓡 3) ∞ M]
    (g : RiemannianMetric 3 M) (D : LeviCivitaData g)
    (hcomplete : MetricComplete g) (p : M) (hbase : D.scalarCurvature p = 1)
    (E : ℕ → Set M) (hE : ∀ j, IsOpen (E j)) (hmono : Monotone E)
    (hconnected : ∀ j, IsPreconnected (E j)) (hp : ∀ j, p ∈ E j)
    (hcompact : ∀ j, IsCompact (closure (E j)))
    (hstep : ∀ j, closure (E j) ⊆ E (j + 1))
    (hcover : ⋃ j, E j = univ) (f : ∀ k, M → S.terminalComponent (sigma k))
    (hemb : ∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x))
    (hlocal : ∀ k, IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k))
    (himage : ∀ K : Set M, IsCompact K → ∃ R : ℝ, 0 < R ∧
      ∀ᶠ k in atTop, ∀ x ∈ K, (f k x).val ∈ S.baseBall (sigma k) R)
    (hjet : ∀ q m K, IsCompact K → K ⊆ (extChartAt (𝓡 3) q).target →
      TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ m ((S.terminalComponentMetric (sigma k)).pullbackCoefficients
          (f k ∘ (extChartAt (𝓡 3) q).symm)))
        (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm)) atTop K)
    (htensor : ∀ K, IsCompact K → ∀ d > 0, ∀ᶠ k in atTop,
      ∀ x ∈ K, ∀ v w : TangentSpace (𝓡 3) x,
        g.tangentNorm x v ≤ 1 → g.tangentNorm x w ≤ 1 →
        |(S.terminalComponentMetric (sigma k)).inner (f k x)
          (mfderiv (𝓡 3) (𝓡 3) (f k) x v) (mfderiv (𝓡 3) (𝓡 3) (f k) x w) -
            g.inner x v w| < d)
    (hscalar : ∀ K, IsCompact K → TendstoUniformlyOn
      (fun k y => (S.terminalComponentConnection (sigma k)).scalarCurvature (f k y))
      D.scalarCurvature atTop K) :
    ∀ x : M, D.scalarCurvature x ≤ max 4 (max (C / 6) 2) ∨
      ∃ N : EpsilonNeck g, N.epsilon = epsilon' ∧ N.connection = D ∧
        D.scalarCurvature x ≤ 2 * max C 1 * D.scalarCurvature N.center := by
  classical
  let : Nonempty M := ⟨p⟩
  intro x
  by_cases hx : D.scalarCurvature x ≤ max 4 (max (C / 6) 2)
  · exact Or.inl hx
  apply Or.inr
  have hxlarge := lt_of_not_ge hx
  have hxpos : 0 < D.scalarCurvature x :=
    (by norm_num : (0 : ℝ) < 4).trans ((le_max_left _ _).trans_lt hxlarge)
  let l := D.scalarCurvature x / 2
  let u := 2 * D.scalarCurvature x
  have hl : 0 < l := by dsimp [l]; positivity
  have hlx : l < D.scalarCurvature x := by dsimp [l]; linarith
  have hxu : D.scalarCurvature x < u := by dsimp [u]; linarith
  let r := max ((2 * Real.pi + 2 * epsilon⁻¹) * l ^ (-1 / 2 : ℝ) + 1)
    (max C 1 * l ^ (-1 / 2 : ℝ) + 1)
  have hneckradius : (2 * Real.pi + 2 * epsilon⁻¹) * l ^ (-1 / 2 : ℝ) + 1 ≤ r :=
    le_max_left _ _
  have hcapradius : max C 1 * l ^ (-1 / 2 : ℝ) + 1 ≤ r := le_max_right _ _
  have hr : 0 < r := lt_of_lt_of_le (by positivity) hcapradius
  have hbig : IsCompact (closure (g.ball x (2 * r + 1))) :=
    g.isCompact_closure_ball_of_metricComplete hcomplete x (2 * r + 1)
  have hA : IsCompact (closure (g.ball x (2 * r))) :=
    g.isCompact_closure_ball_of_metricComplete hcomplete x (2 * r)
  have hAbig : closure (g.ball x (2 * r)) ⊆ closure (g.ball x (2 * r + 1)) :=
    closure_mono (fun _ hy => hy.trans_le (ENNReal.ofReal_le_ofReal (by linarith)))
  obtain ⟨j, hj⟩ := hbig.elim_directed_cover E hE
    (by rw [hcover]; exact subset_univ _) hmono.directed_le
  let U := E (j + 1)
  let K₀ := closure (E j)
  have hK₀U : K₀ ⊆ U := hstep j
  have hAU : closure (g.ball x (2 * r)) ⊆ U :=
    hAbig.trans (hj.trans (subset_closure.trans hK₀U))
  have hsource : closure (g.ball x (2 * r + 1)) ⊆ U :=
    hj.trans (subset_closure.trans hK₀U)
  have hxU : x ∈ U := by
    apply hsource
    apply subset_closure
    let : Bundle.RiemannianBundle (TangentSpace (𝓡 3) : M → Type _) :=
      ⟨g.toRiemannianMetric⟩
    change g.edist x x < ENNReal.ofReal (2 * r + 1)
    rw [RiemannianMetric.edist, Manifold.riemannianEDist_self]
    exact ENNReal.ofReal_pos.mpr (by positivity)
  obtain ⟨s, K, hK, hcharts⟩ := TerminalNeck.exists_finite_compact_chart_cover
    hA (hE (j + 1)) hAU
  let q := fun i : s => i.val.val
  let K' := fun i : s => K i.val
  have hK' (i : s) : IsCompact (K' i) ∧ K' i ⊆ U ∩ (extChartAt (𝓡 3) (q i)).source :=
    hK i.val
  obtain ⟨sigma', _hsigma', t, e, hes, hgood, hconv, hscalarconv, hlower⟩ :=
    H.exists_canonical_comparison_stage_of_terminal_extraction P04 hbound hsigma g D
      E hE hmono hcover f hemb hlocal himage hjet htensor (hE (j + 1)) (hcompact (j + 1))
      (hcompact j) hK₀U (hscalar K₀ (hcompact j)) q K' hK'
  have hcompacts : closure (g.ball x (2 * r)) ⊆ K₀ := hAbig.trans (hj.trans subset_closure)
  apply ControlledTerminal.exists_terminal_neck_above_canonical_component_cutoff
    (fun k => S.flow (sigma' k)) t (fun k => S.scale (sigma' k))
    (fun k => S.base_scalar_pos (sigma' k)) g D hcomplete
    (fun k => (e k).toOpenPartialHomeomorph)
    (fun k => (e k).contMDiffOn_toFun) (fun k => (e k).contMDiffOn_invFun)
    (hE (j + 1)) (hconnected (j + 1)) (fun k => (hes k).symm ▸ Subset.rfl)
    p x (hp (j + 1)) hxU H.epsilon_pos hsmall hround haccuracy hepsilon'
    hl hlx hxu hxlarge (fun k => (hgood k).2) hneckradius hcapradius hsource
    (fun k y hy => hlower k y (subset_closure (hj hy)))
    Finset.univ q K' (fun i _ => hK' i)
    (fun y hy => by
      obtain ⟨i, hi, hyi⟩ := hcharts y hy
      exact ⟨⟨i, hi⟩, Finset.mem_univ _, hyi⟩)
    (fun i _ m => hconv i m) (hscalarconv.mono hcompacts)
  change Tendsto (fun k => (S.scale (sigma' k))⁻¹ *
    ((S.flow (sigma' k)).connection (t k)).scalarCurvature (e k p)) atTop (𝓝 1)
  rw [← hbase]
  exact hscalarconv.tendsto_at (subset_closure (hp j))

end PoincareMT.M30CommonBlowupControls
