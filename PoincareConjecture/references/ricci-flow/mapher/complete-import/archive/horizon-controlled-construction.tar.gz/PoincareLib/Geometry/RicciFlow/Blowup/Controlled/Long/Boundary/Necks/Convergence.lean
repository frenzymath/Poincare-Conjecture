import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Sequence.Jets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.MetricJetsEventual
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.ScalarNeckLimit

/-! # Passing captured necks through a smooth metric limit on one carrier -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxHeartbeats 1200000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledBlowupBoundary

theorem exists_neck_of_captured_metric_convergence
    {M : Type*} [TopologicalSpace M] [T2Space M] [T3Space M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    (g : RiemannianMetric 3 M) (D : LeviCivitaData g)
    (h : ℕ → RiemannianMetric 3 M) (Ds : ∀ k, LeviCivitaData (h k))
    (N : ∀ k, EpsilonNeck (h k)) {A : Set M} (hA : IsCompact A)
    (hcapture : ∀ k, (N k).carrier ⊆ A)
    (x : M) (hxA : x ∈ A) (hx : 0 < D.scalarCurvature x)
    {delta epsilon l u C : ℝ} (hdelta : 0 < delta) (hsmall : delta < 1 / 200)
    (haccuracy : delta < epsilon) (hepsilon : epsilon < 1 / 2)
    (hl : 0 < l) (hu : 0 < u) (hC : 0 < C)
    (heq : ∀ k, (N k).epsilon = delta) (hD : ∀ k, (N k).connection = Ds k)
    (hscalar : ∀ k, l ≤ (Ds k).scalarCurvature (N k).center ∧
      (Ds k).scalarCurvature (N k).center ≤ u)
    (hratio : ∀ k, (Ds k).scalarCurvature x ≤ C * (Ds k).scalarCurvature (N k).center)
    (hjets : ∀ q : M, ∀ K : Set (EuclideanSpace ℝ (Fin 3)), IsCompact K →
      K ⊆ (extChartAt (𝓡 3) q).target → ∀ m,
      TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ m ((h k).parametrizedCoefficients (extChartAt (𝓡 3) q).symm))
        (iteratedFDeriv ℝ m (g.parametrizedCoefficients (extChartAt (𝓡 3) q).symm)) atTop K)
    (hscalarconv : TendstoUniformlyOn (fun k y => (Ds k).scalarCurvature y)
      D.scalarCurvature atTop A) :
    ∃ L : EpsilonNeck g, L.epsilon = epsilon ∧ L.connection = D ∧
      D.scalarCurvature x ≤ 2 * C * D.scalarCurvature L.center := by
  classical
  let e : ℕ → OpenPartialHomeomorph M M := fun _ => OpenPartialHomeomorph.refl M
  have he (k : ℕ) : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source := contMDiffOn_id
  have hei (k : ℕ) : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k).symm (e k).target := contMDiffOn_id
  have hsource (k : ℕ) : univ ⊆ (e k).source := subset_rfl
  have hNe (k : ℕ) : (N k).carrier ⊆ (e k).source := subset_univ _
  have himage (k : ℕ) : e k '' (N k).carrier ⊆ A := by
    rintro _ ⟨y, hy, rfl⟩
    exact hcapture k hy
  obtain ⟨s, K, hK, hcover⟩ := TerminalNeck.exists_finite_compact_chart_cover
    hA isOpen_univ (subset_univ A)
  have hconv (q : A) (m : ℕ) : TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((h k).parametrizedCoefficients
        (e k ∘ (extChartAt (𝓡 3) q.val).symm)))
      (iteratedFDeriv ℝ m (g.parametrizedCoefficients (extChartAt (𝓡 3) q.val).symm))
      atTop ((extChartAt (𝓡 3) q.val) '' K q) := by
    have hcompact := (hK q).1.image_of_continuousOn
      ((continuousOn_extChartAt q.val).mono (fun _ hx => ((hK q).2 hx).2))
    have htarget : (extChartAt (𝓡 3) q.val) '' K q ⊆ (extChartAt (𝓡 3) q.val).target := by
      rintro _ ⟨y, hy, rfl⟩
      exact (extChartAt (𝓡 3) q.val).map_source ((hK q).2 hy).2
    exact hjets q.val _ hcompact htarget m
  let m := ⌊epsilon⁻¹⌋₊
  have hepsilonpos : 0 < epsilon := hdelta.trans haccuracy
  have hm : 1 ≤ m := (Nat.one_le_floor_iff _).mpr
    ((one_le_inv₀ hepsilonpos).mpr (hepsilon.le.trans (by norm_num)))
  have horder (k : ℕ) : m ≤ ⌊(N k).epsilon⁻¹⌋₊ := by
    rw [heq k]
    exact Nat.floor_mono ((inv_le_inv₀ hepsilonpos hdelta).mpr haccuracy.le)
  have hcontrols (q : A) := ControlledTerminal.reference_controls_of_comparison_metric_convergence
    g h e he hsource q.val (hK q).1 (hK q).2 (hconv q) m
  have herr (d : ℝ) (hd : 0 < d) :=
    TerminalNeck.eventually_small_transported_neck_errors_of_finite_chart_cover
      h g N e he hei hNe isOpen_univ hsource himage
      (fun k => by rw [heq k]; exact hsmall) s (fun q : A => q.val) K
      (fun q _ => hK q) hcover m hm horder hl hu
      (fun k => by simpa only [hD k] using hscalar k)
      (fun q _ => (hcontrols q).1) (fun q _ => (hcontrols q).2.1)
      (fun q _ j _ => (hcontrols q).2.2 j) hd
  have hresult := TerminalNeck.eventually_necks_with_scalar_control_of_captured_convergence
    h g N e he hei hNe himage D x hxA hx hdelta haccuracy hepsilon heq hl hu hC
    (fun k => by simpa only [hD k] using hscalar k)
    (fun k => by
      change (N k).connection.scalarCurvature x ≤ C * (N k).connection.scalarCurvature (N k).center
      simpa only [hD k] using hratio k)
    herr (by
      change TendstoUniformlyOn (fun k y => (N k).connection.scalarCurvature y) D.scalarCurvature atTop A
      simpa only [hD] using hscalarconv)
  obtain ⟨k, L, hL, hLD, _, hratioL⟩ := hresult.exists
  exact ⟨L, hL, hLD, hratioL⟩

end PoincareMT.ControlledBlowupBoundary
