import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.TransportCoordinates
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.MetricError
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.ChartCover

/-!
# Metric errors on whole captured varying necks

Bounded inverse comparison coordinates transfer ambient metric convergence
to the source neck charts. The exact inverse-map identities recover the
original source metric there, and a finite compact chart cover makes the
estimate uniform over the entire neck.

Reference: Morgan--Tian, Claim 11.6 and Proposition 9.79(3).
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Topology

universe u v

namespace PoincareMT.TerminalNeck

open MetricSurgery

local notation "E" => EuclideanSpace ℝ (Fin 3)

variable {X : ℕ → Type u}
  [∀ k, TopologicalSpace (X k)] [∀ k, ChartedSpace E (X k)]
  [∀ k, IsManifold (𝓡 3) ∞ (X k)]
  {M : Type v} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]

theorem eventually_small_transported_neck_metric_errors_on_chart
    (g : ∀ k, RiemannianMetric 3 (X k)) (h : RiemannianMetric 3 M)
    (N : ∀ k, EpsilonNeck (g k)) (e : ∀ k, OpenPartialHomeomorph (X k) M)
    (he : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source)
    (hei : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k).symm (e k).target)
    (hcapture : ∀ k, (N k).carrier ⊆ (e k).source)
    {U : Set M} (hU : IsOpen U) (hUt : ∀ k, U ⊆ (e k).target)
    (hsmall : ∀ k, (N k).epsilon < 1 / 200) (q : M)
    {K : Set M} (hK : IsCompact K) (hKU : K ⊆ U)
    (hKq : K ⊆ (extChartAt (𝓡 3) q).source)
    (r : ℕ) (hr : 1 ≤ r) (horder : ∀ k, r ≤ ⌊(N k).epsilon⁻¹⌋₊)
    {l u b : ℝ} (hl : 0 < l) (hu : 0 < u) (hb : 0 < b)
    (hscalar : ∀ k, l ≤ (N k).connection.scalarCurvature (N k).center ∧
      (N k).connection.scalarCurvature (N k).center ≤ u)
    (hambient : ∃ C : ℝ, ∀ k j, j ≤ r → ∀ y ∈ (extChartAt (𝓡 3) q) '' K,
      ‖iteratedFDeriv ℝ j ((g k).parametrizedCoefficients
        ((e k).symm ∘ (extChartAt (𝓡 3) q).symm)) y‖ ≤ C)
    (helliptic : ∀ k y, y ∈ (extChartAt (𝓡 3) q) '' K → ∀ w : E,
      b * ‖w‖ ^ 2 ≤ (g k).parametrizedCoefficients
        ((e k).symm ∘ (extChartAt (𝓡 3) q).symm) y w w)
    (hjet : ∀ j, j ≤ r → TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ j (fun y =>
        (g k).parametrizedCoefficients ((e k).symm ∘ (extChartAt (𝓡 3) q).symm) y -
        h.parametrizedCoefficients (extChartAt (𝓡 3) q).symm y))
      (fun _ => 0) atTop ((extChartAt (𝓡 3) q) '' K))
    {η : ℝ} (hη : 0 < η) :
    ∀ᶠ k in atTop, ∀ z : RoundCylinderSpace,
      z.2 ∈ Ioo (-(N k).epsilon⁻¹) (N k).epsilon⁻¹ →
      e k ((N k).coordinate_map z) ∈ K → ∀ j : ℕ, j ≤ r →
        ‖iteratedFDeriv ℝ j (fun p =>
          (g k).parametrizedCoefficients (centeredNeckLift (N k) z.1 z.2) p -
          h.parametrizedCoefficients (e k ∘ centeredNeckLift (N k) z.1 z.2) p) 0‖ ≤ η := by
  obtain ⟨C, hC, hbound⟩ := exists_transported_centered_neck_jet_bound
    g N e he hei hcapture hsmall q hK hKq (fun k => hKU.trans (hUt k))
    r hr horder hl hu hb hscalar hambient helliptic
  let Z := Σ k : ℕ, {z : RoundCylinderSpace //
    z.2 ∈ Ioo (-(N k).epsilon⁻¹) (N k).epsilon⁻¹ ∧ e k ((N k).coordinate_map z) ∈ K}
  let a := fun z : Z => centeredNeckLift (N z.1) z.2.1.1 z.2.1.2
  let f := fun z : Z => e z.1 ∘ a z
  have hf (z : Z) : ∃ W, IsOpen W ∧ (0 : E) ∈ W ∧
      ContMDiffOn (𝓡 3) (𝓡 3) ∞ (f z) W := by
    refine ⟨centeredNeckDomain (N z.1) z.2.1.2,
      centeredNeckDomain_isOpen (N z.1) z.2.1.2,
      zero_mem_centeredNeckDomain (N z.1) z.2.2.1, ?_⟩
    exact (he z.1).comp (fun y hy =>
      (centeredNeckLift_contMDiffAt (N z.1) z.2.1.1 z.2.1.2 hy).contMDiffWithinAt)
      (fun y hy => hcapture z.1 (centeredNeckLift_mem (N z.1) z.2.1.1 z.2.1.2 hy))
  have hmap (z : Z) : f z 0 ∈ K := by
    simpa only [f, a, Function.comp_apply, centeredNeckLift_zero] using z.2.2.2
  have herrors := eventually_small_parametrized_metric_error_of_chart_bound
    g h (fun k => (e k).symm) hU
    (Eventually.of_forall fun k => (hei k).mono (hUt k)) q hK hKU hKq
    f hf hmap r hC (fun z j _ hj => hbound z.1 z.2.1 z.2.2.1 z.2.2.2 j hj) hjet hη
  filter_upwards [herrors] with k hk z hz hKz j hj
  let z' : Z := ⟨k, z, hz, hKz⟩
  have heq : (fun p => (g k).parametrizedCoefficients ((e k).symm ∘ f z') p -
      h.parametrizedCoefficients (f z') p) =ᶠ[𝓝 (0 : E)]
      (fun p => (g k).parametrizedCoefficients (a z') p -
        h.parametrizedCoefficients (f z') p) := by
    filter_upwards [(centeredNeckDomain_isOpen (N k) z.2).mem_nhds
      (zero_mem_centeredNeckDomain (N k) hz)] with p hp
    have hmaps : (e k).symm ∘ f z' =ᶠ[𝓝 p] a z' := by
      filter_upwards [(centeredNeckDomain_isOpen (N k) z.2).mem_nhds hp] with y hy
      exact (e k).left_inv (hcapture k (centeredNeckLift_mem (N k) z.1 z.2 hy))
    exact congrArg (fun B : E →L[ℝ] E →L[ℝ] ℝ => B - h.parametrizedCoefficients (f z') p)
      ((g k).parametrizedCoefficients_congr_of_eventuallyEq hmaps)
  have hh := hk z' j hj
  rw [(heq.iteratedFDeriv ℝ j).self_of_nhds] at hh
  exact hh

theorem eventually_small_transported_neck_metric_errors
    [T2Space M] [T3Space M]
    (g : ∀ k, RiemannianMetric 3 (X k)) (h : RiemannianMetric 3 M)
    (N : ∀ k, EpsilonNeck (g k)) (e : ∀ k, OpenPartialHomeomorph (X k) M)
    (he : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k) (e k).source)
    (hei : ∀ k, ContMDiffOn (𝓡 3) (𝓡 3) ∞ (e k).symm (e k).target)
    (hcapture : ∀ k, (N k).carrier ⊆ (e k).source)
    {A U : Set M} (hA : IsCompact A) (hU : IsOpen U) (hAU : A ⊆ U)
    (hUt : ∀ k, U ⊆ (e k).target) (himage : ∀ k, e k '' (N k).carrier ⊆ A)
    (hsmall : ∀ k, (N k).epsilon < 1 / 200)
    (r : ℕ) (hr : 1 ≤ r) (horder : ∀ k, r ≤ ⌊(N k).epsilon⁻¹⌋₊)
    {l u : ℝ} (hl : 0 < l) (hu : 0 < u)
    (hscalar : ∀ k, l ≤ (N k).connection.scalarCurvature (N k).center ∧
      (N k).connection.scalarCurvature (N k).center ≤ u)
    (hambient : ∀ q (K : Set M), IsCompact K → K ⊆ U ∩ (extChartAt (𝓡 3) q).source →
      (∃ C : ℝ, ∀ k j, j ≤ r → ∀ y ∈ (extChartAt (𝓡 3) q) '' K,
        ‖iteratedFDeriv ℝ j ((g k).parametrizedCoefficients
          ((e k).symm ∘ (extChartAt (𝓡 3) q).symm)) y‖ ≤ C) ∧
      ∃ b : ℝ, 0 < b ∧ ∀ k y, y ∈ (extChartAt (𝓡 3) q) '' K → ∀ w : E,
        b * ‖w‖ ^ 2 ≤ (g k).parametrizedCoefficients
          ((e k).symm ∘ (extChartAt (𝓡 3) q).symm) y w w)
    (hjet : ∀ q (K : Set M), IsCompact K → K ⊆ U ∩ (extChartAt (𝓡 3) q).source →
      ∀ j, j ≤ r → TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ j (fun y =>
          (g k).parametrizedCoefficients ((e k).symm ∘ (extChartAt (𝓡 3) q).symm) y -
          h.parametrizedCoefficients (extChartAt (𝓡 3) q).symm y))
        (fun _ => 0) atTop ((extChartAt (𝓡 3) q) '' K))
    {η : ℝ} (hη : 0 < η) :
    ∀ᶠ k in atTop, ∀ z : RoundCylinderSpace,
      z.2 ∈ Ioo (-(N k).epsilon⁻¹) (N k).epsilon⁻¹ → ∀ j : ℕ, j ≤ r →
        ‖iteratedFDeriv ℝ j (fun p =>
          (g k).parametrizedCoefficients (centeredNeckLift (N k) z.1 z.2) p -
          h.parametrizedCoefficients (e k ∘ centeredNeckLift (N k) z.1 z.2) p) 0‖ ≤ η := by
  obtain ⟨s, K, hK, hcover⟩ := exists_finite_compact_chart_cover hA hU hAU
  have hlocal (q : A) : ∀ᶠ k in atTop, ∀ z : RoundCylinderSpace,
      z.2 ∈ Ioo (-(N k).epsilon⁻¹) (N k).epsilon⁻¹ →
      e k ((N k).coordinate_map z) ∈ K q → ∀ j : ℕ, j ≤ r →
        ‖iteratedFDeriv ℝ j (fun p =>
          (g k).parametrizedCoefficients (centeredNeckLift (N k) z.1 z.2) p -
          h.parametrizedCoefficients (e k ∘ centeredNeckLift (N k) z.1 z.2) p) 0‖ ≤ η := by
    obtain ⟨hbound, b, hb, hell⟩ := hambient q.val (K q) (hK q).1 (hK q).2
    exact eventually_small_transported_neck_metric_errors_on_chart
      g h N e he hei hcapture hU hUt hsmall q.val (hK q).1
      (fun _ hx => ((hK q).2 hx).1) (fun _ hx => ((hK q).2 hx).2)
      r hr horder hl hu hb hscalar hbound hell (hjet q.val (K q) (hK q).1 (hK q).2) hη
  have hall := (eventually_all_finite s.finite_toSet).mpr (fun q _ => hlocal q)
  filter_upwards [hall] with k hk z hz j hj
  have hzA := himage k (mem_image_of_mem (e k)
    (neck_coordinate_mem (N k) z ⟨mem_univ _, hz⟩))
  obtain ⟨q, hqs, hzq⟩ := hcover _ hzA
  exact hk q hqs z hz hzq j hj

end PoincareMT.TerminalNeck
