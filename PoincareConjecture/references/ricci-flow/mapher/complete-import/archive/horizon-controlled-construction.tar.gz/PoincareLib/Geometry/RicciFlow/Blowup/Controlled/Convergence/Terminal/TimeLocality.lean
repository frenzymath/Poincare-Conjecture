import PoincareLib.Geometry.Riemannian.Connection.Construction
import PoincareLib.Geometry.RicciFlow.Limit.Descent

/-!
# Gluing Ricci flows by local agreement in time
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 600000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.RicciFlow

/-- A metric family locally equal, within its time domain, to genuine Ricci
flows is itself a Ricci flow on that domain. -/
theorem exists_of_locally_matching_flows
    {n : ℕ} {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    {J : Set ℝ} (hJ : J.OrdConnected) (hne : J.Nontrivial)
    (g : ℝ → RiemannianMetric n M)
    (hlocal : ∀ t ∈ J, ∃ K : Set ℝ, ∃ F : RicciFlow n M K,
      t ∈ K ∧ K ∈ 𝓝[J] t ∧ g =ᶠ[𝓝[J] t] F.metric) :
    ∃ F : RicciFlow n M J, F.metric = g := by
  let D (t : ℝ) : LeviCivitaData (g t) := (g t).leviCivitaData
  have hsmooth : RiemannianMetric.IsSmoothFamilyOn g J := by
    rintro ⟨t, x⟩ ⟨ht, _⟩
    obtain ⟨K, F, htK, hK, heq⟩ := hlocal t ht
    have hprod : K ×ˢ (univ : Set M) ∈ 𝓝[J ×ˢ univ] (t, x) :=
      mem_nhdsWithin_prod_iff.mpr ⟨K, hK, univ, univ_mem, subset_rfl⟩
    have hs := (F.smooth (t, x) ⟨htK, mem_univ x⟩).mono_of_mem_nhdsWithin hprod
    apply hs.congr_of_eventuallyEq_of_mem _ ⟨ht, mem_univ x⟩
    have hp : {s : ℝ | g s = F.metric s} ×ˢ (univ : Set M) ∈
        𝓝[J ×ˢ univ] (t, x) :=
      mem_nhdsWithin_prod_iff.mpr ⟨_, heq, univ, univ_mem, subset_rfl⟩
    filter_upwards [hp] with p hp
    rw [hp.1]
  refine ⟨{
    metric := g
    connection := D
    interval := hJ
    nontrivial := hne
    smooth := hsmooth
    equation := ?_ }, rfl⟩
  intro t ht x v w
  obtain ⟨K, F, htK, hK, heq⟩ := hlocal t ht
  have htmetric : g t = F.metric t := heq.eq_of_nhdsWithin ht
  have hRicci : (F.connection t).ricci x v w = (D t).ricci x v w := by
    have h := (F.connection t).ricci_eq_of_local_isometry (D t)
      (f := id) isOpen_univ contMDiffOn_id
      (fun y _ a b => by simp only [id_eq, mfderiv_id, ContinuousLinearMap.id_apply, htmetric])
      (mem_univ x) v w
    simpa only [id_eq, mfderiv_id, ContinuousLinearMap.id_apply] using h
  have hd := (F.equation t htK x v w).mono_of_mem_nhdsWithin hK
  rw [hRicci] at hd
  apply hd.congr_of_eventuallyEq_of_mem _ ht
  exact heq.mono fun s hs => by
    change (g s).inner x v w = (F.metric s).inner x v w
    rw [hs]

/-- Attach a closed terminal slab to an existing open flow without losing
any earlier time. Agreement is needed only on their open overlap. -/
theorem exists_attach_terminal_slab
    {n : ℕ} {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    {a b c : ℝ} (hac : a < c) (hcb : c < b)
    (F : RicciFlow n M (Ioo a b)) (H : RicciFlow n M (Icc c b))
    (hmatch : ∀ t ∈ Ioo c b, H.metric t = F.metric t) :
    ∃ G : RicciFlow n M (Ioc a b),
      (∀ t ∈ Ioo a b, G.metric t = F.metric t) ∧ G.metric b = H.metric b := by
  classical
  let g (t : ℝ) := if t < b then F.metric t else H.metric t
  obtain ⟨G, hG⟩ := exists_of_locally_matching_flows ordConnected_Ioc
    (show (Ioc a b).Nontrivial from ⟨c, ⟨hac, hcb.le⟩, b, ⟨hac.trans hcb, le_rfl⟩, hcb.ne⟩)
    g (by
      intro t ht
      by_cases htb : t < b
      · refine ⟨Ioo a b, F, ⟨ht.1, htb⟩,
          mem_nhdsWithin_of_mem_nhds (isOpen_Ioo.mem_nhds ⟨ht.1, htb⟩), ?_⟩
        filter_upwards [mem_nhdsWithin_of_mem_nhds (Iio_mem_nhds htb)] with s hs
        exact if_pos hs
      · have hteq : t = b := le_antisymm ht.2 (le_of_not_gt htb)
        subst t
        have hnear : Ioi c ∈ 𝓝[Ioc a b] b :=
          mem_nhdsWithin_of_mem_nhds (Ioi_mem_nhds hcb)
        refine ⟨Icc c b, H, ⟨hcb.le, le_rfl⟩, ?_, ?_⟩
        · filter_upwards [hnear, self_mem_nhdsWithin] with s hs hsJ
          exact ⟨hs.le, hsJ.2⟩
        · filter_upwards [hnear, self_mem_nhdsWithin] with s hs hsJ
          dsimp only [g]
          split_ifs with hsb
          · exact (hmatch s ⟨hs, hsb⟩).symm
          · rfl)
  refine ⟨G, ?_, ?_⟩
  · intro t ht
    rw [hG]
    exact if_pos ht.2
  · rw [hG]
    exact if_neg (lt_irrefl b)

end PoincareMT.RicciFlow
