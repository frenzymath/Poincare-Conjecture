import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Horizon.Retained.CylinderJets

/-! # The exact generalized convergence structure on the full horizon -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace
  RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ}
  {A eta tau B : ℕ → ℝ} {hA : ∀ i, 0 < A i} {htau : ∀ j, 0 < tau j}
  {e : ∀ i j, j ≤ i → ControlledBlowupCylinder S (idx i) (A i) (tau j) (B j) (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta (tau 0) (B 0) hA
    (htau 0) (fun i => e i 0 (Nat.zero_le i))))
  (F₀ : RicciFlow 3 G.limitCarrier.carrier (Ioc (-tau 0 / 2) (tau 0 / 2)))
  (hF₀ : ∀ t ∈ Ioo (-tau 0 / 2) (tau 0 / 2), F₀.metric t = G.limitFlow.metricAt t)
  (F : RicciFlow 3 G.limitCarrier.carrier (horizonOpenTime tau ∪ {0}))
  (hmatch : ∀ t ∈ Ioc (-tau 0) 0, F.metric t = F₀.metric (t + tau 0 / 2))
  (P04 : RicciFlowCurvatureTheory.{u}) (hAr : Tendsto A atTop atTop)
  (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
  (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
  (htmono : StrictMono tau) (hB : ∀ j, 0 ≤ B j)
  {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
  (hjets : ∀ q r K, IsCompact K → K ⊆ horizonOpenTime tau ×ˢ (extChartAt (𝓡 3) q).target →
    TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ r (horizonSpacetimeCoefficients G q (sigma k)))
      (iteratedFDeriv ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)) atTop K)
  (heta : Tendsto eta atTop (𝓝 0))

local notation "theLimit" => liftedLimit (horizonLimit G F₀ hF₀ F hmatch P04 hAr hcompact
  hcomplete htmono.monotone hB hsigma hjets heta)

theorem horizon_pullback_metric_CInfinity
    (q : (liftedSliceCarrier.{u} G.limitCarrier).carrier) (j r : ℕ)
    (K : Set (ℝ × EuclideanSpace ℝ (Fin 3))) (hK : IsCompact K)
    (hKU : K ⊆ {p | p ∈ blowupMetricChartDomain theLimit q ∧
      (extChartAt (𝓡 3) q).symm p.2 ∈ retainedSpace G (sigma j)})
    (epsilon : ℝ) (hepsilon : 0 < epsilon) :
    ∃ N : ℕ, j ≤ N ∧ ∀ k ≥ N,
      K ⊆ Icc (-tau k) 0 ×ˢ (extChartAt (𝓡 3) q).target ∧
      ∀ a b : Fin 3, ∀ p ∈ K,
        ‖iteratedFDerivWithin ℝ r
            (blowupPullbackCoefficient (L := theLimit) (horizonRetainedCylinder G hsigma k) q a b)
            (Icc (-tau k) 0 ×ˢ (extChartAt (𝓡 3) q).target) p -
          iteratedFDerivWithin ℝ r
            (FlowCarrier.coordinateCoefficient (theLimit).carrier q
              (fun t x v w => ((theLimit).flow.metric t).inner x v w) a b)
            (blowupMetricChartDomain theLimit q) p‖ < epsilon := by
  have hchart : (extChartAt (𝓡 3) q).target = (extChartAt (𝓡 3) q.down).target := by
    simp only [extChartAt_target]
    congr 1
    change (Homeomorph.ulift.toOpenPartialHomeomorph.trans
      (chartAt (EuclideanSpace ℝ (Fin 3)) q.down)).target = _
    simp
  have hKU0 : K ⊆ (horizonOpenTime tau ∪ {0}) ×ˢ (extChartAt (𝓡 3) q.down).target :=
    fun p hp => ⟨(hKU hp).1.1, hchart ▸ (hKU hp).1.2⟩
  have hc (a b : Fin 3) := Metric.tendstoUniformlyOn_iff.mp
    (tendstoUniformlyOn_horizon_scalarJet G F₀ hF₀ F hmatch P04 hAr hcompact hcomplete
      htmono.monotone hB hsigma hjets q.down r a b hK hKU0) epsilon hepsilon
  have hall := Filter.eventually_all.mpr fun a => Filter.eventually_all.mpr (hc a)
  have hs := eventually_horizonRetainedCylinder_jet_eq G F₀ hF₀ F hmatch P04 hAr hcompact
    hcomplete htmono hB hsigma hjets heta q j r hK hKU
  obtain ⟨N, hN⟩ := eventually_atTop.mp (hs.and hall)
  refine ⟨max j N, le_max_left _ _, fun k hk => ?_⟩
  have hh := hN k ((le_max_right j N).trans hk)
  refine ⟨hh.1.1, fun a b p hp => ?_⟩
  rw [hh.1.2 a b p hp, liftedLimit_coordinateJet
    (horizonLimit G F₀ hF₀ F hmatch P04 hAr hcompact hcomplete htmono.monotone hB hsigma hjets heta)
      q a b (blowupMetricChartDomain theLimit q) r p (hKU hp).1.2]
  change ‖iteratedFDerivWithin ℝ r _ ((horizonOpenTime tau ∪ {0}) ×ˢ (extChartAt (𝓡 3) q).target) p -
    iteratedFDerivWithin ℝ r
      (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q.down).symm z.2
          (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))
      ((horizonOpenTime tau ∪ {0}) ×ˢ (extChartAt (𝓡 3) q).target) p‖ < epsilon
  rw [hchart]
  have hh' := hh.2 a b p hp
  rw [dist_eq_norm, norm_sub_rev] at hh'
  convert hh' using 1
  rfl

/-- The initial spatial extraction and the horizon diagonal together give
the actual frozen generalized convergence, including terminal-time jets. -/
def horizonConvergence (hidx : StrictMono idx) :
    GeneralizedBlowupConvergence S (horizonOpenTime tau ∪ {0}) where
  limit := theLimit
  subsequence := idx ∘ G.subsequence ∘ sigma
  subsequence_strictMono := hidx.comp (G.subsequence_strictMono.comp hsigma)
  exhaustion := horizonExhaustion G F₀ hF₀ F hmatch P04 hAr hcompact hcomplete htmono hB hsigma hjets heta
  embedding := horizonRetainedCylinder G hsigma
  base_preserving := horizonRetainedCylinder_base G hsigma
  source_balls_in_image := fun _ hr => horizonRetainedCylinder_eventually_covers_baseBall G hsigma hAr hcomplete hr
  pullback_metric_CInfinity := horizon_pullback_metric_CInfinity G F₀ hF₀ F hmatch P04 hAr hcompact
    hcomplete htmono hB hsigma hjets heta

end PoincareMT.ControlledBlowupCompactness
