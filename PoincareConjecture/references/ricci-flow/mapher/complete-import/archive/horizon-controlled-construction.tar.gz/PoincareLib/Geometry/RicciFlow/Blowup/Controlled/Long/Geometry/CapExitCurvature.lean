import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Geometry.CapExitTriangle
import PoincareLib.Topology.Manifold.NeckCap.Cap.Bounds

/-!
# Scalar bounds at cap cores in large triangles

The cap diameter estimate turns large-triangle exclusion into a bound at its
core vertex. All cap and connection data are the actual geometric certificates.
Reference: Morgan--Tian, Claim 11.14, pp. 276--277.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle

universe u

namespace PoincareMT.CapCertificate

theorem exists_large_triangle_core_scalar_bound_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 1000 ∧
      ∀ {M : Type u} [TopologicalSpace M] [ConnectedSpace M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
        [MeasurableSpace M] [BorelSpace M] [T2Space M] [T3Space M]
        {g : RiemannianMetric 3 M},
        ∀ C : CapCertificate g, C.epsilon ≤ epsilon₀ →
        ∀ D : LeviCivitaData g, MetricComplete g → D.NonnegativeSectionalCurvature →
        ∀ {p y z : M} {d B : ℝ}, 0 < d → C.cap_constant ≤ B →
        d ≤ (g.edist y p).toReal → d ≤ (g.edist y z).toReal →
        (g.edist y p).toReal ≤ 3 * d / 2 → (g.edist y z).toReal ≤ 3 * d / 2 →
        d ≤ (g.edist p z).toReal → y ∈ C.core →
        D.scalarCurvature y < (B / d) ^ 2 := by
  obtain ⟨epsilon₀, hepsilon₀, hsmall, hexclude⟩ :=
    exists_large_triangle_exclusion_threshold.{u}
  refine ⟨epsilon₀, hepsilon₀, hsmall, ?_⟩
  intro M _ _ _ _ _ _ _ _ g C hepsilon D hcomplete hsec p y z d B hd hB
    ha hb ha' hb' hfar hy
  have hyC := C.core_subset_carrier hy
  have hBpos : 0 < B := C.cap_constant_pos.trans_le hB
  have hR : 0 < C.connection.scalarCurvature y := C.scalar_pos y hyC
  rw [← C.connection.scalarCurvature_eq D y]
  by_contra hn
  have hlarge : (B / d) ^ 2 ≤ C.connection.scalarCurvature y := not_lt.mp hn
  have hroot : B / d ≤ Real.sqrt (C.connection.scalarCurvature y) := by
    have hh := Real.sqrt_le_sqrt hlarge
    simpa only [Real.sqrt_sq (div_pos hBpos hd).le] using hh
  have hdiam : B * C.connection.scalarCurvature y ^ (-1 / 2 : ℝ) ≤ d := by
    rw [neg_div, Real.rpow_neg hR.le, ← Real.sqrt_eq_rpow, ← div_eq_mul_inv]
    apply (div_le_iff₀ (Real.sqrt_pos.mpr hR)).mpr
    have hh := (div_le_iff₀ hd).mp hroot
    nlinarith
  have hout (w : M) (hw : d ≤ (g.edist y w).toReal) : w ∉ C.carrier := by
    intro hwC
    have hh := (ENNReal.lt_ofReal_iff_toReal_lt (g.edist_ne_top y w)).mp
      (C.edist_lt_at_point hB hyC hwC)
    exact (not_lt_of_ge hw) (hh.trans_le hdiam)
  exact hexclude C hepsilon D hcomplete hsec hd ha hb ha' hb' hfar hy
    (hout p ha) (hout z hb)

end PoincareMT.CapCertificate
