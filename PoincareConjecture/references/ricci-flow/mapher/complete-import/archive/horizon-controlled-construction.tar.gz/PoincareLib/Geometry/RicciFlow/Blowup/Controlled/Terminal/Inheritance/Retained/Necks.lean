import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Retained.DenseTimes
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Retained.MetricJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Retained.MetricControl
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Sequence.NearbyNecks
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Alternatives
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Canonical.Elimination

/-!
# Nearby necks on actual noncompact retained slices

The frozen dense source alternatives are sampled below the chosen time.
Noncompactness excludes entire compact source components, and actual metric
convergence transports a neck or a cap end neck with its scalar-scale location.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1800000
set_option synthInstance.maxHeartbeats 100000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem exists_nearby_neck_at_retained_time
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    {J : SpacetimeInterval} (G : GeneralizedBlowupConvergence S J.domain)
    (hNC : ¬ IsCompact (univ : Set G.limit.carrier.carrier))
    (hsmall : epsilon < 1 / 200)
    (hround : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold)
    {epsilon' : ℝ} (haccuracy : epsilon < epsilon') (hepsilon' : epsilon' < 1 / 2)
    {a t : ℝ} (hat : a < t) (ht0 : t ≤ 0) (hI : Icc a t ⊆ J.domain)
    (x : G.limit.carrier.carrier)
    (hpositive : ∀ s ∈ Icc a t, 0 < (G.limit.flow.connection s).scalarCurvature x)
    (hxlarge : 4 < (G.limit.flow.connection t).scalarCurvature x) :
    ∃ N : EpsilonNeck (G.limit.flow.metric t),
      N.epsilon = epsilon' ∧ N.connection = G.limit.flow.connection t ∧
      (G.limit.flow.connection t).scalarCurvature x ≤
        2 * max C 1 * (G.limit.flow.connection t).scalarCurvature N.center ∧
      N.center ∈ closure ((G.limit.flow.metric t).ball x
        (2 * max C 1 * ((G.limit.flow.connection t).scalarCurvature x / 2) ^ (-1 / 2 : ℝ))) := by
  classical
  let g := G.limit.flow.metric t
  let D := G.limit.flow.connection t
  have htI : t ∈ Icc a t := ⟨hat.le, le_rfl⟩
  have ht : t ∈ J.domain := hI htI
  have hxpos : 0 < D.scalarCurvature x := (by norm_num : (0 : ℝ) < 4).trans hxlarge
  let l := D.scalarCurvature x / 2
  let u := 2 * D.scalarCurvature x
  have hl : 0 < l := by dsimp [l]; positivity
  have hlx : l < D.scalarCurvature x := by dsimp [l]; linarith
  have hxu : D.scalarCurvature x < u := by dsimp [u]; linarith
  let r := max ((2 * Real.pi + 2 * epsilon⁻¹) * l ^ (-1 / 2 : ℝ) + 1)
    (max C 1 * l ^ (-1 / 2 : ℝ) + 1)
  have hneckradius : (2 * Real.pi + 2 * epsilon⁻¹) * l ^ (-1 / 2 : ℝ) + 1 ≤ r :=
    le_max_left _ _
  have hcapradius : max C 1 * l ^ (-1 / 2 : ℝ) + 1 ≤ r := le_max_right _ _
  have hr : 0 < r := lt_of_lt_of_le (by positivity) hcapradius
  have hcomplete : MetricComplete g := G.limit.complete t ht
  have hbig : IsCompact (closure (g.ball x (2 * r + 1))) :=
    g.isCompact_closure_ball_of_metricComplete hcomplete x (2 * r + 1)
  have hA : IsCompact (closure (g.ball x (2 * r))) :=
    g.isCompact_closure_ball_of_metricComplete hcomplete x (2 * r)
  have hAbig : closure (g.ball x (2 * r)) ⊆ closure (g.ball x (2 * r + 1)) :=
    closure_mono (fun _ hy => hy.trans_le (ENNReal.ofReal_le_ofReal (by linarith)))
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset hbig
  let U := G.exhaustion.space j
  have hU : IsOpen U := G.exhaustion.space_open j
  have hAU : closure (g.ball x (2 * r)) ⊆ U := hAbig.trans hj
  obtain ⟨charts, K, hK, hcharts⟩ := TerminalNeck.exists_finite_compact_chart_cover hA hU hAU
  let q := fun i : charts => i.val.val
  let K' := fun i : charts => K i.val
  have hK' (i : charts) : IsCompact (K' i) ∧
      K' i ⊆ U ∩ (extChartAt (𝓡 3) (q i)).source := hK i.val
  obtain ⟨n, s, hst, hsI, hs, hgood⟩ :=
    H.exists_canonical_times_near_retained_time G hat ht0 hI
  have hn : Tendsto (fun k : ℕ => k + n) atTop atTop := tendsto_add_atTop_nat n
  have hscalarx := (G.tendstoUniformlyOn_movingSource_scalar hn hI hsI htI hst hs
    (isCompact_singleton (x := x))).tendsto_at (mem_singleton x)
  have hscalar : ∀ᶠ k in atTop,
      l ≤ (G.normalizedSourceConnection (k + n) (s k)).scalarCurvature
        ((G.embedding (k + n)).forward (s k) (hs k) x) ∧
      (G.normalizedSourceConnection (k + n) (s k)).scalarCurvature
        ((G.embedding (k + n)).forward (s k) (hs k) x) ≤ u ∧
      4 < (G.normalizedSourceConnection (k + n) (s k)).scalarCurvature
        ((G.embedding (k + n)).forward (s k) (hs k) x) := by
    filter_upwards [hscalarx.eventually (eventually_gt_nhds hlx),
      hscalarx.eventually (eventually_lt_nhds hxu),
      hscalarx.eventually (eventually_gt_nhds hxlarge)] with k hkl hku hk4
    exact ⟨hkl.le, hku.le, hk4⟩
  have hI0 : Icc a t ⊆ Iic 0 := fun _ hz => hz.2.trans ht0
  have hco := hn.eventually (G.eventually_no_controlled_compact_component hNC
    isCompact_Icc hI hI0 x hpositive H.C_pos)
  have hro := hn.eventually (G.eventually_no_round_component hNC
    isCompact_Icc hI hI0 x hpositive hround)
  have hnorm := G.eventually_movingSource_tangentNorm_lower hn isCompact_Icc hI hsI ht
    (fun k => (hsI k).2) hs hbig
  obtain ⟨m, hm⟩ := eventually_atTop.mp
    (hscalar.and (hco.and (hro.and (hnorm.and (hn.eventually (eventually_ge_atTop j))))))
  let idx := fun k => (k + m) + n
  let times := fun k => s (k + m)
  have hidx : Tendsto idx atTop atTop := hn.comp (tendsto_add_atTop_nat m)
  have htimes : Tendsto times atTop (𝓝 t) := hst.comp (tendsto_add_atTop_nat m)
  have htimesI (k : ℕ) : times k ∈ Icc a t := hsI (k + m)
  have htimesE (k : ℕ) : times k ∈ Icc (-G.exhaustion.time (idx k)) 0 := hs (k + m)
  let e := fun k => (G.embedding (idx k)).sliceHomeomorph
    (G.exhaustion.space_open (idx k)) (times k) (htimesE k)
  have hall (k : ℕ) := hm (k + m) (Nat.le_add_left m k)
  have hcanonical (k : ℕ) :
      (∃ N : EpsilonNeck (G.normalizedSourceMetric (idx k) (times k)),
        N.epsilon = epsilon ∧ N.center = e k x ∧
          N.connection = G.normalizedSourceConnection (idx k) (times k)) ∨
      ∃ N : CapCertificate (G.normalizedSourceMetric (idx k) (times k)),
        N.epsilon = epsilon ∧ N.cap_constant ≤ max C 1 ∧ e k x ∈ N.core ∧
          N.connection = G.normalizedSourceConnection (idx k) (times k) := by
    have habsolute : 4 * S.scale (G.subsequence (idx k)) ≤
        (S.flow (G.subsequence (idx k))).scalar
          ⟨(S.base (G.subsequence (idx k))).1 + times k / S.scale (G.subsequence (idx k)), e k x⟩ := by
      have hh := (hall k).1.2.2.le
      simp only [GeneralizedBlowupConvergence.normalizedSourceConnection,
        rescaledMetric_scalarCurvature] at hh
      change 4 ≤ (S.scale (G.subsequence (idx k)))⁻¹ * _ at hh
      have hq : 0 < S.scale (G.subsequence (idx k)) := S.base_scalar_pos _
      have hmul := mul_le_mul_of_nonneg_left hh hq.le
      rw [← mul_assoc, mul_inv_cancel₀ hq.ne', one_mul] at hmul
      simpa only [idx, times, e, GeneralizedRicciFlowData.scalar,
        GeneralizedFlowCylinder.sliceHomeomorph_apply, mul_comm] using hmul
    obtain ⟨can⟩ := hgood (k + m) (e k x) habsolute
    rcases can.normalized_spatial_alternatives (hsmall.trans (by norm_num))
      (S.scale (G.subsequence (idx k))) (S.base_scalar_pos (G.subsequence (idx k)))
      with hn | hc | hcompact | hround
    · exact Or.inl hn
    · obtain ⟨N, hNe, hNC, hNx, hND⟩ := hc
      exact Or.inr ⟨N, hNe, hNC.trans (le_max_left _ _), hNx, hND⟩
    · obtain ⟨N, hNx⟩ := hcompact
      exact ((hall k).2.1 (times k) (htimesI k) (htimesE k) N hNx).elim
    · obtain ⟨N, hNx⟩ := hround
      exact ((hall k).2.2.1 (times k) (htimesI k) (htimesE k) N hNx).elim
  apply ControlledTerminal.exists_nearby_terminal_neck_of_convergent_canonical_alternatives
    g D (fun k => G.normalizedSourceMetric (idx k) (times k))
    (fun k => G.normalizedSourceConnection (idx k) (times k)) hcomplete e
    (fun k => (G.embedding (idx k)).forward_smooth (times k) (htimesE k))
    (fun k => (G.embedding (idx k)).inverse_smooth (times k) (htimesE k))
    hU (fun k => G.exhaustion.space_increasing (hall k).2.2.2.2)
    x hxpos H.epsilon_pos hsmall haccuracy hepsilon' (le_max_right C 1) hl
    (by dsimp [u]; positivity) (fun k => ⟨(hall k).1.1, (hall k).1.2.1⟩)
    hneckradius hcapradius hj (fun k => (hall k).2.2.2.1) hcanonical
    Finset.univ q K' (fun i _ => hK' i)
    (fun y hy => by
      obtain ⟨i, hi, hyi⟩ := hcharts y hy
      exact ⟨⟨i, hi⟩, Finset.mem_univ _, hyi⟩)
  · intro i _ order
    apply G.tendstoUniformlyOn_movingSourceMetric_bilinear_jets hidx isCompact_Icc hI
      htimesI htI htimes htimesE (q i)
    · exact (hK' i).1.image_of_continuousOn
        ((continuousOn_extChartAt (q i)).mono (fun y hy => ((hK' i).2 hy).2))
    · rintro z ⟨y, hy, rfl⟩
      exact (extChartAt (𝓡 3) (q i)).map_source ((hK' i).2 hy).2
  · exact G.tendstoUniformlyOn_movingSource_scalar hidx hI htimesI htI htimes htimesE hA

end PoincareMT.M30CommonBlowupControls
