import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.LocalNullLine
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NullPullback
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NullBound
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NeckLift
import PoincareLib.Geometry.Riemannian.Covering.Completeness
import PoincareLib.Topology.Manifold.NeckCap.Fibration.UniversalCover

/-!
# A scalar bound from a local terminal null line and one small neck

Lift the complete metric and its local parallel null line to the actual
universal cover. The resulting global parallel coordinate constructs a line
product. The lifted neck makes the transverse factor compact, and the scalar
bound descends through the surjective covering projection.

Reference: Morgan--Tian, Claim 11.7, p. 271.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle

universe u

namespace PoincareMT.RicciFlow.Splitting

/-- The local sections may come from point-dependent backward intervals.
The cover, product and compact transverse factor are all constructed. -/
theorem exists_local_null_neck_scalar_bound_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 200 ∧
      ∀ (M : Type u) [TopologicalSpace M] [T2Space M] [T3Space M] [ConnectedSpace M]
        [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
        [MeasurableSpace M] [BorelSpace M],
      ∀ (g : RiemannianMetric 3 M) (D : LeviCivitaData g),
        MetricComplete g → (∀ y : M, ricciNullity D y = 1) →
        (∀ p : UnitRicciKernel D,
          ∃ (U : Set M) (V : (y : M) → TangentSpace (𝓡 3) y),
            IsOpen U ∧ p.1.proj ∈ U ∧
            ContMDiffOn (𝓡 3) ((𝓡 3).prod (𝓡 3)) ∞ (T% V) U ∧
            V p.1.proj = p.1.snd ∧
            ∀ y ∈ U, g.inner y (V y) (V y) = 1 ∧
              (∀ w, D.ricci y (V y) w = 0) ∧ ∀ w, D.connection V y w = 0) →
      ∀ N : EpsilonNeck g, N.epsilon ≤ epsilon₀ →
        ∃ B : ℝ, 0 < B ∧ ∀ y : M, D.scalarCurvature y ≤ B := by
  obtain ⟨epsilon₀, hpos, hsmall, hbound⟩ :=
    RiemannianMetric.exists_parallel_potential_neck_scalar_bound_threshold.{u}
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro M _ _ _ _ _ _ _ _ g D hcomplete hdim hlocal N hN
  let : LocallyPathConnectedSpace M :=
    ChartedSpace.locallyPathConnectedSpace (EuclideanSpace ℝ (Fin 3)) M
  let : PathConnectedSpace M := PathConnectedSpace.of_locallyPathConnectedSpace
  let : Poincare.Topology.SemilocallySimplyConnectedSpace M :=
    Poincare.Topology.semilocallySimplyConnectedSpace_of_chartedSpace 3 M
  let E := Poincare.Topology.UniversalCover N.center
  let := Poincare.Topology.UniversalCover.chartedSpace N.center
  let := Poincare.Topology.UniversalCover.isManifold N.center
  let := Poincare.Topology.UniversalCover.t2Space N.center
  let := Poincare.Topology.UniversalCover.t3Space N.center
  let : MeasurableSpace E := borel E
  let : BorelSpace E := ⟨rfl⟩
  let projection : E → M := Poincare.Topology.UniversalCover.proj
  have hcover : IsCoveringMap projection := Poincare.Topology.UniversalCover.isCoveringMap N.center
  have hprojection : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ projection :=
    Poincare.Topology.UniversalCover.isLocalDiffeomorph N.center
  have hsurj : Function.Surjective projection :=
    Poincare.Topology.UniversalCover.surjective_proj N.center
  let G := g.pullbackOfLocalDiffeomorph projection hprojection
  let DG := G.leviCivitaData
  have hmetric (x : E) (v w : TangentSpace (𝓡 3) x) :
      G.inner x v w = g.inner (projection x)
        (mfderiv (𝓡 3) (𝓡 3) projection x v)
        (mfderiv (𝓡 3) (𝓡 3) projection x w) := rfl
  have hcompleteG : MetricComplete G :=
    RiemannianMetric.metricComplete_of_isCoveringMap
      G g hprojection.contMDiff hcover hmetric hcomplete
  have hdimG (x : E) : ricciNullity DG x = 1 :=
    (ricciNullity_eq_of_local_metric_pullback DG D hprojection hmetric x).trans
      (hdim (projection x))
  obtain ⟨z, hz⟩ := hsurj N.center
  obtain ⟨L, hepsilon, _, _, _⟩ :=
    N.exists_lifted_neck_of_covering hcover hprojection z hz
  obtain ⟨f, hf, _, hu, hessian⟩ :=
    exists_parallel_potential_of_simplyConnected_local_null_sections DG hdimG
      (exists_local_parallel_null_section_of_local_metric_pullback
        DG D hprojection hmetric hlocal) z
  obtain ⟨B, hB, hscalar⟩ :=
    hbound E G DG f hcompleteG hf hu hessian L (hepsilon.trans_le hN)
  refine ⟨B, hB, ?_⟩
  intro x
  obtain ⟨y, rfl⟩ := hsurj x
  have hcurv := DG.scalarCurvature_eq_of_local_isometry D isOpen_univ
    hprojection.contMDiff.contMDiffOn (fun z _ => hmetric z) (mem_univ y)
  exact hcurv.symm.trans_le (hscalar y)

end PoincareMT.RicciFlow.Splitting
