import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Positive
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Neck.Spatial

/-!
# Global terminal scalar bounds from generalized canonical control

On a connected slice the compact component alternatives imply compactness of
the whole slice. Otherwise actual strong-neck and cap certificates supply the
neck/cap cover needed by the positive-curvature bound.

Reference: Morgan--Tian, Claim 11.7, p. 271.
-/

set_option autoImplicit false

open Set
open scoped Manifold ContDiff

universe u

namespace PoincareMT.GeneralizedCanonicalControl

/-- Positive curvature and canonical control above a scalar threshold give a
global scalar bound, with the accuracy threshold independent of the flow. -/
theorem exists_universal_positive_scalar_bound_threshold :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ < 1 / 2 ∧
      ∀ (F : GeneralizedRicciFlowData.{u}) (t : ℝ)
        [ConnectedSpace (F.slice t).carrier],
        MetricComplete (F.metric t) →
        (F.connection t).StrictlyPositiveSectionalCurvature →
      ∀ epsilon C cutoff : ℝ, 0 < epsilon → epsilon ≤ epsilon₀ →
        (∀ x : (F.slice t).carrier, cutoff < (F.connection t).scalarCurvature x →
          GeneralizedCanonicalControl t x epsilon C) →
        ∃ B : ℝ, 0 < B ∧
          ∀ x : (F.slice t).carrier, (F.connection t).scalarCurvature x ≤ B := by
  classical
  obtain ⟨epsilon₀, hpos, hhalf, hbound⟩ :=
    RiemannianMetric.exists_universal_neck_cap_scalar_bound_threshold.{u}
  refine ⟨epsilon₀, hpos, hhalf, ?_⟩
  intro F t _ hcomplete hpositive epsilon C cutoff hepsilon hsmall hcanonical
  by_cases hcompact : CompactSpace (F.slice t).carrier
  · let : CompactSpace (F.slice t).carrier := hcompact
    obtain ⟨B, hB⟩ := isCompact_univ.bddAbove_image
      (F.connection t).continuous_scalarCurvature.continuousOn
    exact ⟨max 1 B, lt_of_lt_of_le zero_lt_one (le_max_left _ _),
      fun x => (hB (mem_image_of_mem _ (mem_univ x))).trans (le_max_right _ _)⟩
  · apply hbound (F.slice t).carrier (F.metric t) (F.connection t)
      hcomplete hpositive epsilon C cutoff hepsilon hsmall
    intro x hx
    cases hcanonical x hx with
    | neck N hcenter =>
      exact Or.inl ⟨N.spatialNeck (hsmall.trans_lt hhalf), rfl, hcenter⟩
    | cap N heq hC _ hcore =>
      exact Or.inr ⟨N, heq, hC, hcore⟩
    | component N _ =>
      apply False.elim (hcompact ?_)
      apply isCompact_univ_iff.mp
      simpa only [N.component_eq, PreconnectedSpace.connectedComponent_eq_univ]
        using N.compact
    | round N _ =>
      apply False.elim (hcompact ?_)
      apply isCompact_univ_iff.mp
      simpa only [N.component_eq, PreconnectedSpace.connectedComponent_eq_univ]
        using N.compact

end PoincareMT.GeneralizedCanonicalControl
