import PoincareLib.Geometry.Riemannian.Comparison.Toponogov.Triangle

/-!
# Transverse chords in large triangles

Corresponding-side Toponogov comparison prevents two long minimizing sides
of a quantitatively nondegenerate triangle from passing through a small
common transverse region. The two transverse points may occur at different
arclengths, as happens at first exits from a neck.

Reference: Morgan--Tian, Claim 11.14, in the proof of Claim 11.13.
-/

noncomputable section
set_option autoImplicit false

open Set
open scoped Manifold ContDiff Bundle

namespace PoincareMT.ControlledTerminal

/-- The algebraic form of the corresponding-side obstruction. -/
theorem transverse_chord_sq_gt_of_comparison
    {a b c d r t v : ℝ} (hd : 0 < d) (ha : d ≤ a) (hb : d ≤ b)
    (ha' : a ≤ 3 * d / 2) (hb' : b ≤ 3 * d / 2)
    (hc : d ≤ c) (hr : 0 < r) (ht : 0 < t)
    (hcomparison : r ^ 2 + t ^ 2 -
      2 * r * t * ((a ^ 2 + b ^ 2 - c ^ 2) / (2 * a * b)) ≤ v ^ 2) :
    r * t / 4 < v ^ 2 := by
  have ha0 : 0 < a := hd.trans_le ha
  have hb0 : 0 < b := hd.trans_le hb
  have hab : 0 < a * b := mul_pos ha0 hb0
  have hrt : 0 < r * t := mul_pos hr ht
  have hrewrite :
      2 * r * t * ((a ^ 2 + b ^ 2 - c ^ 2) / (2 * a * b)) =
        r * t * (a ^ 2 + b ^ 2 - c ^ 2) / (a * b) := by
    field_simp
  rw [hrewrite] at hcomparison
  have hmul : (r ^ 2 + t ^ 2 - v ^ 2) * (a * b) ≤
      r * t * (a ^ 2 + b ^ 2 - c ^ 2) :=
    (le_div_iff₀ hab).mp (by linarith)
  have hchord : r * t * c ^ 2 ≤
      a * b * v ^ 2 + r * t * (a - b) ^ 2 := by
    nlinarith [mul_nonneg hab.le (sq_nonneg (r - t))]
  have hdiff : (a - b) ^ 2 ≤ d ^ 2 / 4 := by
    have hneg : -(d / 2) ≤ a - b := by linarith
    have hpos : a - b ≤ d / 2 := by linarith
    nlinarith [mul_nonneg (sub_nonneg.mpr hpos) (sub_nonneg.mpr hneg)]
  have hprod : a * b ≤ 9 * d ^ 2 / 4 := by
    have h := mul_le_mul ha' hb' hb0.le (by positivity : 0 ≤ 3 * d / 2)
    nlinarith
  have hc2 : d ^ 2 ≤ c ^ 2 := sq_le_sq₀ hd.le (hd.le.trans hc) |>.mpr hc
  by_contra hnot
  have hv : v ^ 2 ≤ r * t / 4 := le_of_not_gt hnot
  have hupper : r * t * c ^ 2 ≤ r * t * (13 * d ^ 2 / 16) := calc
    _ ≤ a * b * (r * t / 4) + r * t * (d ^ 2 / 4) :=
      hchord.trans (add_le_add (mul_le_mul_of_nonneg_left hv hab.le)
        (mul_le_mul_of_nonneg_left hdiff hrt.le))
    _ ≤ (9 * d ^ 2 / 4) * (r * t / 4) + r * t * (d ^ 2 / 4) :=
      add_le_add (mul_le_mul_of_nonneg_right hprod
        (show 0 ≤ r * t / 4 by positivity)) le_rfl
    _ = _ := by ring
  have hcancel := le_of_mul_le_mul_left hupper hrt
  nlinarith [sq_pos_of_pos hd]

end PoincareMT.ControlledTerminal

namespace PoincareMT.RiemannianMetric

variable {n : ℕ} {M : Type*} [TopologicalSpace M] [T3Space M]
  [ConnectedSpace M] [ChartedSpace (EuclideanSpace ℝ (Fin n)) M]
  [IsManifold (𝓡 n) ∞ M]

/-- A small transverse chord is impossible in a large nonnegative-curvature
triangle whose two radial side lengths differ by at most half their scale. -/
theorem transverse_chord_sq_gt_of_large_triangle
    (g : RiemannianMetric n M) (D : LeviCivitaData g)
    (hcomplete : MetricComplete g) (hsec : D.NonnegativeSectionalCurvature)
    {γ σ : ℝ → M} {p : M} {a b d : ℝ} (hd : 0 < d)
    (ha : d ≤ a) (hb : d ≤ b) (ha' : a ≤ 3 * d / 2) (hb' : b ≤ 3 * d / 2)
    (hfar : d ≤ (g.edist (γ a) (σ b)).toReal)
    (hγ : g.IsGeodesicOn γ (Icc 0 a)) (hσ : g.IsGeodesicOn σ (Icc 0 b))
    (hγ0 : γ 0 = p) (hσ0 : σ 0 = p)
    (hγspeed : ∀ s ∈ Icc 0 a,
      g.tangentNorm (γ s) (mfderiv 𝓘(ℝ, ℝ) (𝓡 n) γ s 1) = 1)
    (hσspeed : ∀ s ∈ Icc 0 b,
      g.tangentNorm (σ s) (mfderiv 𝓘(ℝ, ℝ) (𝓡 n) σ s 1) = 1)
    (hγmin : ∀ s ∈ Icc 0 a, ∀ t ∈ Icc 0 a,
      g.edist (γ s) (γ t) = ENNReal.ofReal |s - t|)
    (hσmin : ∀ s ∈ Icc 0 b, ∀ t ∈ Icc 0 b,
      g.edist (σ s) (σ t) = ENNReal.ofReal |s - t|)
    {r t : ℝ} (hr : r ∈ Ioc 0 a) (ht : t ∈ Ioc 0 b) :
    r * t / 4 < (g.edist (γ r) (σ t)).toReal ^ 2 := by
  apply ControlledTerminal.transverse_chord_sq_gt_of_comparison hd ha hb ha' hb'
    hfar hr.1 ht.1
  exact g.toponogov_corresponding_side D hcomplete hsec (hd.trans_le ha)
    (hd.trans_le hb) hγ hσ hγ0 hσ0 hγspeed hσspeed hγmin hσmin
    r ⟨hr.1.le, hr.2⟩ t ⟨ht.1.le, ht.2⟩

end PoincareMT.RiemannianMetric
