import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Carrier

/-!
# Terminal source jets converge to the actual extended flow
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)

include hF

/-- Every source-derived closed coefficient limit is the metric of the
actual extension, including the included terminal slice. -/
theorem terminal_coefficients_eqOn_actualFlow
    (q : G.limitCarrier.carrier) {x₀ : EuclideanSpace ℝ (Fin 3)} {ρ : ℝ} (hρ : 0 < ρ)
    (hchart : closedBall x₀ ρ ⊆ (extChartAt (𝓡 3) q).target)
    (C : ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3)
    (hC : ContDiffOn ℝ ∞ C (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ))
    (hinterior : ∀ m, EqOn
      (iteratedFDeriv ℝ m (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (G.limitFlow.metricAt z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2))
      (iteratedFDerivWithin ℝ m C (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ))
      (Ioo 0 (T / 2) ×ˢ ball x₀ ρ)) :
    EqOn C (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
      (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)
      (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ) := by
  let D := fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
    (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2
  have hD : ContDiffOn ℝ ∞ D (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ) :=
    (F.contDiffOn_pullbackCoefficients_within (isOpen_extChartAt_target q)
      (contMDiffOn_extChartAt_symm (n := ∞) q)).mono
        (prod_mono (fun _ ht => ⟨by linarith [ht.1], ht.2⟩) hchart)
  have hEq : EqOn C D (Ioo 0 (T / 2) ×ˢ ball x₀ ρ) := by
    intro z hz
    have h := hinterior 0 hz
    have hval := congrArg (fun L => L (0 : Fin 0 → ℝ × EuclideanSpace ℝ (Fin 3))) h
    simp only [iteratedFDeriv_zero_apply, iteratedFDerivWithin_zero_apply] at hval
    dsimp only [D]
    rw [hF z.1 ⟨by linarith [hz.1.1], hz.1.2⟩]
    exact hval.symm
  apply hEq.of_subset_closure hC.continuousOn hD.continuousOn
    (prod_mono Ioo_subset_Icc_self ball_subset_closedBall)
  rw [closure_prod_eq, closure_Ioo (show 0 ≠ T / 2 by linarith), closure_ball x₀ hρ.ne']

/-- All canonical closed-slab bilinear jets of the retained sources converge
uniformly to those of the actual terminal extension. -/
theorem tendstoUniformlyOn_terminal_bilinearJet_on_closedBall
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier) {x₀ : EuclideanSpace ℝ (Fin 3)} {ρ : ℝ} (hρ : 0 < ρ)
    (hchart : closedBall x₀ ρ ⊆ (extChartAt (𝓡 3) q).target) (m : ℕ) :
    TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ m (G.spatialSpacetimeCoefficients q k)
        (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ))
      (iteratedFDerivWithin ℝ m
        (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
          (F.metric z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2)
        (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ)) atTop
      (Icc 0 (T / 2) ×ˢ closedBall x₀ ρ) := by
  obtain ⟨C, hC, hinterior, hconv⟩ := exists_smooth_terminal_source_coefficients
    G P04 hB hAr hcompact hcomplete q hρ hchart
  have heq := terminal_coefficients_eqOn_actualFlow G F hF q hρ hchart C hC hinterior
  exact (hconv m).congr_right fun z hz => iteratedFDerivWithin_congr heq hz m

end PoincareMT.ControlledBlowupCompactness
