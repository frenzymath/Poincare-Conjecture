import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.NeighborhoodCapture

/-! # Fixed compact capture of necks with controlled center drift -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology ENNReal

namespace PoincareMT.ControlledBlowupBoundary

theorem neck_carrier_subset_fixed_ball_of_center_control
    {M : Type*} [TopologicalSpace M] [T2Space M] [T3Space M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    [MeasurableSpace M] [BorelSpace M]
    (g h : RiemannianMetric 3 M) (hcomplete : MetricComplete g)
    (N : EpsilonNeck h) (p : M) {l A r : ℝ} (hl : 0 < l) (hA : 0 ≤ A) (hr : 0 < r)
    (hscalar : l ≤ N.connection.scalarCurvature N.center)
    (hcenter : h.edist p N.center ≤ ENNReal.ofReal A)
    (hradius : A + (2 * Real.pi + 2 * N.epsilon⁻¹) * l ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hbound : ∀ x ∈ closure (g.ball p (2 * r + 1)), ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ 2 * h.tangentNorm x v) :
    N.carrier ⊆ closure (g.ball p (2 * r)) := by
  have hball : N.carrier ⊆ h.ball p r := by
    intro x hx
    exact (N.closure_carrier_subset_ball_of_scalar_lower hl hA hscalar p hcenter
      (subset_closure hx)).trans_le (ENNReal.ofReal_le_ofReal hradius)
  have hcapture := ControlledTerminal.compact_capture_of_inverse_tangent_control
    g h hcomplete (OpenPartialHomeomorph.refl M) contMDiffOn_id contMDiffOn_id p hr
    (subset_univ _) (by
      intro x hx v
      change g.tangentNorm x v ≤ 2 * h.tangentNorm x
        (mfderiv (𝓡 3) (𝓡 3) (id : M → M) x v)
      rw [mfderiv_id]
      exact hbound x hx v) hball
  intro x hx
  exact hcapture.2 (mem_image_of_mem _ hx)

theorem neck_closure_subset_fixed_ball_of_center_control
    {M : Type*} [TopologicalSpace M] [T2Space M] [T3Space M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    [MeasurableSpace M] [BorelSpace M]
    (g h : RiemannianMetric 3 M) (hcomplete : MetricComplete g)
    (N : EpsilonNeck h) (p : M) {l A r : ℝ} (hl : 0 < l) (hA : 0 ≤ A) (hr : 0 < r)
    (hscalar : l ≤ N.connection.scalarCurvature N.center)
    (hcenter : h.edist p N.center ≤ ENNReal.ofReal A)
    (hradius : A + (2 * Real.pi + 2 * N.epsilon⁻¹) * l ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hbound : ∀ x ∈ closure (g.ball p (2 * r + 1)), ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ 2 * h.tangentNorm x v) :
    closure N.carrier ⊆ closure (g.ball p (2 * r)) :=
  closure_minimal
    (neck_carrier_subset_fixed_ball_of_center_control g h hcomplete N p
      hl hA hr hscalar hcenter hradius hbound) isClosed_closure

theorem neck_closure_subset_fixed_ball_of_scalar_drift
    {M : Type*} [TopologicalSpace M] [T2Space M] [T3Space M] [ConnectedSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    [MeasurableSpace M] [BorelSpace M]
    (g h : RiemannianMetric 3 M) (hcomplete : MetricComplete g)
    (N : EpsilonNeck h) (p : M) {l C r : ℝ} (hl : 0 < l) (hC : 0 < C)
    (hpoint : l ≤ N.connection.scalarCurvature p)
    (hratio : N.connection.scalarCurvature p ≤ C * N.connection.scalarCurvature N.center)
    (hcenter : (h.edist p N.center).toReal ≤
      C * N.connection.scalarCurvature p ^ (-1 / 2 : ℝ))
    (hradius : C * l ^ (-1 / 2 : ℝ) +
      (2 * Real.pi + 2 * N.epsilon⁻¹) * (l / C) ^ (-1 / 2 : ℝ) + 1 ≤ r)
    (hbound : ∀ x ∈ closure (g.ball p (2 * r + 1)), ∀ v : TangentSpace (𝓡 3) x,
      g.tangentNorm x v ≤ 2 * h.tangentNorm x v) :
    l / C ≤ N.connection.scalarCurvature N.center ∧
      closure N.carrier ⊆ closure (g.ball p (2 * r)) := by
  have hscalar : l / C ≤ N.connection.scalarCurvature N.center :=
    (div_le_iff₀ hC).mpr (by simpa only [mul_comm] using hpoint.trans hratio)
  have hA : 0 ≤ C * l ^ (-1 / 2 : ℝ) := by positivity
  have hdist : h.edist p N.center ≤ ENNReal.ofReal (C * l ^ (-1 / 2 : ℝ)) := by
    have hle := hcenter.trans (mul_le_mul_of_nonneg_left
      (Real.rpow_le_rpow_of_nonpos hl hpoint (by norm_num)) hC.le)
    rw [← ENNReal.ofReal_toReal (h.edist_ne_top p N.center)]
    exact ENNReal.ofReal_le_ofReal hle
  have hr : 0 < r := lt_of_lt_of_le
    (by positivity [Real.pi_pos, N.epsilon_pos]) hradius
  exact ⟨hscalar, neck_closure_subset_fixed_ball_of_center_control g h hcomplete N p
    (div_pos hl hC) hA hr hscalar hdist hradius hbound⟩

/-- The boundary capture radius is chosen before the varying old metric
and its neck. The larger ball is used only for the local tensor comparison. -/
theorem exists_fixed_neck_capture_radius
    {M : Type*} [TopologicalSpace M] [T2Space M] [T3Space M] [ConnectedSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    [MeasurableSpace M] [BorelSpace M]
    (g : RiemannianMetric 3 M) (hcomplete : MetricComplete g) (p : M)
    {epsilon l C : ℝ} (hepsilon : 0 < epsilon) (hl : 0 < l) (hC : 0 < C) :
    ∃ r : ℝ, 0 < r ∧
      ∀ (h : RiemannianMetric 3 M) (N : EpsilonNeck h), N.epsilon = epsilon →
        l ≤ N.connection.scalarCurvature p →
        N.connection.scalarCurvature p ≤ C * N.connection.scalarCurvature N.center →
        (h.edist p N.center).toReal ≤ C * N.connection.scalarCurvature p ^ (-1 / 2 : ℝ) →
        (∀ x ∈ closure (g.ball p (2 * r + 1)), ∀ v : TangentSpace (𝓡 3) x,
          g.tangentNorm x v ≤ 2 * h.tangentNorm x v) →
        l / C ≤ N.connection.scalarCurvature N.center ∧
          closure N.carrier ⊆ closure (g.ball p (2 * r)) := by
  let r := C * l ^ (-1 / 2 : ℝ) +
    (2 * Real.pi + 2 * epsilon⁻¹) * (l / C) ^ (-1 / 2 : ℝ) + 1
  have hr : 0 < r := by dsimp [r]; positivity [Real.pi_pos]
  refine ⟨r, hr, ?_⟩
  intro h N hNe hpoint hratio hcenter hbound
  exact neck_closure_subset_fixed_ball_of_scalar_drift g h hcomplete N p hl hC
    hpoint hratio hcenter (by rw [hNe]) hbound

end PoincareMT.ControlledBlowupBoundary
