import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.AncientVolume.ScalarRatio.Annular.SpacetimeBounds
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.NeckTransfer.SpatialJets

/-!
# Compact-uniform spatial jets at a terminal time

Joint within-domain smoothness of the actual Ricci-flow metric makes its
spatial jets continuous through the included terminal slice. Compactness
then gives uniform terminal continuity in each fixed smooth source chart.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12

open Set Filter Metric
open scoped Manifold ContDiff Topology

namespace PoincareMT.RicciFlow

local notation "E" => EuclideanSpace ℝ (Fin 3)

theorem tendstoUniformlyOn_spatialMetricJets_at_terminal
    {M : Type*} [TopologicalSpace M] [ChartedSpace E M] [IsManifold (𝓡 3) ∞ M]
    {T : ℝ} (hT : 0 < T) (F : RicciFlow 3 M (Icc (-T) 0))
    {U K : Set E} (hU : IsOpen U) (hK : IsCompact K) (hKU : K ⊆ U)
    (e : E → M) (he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ e U) (m : ℕ) :
    TendstoUniformlyOn
      (fun s => iteratedFDeriv ℝ m ((F.metric s).pullbackCoefficients e))
      (iteratedFDeriv ℝ m ((F.metric 0).pullbackCoefficients e))
      (𝓝[Icc (-T) 0] 0) K := by
  let J : SpacetimeInterval := ⟨Icc (-T) 0, ordConnected_Icc,
    ⟨-T, ⟨le_rfl, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩⟩
  let f := fun z : ℝ × E => (F.metric z.1).pullbackCoefficients e z.2
  have hf : ContDiffOn ℝ ∞ f (J.domain ×ˢ U) :=
    F.contDiffOn_pullbackCoefficients_within hU he
  let P := ContinuousMultilinearMap.compContinuousLinearMapL
    (𝕜 := ℝ) (F := E →L[ℝ] E →L[ℝ] ℝ)
    (fun _ : Fin m => ContinuousLinearMap.inr ℝ ℝ E)
  have huniq := (Poincare.Spacetime.Realization.interval_uniqueDiffOn J).prod hU.uniqueDiffOn
  have hm : (m : ℕ∞ω) ≤ ∞ := WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤)
  have hcont : ContinuousOn (fun z : ℝ × E =>
      iteratedFDeriv ℝ m ((F.metric z.1).pullbackCoefficients e) z.2) (J.domain ×ˢ U) := by
    apply (P.continuous.comp_continuousOn (hf.continuousOn_iteratedFDerivWithin hm huniq)).congr
    intro z hz
    exact DeepHorn.iteratedFDeriv_spatial_slice_of_interval J hU f hf hz.1 hz.2 m
  have huc := (isCompact_Icc.prod hK).uniformContinuousOn_of_continuous
    (hcont.mono (prod_mono subset_rfl hKU))
  exact huc.tendstoUniformlyOn (show (0 : ℝ) ∈ Icc (-T) 0 from ⟨by linarith, le_rfl⟩)

end PoincareMT.RicciFlow
