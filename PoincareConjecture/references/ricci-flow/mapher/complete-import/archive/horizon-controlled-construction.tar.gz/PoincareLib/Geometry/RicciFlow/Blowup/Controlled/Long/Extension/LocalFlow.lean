import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.LocalSequence
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Coefficients
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Flow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.PinchingLimit

/-!
# Local backward extensions of the actual finite-horizon limit

The extensions agree with the existing limit at every overlapping time.
Their nonnegative curvature and source convergence hold on a closed interval
strictly crossing the old past endpoint.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_local_backward_extension_of_compact_scalar_bounds
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u})
    {epsilon C kappa r₀ mu : ℝ} {T₀ : ℝ≥0∞}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    (horizon : ENNReal.ofReal T < T₀)
    (hcompact : ∀ K : Set G.limit.carrier.carrier, IsCompact K →
      ∃ D : ℝ, ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
        (G.limit.flow.connection t).scalarCurvature x ≤ D)
    (q : G.limit.carrier.carrier) :
    ∃ rho V : ℝ, 0 < rho ∧ T < V ∧
      ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target ∧
      let U : Opens (EuclideanSpace ℝ (Fin 3)) :=
        ⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩
      ∃ F : RicciFlow 3 U (Icc (-V) 0),
        (∀ t ∈ Icc (-V) 0, ∀ x : U, (F.connection t).NonnegativeCurvatureOperator x) ∧
        ∀ t ∈ Ioc (-T) 0, ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
          (F.metric t).inner x v w = (G.limit.flow.metric t).pullbackCoefficients
            (extChartAt (𝓡 3) q).symm x v w := by
  obtain ⟨rho, R, A, V, B, hrho, hR, hRA, hTV, hB, hchart,
    tau, htau, cyl, Phi, hcompact', hsource, hcapture, hconv⟩ :=
    G.exists_local_extended_source_sequence hT P04 H horizon hcompact q
  have hV : 0 < V := hT.trans hTV
  let V' := (T + V) / 2
  have hTV' : T < V' := by dsimp [V']; linarith
  have hV'V : V' < V := by dsimp [V']; linarith
  have hV' : 0 < V' := hT.trans hTV'
  have hKc : closedBall (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target :=
    (closedBall_subset_closedBall (by linarith : rho ≤ 2 * rho)).trans hchart
  have heta : Tendsto (fun i : ℕ => (((i : ℝ) + 1)⁻¹)) atTop (𝓝 0) := by
    simpa only [one_div] using (tendsto_one_div_add_atTop_nhds_zero_nat (𝕜 := ℝ))
  obtain ⟨sigma, hsigma, b, F, hb, hF, _hzero, hnonneg, hjets⟩ :=
    ControlledTerminal.exists_local_backward_flow_on_subwindow P04 (G.limit.flow.metric 0) q
      hrho hR hRA hV hV' hV'V hB.le hKc cyl Phi hcompact' hsource
      (fun k z hz => (hcapture k z hz).2) (hconv hV) heta
  refine ⟨rho, V', hrho, hTV', ball_subset_closedBall.trans hKc, F, hnonneg, ?_⟩
  intro t ht x v w
  have htV' : t ∈ Icc (-V') 0 := ⟨by linarith [ht.1], ht.2⟩
  have htV : t ∈ Icc (-V) 0 := ⟨by linarith [ht.1], ht.2⟩
  rw [hF t htV' x v w]
  have hpoint : Tendsto (fun k => (((cyl (sigma k)).ordinaryFlow hV).metric t).pullbackCoefficients
      (Phi (sigma k)) x) atTop (𝓝 (b (t, x))) := by
    have hvalue := (ContinuousMultilinearMap.uniformContinuous_eval_const
      (𝕜 := ℝ) (0 : Fin 0 → ℝ × EuclideanSpace ℝ (Fin 3))).comp_tendstoUniformlyOn (hjets 0)
    simpa only [Function.comp_apply, iteratedFDerivWithin_zero_apply] using
      hvalue.tendsto_at (x := (t, (x : EuclideanSpace ℝ (Fin 3))))
        ⟨htV', ball_subset_closedBall x.property⟩
  have hmetric : b (t, x) = (G.limit.flow.metric t).pullbackCoefficients
      (extChartAt (𝓡 3) q).symm x := by
    apply ContinuousLinearMap.coe_injective
    apply (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis.ext
    intro a
    apply ContinuousLinearMap.coe_injective
    apply (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis.ext
    intro b'
    have heval := ((ContinuousLinearMap.apply ℝ ℝ (EuclideanSpace.basisFun (Fin 3) ℝ b')).continuous.tendsto _).comp
      (((ContinuousLinearMap.apply ℝ (EuclideanSpace ℝ (Fin 3) →L[ℝ] ℝ)
        (EuclideanSpace.basisFun (Fin 3) ℝ a)).continuous.tendsto _).comp hpoint)
    let J : SpacetimeInterval := ⟨Ioc (-T) 0, ordConnected_Ioc,
      ⟨-T / 2, ⟨by linarith, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩⟩
    have hretained := G.controlledCylinder_chart_entry_tendsto (J := J)
      (htau.tendsto_atTop.comp hsigma.tendsto_atTop)
      (fun k => cyl (sigma k)) hV q (fun k => Phi (sigma k))
      (fun k z hz => (hcapture (sigma k) z hz).1) ht htV
      (fun k => by
        rw [hsource (sigma k)]
        exact ball_subset_ball (by linarith : rho ≤ 2 * rho) x.property)
      (hKc (ball_subset_closedBall x.property)) a b'
    exact tendsto_nhds_unique heval hretained
  exact congrArg (fun Q => Q v w) hmetric

end PoincareMT.GeneralizedBlowupConvergence
