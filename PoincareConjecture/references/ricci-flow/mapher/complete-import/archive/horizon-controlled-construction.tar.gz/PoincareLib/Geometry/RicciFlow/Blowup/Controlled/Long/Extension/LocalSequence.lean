import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Charts
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Cylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.TerminalJets
import PoincareLib.Topology.Sequences.Diagonal

/-!
# Controlled source sequences extending one retained coordinate neighborhood

Each selected chart uses the original zero-time convergence map. Its controlled
source cylinders extend strictly beyond the old finite horizon, leaving a
positive past buffer for derivative estimates.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_local_extended_source_sequence
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u})
    {epsilon C kappa r₀ mu : ℝ} {T₀ : ℝ≥0∞}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    (horizon : ENNReal.ofReal T < T₀)
    (hcompact : ∀ K : Set G.limit.carrier.carrier, IsCompact K →
      ∃ D : ℝ, ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
        (G.limit.flow.connection t).scalarCurvature x ≤ D)
    (q : G.limit.carrier.carrier) :
    ∃ rho R A V B : ℝ, 0 < rho ∧ 0 < R ∧ R < A ∧ T < V ∧ 0 < B ∧
      closedBall (extChartAt (𝓡 3) q q) (2 * rho) ⊆ (extChartAt (𝓡 3) q).target ∧
      ∃ tau : ℕ → ℕ, StrictMono tau ∧
        ∃ cyl : ∀ i, ControlledBlowupCylinder S (G.subsequence (tau i)) A V B (((i : ℝ) + 1)⁻¹),
        ∃ Phi : ∀ i, PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
          (sourceBall S (G.subsequence (tau i)) A) ∞,
          (∀ i, IsCompact (closure (S.baseBall (G.subsequence (tau i)) A))) ∧
          (∀ i, (Phi i).source = ball (extChartAt (𝓡 3) q q) (2 * rho)) ∧
          (∀ i z, z ∈ (Phi i).source →
            (Phi i z).val = G.zeroSliceEmbedding (tau i) ((extChartAt (𝓡 3) q).symm z) ∧
              (Phi i z).val ∈ S.baseBall (G.subsequence (tau i)) R) ∧
          ∀ (hV : 0 < V) m, TendstoUniformlyOn
            (fun i => iteratedFDeriv ℝ m ((((cyl i).ordinaryFlow hV).metric 0).pullbackCoefficients
              (Phi i)))
            (iteratedFDeriv ℝ m ((G.limit.flow.metric 0).pullbackCoefficients
              (extChartAt (𝓡 3) q).symm))
            atTop (closedBall (extChartAt (𝓡 3) q q) rho) := by
  let J : SpacetimeInterval := ⟨Ioc (-T) 0, ordConnected_Ioc,
    ⟨-T / 2, ⟨by linarith, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩⟩
  obtain ⟨rho, R, hrho, hR, hchart, hcharts⟩ := G.exists_captured_source_partial_charts (J := J) q
  let A := R + 1
  have hA : 0 < A := by dsimp [A]; linarith
  have hRA : R < A := by dsimp [A]; linarith
  obtain ⟨V, B, hTV, _hV₀, hB, hcyl⟩ :=
    G.exists_controlled_source_extension_on_fixed_ball hT P04 H horizon hcompact hA
  have hcapture := hcharts A hRA.le
  have hcompact' := G.subsequence_strictMono.tendsto_atTop.eventually (H.balls_compact A hA)
  let Q (i k : ℕ) : Prop :=
    IsCompact (closure (S.baseBall (G.subsequence k) A)) ∧
      Nonempty (ControlledBlowupCylinder S (G.subsequence k) A V B (((i : ℝ) + 1)⁻¹)) ∧
      ∃ Phi : PartialDiffeomorph (𝓡 3) (𝓡 3) (EuclideanSpace ℝ (Fin 3))
          (sourceBall S (G.subsequence k) A) ∞,
        Phi.source = ball (extChartAt (𝓡 3) q q) (2 * rho) ∧
        (∀ z ∈ Phi.source, (Phi z).val = G.zeroSliceEmbedding k ((extChartAt (𝓡 3) q).symm z) ∧
          (Phi z).val ∈ S.baseBall (G.subsequence k) R) ∧
        ∀ (V B eta : ℝ) (cyl : ControlledBlowupCylinder S (G.subsequence k) A V B eta)
          (hV : 0 < V), ∀ z ∈ Phi.source,
          ((cyl.ordinaryFlow hV).metric 0).pullbackCoefficients Phi z =
            (G.zeroSourceMetric k).pullbackCoefficients
              (G.zeroSliceEmbedding k ∘ (extChartAt (𝓡 3) q).symm) z
  have hQ (i : ℕ) : ∀ᶠ k in atTop, Q i k :=
    hcompact'.and ((hcyl (((i : ℝ) + 1)⁻¹) (by positivity)).and hcapture)
  obtain ⟨tau, htau, hselected⟩ := Poincare.exists_strictMono_forall_le_of_eventually hQ
  let cyl i := Classical.choice (hselected i i le_rfl).2.1
  let Phi i := (hselected i i le_rfl).2.2.choose
  have hPhi i := (hselected i i le_rfl).2.2.choose_spec
  refine ⟨rho, R, A, V, B, hrho, hR, hRA, hTV, hB, hchart, tau, htau, cyl, Phi,
    fun i => (hselected i i le_rfl).1, fun i => (hPhi i).1, fun i => (hPhi i).2.1, ?_⟩
  intro hV m
  have hKc : closedBall (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target :=
    (closedBall_subset_closedBall (by linarith : rho ≤ 2 * rho)).trans hchart
  have hconv := G.tendstoUniformlyOn_zeroSourceMetric_bilinear_jets (J := J) q
    (isCompact_closedBall _ _) hKc m
  apply (show TendstoUniformlyOn
    (fun i => iteratedFDeriv ℝ m ((G.zeroSourceMetric (tau i)).pullbackCoefficients
      (G.zeroSliceEmbedding (tau i) ∘ (extChartAt (𝓡 3) q).symm))) _ atTop _ from
      fun W hW => htau.tendsto_atTop.eventually (hconv W hW)).congr
  apply Eventually.of_forall
  intro i z hz
  have hzPhi : z ∈ (Phi i).source := by
    rw [(hPhi i).1]
    exact closedBall_subset_ball (by linarith) hz
  have heq : (((cyl i).ordinaryFlow hV).metric 0).pullbackCoefficients (Phi i) =ᶠ[𝓝 z]
      (G.zeroSourceMetric (tau i)).pullbackCoefficients
        (G.zeroSliceEmbedding (tau i) ∘ (extChartAt (𝓡 3) q).symm) :=
    Filter.mem_of_superset ((Phi i).open_source.mem_nhds hzPhi)
      fun y hy => (hPhi i).2.2 V B _ (cyl i) hV y hy
  exact (heq.iteratedFDeriv ℝ m).self_of_nhds.symm

end PoincareMT.GeneralizedBlowupConvergence
