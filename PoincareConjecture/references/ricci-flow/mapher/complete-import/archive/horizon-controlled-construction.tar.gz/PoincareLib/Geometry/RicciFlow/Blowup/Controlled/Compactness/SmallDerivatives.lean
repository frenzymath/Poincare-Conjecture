import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.SmallCylinder
import PoincareLib.Geometry.Riemannian.Coordinates.Exponential.JetBounds.CurvatureNaturality

/-!
# Covariant curvature derivatives on the small cylinder

Restriction to the based component and shrinking its universe preserve
the geometric norm of every covariant derivative of curvature.
Source: Morgan--Tian, Corollary 11.4, pp. 269--270.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

attribute [local instance] normedAddCommGroupTangentSpaceVectorSpace
  normedSpaceTangentSpaceVectorSpace

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

theorem smallFlow_curvatureDerivativeNorm
    {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}
    (e : ControlledBlowupCylinder S k A T B eta) (hA : 0 < A) (hT : 0 < T)
    (s : ℝ) (m : ℕ) (x : (componentCarrier S k hA).shrink.carrier) :
    ((e.smallFlow hA hT).connection s).curvatureDerivativeNorm m x =
      ((e.ordinaryFlow hT).connection s).curvatureDerivativeNorm m
        ((equivShrink (componentCarrier S k hA).carrier).symm x).val := by
  let E := (Poincare.Manifold.shrinkDiffeomorph (𝓡 3) (componentCarrier S k hA).carrier).symm
  have hshrink := (((e.componentFlow hA hT).shrink).connection s).curvatureDerivativeNorm_eq_pullback
    ((e.componentFlow hA hT).connection s) isOpen_univ E.contMDiff.contMDiffOn
    (fun y _ => ⟨E.mfderivToContinuousLinearEquiv (by simp) y, rfl⟩)
    (fun _ _ _ _ => rfl) m (mem_univ x)
  have hcomponent := ((e.componentFlow hA hT).connection s).curvatureDerivativeNorm_eq_pullback
    ((e.ordinaryFlow hT).connection s) (f := Subtype.val)
    isOpen_univ contMDiff_subtype_val.contMDiffOn (fun y _ => ?_)
    (fun _ _ _ _ => rfl) m (mem_univ (E x))
  · exact hshrink.trans hcomponent
  · have hbij := ((e.componentFlow hA hT).metric s).mfderiv_bijective_of_pullback_eq
      ((e.ordinaryFlow hT).metric s) (f := Subtype.val) y (fun _ _ => rfl)
    let : FiniteDimensional ℝ (TangentSpace (𝓡 3) y) := by
      unfold TangentSpace
      infer_instance
    exact ⟨(LinearEquiv.ofBijective
      (mfderiv (𝓡 3) (𝓡 3) Subtype.val y).toLinearMap hbij).toContinuousLinearEquiv, rfl⟩

end PoincareMT.ControlledBlowupCylinder
