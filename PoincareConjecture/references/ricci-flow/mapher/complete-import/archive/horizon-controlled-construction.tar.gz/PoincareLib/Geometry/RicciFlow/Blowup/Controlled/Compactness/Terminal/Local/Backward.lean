import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Flow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.SourceSequence

/-!
# Local backward realizations of the actual terminal limit

The common controls supply source cylinders on each captured coordinate
neighborhood. Smooth convergence of the actual terminal embeddings identifies
the terminal tensors of their local backward limits.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 800000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.M30CommonBlowupControls

theorem exists_local_backward_flow_at_terminal_limit
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    {sigma : ℕ → ℕ} (hsigma : StrictMono sigma)
    {L : Type v} [TopologicalSpace L] [ChartedSpace (EuclideanSpace ℝ (Fin 3)) L]
    [IsManifold (𝓡 3) ∞ L] (g : RiemannianMetric 3 L)
    (E : ℕ → Set L) (hE : ∀ j, IsOpen (E j)) (hEmono : Monotone E)
    (hEcover : ⋃ j, E j = univ) (f : ∀ k, L → S.terminalComponent (sigma k))
    (hemb : ∀ k, Topology.IsOpenEmbedding (fun x : E k => f k x))
    (hlocal : ∀ k, IsLocalDiffeomorphOn (𝓡 3) (𝓡 3) ∞ (f k) (E k))
    (himage : ∀ K : Set L, IsCompact K → ∃ R : ℝ, 0 < R ∧
      ∀ᶠ k in atTop, ∀ x ∈ K, (f k x).val ∈ S.baseBall (sigma k) R)
    (hconv : ∀ q m K, IsCompact K → K ⊆ (extChartAt (𝓡 3) q).target →
      TendstoUniformlyOn
        (fun k => iteratedFDeriv ℝ m ((S.terminalComponentMetric (sigma k)).pullbackCoefficients
          (f k ∘ (extChartAt (𝓡 3) q).symm)))
        (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm)) atTop K)
    (q : L) :
    ∃ rho T : ℝ, 0 < rho ∧ 0 < T ∧
      ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target ∧
      let U : Opens (EuclideanSpace ℝ (Fin 3)) := ⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩
      ∃ F : RicciFlow 3 U (Icc (-T) 0),
        (∀ (x : U) (v w : TangentSpace (𝓡 3) x),
          (F.metric 0).inner x v w = g.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w) ∧
        ∀ t ∈ Icc (-T) 0, ∀ x : U, (F.connection t).NonnegativeCurvatureOperator x := by
  obtain ⟨rho, R, A, T, B, hrho, hR, hRA, hT, hB, hchart,
    tau, htau, cyl, Phi, hcompact, hsource, hcapture, hterminal⟩ :=
    H.exists_local_source_sequence P04 hbound hsigma E hE hEmono hEcover
      f hemb hlocal himage q
  let K := closedBall (extChartAt (𝓡 3) q q) rho
  have hKc : K ⊆ (extChartAt (𝓡 3) q).target :=
    (closedBall_subset_closedBall (by linarith : rho ≤ 2 * rho)).trans hchart
  have hKsource (k : ℕ) : K ⊆ (Phi k).source := by
    rw [hsource k]
    exact closedBall_subset_ball (by linarith)
  have hcoeff (m k : ℕ) (x : EuclideanSpace ℝ (Fin 3)) (hx : x ∈ K) :
      iteratedFDeriv ℝ m ((((cyl k).ordinaryFlow hT).metric 0).pullbackCoefficients (Phi k)) x =
        iteratedFDeriv ℝ m ((S.terminalComponentMetric (sigma (tau k))).pullbackCoefficients
          (f (tau k) ∘ (extChartAt (𝓡 3) q).symm)) x := by
    have heq : (((cyl k).ordinaryFlow hT).metric 0).pullbackCoefficients (Phi k) =ᶠ[𝓝 x]
        (S.terminalComponentMetric (sigma (tau k))).pullbackCoefficients
          (f (tau k) ∘ (extChartAt (𝓡 3) q).symm) :=
      Filter.mem_of_superset ((Phi k).open_source.mem_nhds (hKsource k hx))
        fun z hz => hterminal hT k z hz
    exact (heq.iteratedFDeriv ℝ m).self_of_nhds
  have hconv' (m : ℕ) : TendstoUniformlyOn
      (fun k => iteratedFDeriv ℝ m ((((cyl k).ordinaryFlow hT).metric 0).pullbackCoefficients (Phi k)))
      (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 3) q).symm)) atTop K := by
    apply Metric.tendstoUniformlyOn_iff.mpr
    intro delta hdelta
    filter_upwards [htau.tendsto_atTop.eventually
      (Metric.tendstoUniformlyOn_iff.mp (hconv q m K (isCompact_closedBall _ _) hKc) delta hdelta)]
      with k hk x hx
    rw [hcoeff m k x hx]
    exact hk x hx
  have heta : Tendsto (fun i : ℕ => (((i : ℝ) + 1)⁻¹)) atTop (𝓝 0) := by
    simpa only [one_div] using (tendsto_one_div_add_atTop_nhds_zero_nat (𝕜 := ℝ))
  obtain ⟨tau', htau', b, F, hb, hF, hzero, hnonneg, hjets⟩ :=
    ControlledTerminal.exists_local_backward_flow_of_cylinder_sequence P04 g q
      hrho hR hRA hT hB.le hKc cyl Phi hcompact hsource
      (fun k z hz => (hcapture k z hz).2) hconv' heta
  refine ⟨rho, T / 2, hrho, half_pos hT, ball_subset_closedBall.trans hKc, ?_⟩
  dsimp only
  rw [← neg_div]
  exact ⟨F, hzero, hnonneg⟩

end PoincareMT.M30CommonBlowupControls
