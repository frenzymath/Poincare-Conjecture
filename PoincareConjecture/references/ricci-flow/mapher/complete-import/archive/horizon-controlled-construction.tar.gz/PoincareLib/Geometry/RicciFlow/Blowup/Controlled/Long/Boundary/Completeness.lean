import PoincareLib.Geometry.RicciFlow.Compactness.Pointed
import PoincareLib.Geometry.Riemannian.Distance.TangentBound
import PoincareLib.Topology.MetricSpace.Completeness

/-! # Completeness from a pointwise lower metric bound -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal NNReal

namespace PoincareMT

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space

/-- A smooth metric which dominates a complete metric on the same connected
carrier is complete. Only one direction of distance comparison is needed. -/
theorem FlowCarrier.metricComplete_of_inner_le {n : ℕ} (C : FlowCarrier n) (p : C.carrier)
    (g₀ g₁ : C.metric) (hcomplete : C.metricComplete g₀)
    (hle : ∀ x v, g₀.inner x v v ≤ g₁.inner x v v) : C.metricComplete g₁ := by
  let d₀ := (C.metricEMetricSpace g₀).toPseudoEMetricSpace
  let d₁ := (C.metricEMetricSpace g₁).toPseudoEMetricSpace
  change @CompleteSpace C.carrier d₁.toUniformSpace
  apply Poincare.completeSpace_of_continuous_local_edist_bound d₀ d₁ p hcomplete
  · change @Continuous C.carrier C.carrier C.topologicalSpace C.topologicalSpace id
    exact continuous_id
  · exact fun x => @Poincare.edist_ne_top_of_preconnected C.carrier d₁
      (C.preconnected_metricEMetricSpace g₁) x p
  · intro R
    refine ⟨1, fun x y _ _ => ?_⟩
    change g₀.edist x y ≤ (1 : ℝ≥0∞) * g₁.edist x y
    have h := g₁.edist_le_mul_of_inner_mfderiv_le g₀ (F := id) contMDiff_id
      (C := 1) zero_lt_one (by
        intro z v
        simpa only [id_eq, mfderiv_id, ContinuousLinearMap.id_apply, one_pow, one_mul] using hle z v) x y
    simpa only [id_eq, ENNReal.ofReal_one, ENNReal.coe_one, one_mul] using h

end PoincareMT
