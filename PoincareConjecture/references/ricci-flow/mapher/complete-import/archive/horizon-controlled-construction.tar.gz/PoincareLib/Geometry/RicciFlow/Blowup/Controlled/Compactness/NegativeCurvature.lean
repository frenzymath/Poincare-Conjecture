import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.SmallCylinder
import PoincareLib.Geometry.RicciFlow.Surgery.Metric.Curvature.Conformal.ConformalPinching
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Extension.Pinching

/-!
# Negative curvature of normalized controlled cylinders

The stored negative-curvature error divides by the blow-up scale, just as
the scalar curvature and full curvature norm do. Component restriction and
universe transport retain the same error. Source: Morgan--Tian, Theorem 11.1,
pp. 267--269, and Theorem 11.8, pp. 274--279.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT

theorem rescaledMetric_negativeCurvaturePart
    {M : Type u} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    (g : RiemannianMetric 3 M) (D : LeviCivitaData g) (q : ℝ) (hq : 0 < q)
    (x : M) :
    (rescaledMetric_connection g D q hq).negativeCurvaturePart x =
      D.negativeCurvaturePart x / q := by
  have hg : rescaledMetric g q hq =
      MetricSurgery.positiveScaling g (fun _ => q) contMDiff_const (fun _ => hq) := by
    rfl
  have hscale : ∀ D' : LeviCivitaData (rescaledMetric g q hq),
      D'.negativeCurvaturePart x = q⁻¹ * D.negativeCurvaturePart x := by
    rw [hg]
    exact fun D' => MetricSurgery.negativeCurvaturePart_positiveScaling_const D hq D' x
  simpa only [div_eq_mul_inv, mul_comm] using hscale (rescaledMetric_connection g D q hq)

namespace GeneralizedFlowCylinder

open EpochExtension.Spacetime

theorem ordinaryPullbackFlow_negativeCurvaturePart
    {F : GeneralizedRicciFlowData.{u}} {C : GeneralizedSliceCarrier.{u}}
    {a q : ℝ} {J : SpacetimeInterval} {U : TopologicalSpace.Opens C.carrier}
    (e : GeneralizedFlowCylinder F C a q J.domain U) (hC : Nonempty C.carrier)
    (s : ℝ) (hs : s ∈ J.domain) (x : U) :
    ((e.ordinaryPullbackFlow hC).connection s).negativeCurvaturePart x =
      (F.connection (a + s / q)).negativeCurvaturePart (e.forward s hs x.val) / q := by
  let D := rescaledMetric_connection (F.metric (a + s / q))
    (F.connection (a + s / q)) q e.scale_pos
  have h := ((e.ordinaryPullbackFlow hC).connection s).negativeCurvaturePart_eq_of_local_isometry
    D isOpen_univ (rawSpatialMap_smooth e ⟨s, hs⟩).contMDiffOn
    (fun y _ v w => e.ordinaryPullbackFlow_rescaled_inner hC ⟨s, hs⟩ y v w) (mem_univ x)
  rw [h, rescaledMetric_negativeCurvaturePart]
  rfl

end GeneralizedFlowCylinder

namespace ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

theorem ordinaryFlow_negativeCurvaturePart_le
    (e : ControlledBlowupCylinder S k A T B eta) (hT : 0 < T)
    (s : ℝ) (hs : s ∈ Icc (-T) 0) (x : sourceBall S k A) :
    ((e.ordinaryFlow hT).connection s).negativeCurvaturePart x ≤ eta := by
  unfold ordinaryFlow
  rw [GeneralizedFlowCylinder.ordinaryPullbackFlow_negativeCurvaturePart]
  apply (div_le_iff₀ (S.base_scalar_pos k)).mpr
  exact e.negative_curvature_bound s hs x.val x.property

theorem smallFlow_negativeCurvaturePart_le
    (e : ControlledBlowupCylinder S k A T B eta) (hA : 0 < A) (hT : 0 < T)
    (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (x : (componentCarrier S k hA).shrink.carrier) :
    ((e.smallFlow hA hT).connection s).negativeCurvaturePart x ≤ eta := by
  let E := (Poincare.Manifold.shrinkDiffeomorph (𝓡 3) (componentCarrier S k hA).carrier).symm
  have hshrink := (((e.componentFlow hA hT).shrink).connection s).negativeCurvaturePart_eq_of_local_isometry
    ((e.componentFlow hA hT).connection s) isOpen_univ E.contMDiff.contMDiffOn
    (fun y _ v w => rfl) (mem_univ x)
  have hcomponent := ((e.componentFlow hA hT).connection s).negativeCurvaturePart_eq_of_local_isometry
    ((e.ordinaryFlow hT).connection s) isOpen_univ contMDiff_subtype_val.contMDiffOn
    (fun y _ v w => rfl) (mem_univ (E x))
  exact (hshrink.trans hcomponent).le.trans
    (e.ordinaryFlow_negativeCurvaturePart_le hT s hs (E x).val)

end ControlledBlowupCylinder

end PoincareMT
