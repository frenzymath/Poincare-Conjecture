import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.CylinderCurvature
import PoincareLib.Geometry.RicciFlow.Generalized.Noncollapse.Cylinder.BallTopology

/-!
# Ordinary normalized flows from controlled blowup cylinders

The finite-cylinder curvature bound becomes a spatially uniform ordinary-flow
bound with the original constant. Its terminal base scalar is exactly one.
Source: Morgan--Tian Theorem 11.1, pp. 267--269, and Theorem 11.8, pp. 274--279.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

/-- The actual normalized terminal ball as an open source manifold. -/
def sourceBall (S : GeneralizedBlowupSequence.{u}) (k : ℕ) (A : ℝ) :
    TopologicalSpace.Opens ((S.flow k).slice (S.base k).1).carrier :=
  ⟨S.baseBall k A, RicciFlowAnalysis.initial_ball_isOpen _ _ _⟩

theorem base_mem_sourceBall (hA : 0 < A) : (S.base k).2 ∈ sourceBall S k A := by
  change ((S.flow k).metric (S.base k).1).edist (S.base k).2 (S.base k).2 < _
  simp only [RiemannianMetric.edist, Manifold.riemannianEDist_self]
  exact ENNReal.ofReal_pos.mpr (div_pos hA (Real.sqrt_pos.mpr (S.base_scalar_pos k)))

private def timeInterval (T : ℝ) (hT : 0 < T) : SpacetimeInterval where
  domain := Icc (-T) 0
  ordConnected := ordConnected_Icc
  nontrivial := ⟨-T, ⟨le_rfl, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩

/-- The ordinary flow constructed on this cylinder's actual source ball. -/
noncomputable def ordinaryFlow (e : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) : RicciFlow 3 (sourceBall S k A) (Icc (-T) 0) :=
  GeneralizedFlowCylinder.ordinaryPullbackFlow (J := timeInterval T hT)
    (U := sourceBall S k A) e.embedding ⟨(S.base k).2⟩

theorem ordinaryFlow_inner (e : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (s : ℝ) (hs : s ∈ Icc (-T) 0) (x : sourceBall S k A)
    (v w : TangentSpace (𝓡 3) x) :
    ((e.ordinaryFlow hT).metric s).inner x v w = e.embedding.pullbackInner s hs x.val
      (mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) x v)
      (mfderiv (𝓡 3) (𝓡 3) (Subtype.val : sourceBall S k A → _) x w) :=
  GeneralizedFlowCylinder.ordinaryPullbackFlow_inner (J := timeInterval T hT)
    (U := sourceBall S k A) e.embedding ⟨(S.base k).2⟩ s hs x v w

/-- The prescribed curvature bound survives normalization without loss. -/
theorem ordinaryFlow_curvature_bound (e : ControlledBlowupCylinder S k A T B eta)
    (hT : 0 < T) (s : ℝ) (hs : s ∈ Icc (-T) 0) (x : sourceBall S k A) :
    |((e.ordinaryFlow hT).connection s).curvatureTensorNorm x| ≤ B := by
  unfold ordinaryFlow
  rw [GeneralizedFlowCylinder.ordinaryPullbackFlow_curvatureTensorNorm
    (J := timeInterval T hT) (U := sourceBall S k A) e.embedding ⟨(S.base k).2⟩ s hs x]
  rw [abs_div]
  change |(S.flow k).curvatureNorm (e.embedding.pointMap s hs x.val)| / |S.scale k| ≤ B
  have hscale : 0 < S.scale k := S.base_scalar_pos k
  rw [abs_of_pos hscale]
  exact (div_le_iff₀ hscale).mpr (e.curvature_bound s hs x.val x.property)

/-- Terminal scalar normalization uses the actual cylinder basepoint identity. -/
theorem ordinaryFlow_scalar_normalized (e : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (hT : 0 < T) :
    ((e.ordinaryFlow hT).connection 0).scalarCurvature
      ⟨(S.base k).2, base_mem_sourceBall hA⟩ = 1 := by
  unfold ordinaryFlow
  have hzero : (0 : ℝ) ∈ Icc (-T) 0 := ⟨by linarith, le_rfl⟩
  rw [GeneralizedFlowCylinder.ordinaryPullbackFlow_scalarCurvature
    (J := timeInterval T hT) (U := sourceBall S k A) e.embedding ⟨(S.base k).2⟩ 0 hzero]
  rw [e.zero_identity hzero (S.base k).2 (base_mem_sourceBall hA)]
  exact div_self (S.base_scalar_pos k).ne'

end PoincareMT.ControlledBlowupCylinder
