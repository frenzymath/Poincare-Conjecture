import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Separation.Depth
import PoincareLib.Geometry.RicciFlow.CanonicalNeighborhood.Neck.Flux.Cutoff.DepthProfile

/-!
# Distance from a neck center slice to the exterior

A rescaled central bump gives ambient depth for every central-sphere point.
The estimate applies to arbitrary paths, including paths leaving the neck.

Reference: Morgan--Tian, Claim 11.14, in the proof of Claim 11.13.
-/

noncomputable section
set_option autoImplicit false

open Set Function
open scoped Manifold ContDiff Bundle

namespace PoincareMT.ControlledTerminal

theorem exists_central_neck_profile :
    ∃ C : ℝ, 0 < C ∧ ∀ ε : ℝ, 0 < ε →
      ∃ φ : ℝ → ℝ, ContDiff ℝ ∞ φ ∧
        support φ ⊆ Icc (-(1 / 4) * ε⁻¹) ((1 / 4) * ε⁻¹) ∧
        φ 0 = 1 ∧ ∀ s, |deriv φ s| ≤ C * ε := by
  let f : ContDiffBump (0 : ℝ) := ⟨1 / 8, 1 / 4, by norm_num, by norm_num⟩
  have hf : ContDiff ℝ ∞ (f : ℝ → ℝ) := f.contDiff
  have hcont : Continuous (fun s : ℝ => ‖deriv (f : ℝ → ℝ) s‖) :=
    (hf.continuous_deriv (by simp)).norm
  obtain ⟨B, hB⟩ := hcont.bddAbove_range_of_hasCompactSupport f.hasCompactSupport.deriv.norm
  refine ⟨max B 1, lt_of_lt_of_le zero_lt_one (le_max_right _ _), ?_⟩
  intro ε hε
  let φ : ℝ → ℝ := fun s => f (ε * s)
  refine ⟨φ, hf.comp (by fun_prop), ?_, ?_, ?_⟩
  · intro s hs
    have hs' : ε * s ∈ support (f : ℝ → ℝ) := hs
    rw [f.support_eq] at hs'
    have hb : |ε * s| < 1 / 4 := by
      simpa only [Metric.mem_ball, Real.dist_eq, sub_zero] using hs'
    rw [abs_mul, abs_of_pos hε] at hb
    have hsa : |s| ≤ (1 / 4) * ε⁻¹ := by
      apply (le_div_iff₀ hε).mpr
      simpa only [mul_comm] using hb.le
    exact ⟨by linarith [neg_abs_le s], (le_abs_self s).trans hsa⟩
  · change f (ε * 0) = 1
    rw [mul_zero]
    exact f.one_of_mem_closedBall (by norm_num [f])
  · intro s
    have hd : deriv φ s = deriv (f : ℝ → ℝ) (ε * s) * ε := by
      simpa only [φ, Function.comp_def, mul_one, id_eq] using
        ((hf.differentiable (by simp) _).hasDerivAt.comp s
          ((hasDerivAt_id s).const_mul ε)).deriv
    rw [hd, abs_mul, abs_of_pos hε]
    apply mul_le_mul_of_nonneg_right _ hε.le
    exact (show |deriv (f : ℝ → ℝ) (ε * s)| ≤ B from
      hB (mem_range_self _)).trans (le_max_left _ _)

def centralNeckDepthConstant : ℝ := exists_central_neck_profile.choose

theorem centralNeckDepthConstant_pos : 0 < centralNeckDepthConstant :=
  exists_central_neck_profile.choose_spec.1

end PoincareMT.ControlledTerminal

namespace PoincareMT.EpsilonNeck

variable {M : Type*} [TopologicalSpace M] [PreconnectedSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M]
  [IsManifold (𝓡 3) ∞ M] [MeasurableSpace M] [BorelSpace M]
  [T2Space M] [T3Space M] {g : RiemannianMetric 3 M}

/-- Every point outside the actual carrier is far from its central sphere,
in the ambient Riemannian distance. -/
theorem central_sphere_depth_lower_bound (N : EpsilonNeck g)
    {x y : M} (hx : x ∉ N.carrier) (hy : y ∈ N.central_sphere) :
    N.scale * Real.sqrt (1 - N.epsilon) /
      (ControlledTerminal.centralNeckDepthConstant * N.epsilon) ≤
        (g.edist x y).toReal := by
  have hC := ControlledTerminal.centralNeckDepthConstant_pos
  have hε := N.epsilon_pos
  have hi : 0 < N.epsilon⁻¹ := inv_pos.mpr hε
  have hfactor : 0 < N.scale * Real.sqrt (1 - N.epsilon) :=
    mul_pos N.scale_pos (Real.sqrt_pos.mpr (by linarith [N.epsilon_lt_half]))
  obtain ⟨φ, hφ, hsupp, hone, hderiv⟩ :=
    ControlledTerminal.exists_central_neck_profile.choose_spec.2 N.epsilon hε
  have hxzero : N.axialCutoff φ x = 0 := N.axialCutoff_eq_zero_of_not_mem φ hx
  have hyone : N.axialCutoff φ y = 1 := by
    have hy' := (N.mem_central_sphere_iff y).mp hy
    rw [N.axialCutoff_eq_of_mem φ hy'.1, hy'.2, hone]
  have hdist := N.abs_axialCutoff_sub_le
    (show -N.epsilon⁻¹ < -(1 / 4) * N.epsilon⁻¹ by linarith)
    (show (1 / 4) * N.epsilon⁻¹ < N.epsilon⁻¹ by linarith)
    hφ hsupp (mul_pos hC hε) hderiv x y
  rw [hxzero, hyone, zero_sub, abs_neg, abs_one] at hdist
  apply (div_le_iff₀ (mul_pos hC hε)).mpr
  have hm := (le_div_iff₀ hfactor).mp (show 1 ≤
      (ControlledTerminal.centralNeckDepthConstant * N.epsilon * (g.edist x y).toReal) /
        (N.scale * Real.sqrt (1 - N.epsilon)) by
    simpa only [div_mul_eq_mul_div] using hdist)
  nlinarith

/-- A weaker constant form avoids square roots in the exit-time estimate. -/
theorem central_sphere_depth_lower_bound_simple (N : EpsilonNeck g)
    {x y : M} (hx : x ∉ N.carrier) (hy : y ∈ N.central_sphere) :
    N.scale / (2 * ControlledTerminal.centralNeckDepthConstant * N.epsilon) ≤
      (g.edist x y).toReal := by
  have hε := N.epsilon_pos
  have hC := ControlledTerminal.centralNeckDepthConstant_pos
  have hs := N.scale_pos
  have hroot : (1 / 2 : ℝ) ≤ Real.sqrt (1 - N.epsilon) := by
    have hsq := Real.sq_sqrt (show 0 ≤ 1 - N.epsilon by linarith [N.epsilon_lt_half])
    nlinarith [Real.sqrt_nonneg (1 - N.epsilon), N.epsilon_lt_half]
  apply le_trans _ (N.central_sphere_depth_lower_bound hx hy)
  calc
    _ = (N.scale * (1 / 2)) /
        (ControlledTerminal.centralNeckDepthConstant * N.epsilon) := by ring
    _ ≤ _ := div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hroot hs.le)
      (by positivity)

end PoincareMT.EpsilonNeck
