import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Distance.Scalar
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Distance.Barrier
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Distance.Continuity
import PoincareLib.Geometry.Curvature.Operator.RicciBounds

/-!
# Uniform additive distance control from the terminal slice

Finite-origin Harnack and Calabi distance supports give a bound which stays
finite at the open past endpoint. Reference: Morgan--Tian, Claim 11.11.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongDistance

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem limit_continuousOn_toReal_edist
    (P04 : RicciFlowCurvatureTheory.{u}) {J : Set ℝ} (L : BlowupLimitFlow.{u} J)
    {a b : ℝ} (hJ : Icc a b ⊆ J) (p x : L.carrier.carrier) :
    ContinuousOn (fun t => ((L.flow.metric t).edist p x).toReal) (Icc a b) := by
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  obtain ⟨B, _, hbound⟩ := L.curvature_locally_bounded_in_time (Icc a b) isCompact_Icc hJ
  apply continuousOn_toReal_edist_of_global_ricci_bound L.flow (convex_Icc a b) hJ (3 * B) _ p x
  intro t ht y v
  have hRic := (L.flow.connection t).ricci_bounds_of_nonnegative_curvatureOperator
    (P04.tensor_calculus 3 L.carrier.carrier _ _) y
    (L.nonnegative_curvature_operator t (hJ ht) y) v
  have hg : 0 ≤ (L.flow.metric t).inner y v v := by
    by_cases hv : v = 0
    · subst v; simp
    exact ((L.flow.metric t).pos y v hv).le
  rw [abs_of_nonneg hRic.1]
  refine hRic.2.trans (mul_le_mul_of_nonneg_right ?_ hg)
  exact ((L.flow.connection t).scalarCurvature_le_curvatureTensorNorm_sharp y).trans
    (mul_le_mul_of_nonneg_left ((le_abs_self _).trans (hbound t ht y)) (by norm_num))

theorem toReal_edist_add_sqrt_le_terminal
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T Q : ℝ} (hT : 0 < T) (hQpos : 0 < Q)
    (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    (hQ : ∀ x, (L.flow.connection 0).scalarCurvature x ≤ Q)
    {t : ℝ} (ht : t ∈ Ioc (-T) 0) (p x : L.carrier.carrier) :
    ((L.flow.metric t).edist p x).toReal + 40 * Real.sqrt (Q * T) * Real.sqrt (t + T) ≤
      ((L.flow.metric 0).edist p x).toReal + 40 * Real.sqrt (Q * T) * Real.sqrt T := by
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  by_cases ht0 : t = 0
  · subst t; simp
  have htneg : t < 0 := lt_of_le_of_ne ht.2 ht0
  have hJ : Icc t 0 ⊆ Ioc (-T) 0 := fun r hr => ⟨ht.1.trans_le hr.1, hr.2⟩
  have hineq (s : ℝ) (hs : s ∈ Ioo t 0) :
      ((L.flow.metric t).edist p x).toReal + 40 * Real.sqrt (Q * T) * Real.sqrt (t + T) ≤
        ((L.flow.metric s).edist p x).toReal + 40 * Real.sqrt (Q * T) * Real.sqrt (s + T) := by
    have hJ' : Icc t s ⊆ interior (Ioc (-T) 0) := by
      rw [interior_Ioc]
      exact fun r hr => ⟨ht.1.trans_le hr.1, hr.2.trans_lt hs.2⟩
    have htime (r : ℝ) (hr : r ∈ Icc t s) : r ∈ Ioc (-T) 0 :=
      ⟨ht.1.trans_le hr.1, hr.2.trans hs.2.le⟩
    apply toReal_edist_add_sqrt_le L.flow hT hQpos hs.1.le ht.1 hJ'
      (fun r hr => L.complete r (htime r hr))
    · intro r hr y v
      exact ((L.flow.connection r).ricci_bounds_of_nonnegative_curvatureOperator
        (P04.tensor_calculus 3 L.carrier.carrier _ _) y
        (L.nonnegative_curvature_operator r (htime r hr) y) v).1
    · intro r hr y v
      have hh := ((L.flow.connection r).ricci_bounds_of_nonnegative_curvatureOperator
        (P04.tensor_calculus 3 L.carrier.carrier _ _) y
        (L.nonnegative_curvature_operator r (htime r hr) y) v).2
      apply hh.trans (mul_le_mul_of_nonneg_right
        (scalar_le_finite_origin_bound P04 P06 hT L hQ (htime r hr) y) _)
      by_cases hv : v = 0
      · subst v; simp
      exact ((L.flow.metric r).pos y v hv).le
  have hcontinuous : ContinuousOn (fun s => ((L.flow.metric s).edist p x).toReal +
      40 * Real.sqrt (Q * T) * Real.sqrt (s + T)) (Icc t 0) :=
    (limit_continuousOn_toReal_edist P04 L hJ p x).add
    ((continuous_const.mul (Real.continuous_sqrt.comp
      (continuous_id.add continuous_const))).continuousOn)
  have hzero : (0 : ℝ) ∈ closure (Ioo t 0) := by
    rw [closure_Ioo htneg.ne]
    exact ⟨htneg.le, le_rfl⟩
  have hend := ContinuousWithinAt.closure_le hzero continuousWithinAt_const
    ((hcontinuous 0 ⟨htneg.le, le_rfl⟩).mono Ioo_subset_Icc_self) hineq
  simpa only [zero_add] using hend

theorem toReal_edist_le_terminal_add
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T Q : ℝ} (hT : 0 < T) (hQpos : 0 < Q)
    (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    (hQ : ∀ x, (L.flow.connection 0).scalarCurvature x ≤ Q)
    {t : ℝ} (ht : t ∈ Ioc (-T) 0) (p x : L.carrier.carrier) :
    ((L.flow.metric t).edist p x).toReal ≤
      ((L.flow.metric 0).edist p x).toReal + 40 * Real.sqrt (Q * T) * Real.sqrt T := by
  have h := toReal_edist_add_sqrt_le_terminal P04 P06 hT hQpos L hQ ht p x
  have hnonneg : 0 ≤ 40 * Real.sqrt (Q * T) * Real.sqrt (t + T) := by positivity
  linarith

theorem exists_uniform_additive_distance_bound
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {T : ℝ} (hT : 0 < T) (L : BlowupLimitFlow.{u} (Ioc (-T) 0)) :
    ∃ C : ℝ, 0 < C ∧ ∀ t ∈ Ioc (-T) 0, ∀ p x : L.carrier.carrier,
      ((L.flow.metric t).edist p x).toReal ≤ ((L.flow.metric 0).edist p x).toReal + C := by
  obtain ⟨B, _, hB⟩ := L.curvature_locally_bounded_in_time {0} isCompact_singleton
    (singleton_subset_iff.mpr L.zero_mem)
  let Q := max (3 * B) 1
  have hQpos : 0 < Q := lt_of_lt_of_le (by norm_num) (le_max_right _ _)
  have hQ (x : L.carrier.carrier) : (L.flow.connection 0).scalarCurvature x ≤ Q :=
    (((L.flow.connection 0).scalarCurvature_le_curvatureTensorNorm_sharp x).trans
      (mul_le_mul_of_nonneg_left ((le_abs_self _).trans (hB 0 (mem_singleton _) x))
        (by norm_num))).trans (le_max_left _ _)
  refine ⟨40 * Real.sqrt (Q * T) * Real.sqrt T, by positivity, ?_⟩
  exact fun t ht p x => toReal_edist_le_terminal_add P04 P06 hT hQpos L hQ ht p x

end PoincareMT.ControlledLongDistance
