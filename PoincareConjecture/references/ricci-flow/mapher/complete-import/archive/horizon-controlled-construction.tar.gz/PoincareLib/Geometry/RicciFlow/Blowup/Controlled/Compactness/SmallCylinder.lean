import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.ControlledCylinder
import PoincareLib.Geometry.RicciFlow.Restriction
import PoincareLib.Geometry.RicciFlow.Harnack.Noncompact.CurvatureControl.Cylinders.SmallCarrier

/-!
# Connected universe-zero models of controlled cylinders

Restrict the constructed ordinary flow to its based component and transport
it by the existing shrinking diffeomorphism. This produces the carrier used
by the frozen M07 service without an additional geometric hypothesis.
Source: Morgan--Tian Theorem 11.1, pp. 267--269.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A T B eta : ℝ}

/-- The specified terminal base, as a point of the ordinary cylinder source. -/
def sourceBase (S : GeneralizedBlowupSequence.{u}) (k : ℕ) {A : ℝ} (hA : 0 < A) :
    sourceBall S k A := ⟨(S.base k).2, base_mem_sourceBall hA⟩

/-- The based connected component of the actual source ball. -/
noncomputable def componentCarrier (S : GeneralizedBlowupSequence.{u}) (k : ℕ) {A : ℝ}
    (hA : 0 < A) : FlowCarrier.{u} 3 where
  carrier := Poincare.connectedComponentOpens (EuclideanSpace ℝ (Fin 3)) (sourceBase S k hA)
  topologicalSpace := inferInstance
  measurableSpace := inferInstance
  borelSpace := inferInstance
  chartedSpace := inferInstance
  isManifold := inferInstance
  t2Space := inferInstance
  t3Space := inferInstance
  secondCountable := inferInstance
  connected := isConnected_univ

def componentBase (S : GeneralizedBlowupSequence.{u}) (k : ℕ) {A : ℝ} (hA : 0 < A) :
    (componentCarrier S k hA).carrier :=
  ⟨sourceBase S k hA, mem_connectedComponent⟩

/-- The connected ordinary cylinder keeps the same time interval. -/
noncomputable def componentFlow (e : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (hT : 0 < T) :
    RicciFlow 3 (componentCarrier S k hA).carrier (Icc (-T) 0) :=
  (e.ordinaryFlow hT).restrictComponent (sourceBase S k hA)

/-- The actual universe-zero cylinder flow supplied to pointed compactness. -/
noncomputable def smallFlow (e : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (hT : 0 < T) :
    RicciFlow 3 (componentCarrier S k hA).shrink.carrier (Icc (-T) 0) :=
  (e.componentFlow hA hT).shrink

noncomputable def smallBase (S : GeneralizedBlowupSequence.{u}) (k : ℕ) {A : ℝ}
    (hA : 0 < A) : (componentCarrier S k hA).shrink.carrier :=
  equivShrink (componentCarrier S k hA).carrier (componentBase S k hA)

/-- Component restriction and universe transport retain the uniform bound. -/
theorem smallFlow_curvature_bound (e : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (hT : 0 < T) (s : ℝ) (hs : s ∈ Icc (-T) 0)
    (x : (componentCarrier S k hA).shrink.carrier) :
    |((e.smallFlow hA hT).connection s).curvatureTensorNorm x| ≤ B := by
  unfold smallFlow
  rw [RicciFlow.shrink_curvatureTensorNorm]
  unfold componentFlow
  rw [RicciFlow.restrictComponent_curvatureTensorNorm]
  exact e.ordinaryFlow_curvature_bound hT s hs _

/-- The universe-zero flow has terminal scalar one at its retained basepoint. -/
theorem smallFlow_scalar_normalized (e : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (hT : 0 < T) :
    ((e.smallFlow hA hT).connection 0).scalarCurvature (smallBase S k hA) = 1 := by
  unfold smallFlow smallBase
  rw [RicciFlow.shrink_scalarCurvature, Equiv.symm_apply_apply]
  unfold componentFlow
  rw [RicciFlow.restrictComponent_scalarCurvature]
  exact e.ordinaryFlow_scalar_normalized hA hT

/-- Centered ball volumes are unchanged by the based-component and universe
restrictions, at every time represented by the actual ordinary metric. -/
theorem smallFlow_volumeMeasure_ball (e : ControlledBlowupCylinder S k A T B eta)
    (hA : 0 < A) (hT : 0 < T) (s r : ℝ) :
    ((e.smallFlow hA hT).metric s).volumeMeasure
        (((e.smallFlow hA hT).metric s).ball (smallBase S k hA) r) =
      ((e.ordinaryFlow hT).metric s).volumeMeasure
        (((e.ordinaryFlow hT).metric s).ball (sourceBase S k hA) r) := by
  have h := (e.componentFlow hA hT).shrink_volumeMeasure_ball s
    (equivShrink (componentCarrier S k hA).carrier (componentBase S k hA)) r
  simp only [Equiv.symm_apply_apply] at h
  exact h.trans ((e.ordinaryFlow hT).restrictComponent_volumeMeasure_ball
    (sourceBase S k hA) s (componentBase S k hA) r)

end PoincareMT.ControlledBlowupCylinder
