import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Cover
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Completeness
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Backward
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.ScalarBound
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.UniformBounds
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Restriction.Short
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Subsequence

/-!
# Controlled short-time blow-up limits

The complete terminal metric inherits actual necks from the dense source
slices. Local backward Ricci flows determine its curvature alternative, and
the universal neck bounds give a global scalar bound. Ball coverage transfers
that bound to one source subsequence before its spatial radius is chosen,
so its backward cylinders have one common positive lifetime.

Reference: Morgan--Tian, Theorem 11.1 and Claims 11.5--11.7, pp. 267--271.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.M30ControlledBlowupPredecessors

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_short_geometric_controls_threshold (P : M30ControlledBlowupPredecessors.{u}) :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 400 ∧
      ∀ (S : GeneralizedBlowupSequence.{u}) (epsilon C kappa r₀ mu : ℝ),
        epsilon ≤ epsilon₀ → M30CommonBlowupControls S epsilon C kappa r₀ mu →
        ∃ (sigma : ℕ → ℕ) (hsigma : StrictMono sigma) (T : ℝ), 0 < T ∧
          Nonempty (M30GeometricLongControls (S.subsequence sigma hsigma) (ENNReal.ofReal T)) := by
  obtain ⟨epsilonD, hDpos, hDsmall, hbounded⟩ := P.m29.constants
  obtain ⟨epsilonG, hGpos, hGsmall, hglobal⟩ :=
    ControlledTerminal.exists_universal_local_backward_scalar_bound_threshold.{u, 0}
  let epsilon₀ := min (epsilonD / 2)
    (min SingularRegularLimit.RoundComparison.roundComparisonThreshold (epsilonG / 4))
  have hpos : 0 < epsilon₀ := lt_min (half_pos hDpos)
    (lt_min SingularRegularLimit.RoundComparison.roundComparisonThreshold_pos (by positivity))
  have hsmall : epsilon₀ ≤ 1 / 400 :=
    (min_le_left _ _).trans (by linarith)
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro S epsilon C kappa r₀ mu hepsilon H
  have hD : epsilon ≤ epsilonD / 2 := hepsilon.trans (min_le_left _ _)
  have hround : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold :=
    hepsilon.trans ((min_le_right _ _).trans (min_le_left _ _))
  have hG : 2 * epsilon ≤ epsilonG := by
    have hh := hepsilon.trans ((min_le_right _ _).trans (min_le_right _ _))
    linarith
  have hbound : GeneralizedBlowupBoundedDistance S :=
    hbounded epsilon H.epsilon_pos (by linarith) C H.C_pos S ⟨H.branch, H.canonical⟩
  obtain ⟨sigma, hsigma, L, g, p, E, f, hE, hEc, hEp, hEK, hEstep, hEcover,
    hf, hconv, herror, _hescape, hcomplete, hcover, himage⟩ :=
    H.exists_complete_terminal_metric_limit P.m04 hbound
  let : ConnectedSpace L.carrier := connectedSpace_iff_univ.mpr L.connected
  let D := g.leviCivitaData
  have hmono : Monotone E := monotone_nat_of_le_succ fun j => subset_closure.trans (hEstep j)
  have hlocal := fun k => (hf k).2.1
  have hemb := fun k => (hf k).1
  have hbase := fun k => (hf k).2.2
  obtain ⟨hoperator, hscalarp, hscalar⟩ := H.curvature_of_terminal_metric_jets P.m04
    hbound hsigma D p E hE hEstep hEcover f hlocal hbase hconv himage
  have himage' : ∀ K : Set L.carrier, IsCompact K → ∃ R : ℝ, 0 < R ∧
      ∀ᶠ k in atTop, ∀ x ∈ K, (f k x).val ∈ S.baseBall (sigma k) R := by
    intro K hK
    obtain ⟨R, hR, hball⟩ := himage K hK
    refine ⟨R, hR, ?_⟩
    filter_upwards [hball] with k hk x hx
    rw [← S.terminalComponentMetric_image_ball]
    exact mem_image_of_mem Subtype.val (hk (mem_image_of_mem (f k) hx))
  have hbackward := H.exists_local_backward_flow_at_terminal_limit P.m04 hbound hsigma
    g E hE hmono hEcover f hemb hlocal himage' hconv
  have hneck := H.terminal_neck_scalar_control_of_metric_extraction P.m04 hbound
    (by linarith) hround (by linarith [H.epsilon_pos] : epsilon < 2 * epsilon)
    (hG.trans_lt hGsmall) hsigma g D hcomplete p hscalarp E hE hmono
    (fun j => (hEc j).isPreconnected) hEp hEK hEstep hEcover f hemb hlocal
    himage' hconv herror hscalar
  obtain ⟨B, _hB, hBbound⟩ := hglobal L.carrier P.m04 g D hcomplete hoperator p hscalarp
    (by
      intro q
      obtain ⟨rho, T, hrho, hT, hchart, F, hzero, hnonneg⟩ := hbackward q
      exact ⟨rho, T, hrho, hT, hchart, F, hnonneg, hzero⟩)
    (2 * epsilon) (2 * max C 1) (max 4 (max (C / 6) 2))
    (mul_pos (by norm_num) H.epsilon_pos) hG (by positivity) (by
      intro x
      rcases hneck x with hx | ⟨N, hN, _hND, hx⟩
      · exact Or.inl hx
      · exact Or.inr ⟨N, hN, hx⟩)
  have hsource := ControlledTerminal.eventually_uniform_source_scalar_bound D E hEK f hcover
    hscalar hBbound
  exact ⟨sigma, hsigma,
    (H.subsequence sigma hsigma).exists_geometric_short_controls_of_uniform_scalar_bound P.m04 hsource⟩

/-- The accepted short conclusion, with the same universal threshold as the
geometric source controls used to start long-horizon continuation. -/
theorem exists_short_limit_threshold (P : M30ControlledBlowupPredecessors.{u}) :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 400 ∧ M30ShortLimitStatement.{u} epsilon₀ := by
  obtain ⟨epsilon₀, hpos, hsmall, hcontrols⟩ := P.exists_short_geometric_controls_threshold
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro S epsilon C kappa r₀ mu hepsilon H
  obtain ⟨sigma, hsigma, T, hT, ⟨HG⟩⟩ := hcontrols S epsilon C kappa r₀ mu hepsilon H
  have hhalf : 0 < T / 2 := by positivity
  have hhorizon : ENNReal.ofReal (T / 2) < ENNReal.ofReal T :=
    (ENNReal.ofReal_lt_ofReal_iff hT).mpr (by linarith)
  obtain ⟨G⟩ := ControlledBlowupCompactness.nonempty_closed_finite_generalizedBlowupConvergence
    P HG hhalf hhorizon (by positivity : 0 < T / 4) (by linarith)
  exact ⟨{ backward_time := T / 4
           backward_time_pos := by positivity
           convergence := ⟨G.ofSubsequence⟩ }⟩

end PoincareMT.M30ControlledBlowupPredecessors
