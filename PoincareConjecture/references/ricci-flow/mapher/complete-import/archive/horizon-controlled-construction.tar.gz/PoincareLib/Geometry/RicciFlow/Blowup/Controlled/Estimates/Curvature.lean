import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.FixedBall
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Predecessors
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.PinchingBounds

/-!
# Curvature control on surviving terminal worldlines

The bounded-distance scalar estimate and guarded temporal comparison yield
full-curvature bounds on each fixed normalized terminal ball. The same
worldlines have arbitrarily small normalized negative curvature eventually.
Reference: Morgan--Tian Corollary 11.3, p. 269.
-/

set_option autoImplicit false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem eventually_curvature_bounded_worldlines
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u})
    (hbound : GeneralizedBlowupBoundedDistance S) (A : ℝ) (hA : 0 < A) :
    ∃ T B : ℝ, 0 < T ∧ 0 < B ∧ ∀ eta : ℝ, 0 < eta →
      ∀ᶠ k : ℕ in atTop, ∀ x ∈ S.baseBall k A,
        ∃ W : GeneralizedMaximalBackwardFlowLine
          (S.flow k) ⟨(S.base k).1, x⟩ (S.scale k) (m30BackwardDuration S k x mu),
          ∃ hI : Icc (-T) 0 ⊆ W.maximal_interval,
            ∀ s (hs : s ∈ Icc (-T) 0),
              let p := W.embedding.pointMap s (hI hs) x
              |(S.flow k).curvatureNorm p| ≤ B * S.scale k ∧
                ((S.flow k).connection p.1).negativeCurvaturePart p.2 ≤
                  eta * S.scale k := by
  obtain ⟨T, B, hT, hB, hworldlines⟩ :=
    H.eventually_scalar_bounded_worldlines P04 hbound A hA
  refine ⟨T, 13 * max B 1, hT, by positivity, ?_⟩
  intro eta heta
  filter_upwards [hworldlines,
    DeepHorn.eventually_full_and_negative_curvature_bounds P04 S H.branch hB.le heta]
    with k hk hcurv
  intro x hx
  obtain ⟨W, hI, hscalar⟩ := hk x hx
  refine ⟨W, hI, ?_⟩
  intro s hs
  let p := W.embedding.pointMap s (hI hs) x
  exact hcurv p.1 ((S.flow k).slice_nonempty_iff p.1 |>.mp ⟨p.2⟩) p.2
    (hscalar s hs).le

end PoincareMT.M30CommonBlowupControls

namespace PoincareMT.M30ControlledBlowupPredecessors

/-- The original predecessor services choose one threshold for all
radius-dependent backward worldline curvature estimates. -/
theorem exists_worldline_control_threshold (P : M30ControlledBlowupPredecessors.{u}) :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 400 ∧
      ∀ (S : GeneralizedBlowupSequence.{u}) (epsilon C kappa r₀ mu : ℝ),
        epsilon ≤ 2 * epsilon₀ →
        M30CommonBlowupControls S epsilon C kappa r₀ mu →
        ∀ A : ℝ, 0 < A → ∃ T B : ℝ, 0 < T ∧ 0 < B ∧
          ∀ eta : ℝ, 0 < eta → ∀ᶠ k : ℕ in atTop,
            ∀ x ∈ S.baseBall k A, ∃ W : GeneralizedMaximalBackwardFlowLine
              (S.flow k) ⟨(S.base k).1, x⟩ (S.scale k) (m30BackwardDuration S k x mu),
              ∃ hI : Icc (-T) 0 ⊆ W.maximal_interval,
                ∀ s (hs : s ∈ Icc (-T) 0),
                  let p := W.embedding.pointMap s (hI hs) x
                  |(S.flow k).curvatureNorm p| ≤ B * S.scale k ∧
                    ((S.flow k).connection p.1).negativeCurvaturePart p.2 ≤
                      eta * S.scale k := by
  obtain ⟨epsilon₀, hpos, hsmall, hdistance⟩ :=
    M30CommonBlowupControls.exists_universal_boundedDistance_threshold P.m29
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro S epsilon C kappa r₀ mu hepsilon H A hA
  exact H.eventually_curvature_bounded_worldlines P.m04
    (hdistance S epsilon C kappa r₀ mu hepsilon H) A hA

end PoincareMT.M30ControlledBlowupPredecessors
