import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.Inheritance.Retained.Cover
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.NeckCover
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Predecessors

/-!
# Uniform past curvature control on compact subsets

The actual inherited nearby-neck cover supplies the noncompact branch of
the long-time bounded-distance argument. The universal accuracy threshold
is selected from the frozen predecessors before the flow and its parameters.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  FlowCarrier.measurableSpace FlowCarrier.borelSpace

theorem uniform_compact_scalar_bound_of_convergence
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu T : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (hT : 0 < T) (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    (hM29 : ∀ S : GeneralizedBlowupSequence.{u},
      DenseGeneralizedBoundedDistanceHypotheses S epsilon C → GeneralizedBlowupBoundedDistance S)
    (hsmall : epsilon < 1 / 200)
    (hround : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold)
    (hgeometry : 2 * epsilon ≤ 1 / (400 * Real.pi))
    {K : Set G.limit.carrier.carrier} (hK : IsCompact K) :
    ∃ B : ℝ, 0 < B ∧ ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
      (G.limit.flow.connection t).scalarCurvature x ≤ B := by
  apply G.exists_uniform_compact_scalar_bound_of_controlled_neck_cover hT P04 P06
    (neckEpsilon := 2 * epsilon) (neckConstant := 4 * max C 1) (cutoff := 4)
    (by positivity [H.epsilon_pos]) hgeometry (by positivity)
    hM29 ⟨H.branch, H.canonical⟩ ?_ hK
  intro hNC t ht x hx
  have hnoncompact : ¬ IsCompact (univ : Set G.limit.carrier.carrier) :=
    fun h => hNC (isCompact_univ_iff.mp h)
  obtain ⟨N, hepsilon, _hD, hcenter, hscalar⟩ := H.retained_neck_scalar_and_center_control
    (epsilon' := 2 * epsilon) G hnoncompact hsmall hround
      (by linarith [H.epsilon_pos]) (by linarith) t ht x hx
  exact ⟨N, hepsilon, hcenter, hscalar⟩

end PoincareMT.M30CommonBlowupControls

namespace PoincareMT.M30ControlledBlowupPredecessors

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space

theorem exists_uniform_compact_scalar_bound_threshold
    (P : M30ControlledBlowupPredecessors.{u}) :
    ∃ epsilon₀ : ℝ, 0 < epsilon₀ ∧ epsilon₀ ≤ 1 / 400 ∧
      ∀ (S : GeneralizedBlowupSequence.{u}) (epsilon C kappa r₀ mu : ℝ),
        epsilon ≤ epsilon₀ → M30CommonBlowupControls S epsilon C kappa r₀ mu →
        ∀ T : ℝ, 0 < T → ∀ G : GeneralizedBlowupConvergence S (Ioc (-T) 0),
          ∀ K : Set G.limit.carrier.carrier, IsCompact K →
            ∃ B : ℝ, 0 < B ∧ ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
              (G.limit.flow.connection t).scalarCurvature x ≤ B := by
  obtain ⟨delta, hdelta, hdsmall, hbound⟩ := P.m29.constants
  let epsilon₀ := min (delta / 2)
    (min SingularRegularLimit.RoundComparison.roundComparisonThreshold (1 / (800 * Real.pi)))
  have hpos : 0 < epsilon₀ := lt_min (by positivity)
    (lt_min SingularRegularLimit.RoundComparison.roundComparisonThreshold_pos
      (by positivity [Real.pi_pos]))
  have hsmall : epsilon₀ ≤ 1 / 400 := (min_le_left _ _).trans (by linarith)
  refine ⟨epsilon₀, hpos, hsmall, ?_⟩
  intro S epsilon C kappa r₀ mu hepsilon H T hT G K hK
  have hd : epsilon ≤ delta / 2 := hepsilon.trans (min_le_left _ _)
  have hr : epsilon ≤ SingularRegularLimit.RoundComparison.roundComparisonThreshold :=
    hepsilon.trans ((min_le_right _ _).trans (min_le_left _ _))
  have hg : epsilon ≤ 1 / (800 * Real.pi) :=
    hepsilon.trans ((min_le_right _ _).trans (min_le_right _ _))
  apply H.uniform_compact_scalar_bound_of_convergence hT G P.m04 P.m06
    (hbound epsilon H.epsilon_pos (by linarith) C H.C_pos)
    (by linarith [hepsilon.trans hsmall]) hr ?_ hK
  calc
    2 * epsilon ≤ 2 * (1 / (800 * Real.pi)) := mul_le_mul_of_nonneg_left hg (by norm_num)
    _ = 1 / (400 * Real.pi) := by ring

end PoincareMT.M30ControlledBlowupPredecessors
