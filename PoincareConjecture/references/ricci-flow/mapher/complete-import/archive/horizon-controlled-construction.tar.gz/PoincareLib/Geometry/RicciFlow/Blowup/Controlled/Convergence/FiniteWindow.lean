import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.Generalized

/-!
# Finite controlled generalized blow-up convergence from predecessor services

The actual M07 interior extraction and the source-derived terminal extension
give the exact public generalized convergence structure on every finite
backward window strictly below the prescribed horizon.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT

theorem blowupBackwardInterval_ofReal_eq {T : ℝ} (hT : 0 < T) :
    blowupBackwardInterval (ENNReal.ofReal T) = Ioc (-T) 0 := by
  ext t
  change (t ≤ 0 ∧ ENNReal.ofReal (-t) < ENNReal.ofReal T) ↔ -T < t ∧ t ≤ 0
  rw [ENNReal.ofReal_lt_ofReal_iff hT]
  constructor <;> intro h <;> exact ⟨by linarith [h.1, h.2], by linarith [h.1, h.2]⟩

namespace ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

theorem nonempty_finite_generalizedBlowupConvergence
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀) {T : ℝ} (hT : 0 < T)
    (horizon : ENNReal.ofReal T < T₀) :
    Nonempty (GeneralizedBlowupConvergence S (Ioc (-T) 0)) := by
  obtain ⟨B, hB, idx, hidx, e, hcompact, G, hcomplete, hbound⟩ :=
    exists_finite_window_limit_with_compact_balls P H hT horizon
  have hAr : Tendsto expandingRadius atTop atTop :=
    tendsto_atTop_add_const_right atTop 1 tendsto_natCast_atTop_atTop
  have heta : Tendsto (fun i => (expandingRadius i)⁻¹) atTop (𝓝 0) :=
    tendsto_inv_atTop_zero.comp hAr
  obtain ⟨F, hF⟩ := exists_shifted_terminal_flow_on_carrier G P.m04 hB hAr hcompact
    (hcomplete 0 ⟨by linarith, by linarith⟩)
  exact ⟨terminalConvergence G F hF P.m04 hB hAr hcompact hcomplete hbound heta hidx⟩

/-- Every finite window below the horizon has the exact public M30 limit
and convergence data, including the terminal slice and all canonical jets. -/
theorem nonempty_generalizedBlowupConvergence_of_finite_subhorizon
    (P : M30ControlledBlowupPredecessors.{u})
    {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}
    (H : M30GeometricLongControls S T₀) {T : ℝ} (hT : 0 < T)
    (horizon : ENNReal.ofReal T < T₀) :
    Nonempty (GeneralizedBlowupConvergence S (blowupBackwardInterval (ENNReal.ofReal T))) := by
  rw [blowupBackwardInterval_ofReal_eq hT]
  exact nonempty_finite_generalizedBlowupConvergence P H hT horizon

end ControlledBlowupCompactness
end PoincareMT
