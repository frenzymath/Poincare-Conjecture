import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Scalar
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.SourceBounds
import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Blowup.PinchingBounds

/-!
# Extension across a finite limit horizon on each source ball

Uniform past scalar bounds on compact limit sets give controlled original
source cylinders beyond the old horizon. The extension duration here can
depend on the radius; obtaining one common duration is a separate geometric
step. Reference: Morgan--Tian, Claim 11.17, pp. 277--278.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_controlled_source_extension_on_fixed_ball
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u})
    {epsilon C kappa r₀ mu : ℝ} {T₀ : ℝ≥0∞}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    (horizon : ENNReal.ofReal T < T₀)
    (hcompact : ∀ K : Set G.limit.carrier.carrier, IsCompact K →
      ∃ D : ℝ, ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
        (G.limit.flow.connection t).scalarCurvature x ≤ D)
    {A : ℝ} (hA : 0 < A) :
    ∃ T' B : ℝ, T < T' ∧ ENNReal.ofReal T' < T₀ ∧ 0 < B ∧
      ∀ eta : ℝ, 0 < eta → ∀ᶠ k in atTop,
        Nonempty (ControlledBlowupCylinder S (G.subsequence k) A T' B eta) := by
  classical
  let J : SpacetimeInterval := ⟨Ioc (-T) 0, ordConnected_Ioc,
    ⟨-T / 2, ⟨by linarith, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩⟩
  obtain ⟨B, hB, hsource⟩ := G.exists_uniform_scalar_bound_on_source_trajectories
    (J := J) P04 hcompact hA
  have hBpos : 0 < B := by linarith
  obtain ⟨V, _hVnonneg, hTV, hV₀⟩ := ENNReal.lt_iff_exists_real_btwn.mp horizon
  have hTVreal : T < V := (ENNReal.ofReal_lt_ofReal_iff'.mp hTV).1
  have hV : 0 < V := hT.trans hTVreal
  let delta := min ((V - T) / 2) (min (T / 2)
    (1 / (8 * (H.analytic_constant + 1) * B)))
  have hdelta : 0 < delta := lt_min (by linarith) (lt_min (by linarith)
    (by positivity [H.analytic_constant_pos]))
  have hdeltaV : delta ≤ (V - T) / 2 := min_le_left _ _
  have hdeltaT : delta ≤ T / 2 := (min_le_right _ _).trans (min_le_left _ _)
  have hdeltaB : delta ≤ 1 / (8 * (H.analytic_constant + 1) * B) :=
    (min_le_right _ _).trans (min_le_right _ _)
  have hshort : delta < 1 / (4 * (H.analytic_constant + 1) * B) := by
    apply hdeltaB.trans_lt
    apply one_div_lt_one_div_of_lt
    · positivity [H.analytic_constant_pos]
    · nlinarith [H.analytic_constant_pos]
  let T' := T + delta / 2
  let a := -T + delta / 2
  have hTT' : T < T' := by dsimp [T']; linarith
  have hT'V : T' < V := by dsimp [T']; linarith
  have ha : a < 0 := by dsimp [a]; linarith
  have hIa : Icc a 0 ⊆ J.domain := by
    intro s hs
    exact ⟨by dsimp [a] at hs; linarith [hs.1], hs.2⟩
  have hIV : Icc (-T') 0 ⊆ Ioc (-V) 0 :=
    fun s hs => ⟨by linarith [hs.1], hs.2⟩
  have hzero : (0 : ℝ) ∈ Ioc (-V) 0 := ⟨by linarith, le_rfl⟩
  have haV : a ∈ Ioc (-V) 0 := hIV ⟨by dsimp [a, T']; linarith, ha.le⟩
  refine ⟨T', 13 * max (2 * B) 1, hTT',
    (ENNReal.ofReal_lt_ofReal_iff hV).mpr hT'V |>.trans hV₀, by positivity, ?_⟩
  intro eta heta
  filter_upwards [hsource (Icc a 0) isCompact_Icc hIa,
    G.subsequence_strictMono.tendsto_atTop.eventually (H.slabs V hV hV₀ A hA),
    G.subsequence_strictMono.tendsto_atTop.eventually
      (DeepHorn.eventually_full_and_negative_curvature_bounds P04 S H.branch
        (by positivity : 0 ≤ 2 * B) heta)] with k hk hslab hcurv
  obtain ⟨d⟩ := hslab
  have hseed := hk _ d.embedding ordConnected_Ioc hzero (d.zero_identity hzero)
  have hscalar : ∀ s (hs : s ∈ Icc (-T') 0), ∀ x ∈ S.baseBall (G.subsequence k) A,
      (S.flow (G.subsequence k)).scalar (d.embedding.pointMap s (hIV hs) x) <
        (2 * B) * S.scale (G.subsequence k) := by
    intro s hs x hx
    by_cases hsa : s ≤ a
    · let f : ℝ → ℝ := fun t => if ht : t ∈ Ioc (-V) 0 then
        (S.flow (G.subsequence k)).scalar (d.embedding.pointMap t ht x) else 0
      have hf : ∀ t (ht : t ∈ Ioc (-V) 0),
          f t = (S.flow (G.subsequence k)).scalar (d.embedding.pointMap t ht x) :=
        fun t ht => dif_pos ht
      have hbound : f a < B * S.scale (G.subsequence k) := by
        rw [hf a haV]
        exact hseed a ⟨le_rfl, ha.le⟩ haV x hx
      have hprop := H.toM30CommonBlowupControls.cylinder_scalar_lt_two_mul_before_time
        P04 (G.subsequence k) d.embedding hx hf hB
        (show Icc (-T') a ⊆ Ioc (-V) 0 from fun t ht => hIV ⟨ht.1, ht.2.trans ha.le⟩)
        ha.le hbound (by dsimp [a, T']; linarith)
      rw [← hf s (hIV hs)]
      exact hprop s ⟨hs.1, hsa⟩
    · have hQ : 0 < S.scale (G.subsequence k) := S.base_scalar_pos (G.subsequence k)
      exact (hseed s ⟨(lt_of_not_ge hsa).le, hs.2⟩ (hIV hs) x hx).trans
        (mul_lt_mul_of_pos_right (by linarith) hQ)
  refine ⟨{
    embedding := d.embedding.restrict hIV Subset.rfl
    zero_identity := fun h x hx => d.zero_identity (hIV h) x hx
    curvature_bound := ?_
    negative_curvature_bound := ?_ }⟩
  · intro s hs x hx
    let p := d.embedding.pointMap s (hIV hs) x
    exact (hcurv p.1 ((S.flow (G.subsequence k)).slice_nonempty_iff p.1 |>.mp ⟨p.2⟩)
      p.2 (hscalar s hs x hx).le).1
  · intro s hs x hx
    let p := d.embedding.pointMap s (hIV hs) x
    exact (hcurv p.1 ((S.flow (G.subsequence k)).slice_nonempty_iff p.1 |>.mp ⟨p.2⟩)
      p.2 (hscalar s hs x hx).le).2

end PoincareMT.GeneralizedBlowupConvergence
