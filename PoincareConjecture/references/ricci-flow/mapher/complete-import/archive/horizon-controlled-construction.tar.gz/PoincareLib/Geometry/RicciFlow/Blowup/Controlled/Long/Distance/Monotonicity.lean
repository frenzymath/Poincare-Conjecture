import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Distance.Bound

/-! # Distance monotonicity through an included terminal time -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledLongDistance

theorem antitoneOn_metric_inner_self_on_closed_slab
    {n : ℕ} {M : Type*} [TopologicalSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    {J : Set ℝ} (F : RicciFlow n M J) {a b : ℝ} (hJ : Icc a b ⊆ J)
    (x : M) (v : TangentSpace (𝓡 n) x)
    (hRic : ∀ t ∈ Icc a b, 0 ≤ (F.connection t).ricci x v v) :
    AntitoneOn (fun t => (F.metric t).inner x v v) (Icc a b) := by
  have hd (t : ℝ) (ht : t ∈ Icc a b) :
      HasDerivWithinAt (fun s => (F.metric s).inner x v v)
        (-2 * (F.connection t).ricci x v v) (Icc a b) t :=
    (F.equation t (hJ ht) x v v).mono hJ
  apply antitoneOn_of_deriv_nonpos (convex_Icc a b)
    (fun t ht => (hd t ht).continuousWithinAt)
    (fun t ht => (hd t (interior_subset ht)).differentiableWithinAt.mono interior_subset)
  intro t ht
  rw [((hd t (interior_subset ht)).hasDerivAt (mem_interior_iff_mem_nhds.mp ht)).deriv]
  exact mul_nonpos_of_nonpos_of_nonneg (by norm_num) (hRic t (interior_subset ht))

theorem toReal_edist_le_on_closed_slab_of_ricci_nonneg
    {n : ℕ} {M : Type*} [TopologicalSpace M] [T3Space M] [PreconnectedSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
    {J : Set ℝ} (F : RicciFlow n M J) {a b : ℝ} (hab : a ≤ b) (hJ : Icc a b ⊆ J)
    (hRic : ∀ t ∈ Icc a b, ∀ x : M, ∀ v : TangentSpace (𝓡 n) x,
      0 ≤ (F.connection t).ricci x v v) (p x : M) :
    ((F.metric b).edist p x).toReal ≤ ((F.metric a).edist p x).toReal := by
  let r := ((F.metric a).edist p x).toReal + 1
  have hr : 0 < r := by dsimp [r]; positivity
  have hp : p ∈ (F.metric a).ball p r := by
    change (F.metric a).edist p p < ENNReal.ofReal r
    simpa only [RiemannianMetric.edist, Manifold.riemannianEDist_self]
      using ENNReal.ofReal_pos.mpr hr
  have hx : x ∈ (F.metric a).ball p r := by
    change (F.metric a).edist p x < ENNReal.ofReal r
    rw [← ENNReal.ofReal_toReal ((F.metric a).edist_ne_top p x)]
    exact (ENNReal.ofReal_lt_ofReal_iff hr).mpr (by dsimp [r]; linarith)
  have hh := RiemannianMetric.edist_le_mul_edist_of_tangentNorm_le_on_ball
    (F.metric a) (F.metric b) p r 1 hr zero_lt_one (by
      intro y _ v
      simpa only [one_mul, RiemannianMetric.tangentNorm] using Real.sqrt_le_sqrt
        (antitoneOn_metric_inner_self_on_closed_slab F hJ y v
          (fun t ht => hRic t ht y v) ⟨le_rfl, hab⟩ ⟨hab, le_rfl⟩ hab)) hp hx
  have hedist : (F.metric b).edist p x ≤ (F.metric a).edist p x := by
    simpa only [ENNReal.ofReal_one, one_mul] using hh
  exact ENNReal.toReal_mono ((F.metric a).edist_ne_top p x) hedist

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem terminal_toReal_edist_le
    (P04 : RicciFlowCurvatureTheory.{u}) {T : ℝ} (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    {t : ℝ} (ht : t ∈ Ioc (-T) 0) (p x : L.carrier.carrier) :
    ((L.flow.metric 0).edist p x).toReal ≤ ((L.flow.metric t).edist p x).toReal := by
  let : ConnectedSpace L.carrier.carrier := L.connectedSpace
  have hJ : Icc t 0 ⊆ Ioc (-T) 0 := fun s hs => ⟨ht.1.trans_le hs.1, hs.2⟩
  apply toReal_edist_le_on_closed_slab_of_ricci_nonneg L.flow ht.2 hJ _ p x
  exact fun s hs y v => ((L.flow.connection s).ricci_bounds_of_nonnegative_curvatureOperator
    (P04.tensor_calculus 3 L.carrier.carrier _ _) y
    (L.nonnegative_curvature_operator s (hJ hs) y) v).1

end PoincareMT.ControlledLongDistance
