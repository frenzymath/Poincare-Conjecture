import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Terminal.NullPlane
import PoincareLib.Geometry.RicciFlow.Soliton.ThreeDimensional.Splitting.UnitCover

/-!
# The terminal null-line orientation cover on a finite slab

The actual unit Ricci-null vectors form a two-sheeted covering. The null line
and its local trivializations are produced from the terminal null sectional
plane and the finite backward flow, without any orientability assumption.

Reference: Morgan--Tian, Claim 11.7, p. 271.
-/

set_option autoImplicit false

open Set
open scoped Manifold ContDiff Bundle

universe u

namespace PoincareMT.RicciFlow

theorem unitRicciKernel_doubleCover_of_closed_slab_terminal_null_plane
    {M : Type u} [TopologicalSpace M] [T2Space M] [ConnectedSpace M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    (hC : RicciFlowCurvatureTheory.{u}) {a b : ℝ} (hab : a < b)
    (F : RicciFlow 3 M (Icc a b))
    (hoperator : ∀ t ∈ Icc a b, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    (hnonflat : ∃ p, (F.connection b).curvatureTensorNorm p ≠ 0)
    (x : M) (v w : TangentSpace (𝓡 3) x)
    (hv : (F.metric b).inner x v v = 1)
    (hw : (F.metric b).inner x w w = 1)
    (hvw : (F.metric b).inner x v w = 0)
    (hzero : (F.connection b).curvatureTensor x v w v w = 0) :
    IsCoveringMap (Splitting.unitRicciKernelProjection (F.connection b)) ∧
      ∀ p : M, Nat.card (Splitting.unitRicciKernelProjection (F.connection b) ⁻¹' {p}) = 2 := by
  have hsec (t : ℝ) (ht : t ∈ Icc a b) :
      (F.connection t).NonnegativeSectionalCurvature := fun y u z =>
    (F.connection t).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
      y (hoperator t ht y) u z
  have hdim := F.ricciNullity_eq_one_of_closed_slab_terminal_null_plane
    hC hab hoperator hnonflat x v w hv hw hvw hzero
  exact ⟨Splitting.unitRicciKernel_isCoveringMap_of_terminal_nullity_one hC hab F hsec hdim,
    Splitting.unitRicciKernel_fiber_card_of_terminal_nullity_one hC hab F hsec hdim⟩

end PoincareMT.RicciFlow
