import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.UniformCylinders
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Cylinders.Restriction

/-!
# Geometric short-time controls from a uniform terminal bound

A common backward cylinder supplies the geometric compactness hypotheses
on every smaller finite window, with its curvature bound chosen before the
spatial radius. The terminal volume comes from the supplied noncollapse.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.M30CommonBlowupControls

theorem exists_geometric_short_controls_of_uniform_scalar_bound
    {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) {D : ℝ}
    (hscalar : ∀ A : ℝ, 0 < A → ∀ᶠ k in atTop, ∀ x ∈ S.baseBall k A,
      (S.flow k).scalar ⟨(S.base k).1, x⟩ ≤ D * S.scale k) :
    ∃ T : ℝ, 0 < T ∧ Nonempty (M30GeometricLongControls S (ENNReal.ofReal T)) := by
  obtain ⟨T, B, hT, hB, hcyl⟩ := H.exists_uniform_controlled_cylinders P04 hscalar
  refine ⟨T, hT, ⟨{
    horizon_pos := ENNReal.ofReal_pos.mpr hT
    balls_compact := H.balls_compact
    terminal_volume := H.terminal_volume_of_eventual_cylinders zero_lt_one hT hB.le
      (hcyl 1 zero_lt_one 1 zero_lt_one)
    cylinders := ?_ }⟩⟩
  intro T' hT' hT'T
  have hless : T' < T := (ENNReal.ofReal_lt_ofReal_iff hT).mp hT'T
  refine ⟨B, hB.le, fun A hA eta heta => ?_⟩
  filter_upwards [hcyl A hA eta heta] with k hk
  exact hk.map (fun e => e.restrictTime hless.le)

end PoincareMT.M30CommonBlowupControls
