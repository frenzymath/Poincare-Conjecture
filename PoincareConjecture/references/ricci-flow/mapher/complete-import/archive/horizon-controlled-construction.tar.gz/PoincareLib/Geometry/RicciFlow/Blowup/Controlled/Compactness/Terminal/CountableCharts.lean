import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Component

/-!
# Countable charts for the terminal pointed metrics

The diagonal normal covers give charts on one common unit ball. Finite
prefixes use earlier available covers; finite extrema retain uniform upper
and positive lower distance bounds. The compact half-ball cores cover every
fixed terminal metric ball eventually.
Reference: Morgan--Tian, Claim 11.5, p. 270, and Theorem 5.6, pp. 86-87.
-/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Metric
open scoped Manifold ContDiff Bundle ENNReal Topology NNReal

universe u

namespace PoincareMT.ControlledTerminal

variable {S : GeneralizedBlowupSequence.{u}} {sigma : ℕ → ℕ}
  {R rho : ℕ → ℝ} {N : ℕ → ℕ}
  (cover : ∀ k j, j ≤ k → NormalChartCover
    (fun _ => S.normalizedTerminalMetric (sigma k)) (S.base (sigma k)).2
    (-1) 1 ((j : ℝ) + 1) (R j) (rho j) (1 / 4) (9 / 4) (N j))
  (hrho : ∀ j, 0 < rho j) (hrhoR : ∀ j, rho j / 2 ≤ R j)

local instance (k : ℕ) : MetricSpace (S.terminalComponent (sigma k)) :=
  (S.terminalCarrier (sigma k)).metricSpaceOf (S.terminalComponentMetric (sigma k))

private def stageMap (k j : ℕ) (hjk : j ≤ k) (l : ℕ)
    (x : ball (0 : EuclideanSpace ℝ (Fin 3)) 1) : S.terminalComponent (sigma k) :=
  (cover k j hjk).componentUnitBallMap (hrho j) (hrhoR j)
    ⟨l % (N j + 1), Nat.mod_lt _ (Nat.succ_pos _)⟩ x

def chartMap (k i : ℕ) (x : ball (0 : EuclideanSpace ℝ (Fin 3)) 1) :
    S.terminalComponent (sigma k) :=
  stageMap cover hrho hrhoR k (min (Nat.unpair i).1 k) (min_le_right _ _)
    (Nat.unpair i).2 x

theorem chartMap_of_le (k i : ℕ) (hik : (Nat.unpair i).1 ≤ k) :
    chartMap cover hrho hrhoR k i =
      (cover k (Nat.unpair i).1 hik).componentUnitBallMap
        (hrho _) (hrhoR _)
        ⟨(Nat.unpair i).2 % (N (Nat.unpair i).1 + 1), Nat.mod_lt _ (Nat.succ_pos _)⟩ := by
  funext x
  simp only [chartMap, min_eq_left hik]
  rfl

theorem chartMap_pair (k j : ℕ) (hjk : j ≤ k) (l : Fin (N j + 1)) :
    chartMap cover hrho hrhoR k (Nat.pair j l) =
      (cover k j hjk).componentUnitBallMap (hrho j) (hrhoR j) l := by
  funext x
  simp only [chartMap, Nat.unpair_pair, min_eq_left hjk]
  simp only [stageMap, Nat.mod_eq_of_lt l.isLt]

theorem chartMap_zero (k : ℕ) :
    chartMap cover hrho hrhoR k 0 ⟨0, by simp⟩ = S.terminalComponentBase (sigma k) := by
  change chartMap cover hrho hrhoR k (Nat.pair 0 (0 : Fin (N 0 + 1))) ⟨0, by simp⟩ = _
  rw [chartMap_pair cover hrho hrhoR k 0 (Nat.zero_le k) (0 : Fin (N 0 + 1))]
  apply Subtype.ext
  simpa only [NormalChartCover.componentUnitBallMap, NormalChartCover.unitBallMap,
    GeneralizedBlowupSequence.terminalComponentBase, smul_zero] using
      ((cover k 0 (Nat.zero_le k)).map_zero 0).trans
      (cover k 0 (Nat.zero_le k)).centre_zero

theorem chartMap_isLocalDiffeomorph (k i : ℕ) :
    letI : Nonempty (ball (0 : EuclideanSpace ℝ (Fin 3)) 1) := ⟨⟨0, by simp⟩⟩
    letI := (isOpen_ball (x := (0 : EuclideanSpace ℝ (Fin 3)))
      (ε := 1)).isOpenEmbedding_subtypeVal.singletonChartedSpace
    IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ (chartMap cover hrho hrhoR k i) :=
  (cover k _ (min_le_right _ _)).componentUnitBallMap_isLocalDiffeomorph
    (hrho _) (hrhoR _) _

theorem chartMap_isOpenEmbedding (k i : ℕ) :
    Topology.IsOpenEmbedding (chartMap cover hrho hrhoR k i) :=
  (cover k _ (min_le_right _ _)).componentUnitBallMap_isOpenEmbedding
    (hrho _) (hrhoR _) _

theorem chartMap_distance_bounds (i : ℕ) :
    ∃ L : ℝ≥0, ∃ c : ℝ, 0 < c ∧
      (∀ k, LipschitzWith L (chartMap cover hrho hrhoR k i)) ∧
      ∀ k x y, c * dist x y ≤
        dist (chartMap cover hrho hrhoR k i x) (chartMap cover hrho hrhoR k i y) := by
  classical
  let s := Finset.range ((Nat.unpair i).1 + 1)
  have hs : s.Nonempty := ⟨0, by simp [s]⟩
  let upper := fun j => Real.sqrt (9 / 4 : ℝ) * (rho j / 2)
  let lower := fun j => Real.sqrt (1 / 4 : ℝ) * (rho j / 2)
  have hupper (j : ℕ) : 0 ≤ upper j :=
    mul_nonneg (Real.sqrt_nonneg _) (half_pos (hrho j)).le
  have hlower (j : ℕ) : 0 < lower j :=
    mul_pos (Real.sqrt_pos.2 (by norm_num)) (half_pos (hrho j))
  let B := s.sup' hs upper
  have hB : 0 ≤ B := (hupper 0).trans (Finset.le_sup' upper (by simp [s]))
  let c := s.inf' hs lower
  have hc : 0 < c := (Finset.lt_inf'_iff hs).2 (fun j _ => hlower j)
  have hdist (k : ℕ) (x y : ball (0 : EuclideanSpace ℝ (Fin 3)) 1) :
      lower (min (Nat.unpair i).1 k) * dist x y ≤
          dist (chartMap cover hrho hrhoR k i x) (chartMap cover hrho hrhoR k i y) ∧
        dist (chartMap cover hrho hrhoR k i x) (chartMap cover hrho hrhoR k i y) ≤
          upper (min (Nat.unpair i).1 k) * dist x y := by
    exact (cover k _ (min_le_right _ _)).componentUnitBallMap_distances
      (hrho _) (hrhoR _) _ x y
  refine ⟨⟨B, hB⟩, c, hc, ?_, ?_⟩
  · intro k
    have hj : min (Nat.unpair i).1 k ∈ s :=
      Finset.mem_range.mpr (Nat.lt_succ_of_le (min_le_left _ _))
    apply LipschitzWith.of_dist_le_mul
    intro x y
    exact (hdist k x y).2.trans
      (mul_le_mul_of_nonneg_right (Finset.le_sup' upper hj) dist_nonneg)
  · intro k x y
    have hj : min (Nat.unpair i).1 k ∈ s :=
      Finset.mem_range.mpr (Nat.lt_succ_of_le (min_le_left _ _))
    exact (mul_le_mul_of_nonneg_right (Finset.inf'_le lower hj) dist_nonneg).trans
      (hdist k x y).1

theorem chartMap_pairwise_bounded
    (L : ℕ → ℝ≥0) (hL : ∀ k i, LipschitzWith (L i) (chartMap cover hrho hrhoR k i))
    (i j : ℕ) (x y : ball (0 : EuclideanSpace ℝ (Fin 3)) 1) :
    ∃ B : ℝ, ∀ k,
      dist (chartMap cover hrho hrhoR k i x) (chartMap cover hrho hrhoR k j y) ≤ B := by
  have hbase (i k : ℕ) (x : ball (0 : EuclideanSpace ℝ (Fin 3)) 1) :
      dist (S.terminalComponentBase (sigma k)) (chartMap cover hrho hrhoR k i x) ≤
        ((Nat.unpair i).1 : ℝ) + 1 + L i := by
    let q := min (Nat.unpair i).1 k
    let l : Fin (N q + 1) := ⟨(Nat.unpair i).2 % (N q + 1), Nat.mod_lt _ (Nat.succ_pos _)⟩
    let z : ball (0 : EuclideanSpace ℝ (Fin 3)) 1 := ⟨0, by simp⟩
    have hz : (chartMap cover hrho hrhoR k i z).val =
        (cover k q (min_le_right _ _)).centre l := by
      change (cover k q (min_le_right _ _)).chart l ((rho q / 2) • 0) = _
      rw [smul_zero, (cover k q (min_le_right _ _)).map_zero]
    have hcentre : dist (S.terminalComponentBase (sigma k))
        (chartMap cover hrho hrhoR k i z) < (q : ℝ) + 1 := by
      change ((S.terminalComponentMetric (sigma k)).edist
        (S.terminalComponentBase (sigma k)) (chartMap cover hrho hrhoR k i z)).toReal < _
      rw [S.terminalComponentMetric_edist, hz]
      exact ENNReal.toReal_lt_of_lt_ofReal
        ((cover k q (min_le_right _ _)).centre_mem l)
    have hx : dist z x ≤ 1 := by
      simpa only [Subtype.dist_eq, z, dist_zero_left] using
        (mem_ball_zero_iff.mp x.property).le
    calc
      dist (S.terminalComponentBase (sigma k)) (chartMap cover hrho hrhoR k i x) ≤
          dist (S.terminalComponentBase (sigma k)) (chartMap cover hrho hrhoR k i z) +
            dist (chartMap cover hrho hrhoR k i z) (chartMap cover hrho hrhoR k i x) :=
        dist_triangle _ _ _
      _ ≤ ((q : ℝ) + 1) + L i := add_le_add hcentre.le
        (((hL k i).dist_le_mul z x).trans
          (by simpa using mul_le_mul_of_nonneg_left hx (L i).coe_nonneg))
      _ ≤ ((Nat.unpair i).1 : ℝ) + 1 + L i := by
        have hq : (q : ℝ) ≤ ((Nat.unpair i).1 : ℝ) := by
          exact_mod_cast min_le_left (Nat.unpair i).1 k
        linarith
  refine ⟨(((Nat.unpair i).1 : ℝ) + 1 + L i) + (((Nat.unpair j).1 : ℝ) + 1 + L j), ?_⟩
  intro k
  exact (dist_triangle_left _ _ (S.terminalComponentBase (sigma k))).trans
    (add_le_add (hbase i k x) (hbase j k y))

theorem chartMap_compact_cover :
    ∀ A : ℝ, 0 < A → ∃ s : Finset ℕ,
      ∃ K : ℕ → Set (ball (0 : EuclideanSpace ℝ (Fin 3)) 1),
        (∀ i ∈ s, IsCompact (K i)) ∧
          ∀ᶠ k in atTop, ball (S.terminalComponentBase (sigma k)) A ⊆
            ⋃ i ∈ s, chartMap cover hrho hrhoR k i '' K i := by
  classical
  intro A _hA
  obtain ⟨j, hj⟩ := exists_nat_gt A
  let K : Set (ball (0 : EuclideanSpace ℝ (Fin 3)) 1) :=
    {x | ‖(x : EuclideanSpace ℝ (Fin 3))‖ ≤ 1 / 2}
  have hK : IsCompact K := by
    rw [Subtype.isCompact_iff]
    have himage : Subtype.val '' K = closedBall (0 : EuclideanSpace ℝ (Fin 3)) (1 / 2) := by
      ext x
      constructor
      · rintro ⟨y, hy, rfl⟩
        exact mem_closedBall_zero_iff.mpr hy
      · intro hx
        exact ⟨⟨x, mem_ball_zero_iff.mpr ((mem_closedBall_zero_iff.mp hx).trans_lt
          (by norm_num))⟩, mem_closedBall_zero_iff.mp hx, rfl⟩
    rw [himage]
    exact isCompact_closedBall _ _
  let s := Finset.univ.image (fun l : Fin (N j + 1) => Nat.pair j l)
  refine ⟨s, fun _ => K, fun _ _ => hK, ?_⟩
  filter_upwards [eventually_ge_atTop j] with k hk
  intro y hy
  have hy' : y ∈ (S.terminalComponentMetric (sigma k)).ball
      (S.terminalComponentBase (sigma k)) ((j : ℝ) + 1) := by
    have h := (ball_subset_ball (show A ≤ (j : ℝ) + 1 by linarith)) hy
    rw [FlowCarrier.metricBall_eq_metricBallOf (S.terminalCarrier (sigma k))
      (S.terminalComponentMetric (sigma k))] at h
    exact h
  obtain ⟨l, x, hx, hxy⟩ := mem_iUnion.mp
    ((cover k j hk).componentUnitBallMap_cover (hrho j) (hrhoR j) hy')
  refine mem_iUnion.mpr ⟨Nat.pair j l, mem_iUnion.mpr ⟨Finset.mem_image.mpr
    ⟨l, Finset.mem_univ _, rfl⟩, x, hx, ?_⟩⟩
  rw [chartMap_pair cover hrho hrhoR k j hk l]
  exact hxy

end PoincareMT.ControlledTerminal
