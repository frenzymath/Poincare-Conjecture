import PoincareLib.Geometry.Riemannian.Coordinates.TransitionCompactness

/-!
# Uniform bounds from the actual terminal metric convergence

Smooth convergence to a positive terminal metric bounds all reference jets
and gives uniform positive quadratic-form bounds on compact coordinate sets.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 8

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology

namespace PoincareMT.ControlledTerminal

variable {n : ℕ} {M : Type*} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin n)) M] [IsManifold (𝓡 n) ∞ M]
  (g : RiemannianMetric n M) (q : M)
  (Bseq : ℕ → EuclideanSpace ℝ (Fin n) →
    EuclideanSpace ℝ (Fin n) →L[ℝ] EuclideanSpace ℝ (Fin n) →L[ℝ] ℝ)
  {K : Set (EuclideanSpace ℝ (Fin n))} (hK : IsCompact K)
  (hKc : K ⊆ (extChartAt (𝓡 n) q).target)
  (hconv : ∀ m, TendstoUniformlyOn (fun k => iteratedFDeriv ℝ m (Bseq k))
    (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 n) q).symm)) atTop K)

include hK hKc hconv in
theorem eventually_bounded_terminal_reference_jets (m : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ k in atTop, ∀ z ∈ K, ‖iteratedFDeriv ℝ m (Bseq k) z‖ ≤ C := by
  have hs (x : EuclideanSpace ℝ (Fin n)) (hx : x ∈ K) :
      ContDiffAt ℝ ∞ (g.pullbackCoefficients (extChartAt (𝓡 n) q).symm) x :=
    g.contDiffAt_pullbackCoefficients
      ((contMDiffWithinAt_extChartAt_symm_target (n := ∞) q (hKc hx)).contMDiffAt
        (extChartAt_target_mem_nhds' (hKc hx)))
  obtain ⟨C, hC⟩ := hK.exists_bound_of_continuousOn (fun x hx =>
    ((hs x hx).continuousAt_iteratedFDeriv
      (WithTop.coe_le_coe.mpr (le_top : (m : ℕ∞) ≤ ⊤))).continuousWithinAt)
  refine ⟨max (C + 1) 0, le_max_right _ _, ?_⟩
  filter_upwards [Metric.tendstoUniformlyOn_iff.mp (hconv m) 1 zero_lt_one] with k hk x hx
  apply le_trans _ (le_max_left (C + 1) 0)
  exact (norm_le_norm_add_norm_sub
    (iteratedFDeriv ℝ m (g.pullbackCoefficients (extChartAt (𝓡 n) q).symm) x)
    (iteratedFDeriv ℝ m (Bseq k) x)).trans
      (add_le_add (hC x hx) (by simpa only [dist_eq_norm] using (hk x hx).le))

include hK hKc hconv in
theorem eventually_elliptic_terminal_reference_coefficients :
    ∃ alpha beta : ℝ, 0 < alpha ∧ 0 < beta ∧ ∀ᶠ k in atTop,
      ∀ z ∈ K, ∀ v,
        alpha * ‖v‖ ^ 2 ≤ Bseq k z v v ∧ Bseq k z v v ≤ beta * ‖v‖ ^ 2 := by
  let B := g.pullbackCoefficients (extChartAt (𝓡 n) q).symm
  have hB : ContinuousOn B K := by
    intro x hx
    exact (g.contDiffAt_pullbackCoefficients
      ((contMDiffWithinAt_extChartAt_symm_target (n := ∞) q (hKc hx)).contMDiffAt
        (extChartAt_target_mem_nhds' (hKc hx)))).continuousAt.continuousWithinAt
  have hpos : ∀ x ∈ K, ∀ v, v ≠ 0 → 0 < B x v v := by
    intro x hx v hv
    apply g.pos
    have hi : (mfderiv (𝓡 n) (𝓡 n) (extChartAt (𝓡 n) q).symm x).IsInvertible := by
      simpa only [ModelWithCorners.range_eq_univ, mfderivWithin_univ] using
        isInvertible_mfderivWithin_extChartAt_symm (I := 𝓡 n) (hKc hx)
    intro hz
    apply hv
    apply hi.injective
    rw [map_zero]
    convert! hz using 1
  obtain ⟨alpha, halpha, hlower⟩ := exists_uniform_bilinear_family_lower_bound hK hB hpos
  obtain ⟨C, hC, hbound⟩ := eventually_bounded_terminal_reference_jets g q Bseq hK hKc hconv 0
  have hzero : TendstoUniformlyOn Bseq B atTop K := by
    rw [Metric.tendstoUniformlyOn_iff]
    intro delta hdelta
    filter_upwards [Metric.tendstoUniformlyOn_iff.mp (hconv 0) delta hdelta] with k hk x hx
    simpa only [iteratedFDeriv_zero_eq_comp, Function.comp_apply,
      LinearIsometryEquiv.dist_map] using hk x hx
  refine ⟨alpha / 2, max C 1, by positivity, lt_max_of_lt_right zero_lt_one, ?_⟩
  filter_upwards [hbound, Metric.tendstoUniformlyOn_iff.mp hzero (alpha / 2) (by positivity)]
    with k hk herror x hx v
  have hd : ‖Bseq k x - B x‖ ≤ alpha / 2 := by
    simpa only [dist_eq_norm, norm_sub_rev] using (herror x hx).le
  have herr : |Bseq k x v v - B x v v| ≤ alpha / 2 * ‖v‖ ^ 2 := by
    calc
      _ ≤ ‖Bseq k x - B x‖ * ‖v‖ * ‖v‖ := by
        simpa only [sub_apply, Real.norm_eq_abs] using (Bseq k x - B x).le_opNorm₂ v v
      _ ≤ alpha / 2 * ‖v‖ ^ 2 := by
        simpa only [pow_two, mul_assoc] using
          mul_le_mul_of_nonneg_right hd (mul_nonneg (norm_nonneg v) (norm_nonneg v))
  constructor
  · have hh := (abs_le.mp herr).1
    linarith [hlower x hx v]
  · have hnormC : ‖Bseq k x‖ ≤ C := by
      simpa only [norm_iteratedFDeriv_zero] using hk x hx
    have hnorm : ‖Bseq k x‖ ≤ max C 1 := hnormC.trans (le_max_left C 1)
    apply (le_abs_self _).trans
    calc
      |Bseq k x v v| ≤ ‖Bseq k x‖ * ‖v‖ * ‖v‖ := by
        simpa only [Real.norm_eq_abs] using (Bseq k x).le_opNorm₂ v v
      _ ≤ max C 1 * ‖v‖ ^ 2 := by
        simpa only [pow_two, mul_assoc] using
          mul_le_mul_of_nonneg_right hnorm (mul_nonneg (norm_nonneg v) (norm_nonneg v))

end PoincareMT.ControlledTerminal
