import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Coverage
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Exhaustion
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Embeddings.Coefficients

/-! # Retained cylinders on the finite backward-time exhaustion -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

noncomputable def finiteRetainedCylinder (k : ℕ) :
    GeneralizedFlowCylinder (S.flow (idx (G.subsequence k)))
      (liftedSliceCarrier.{u} G.limitCarrier)
      (S.base (idx (G.subsequence k))).1 (S.scale (idx (G.subsequence k)))
      (Icc (-finiteTimeRadius T k) 0) (retainedSpace G k) :=
  (retainedCylinder G k).restrict
    ((finiteTimeRadius_interval_subset hT k).trans Ioc_subset_Icc_self) Subset.rfl

theorem finiteRetainedCylinder_base (k : ℕ)
    (hzero : (0 : ℝ) ∈ Icc (-finiteTimeRadius T k) 0) :
    (finiteRetainedCylinder G k).pointMap 0 hzero (ULift.up G.limitFlow.base) =
      S.base (idx (G.subsequence k)) :=
  retainedCylinder_base G k ⟨by linarith [hT], le_rfl⟩

theorem finiteRetainedCylinder_eventually_covers_baseBall
    (hAr : Tendsto A atTop atTop)
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    {r : ℝ} (hr : 0 < r) :
    ∀ᶠ k in atTop, ∀ x ∈ S.baseBall (idx (G.subsequence k)) r,
      ∃ y ∈ retainedSpace G k, ∃ hzero,
        (finiteRetainedCylinder G k).pointMap 0 hzero y =
          (⟨(S.base (idx (G.subsequence k))).1, x⟩ : (S.flow (idx (G.subsequence k))).point) := by
  filter_upwards [retainedCylinder_eventually_covers_baseBall G hAr hcomplete hr] with k hk
  intro x hx
  obtain ⟨y, hy, hz, heq⟩ := hk x hx
  exact ⟨y, hy, ⟨neg_nonpos.mpr (finiteTimeRadius_pos hT k).le, le_rfl⟩, heq⟩

theorem finiteRetainedCylinder_chart_inner (k : ℕ) (s : ℝ)
    (hs : s ∈ Icc (-finiteTimeRadius T k) 0)
    (q : (liftedSliceCarrier.{u} G.limitCarrier).carrier)
    (z : EuclideanSpace ℝ (Fin 3)) (hz : z ∈ (extChartAt (𝓡 3) q).target)
    (hx : ((extChartAt (𝓡 3) q).symm z).down ∈ G.exhaustion k)
    (v w : EuclideanSpace ℝ (Fin 3)) :
    (finiteRetainedCylinder G k).pullbackInner s hs ((extChartAt (𝓡 3) q).symm z)
      (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z v)
      (mfderiv (𝓡 3) (𝓡 3) (extChartAt (𝓡 3) q).symm z w) =
      G.spatialSpacetimeCoefficients q.down k (s + T / 2, z) v w :=
  retainedCylinder_chart_inner G k s
    (((finiteTimeRadius_interval_subset hT k).trans Ioc_subset_Icc_self) hs) q z hz hx v w

end PoincareMT.ControlledBlowupCompactness
