import PoincareLib.Geometry.RicciFlow.Surgery.Singular.DeepHorn.Limit.Metric.Coverage

/-! # Metric lower bounds when dense times approach a retained slice -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t3Space

theorem BlowupLimitFlow.tangentNorm_le_of_time_le
    {J : SpacetimeInterval} (L : BlowupLimitFlow.{u} J.domain)
    {s t : ℝ} (hs : s ∈ J.domain) (ht : t ∈ J.domain) (hst : s ≤ t)
    (x : L.carrier.carrier) (v : TangentSpace (𝓡 3) x) :
    (L.flow.metric t).tangentNorm x v ≤ (L.flow.metric s).tangentNorm x v := by
  have hI : Icc s t ⊆ J.domain := J.ordConnected.out hs ht
  have hd (r : ℝ) (hr : r ∈ interior (Icc s t)) :
      HasDerivAt (fun u => (L.flow.metric u).inner x v v)
        (-2 * (L.flow.connection r).ricci x v v) r := by
    have hrn : J.domain ∈ 𝓝 r := mem_of_superset (mem_interior_iff_mem_nhds.mp hr) hI
    exact (L.flow.equation r (hI (interior_subset hr)) x v v).hasDerivAt hrn
  have hanti : AntitoneOn (fun r => (L.flow.metric r).inner x v v) (Icc s t) := by
    apply antitoneOn_of_deriv_nonpos (convex_Icc s t)
    · intro r hr
      exact (L.flow.equation r (hI hr) x v v).continuousWithinAt.mono hI
    · intro r hr
      exact (hd r hr).differentiableAt.differentiableWithinAt
    · intro r hr
      rw [(hd r hr).deriv]
      apply mul_nonpos_of_nonpos_of_nonneg (by norm_num)
      exact (L.flow.connection r).ricci_nonneg_of_nonnegative_curvatureOperator x
        (L.nonnegative_curvature_operator r (hI (interior_subset hr)) x) v
  exact Real.sqrt_le_sqrt (hanti ⟨le_rfl, hst⟩ ⟨hst, le_rfl⟩ hst)

theorem GeneralizedBlowupConvergence.eventually_movingSource_tangentNorm_lower
    {S : GeneralizedBlowupSequence.{u}} {J : SpacetimeInterval}
    (G : GeneralizedBlowupConvergence S J.domain)
    {idx : ℕ → ℕ} (hidx : Tendsto idx atTop atTop)
    {s : ℕ → ℝ} {t : ℝ} {I : Set ℝ} (hI : IsCompact I) (hIJ : I ⊆ J.domain)
    (hsI : ∀ k, s k ∈ I) (ht : t ∈ J.domain) (hst : ∀ k, s k ≤ t)
    (hs : ∀ k, s k ∈ Icc (-G.exhaustion.time (idx k)) 0)
    {K : Set G.limit.carrier.carrier} (hK : IsCompact K) :
    ∀ᶠ k in atTop, ∀ y ∈ K, ∀ v : TangentSpace (𝓡 3) y,
      (G.limit.flow.metric t).tangentNorm y v ≤
        2 * (G.normalizedSourceMetric (idx k) (s k)).tangentNorm
          ((G.embedding (idx k)).forward (s k) (hs k) y)
          (mfderiv (𝓡 3) (𝓡 3) ((G.embedding (idx k)).forward (s k) (hs k)) y v) := by
  filter_upwards [hidx.eventually (G.eventually_normalized_tangentNorm_bounds
    (hI.prod hK) (fun z hz => hIJ hz.1) (by norm_num : (1 : ℝ) < 2))]
    with k hk y hy v
  exact (G.limit.tangentNorm_le_of_time_le (hIJ (hsI k)) ht (hst k) y v).trans
    (hk (s k, y) ⟨hsI k, hy⟩ (hs k) v).2

end PoincareMT
