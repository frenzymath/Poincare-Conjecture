import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Estimates.Cylinders
import PoincareLib.Geometry.RicciFlow.Compactness.Coordinates.Uniform
import PoincareLib.Geometry.RicciFlow.Rescaling.Volume
import PoincareLib.Geometry.RicciFlow.Generalized.Noncollapse.Volume.LocalVolume
import PoincareLib.Geometry.Riemannian.Homothety.Curvature.ContractionTransport

/-!
# Uniform normal charts for the terminal metrics

Terminal volume, bounded-distance control and pinching provide uniformly
injective exponential charts at every center in each fixed normalized ball.
No common backward time interval is needed for this Riemannian step.
Reference: Morgan--Tian Claim 11.5, p. 270, and Theorem 5.6, pp. 86-87.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter MeasureTheory
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.GeneralizedBlowupSequence

noncomputable def normalizedTerminalMetric (S : GeneralizedBlowupSequence.{u}) (k : ℕ) :
    RiemannianMetric 3 ((S.flow k).slice (S.base k).1).carrier :=
  rescaledMetric ((S.flow k).metric (S.base k).1) (S.scale k) (S.base_scalar_pos k)

noncomputable def normalizedTerminalConnection (S : GeneralizedBlowupSequence.{u}) (k : ℕ) :
    LeviCivitaData (S.normalizedTerminalMetric k) :=
  rescaledMetric_connection ((S.flow k).metric (S.base k).1)
    ((S.flow k).connection (S.base k).1) (S.scale k) (S.base_scalar_pos k)

theorem normalizedTerminalMetric_ball (S : GeneralizedBlowupSequence.{u}) (k : ℕ) (r : ℝ) :
    (S.normalizedTerminalMetric k).ball (S.base k).2 r = S.baseBall k r :=
  rescaledMetric_ball_allDimensions _ _ _ _ _

theorem normalizedTerminalConnection_curvatureTensorNorm
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
    (x : ((S.flow k).slice (S.base k).1).carrier) :
    (S.normalizedTerminalConnection k).curvatureTensorNorm x =
      ((S.flow k).connection (S.base k).1).curvatureTensorNorm x / S.scale k :=
  Homothety.homothety_curvatureTensorNorm_eq _ _ (Diffeomorph.refl _ _ _) _
    (S.base_scalar_pos k) (by intro y v w; simp [normalizedTerminalMetric,
      rescaledMetric_inner, mfderiv_id, GeneralizedBlowupSequence.scale]) _ _ x

theorem normalizedTerminalMetric_volume_lower
    (S : GeneralizedBlowupSequence.{u}) (k : ℕ) {r v : ℝ}
    (hvolume : ENNReal.ofReal (v / (Real.sqrt (S.scale k)) ^ 3) ≤
      calibratedMetricVolume ((S.flow k).metric (S.base k).1) (S.baseBall k r)) :
    ENNReal.ofReal v ≤ (S.normalizedTerminalMetric k).volumeMeasure
      ((S.normalizedTerminalMetric k).ball (S.base k).2 r) := by
  have hsqrt : 0 < Real.sqrt (S.scale k) := Real.sqrt_pos.mpr (S.base_scalar_pos k)
  rw [Generalized.Noncollapse.calibratedMetricVolume_eq_volumeMeasure] at hvolume
  rw [S.normalizedTerminalMetric_ball]
  change ENNReal.ofReal v ≤
    (rescaledMetric ((S.flow k).metric (S.base k).1) (S.scale k) _).volumeMeasure _
  rw [rescaledMetric_volumeMeasure, Measure.smul_apply, smul_eq_mul]
  have hm := mul_le_mul_right hvolume (ENNReal.ofReal (Real.sqrt (S.scale k) ^ 3))
  rw [← ENNReal.ofReal_mul (pow_nonneg hsqrt.le 3),
    mul_div_cancel₀ _ (pow_ne_zero 3 hsqrt.ne')] at hm
  simpa only [ENNReal.ofReal_pow hsqrt.le] using hm

end PoincareMT.GeneralizedBlowupSequence

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem eventually_normalized_terminal_curvature_bound
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    (A : ℝ) (hA : 0 < A) :
    ∃ B : ℝ, 0 < B ∧ ∀ᶠ k : ℕ in atTop, ∀ x ∈ S.baseBall k A,
      (S.normalizedTerminalConnection k).curvatureTensorNorm x ≤ B := by
  obtain ⟨D, hD, hscalar⟩ := hbound A hA
  refine ⟨13 * max D 1, by positivity, ?_⟩
  filter_upwards [hscalar,
    DeepHorn.eventually_full_and_negative_curvature_bounds P04 S H.branch hD.le
      (by norm_num : (0 : ℝ) < 1)] with k hk hcurv x hx
  rw [S.normalizedTerminalConnection_curvatureTensorNorm]
  apply (div_le_iff₀ (S.base_scalar_pos k)).mpr
  have htime := ((S.flow k).slice_nonempty_iff (S.base k).1).mp ⟨(S.base k).2⟩
  exact (le_abs_self _).trans (hcurv _ htime x (hk x hx)).1

/-- A single positive chart radius works for all terminal centers in a fixed
normalized ball, eventually along the original sequence. -/
theorem eventually_uniform_terminal_normal_charts
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u}) (hbound : GeneralizedBlowupBoundedDistance S)
    (A : ℝ) (hA : 0 < A) :
    ∃ rho : ℝ, 0 < rho ∧ ∀ᶠ k : ℕ in atTop,
      ∀ p ∈ S.baseBall k A,
        ∃ L : EuclideanSpace ℝ (Fin 3) ≃L[ℝ] EuclideanSpace ℝ (Fin 3),
        ∃ Phi : PartialDiffeomorph (𝓡 3) (𝓡 3)
            (EuclideanSpace ℝ (Fin 3)) ((S.flow k).slice (S.base k).1).carrier ∞,
          Phi.source = Metric.ball 0 rho ∧
          Phi.target = (S.normalizedTerminalMetric k).ball p rho ∧ Phi 0 = p ∧
          (∀ v w, (S.normalizedTerminalMetric k).pullbackCoefficients
            (extChartAt (𝓡 3) p).symm (extChartAt (𝓡 3) p p) (L v) (L w) = inner ℝ v w) ∧
          HasFDerivAt (fun w => extChartAt (𝓡 3) p (Phi w)) L.toContinuousLinearMap 0 ∧
          (∀ w ∈ Metric.ball 0 rho, (S.normalizedTerminalMetric k).IsGeodesicOn
            (fun t => Phi (t • w)) {t : ℝ | t • w ∈ Metric.ball 0 rho}) ∧
          ∀ w ∈ Metric.ball 0 rho,
            (S.normalizedTerminalMetric k).edist p (Phi w) = ENNReal.ofReal ‖w‖ := by
  obtain ⟨r, v, hr, hv, hvolume⟩ := H.terminal_volume_of_boundedDistance P04 hbound
  let R := A + r + 1
  have hR : 0 < R := by dsimp [R]; positivity
  obtain ⟨B, hB, hcurv⟩ := H.eventually_normalized_terminal_curvature_bound P04 hbound
    (5 * R) (by positivity)
  let rho := RiemannianMetric.localInjectivityRadius 3 B R v
  have hrho : 0 < rho := RiemannianMetric.localInjectivityRadius_pos 3 B hR v
  have hrhoR : rho < R := RiemannianMetric.localInjectivityRadius_lt 3 B hR v
  refine ⟨rho, hrho, ?_⟩
  filter_upwards [hvolume, hcurv, H.balls_compact (5 * R) (by positivity)]
    with k hkvol hkcurv hkcompact p hp
  have hvol := S.normalizedTerminalMetric_volume_lower k hkvol
  have hcomp : IsCompact (closure ((S.normalizedTerminalMetric k).ball (S.base k).2 (5 * R))) := by
    rwa [S.normalizedTerminalMetric_ball]
  have hcurvature : ∀ x ∈ (S.normalizedTerminalMetric k).ball (S.base k).2 (5 * R),
      (S.normalizedTerminalConnection k).curvatureTensorNorm x ≤ B := by
    simpa only [S.normalizedTerminalMetric_ball] using hkcurv
  have hpoint : p ∈ (S.normalizedTerminalMetric k).ball (S.base k).2 A := by
    rwa [S.normalizedTerminalMetric_ball]
  obtain ⟨_, _, L, Phi, hsource, htarget, hzero, hL, hderiv, hgeo, hdist⟩ :=
    (S.normalizedTerminalMetric k).exists_uniform_precompact_exponential_diffeomorph_of_center
      (S.normalizedTerminalConnection k) (S.base k).2 p (by norm_num) hB.le hA hr hv
      (by dsimp [R]; linarith) (by dsimp [R]; linarith) hpoint hcomp hcurvature hvol
  refine ⟨L, Phi, hsource, htarget, hzero, hL, hderiv, ?_, hdist⟩
  intro w hw t ht
  exact hgeo w (Metric.ball_subset_ball hrhoR.le hw) t (Metric.ball_subset_ball hrhoR.le ht)

end PoincareMT.M30CommonBlowupControls
