import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.SourceJets
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.ClosedJets

/-!
# Terminal metric coefficients on the retained controlled charts

Actual closed source smoothness and uniform mixed jets construct the
terminal coefficients in the original limit atlas. Every within-domain jet
converges through the terminal time along the original M07 subsequence.

Reference: Morgan--Tian, Proposition 5.14, pp. 90--91.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.ControlledBlowupCompactness

open ControlledBlowupCylinder

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))

/-- Smoothness within the actual source domain includes its terminal time
on the retained zero-time spatial maps. -/
theorem eventually_source_contDiffOn_closed_slab
    (q : G.limitCarrier.carrier)
    {K : Set (EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKc : K ⊆ (extChartAt (𝓡 3) q).target) :
    ∀ᶠ k : ℕ in atTop, ContDiffOn ℝ ∞ (G.spatialSpacetimeCoefficients q k)
      (Icc 0 (T / 2) ×ˢ K) := by
  have hzero : -T / 2 < 0 ∧ 0 < T / 2 := ⟨by linarith, by linarith⟩
  have hc : ContinuousOn (extChartAt (𝓡 3) q).symm K :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.mono hKc
  obtain ⟨j, hj⟩ := G.exists_exhaustion_superset (hK.image_of_continuousOn hc)
  filter_upwards [eventually_ge_atTop j] with k hk
  let U := (extChartAt (𝓡 3) q).target ∩
    (extChartAt (𝓡 3) q).symm ⁻¹' G.exhaustion k
  have hU : IsOpen U :=
    (contMDiffOn_extChartAt_symm (n := ∞) q).continuousOn.isOpen_inter_preimage
      (isOpen_extChartAt_target q) (G.exhaustion_open k)
  have he : ContMDiffOn (𝓡 3) (𝓡 3) ∞ (G.referenceChartMap q k 0) U :=
    fun x hx => (G.referenceChartMap_contMDiffAt q k hzero hx.1 hx.2).contMDiffWithinAt
  have hsmooth : ContDiffOn ℝ ∞
      (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).metric z.1).pullbackCoefficients
          (G.referenceChartMap q k 0) z.2) (Icc (-T) 0 ×ˢ U) :=
    ((e (G.subsequence k)).smallFlow (hA (G.subsequence k)) hT).contDiffOn_pullbackCoefficients_within
      hU he
  have hshift : ContDiff ℝ ∞ (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
      (z.1 + (-T / 2), z.2)) := (contDiff_fst.add contDiff_const).prodMk contDiff_snd
  have hp := hsmooth.comp (s := Icc 0 (T / 2) ×ˢ K) hshift.contDiffOn (fun z hz =>
    ⟨⟨by linarith [hz.1.1], by linarith [hz.1.2]⟩,
      hKc hz.2, G.exhaustion_monotone hk (hj (mem_image_of_mem _ hz.2))⟩)
  exact hp

/-- Genuine all-order terminal convergence on each retained coordinate ball,
with the same subsequence and spatial maps as the given M07 limit. -/
theorem exists_smooth_terminal_source_coefficients
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier) {x₀ : EuclideanSpace ℝ (Fin 3)} {ρ : ℝ} (hρ : 0 < ρ)
    (hchart : Metric.closedBall x₀ ρ ⊆ (extChartAt (𝓡 3) q).target) :
    ∃ F : ℝ × EuclideanSpace ℝ (Fin 3) → SpacetimeBounds.MetricCoefficient 3,
      ContDiffOn ℝ ∞ F (Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ) ∧
      (∀ m, EqOn
        (iteratedFDeriv ℝ m (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
          (G.limitFlow.metricAt z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2))
        (iteratedFDerivWithin ℝ m F (Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ))
        (Ioo 0 (T / 2) ×ˢ Metric.ball x₀ ρ)) ∧
      ∀ m, TendstoUniformlyOn
        (fun k => iteratedFDerivWithin ℝ m (G.spatialSpacetimeCoefficients q k)
          (Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ))
        (iteratedFDerivWithin ℝ m F (Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ))
        atTop (Icc 0 (T / 2) ×ˢ Metric.closedBall x₀ ρ) := by
  let Ω := Icc (0 : ℝ) (T / 2) ×ˢ Metric.closedBall x₀ ρ
  have hint : interior Ω = Ioo 0 (T / 2) ×ˢ Metric.ball x₀ ρ := by
    rw [interior_prod_eq, interior_Icc, interior_closedBall x₀ hρ.ne']
  have hne : (interior Ω).Nonempty := by
    rw [hint]
    exact ⟨(T / 4, x₀), ⟨by constructor <;> linarith, Metric.mem_ball_self hρ⟩⟩
  have hzero : -T / 2 < 0 ∧ 0 < T / 2 := ⟨by linarith, by linarith⟩
  have hresult := ControlledConvergence.exists_smooth_limit_on_compact_convex_of_open_jets
    (isCompact_Icc.prod (isCompact_closedBall x₀ ρ))
    ((convex_Icc (0 : ℝ) (T / 2)).prod (convex_closedBall x₀ ρ)) hne
    (G.spatialSpacetimeCoefficients q)
    (eventually_source_contDiffOn_closed_slab G q (isCompact_closedBall x₀ ρ) hchart)
    (fun m => iteratedFDeriv ℝ m (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
      (G.limitFlow.metricAt z.1).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2))
    (fun m K hK hKΩ => G.tendstoUniformlyOn_spatialSpacetimeCoefficients_jets hzero q m hK
      (fun z hz => by
        have h := hKΩ hz
        rw [hint] at h
        exact ⟨⟨by linarith [h.1.1], h.1.2⟩, hchart (Metric.ball_subset_closedBall h.2)⟩))
    (fun m => by
      obtain ⟨C, hC, hbound⟩ := exists_eventually_source_open_spacetime_jet_bound
        G P04 hB hAr hcompact hcomplete q (isCompact_closedBall x₀ ρ) hchart m
      refine ⟨C, hC, hbound.mono ?_⟩
      intro k hk z hz
      rw [hint] at hz
      exact hk z.1 hz.1 z.2 (Metric.ball_subset_closedBall hz.2))
  simpa only [interior_prod_eq, interior_Icc, interior_closedBall x₀ hρ.ne'] using hresult

end PoincareMT.ControlledBlowupCompactness
