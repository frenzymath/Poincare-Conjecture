import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Geometry
import PoincareLib.Geometry.RicciFlow.Harnack.Regularity
import PoincareLib.Geometry.RicciFlow.Surgery.Induction.EpochExtension.Spacetime.GeneralizedCylinderRestriction

/-! # Closed subwindows of generalized blow-up limits -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.ControlledBlowupRestriction

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

variable {T T' : ℝ}

theorem closedWindow_subset (h : T' < T) : Icc (-T') (0 : ℝ) ⊆ Ioc (-T) 0 :=
  fun _ ht => ⟨lt_of_lt_of_le (neg_lt_neg h) ht.1, ht.2⟩

def closedWindowLimit (L : BlowupLimitFlow.{u} (Ioc (-T) 0))
    (hT' : 0 < T') (h : T' < T) : BlowupLimitFlow.{u} (Icc (-T') 0) where
  carrier := L.carrier
  connectedSpace := L.connectedSpace
  base := L.base
  flow := Poincare.Geometry.RicciFlow.Harnack.restrictFlow L.flow (closedWindow_subset h)
    ordConnected_Icc ⟨-T', ⟨le_rfl, by linarith⟩, 0, ⟨by linarith, le_rfl⟩, by linarith⟩
  zero_mem := ⟨by linarith, le_rfl⟩
  scalar_normalized := L.scalar_normalized
  complete := fun _ ht => L.complete _ (closedWindow_subset h ht)
  nonnegative_curvature_operator := fun _ ht => L.nonnegative_curvature_operator _ (closedWindow_subset h ht)
  curvature_locally_bounded_in_time := fun I hI hIJ =>
    L.curvature_locally_bounded_in_time I hI (hIJ.trans (closedWindow_subset h))

def closedWindowExhaustion {L : BlowupLimitFlow.{u} (Ioc (-T) 0)}
    (E : BlowupExhaustion L) (hT' : 0 < T') (h : T' < T) :
    BlowupExhaustion (closedWindowLimit L hT' h) where
  space := E.space
  space_open := E.space_open
  space_connected := E.space_connected
  space_compactClosure := E.space_compactClosure
  space_increasing := E.space_increasing
  space_covers := E.space_covers
  base_mem := E.base_mem
  time := fun k => min T' (E.time k)
  time_pos := fun k => lt_min hT' (E.time_pos k)
  time_increasing := fun _ _ hkl => min_le_min_left T' (E.time_increasing hkl)
  time_subset := fun k _ ht => ⟨(neg_le_neg (min_le_left T' (E.time k))).trans ht.1, ht.2⟩
  time_cofinal := by
    intro I hI hIJ
    filter_upwards [E.time_cofinal I hI (hIJ.trans (closedWindow_subset h))] with k hk t ht
    refine ⟨?_, (hIJ ht).2⟩
    rcases le_total T' (E.time k) with hle | hle
    · rw [min_eq_left hle]
      exact (hIJ ht).1
    · rw [min_eq_right hle]
      exact (hk ht).1

theorem closedWindow_time_subset {L : BlowupLimitFlow.{u} (Ioc (-T) 0)}
    (E : BlowupExhaustion L) (hT' : 0 < T') (h : T' < T) (k : ℕ) :
    Icc (-(closedWindowExhaustion E hT' h).time k) 0 ⊆ Icc (-E.time k) 0 :=
  fun _ ht => ⟨(neg_le_neg (min_le_right T' (E.time k))).trans ht.1, ht.2⟩

def closedWindowCylinder {S : GeneralizedBlowupSequence.{u}}
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (hT' : 0 < T') (h : T' < T) (k : ℕ) :
    GeneralizedFlowCylinder (S.flow (G.subsequence k)) (closedWindowLimit G.limit hT' h).sliceCarrier
      (S.base (G.subsequence k)).1 (S.scale (G.subsequence k))
      (Icc (-(closedWindowExhaustion G.exhaustion hT' h).time k) 0)
      ((closedWindowExhaustion G.exhaustion hT' h).space k) :=
  (G.embedding k).restrict (closedWindow_time_subset G.exhaustion hT' h k) Subset.rfl

end PoincareMT.ControlledBlowupRestriction
