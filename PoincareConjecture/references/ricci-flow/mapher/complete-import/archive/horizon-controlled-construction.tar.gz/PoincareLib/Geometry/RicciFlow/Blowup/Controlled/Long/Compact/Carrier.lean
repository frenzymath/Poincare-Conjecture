import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.Bound
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Compact.Minimum

/-! # Uniform past curvature bounds for compact controlled limit carriers -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable

theorem exists_uniform_scalar_bound_of_compact_limit
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u}) (P06 : HarnackAncientTheory.{u})
    {epsilon C : ℝ}
    (hM29 : ∀ S : GeneralizedBlowupSequence.{u},
      DenseGeneralizedBoundedDistanceHypotheses S epsilon C → GeneralizedBlowupBoundedDistance S)
    (H : DenseGeneralizedBoundedDistanceHypotheses S epsilon C)
    [CompactSpace G.limit.carrier.carrier] :
    ∃ D : ℝ, 0 < D ∧ ∀ t ∈ Ioc (-T) 0, ∀ x : G.limit.carrier.carrier,
      (G.limit.flow.connection t).scalarCurvature x ≤ D := by
  let : ConnectedSpace G.limit.carrier.carrier := G.limit.connectedSpace
  obtain ⟨D, hD, hbound⟩ := G.exists_uniform_compact_scalar_bound_of_minimum_bound hT
    P04 P06 hM29 H (K := univ) isCompact_univ isPreconnected_univ (B := 1) (by
      intro t ht
      obtain ⟨x, hx⟩ := ControlledLongCompact.exists_scalar_le_one_of_compact_limit P04 G.limit ht
      exact ⟨x, mem_univ x, hx⟩)
  exact ⟨D, hD, fun t ht x => hbound t ht x (mem_univ x)⟩

end PoincareMT.GeneralizedBlowupConvergence
