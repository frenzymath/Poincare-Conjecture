import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Diagonal
import PoincareLib.Geometry.RicciFlow.Compactness.Coordinates.Rescaling
import PoincareLib.Geometry.Riemannian.Metric.ConnectedComponent
import PoincareLib.Geometry.RicciFlow.Compactness.SourceMetric

/-!
# Terminal charts on the based component

All terminal base balls and all chosen normal charts lie in the component
of the basepoint. Restriction preserves their actual intrinsic distances,
so the metric extraction uses a connected source without assuming that the
entire generalized-flow slice is connected.
-/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle ENNReal Topology

universe u

namespace PoincareMT.GeneralizedBlowupSequence

noncomputable def terminalComponent (S : GeneralizedBlowupSequence.{u}) (k : ℕ) :
    TopologicalSpace.Opens ((S.flow k).slice (S.base k).1).carrier :=
  Poincare.connectedComponentOpens (EuclideanSpace ℝ (Fin 3)) (S.base k).2

def terminalComponentBase (S : GeneralizedBlowupSequence.{u}) (k : ℕ) : S.terminalComponent k :=
  ⟨(S.base k).2, mem_connectedComponent⟩

noncomputable def terminalComponentMetric (S : GeneralizedBlowupSequence.{u}) (k : ℕ) :
    RiemannianMetric 3 (S.terminalComponent k) :=
  (S.normalizedTerminalMetric k).connectedComponentMetric (S.base k).2

noncomputable def terminalCarrier (S : GeneralizedBlowupSequence.{u}) (k : ℕ) :
    FlowCarrier.{u} 3 where
  carrier := S.terminalComponent k
  topologicalSpace := inferInstance
  measurableSpace := inferInstance
  borelSpace := inferInstance
  chartedSpace := inferInstance
  isManifold := inferInstance
  t2Space := inferInstance
  t3Space := inferInstance
  secondCountable := inferInstance
  connected := by
    change IsConnected (univ : Set (Poincare.connectedComponentOpens
      (EuclideanSpace ℝ (Fin 3)) (S.base k).2))
    exact isConnected_univ

theorem terminalComponentMetric_edist (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
    (x y : S.terminalComponent k) :
    (S.terminalComponentMetric k).edist x y =
      (S.normalizedTerminalMetric k).edist x.val y.val :=
  RiemannianMetric.edist_subtype_val isClosed_connectedComponent _ _ (fun _ _ _ => rfl) x y

theorem baseBall_subset_terminalComponent (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
    (A : ℝ) : S.baseBall k A ⊆ S.terminalComponent k := by
  intro x hx
  apply (S.normalizedTerminalMetric k).mem_of_edist_lt_top
    isClosed_connectedComponent (mem_connectedComponent (x := (S.base k).2))
  rw [← S.normalizedTerminalMetric_ball] at hx
  exact hx.trans_le le_top

theorem terminalComponentMetric_image_ball (S : GeneralizedBlowupSequence.{u}) (k : ℕ)
    (A : ℝ) : Subtype.val '' (S.terminalComponentMetric k).ball
      (S.terminalComponentBase k) A = S.baseBall k A := by
  rw [← S.normalizedTerminalMetric_ball]
  exact RiemannianMetric.image_ball_subtype_val isClosed_connectedComponent _ _
    (fun _ _ _ => rfl) (S.terminalComponentBase k) A

end PoincareMT.GeneralizedBlowupSequence

namespace PoincareMT.NormalChartCover

variable {S : GeneralizedBlowupSequence.{u}} {k : ℕ} {A R rho a b : ℝ} {N : ℕ}
  (C : NormalChartCover (fun _ => S.normalizedTerminalMetric k)
    (S.base k).2 (-1) 1 A R rho a b N)

theorem unitBallMap_mem_terminalComponent (hrho : 0 < rho) (hrhoR : rho / 2 ≤ R)
    (i : Fin (N + 1)) (x : Metric.ball (0 : EuclideanSpace ℝ (Fin 3)) 1) :
    C.unitBallMap i x ∈ S.terminalComponent k := by
  have hc : C.centre i ∈ S.terminalComponent k :=
    S.baseBall_subset_terminalComponent k A
      (by simpa only [S.normalizedTerminalMetric_ball] using C.centre_mem i)
  apply (S.normalizedTerminalMetric k).mem_of_edist_lt_top isClosed_connectedComponent hc
  unfold unitBallMap
  rw [C.radial_distance i _ (Metric.ball_subset_ball hrhoR (rescale_mem_half_ball hrho x))]
  exact ENNReal.ofReal_lt_top

noncomputable def componentUnitBallMap (hrho : 0 < rho) (hrhoR : rho / 2 ≤ R)
    (i : Fin (N + 1)) (x : Metric.ball (0 : EuclideanSpace ℝ (Fin 3)) 1) :
    S.terminalComponent k :=
  ⟨C.unitBallMap i x, C.unitBallMap_mem_terminalComponent hrho hrhoR i x⟩

theorem componentUnitBallMap_isLocalDiffeomorph (hrho : 0 < rho) (hrhoR : rho / 2 ≤ R)
    (i : Fin (N + 1)) :
    letI : Nonempty (Metric.ball (0 : EuclideanSpace ℝ (Fin 3)) 1) := ⟨⟨0, by simp⟩⟩
    letI := (Metric.isOpen_ball (x := (0 : EuclideanSpace ℝ (Fin 3))) (ε := 1)).isOpenEmbedding_subtypeVal.singletonChartedSpace
    IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ (C.componentUnitBallMap hrho hrhoR i) := by
  let : Nonempty (Metric.ball (0 : EuclideanSpace ℝ (Fin 3)) 1) := ⟨⟨0, by simp⟩⟩
  let := (Metric.isOpen_ball (x := (0 : EuclideanSpace ℝ (Fin 3))) (ε := 1)).isOpenEmbedding_subtypeVal.singletonChartedSpace
  let f := C.componentUnitBallMap hrho hrhoR i
  have hmap := C.unitBallMap_isLocalDiffeomorph hrho hrhoR i
  have hcont : Continuous f := hmap.contMDiff.continuous.subtype_mk _
  intro x
  have hi := Poincare.isLocalDiffeomorph_opensSubtypeVal (𝓡 3) (S.terminalComponent k) (f x)
  apply ((hmap x).comp (𝓡 3) (S.terminalComponent k)
    hi.localInverse_isLocalDiffeomorphAt).congr_of_eventuallyEq
  filter_upwards [hcont.continuousAt.tendsto.eventually hi.localInverse_eventuallyEq_left]
    with y hy
  exact hy.symm

theorem componentUnitBallMap_isOpenEmbedding (hrho : 0 < rho) (hrhoR : rho / 2 ≤ R)
    (i : Fin (N + 1)) : Topology.IsOpenEmbedding (C.componentUnitBallMap hrho hrhoR i) := by
  let : Nonempty (Metric.ball (0 : EuclideanSpace ℝ (Fin 3)) 1) := ⟨⟨0, by simp⟩⟩
  let := (Metric.isOpen_ball (x := (0 : EuclideanSpace ℝ (Fin 3))) (ε := 1)).isOpenEmbedding_subtypeVal.singletonChartedSpace
  have hd := C.componentUnitBallMap_isLocalDiffeomorph hrho hrhoR i
  apply Topology.IsOpenEmbedding.of_continuous_injective_isOpenMap
    hd.contMDiff.continuous _ hd.isOpenMap
  intro x y hxy
  exact (C.unitBallMap_isOpenEmbedding hrho hrhoR i).injective (congrArg Subtype.val hxy)

theorem componentUnitBallMap_distances (hrho : 0 < rho) (hrhoR : rho / 2 ≤ R)
    (i : Fin (N + 1)) (x y : Metric.ball (0 : EuclideanSpace ℝ (Fin 3)) 1) :
    (Real.sqrt a * (rho / 2)) * dist x y ≤
        ((S.terminalComponentMetric k).edist
          (C.componentUnitBallMap hrho hrhoR i x) (C.componentUnitBallMap hrho hrhoR i y)).toReal ∧
      ((S.terminalComponentMetric k).edist
          (C.componentUnitBallMap hrho hrhoR i x) (C.componentUnitBallMap hrho hrhoR i y)).toReal ≤
        (Real.sqrt b * (rho / 2)) * dist x y := by
  rw [S.terminalComponentMetric_edist]
  exact C.unitBallMap_distances hrho i x y

theorem componentUnitBallMap_cover (hrho : 0 < rho) (hrhoR : rho / 2 ≤ R) :
    (S.terminalComponentMetric k).ball (S.terminalComponentBase k) A ⊆
      ⋃ i, C.componentUnitBallMap hrho hrhoR i ''
        {x : Metric.ball (0 : EuclideanSpace ℝ (Fin 3)) 1 |
          ‖(x : EuclideanSpace ℝ (Fin 3))‖ ≤ 1 / 2} := by
  intro y hy
  have hy' : y.val ∈ (S.normalizedTerminalMetric k).ball (S.base k).2 A := by
    change (S.normalizedTerminalMetric k).edist (S.base k).2 y.val < _
    change (S.terminalComponentMetric k).edist (S.terminalComponentBase k) y < _ at hy
    simpa only [S.terminalComponentMetric_edist,
      GeneralizedBlowupSequence.terminalComponentBase] using hy
  obtain ⟨i, x, hx, hxy⟩ := mem_iUnion.mp (C.unitBallMap_cover hrho hy')
  exact mem_iUnion.mpr ⟨i, x, hx, Subtype.ext hxy⟩

end PoincareMT.NormalChartCover
