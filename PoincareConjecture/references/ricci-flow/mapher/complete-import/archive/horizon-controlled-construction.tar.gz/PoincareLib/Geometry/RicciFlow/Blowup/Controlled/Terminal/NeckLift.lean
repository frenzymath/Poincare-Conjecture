import PoincareLib.Topology.Manifold.NeckCap.Fibration.Lift

/-!
# Lifting one terminal neck

A chosen lift of a neck center determines an actual geometric neck on a
smooth covering space. The accuracy parameter and scalar normalization scale
remain unchanged; a global cover by necks is unnecessary.
-/

set_option autoImplicit false

open Set Function
open scoped Manifold ContDiff

namespace PoincareMT.EpsilonNeck

theorem exists_lifted_neck_of_covering
    {M E : Type*} [TopologicalSpace M] [TopologicalSpace E]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) E] [IsManifold (𝓡 3) ∞ E]
    {g : RiemannianMetric 3 M} (N : EpsilonNeck g) {p : E → M}
    (hcover : IsCoveringMap p) (hp : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ p)
    (e : E) (he : p e = N.center) :
    ∃ L : EpsilonNeck (g.pullbackOfLocalDiffeomorph p hp),
      L.epsilon = N.epsilon ∧ L.scale = N.scale ∧ L.center = e ∧
        p '' L.central_sphere = N.central_sphere ∧
        p '' L.carrier = N.carrier ∧ InjOn p L.carrier := by
  have hecarrier : p e ∈ N.carrier :=
    he.symm ▸ N.central_sphere_subset N.center_on_central_sphere
  obtain ⟨F, hFe, hF, hopen⟩ := N.exists_lifted_coordinate hcover e hecarrier
  have hcentral : p e ∈ N.central_sphere := he.symm ▸ N.center_on_central_sphere
  rw [← N.coordinate_central_range] at hcentral
  obtain ⟨y, hy⟩ := hcentral
  have hy' : N.coordinate
      (y, ⟨0, neg_lt_zero.mpr (inv_pos.mpr N.epsilon_pos), inv_pos.mpr N.epsilon_pos⟩) =
        ⟨p e, hecarrier⟩ := Subtype.ext hy
  have hz := congrArg N.coordinate.symm hy'
  rw [N.coordinate.symm_apply_apply] at hz
  have hcenter : ∃ y : UnitTwoSphere,
      F (y, ⟨0, neg_lt_zero.mpr (inv_pos.mpr N.epsilon_pos),
        inv_pos.mpr N.epsilon_pos⟩) = e := ⟨y, hz ▸ hFe⟩
  exact ⟨N.ofLiftedCoordinate hp e he F hopen hF hcenter, rfl, rfl, rfl,
    N.image_lifted_central_sphere hF, N.image_lifted_coordinate hF,
    N.injOn_projection_lifted_coordinate hF⟩

end PoincareMT.EpsilonNeck
