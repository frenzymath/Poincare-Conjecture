import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Convergence.Terminal.ScalarJets

/-! # Canonical metric jets in the original normalized source clock -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 12
set_option maxHeartbeats 1000000

open Set Filter Metric
open scoped Manifold ContDiff Bundle Topology Pointwise

universe u

namespace PoincareMT.ControlledConvergence

theorem midpoint_translate_domain {E : Type*} [AddCommGroup E] (T : ℝ) (U : Set E) :
    (T / 2, (0 : E)) +ᵥ (Ioc (-T) 0 ×ˢ U) = Ioc (-T / 2) (T / 2) ×ˢ U := by
  ext z
  rw [Set.mem_vadd_set_iff_neg_vadd_mem]
  simp only [mem_prod, mem_Ioc, Prod.fst_add, Prod.snd_add, Prod.fst_neg,
    Prod.snd_neg, neg_zero, zero_add, vadd_eq_add]
  constructor <;> intro h <;>
    exact ⟨⟨by linarith [h.1.1], by linarith [h.1.2]⟩, h.2⟩

theorem iteratedFDerivWithin_midpoint_translate
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    (T : ℝ) (U : Set E) (f : ℝ × E → F) (r : ℕ) (z : ℝ × E) :
    iteratedFDerivWithin ℝ r (fun w : ℝ × E => f (w.1 + T / 2, w.2))
      (Ioc (-T) 0 ×ˢ U) z =
    iteratedFDerivWithin ℝ r f (Ioc (-T / 2) (T / 2) ×ˢ U) (z.1 + T / 2, z.2) := by
  simpa only [midpoint_translate_domain, Prod.add_def, add_zero] using
    (iteratedFDerivWithin_comp_add_right (𝕜 := ℝ) (f := f)
      (s := Ioc (-T) 0 ×ˢ U) r (T / 2, (0 : E)) z)

end PoincareMT.ControlledConvergence

namespace PoincareMT.ControlledBlowupCompactness

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.measurableSpace
  FlowCarrier.borelSpace FlowCarrier.chartedSpace FlowCarrier.isManifold
  FlowCarrier.t2Space FlowCarrier.t3Space FlowCarrier.secondCountable
  PoincareMT.smallCarrier PoincareMT.smallChartedSpace PoincareMT.smallIsManifold
  PoincareMT.smallT3Space PoincareMT.smallMeasurableSpace PoincareMT.smallBorelSpace

variable {S : GeneralizedBlowupSequence.{u}} {idx : ℕ → ℕ} {A eta : ℕ → ℝ}
  {T B : ℝ} {hA : ∀ i, 0 < A i} {hT : 0 < T}
  {e : ∀ i, ControlledBlowupCylinder S (idx i) (A i) T B (eta i)}
  (G : PointedGeometricConvergence (interiorSequence S idx A eta T B hA hT e))
  (F : RicciFlow 3 G.limitCarrier.carrier (Ioc (-T / 2) (T / 2)))
  (hF : ∀ t ∈ Ioo (-T / 2) (T / 2), F.metric t = G.limitFlow.metricAt t)

include hF

theorem tendstoUniformlyOn_originalClock_scalarJet
    (P04 : RicciFlowCurvatureTheory.{u}) (hB : 0 ≤ B)
    (hAr : Tendsto A atTop atTop)
    (hcompact : ∀ i, IsCompact (closure (S.baseBall (idx i) (A i))))
    (hcomplete : G.limitCarrier.metricComplete (G.limitFlow.metricAt 0))
    (q : G.limitCarrier.carrier) (r : ℕ) (a b : Fin 3)
    {K : Set (ℝ × EuclideanSpace ℝ (Fin 3))} (hK : IsCompact K)
    (hKU : K ⊆ Ioc (-T) 0 ×ˢ (extChartAt (𝓡 3) q).target) :
    TendstoUniformlyOn
      (fun k => iteratedFDerivWithin ℝ r
        (fun z => G.spatialSpacetimeCoefficients q k (z.1 + T / 2, z.2)
          (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))
        (Ioc (-T) 0 ×ˢ (extChartAt (𝓡 3) q).target))
      (iteratedFDerivWithin ℝ r (fun z : ℝ × EuclideanSpace ℝ (Fin 3) =>
        (F.metric (z.1 + T / 2)).pullbackCoefficients (extChartAt (𝓡 3) q).symm z.2
          (EuclideanSpace.basisFun (Fin 3) ℝ a) (EuclideanSpace.basisFun (Fin 3) ℝ b))
        (Ioc (-T) 0 ×ˢ (extChartAt (𝓡 3) q).target)) atTop K := by
  let f := fun z : ℝ × EuclideanSpace ℝ (Fin 3) => (z.1 + T / 2, z.2)
  have hc : Continuous f := (continuous_fst.add continuous_const).prodMk continuous_snd
  have hKi : f '' K ⊆ Ioc (-T / 2) (T / 2) ×ˢ (extChartAt (𝓡 3) q).target := by
    rintro _ ⟨z, hz, rfl⟩
    exact ⟨⟨by dsimp [f]; linarith [(hKU hz).1.1],
      by dsimp [f]; linarith [(hKU hz).1.2]⟩, (hKU hz).2⟩
  have hconv := tendstoUniformlyOn_canonical_scalarJet G F hF P04 hB hAr hcompact
    hcomplete q r a b (hK.image hc) hKi
  have hp := (hconv.comp f).mono (subset_preimage_image f K)
  simpa only [Function.comp_def, f, ← ControlledConvergence.iteratedFDerivWithin_midpoint_translate]
    using hp

end PoincareMT.ControlledBlowupCompactness
