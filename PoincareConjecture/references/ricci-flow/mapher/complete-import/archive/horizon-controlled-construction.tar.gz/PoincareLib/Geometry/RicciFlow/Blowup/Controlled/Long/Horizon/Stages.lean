import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Subsequence
import PoincareLib.Topology.Order.SequentialMaximal
import PoincareLib.Topology.Sequences.Refinement

/-!
# Compatible source subsequences along increasing controlled horizons

Horizon stages retain actual controlled cylinders in the original sequence.
Refinement compares their subsequence filters, allowing finite tails to be
discarded in a diagonal extraction. Proper refinements increase the horizon.
-/

set_option autoImplicit false

open Set Filter
open scoped ENNReal Topology

universe u

namespace PoincareMT.ControlledBlowupHorizon

structure Stage (S : GeneralizedBlowupSequence.{u}) (T₀ : ℝ≥0∞) where
  horizon : ℝ≥0∞
  horizon_pos : 0 < horizon
  horizon_le : horizon ≤ T₀
  index : ℕ → ℕ
  strictMono : StrictMono index
  cylinders : ∀ T : ℝ, 0 < T → ENNReal.ofReal T < horizon →
    ∃ B : ℝ, 0 ≤ B ∧ ∀ A : ℝ, 0 < A → ∀ eta : ℝ, 0 < eta →
      ∀ᶠ k in map index atTop, Nonempty (ControlledBlowupCylinder S k A T B eta)

namespace Stage

variable {S : GeneralizedBlowupSequence.{u}} {T₀ : ℝ≥0∞}

def Refines (a b : Stage S T₀) : Prop :=
  a = b ∨ a.horizon < b.horizon ∧ map b.index atTop ≤ map a.index atTop

theorem refines_refl (a : Stage S T₀) : Refines a a := Or.inl rfl

theorem Refines.horizon_le {a b : Stage S T₀} (h : Refines a b) :
    a.horizon ≤ b.horizon := by
  rcases h with rfl | h
  · exact le_rfl
  · exact h.1.le

theorem Refines.filter_le {a b : Stage S T₀} (h : Refines a b) :
    map b.index atTop ≤ map a.index atTop := by
  rcases h with rfl | h
  · exact le_rfl
  · exact h.2

theorem Refines.trans {a b c : Stage S T₀} (hab : Refines a b) (hbc : Refines b c) :
    Refines a c := by
  rcases hab with rfl | hab
  · exact hbc
  rcases hbc with rfl | hbc
  · exact Or.inr hab
  exact Or.inr ⟨hab.1.trans hbc.1, hbc.2.trans hab.2⟩

/-- A countable increasing family has an actual source diagonal at the
supremum of its horizons. Every bound is inherited from one earlier stage. -/
theorem exists_upper_bound (a : ℕ → Stage S T₀)
    (ha : ∀ n, Refines (a n) (a (n + 1))) :
    ∃ b : Stage S T₀, ∀ n, Refines (a n) b := by
  classical
  have htime : Monotone (fun n => (a n).horizon) :=
    monotone_nat_of_le_succ fun n => (ha n).horizon_le
  have hfilter : Antitone (fun n => map (a n).index atTop) :=
    antitone_nat_of_succ_le fun n => (ha n).filter_le
  have hrel : ∀ n m, n ≤ m → Refines (a n) (a m) := by
    intro n m hnm
    induction m, hnm using Nat.le_induction with
    | base => exact refines_refl _
    | succ m hnm ih => exact ih.trans (ha m)
  by_cases hmax : ∃ n, ∀ m, (a m).horizon ≤ (a n).horizon
  · obtain ⟨n, hn⟩ := hmax
    refine ⟨a n, fun m => ?_⟩
    rcases le_total m n with hmn | hnm
    · exact hrel m n hmn
    · rcases hrel n m hnm with h | h
      · exact Or.inl h.symm
      · exact (not_lt_of_ge (hn m) h.1).elim
  · obtain ⟨sigma, hsigma, hsig⟩ := Poincare.exists_strictMono_map_le_of_antitone
      (fun n => (a n).index) (fun n => (a n).strictMono) hfilter
    let b : Stage S T₀ := {
      horizon := ⨆ n, (a n).horizon
      horizon_pos := (a 0).horizon_pos.trans_le (le_iSup (fun n => (a n).horizon) 0)
      horizon_le := iSup_le fun n => (a n).horizon_le
      index := sigma
      strictMono := hsigma
      cylinders := by
        intro T hT hTh
        obtain ⟨n, hn⟩ := lt_iSup_iff.mp hTh
        obtain ⟨B, hB, hcyl⟩ := (a n).cylinders T hT hn
        exact ⟨B, hB, fun A hA eta heta => (hsig n) (hcyl A hA eta heta)⟩ }
    refine ⟨b, fun n => Or.inr ⟨?_, hsig n⟩⟩
    apply (le_iSup (fun n => (a n).horizon) n).lt_of_ne
    intro heq
    apply hmax
    exact ⟨n, fun m => heq ▸ le_iSup (fun n => (a n).horizon) m⟩

theorem exists_full_horizon [Nonempty (Stage S T₀)]
    (hextend : ∀ a : Stage S T₀, a.horizon < T₀ →
      ∃ b : Stage S T₀, Refines a b ∧ a.horizon < b.horizon) :
    ∃ a : Stage S T₀, a.horizon = T₀ := by
  obtain ⟨a, hmax⟩ := Poincare.exists_maximal_of_sequential_bounds
    (A := Stage S T₀) Refines Stage.horizon
    refines_refl (fun h h' => h.trans h')
    (fun h => h.imp_right fun h' => h'.1) exists_upper_bound
  refine ⟨a, a.horizon_le.antisymm ?_⟩
  by_contra h
  obtain ⟨b, hab, htime⟩ := hextend a (lt_of_not_ge h)
  exact (not_lt_of_ge (hmax b hab).horizon_le) htime

end Stage
end PoincareMT.ControlledBlowupHorizon
