import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Boundary.ClosedFlow
import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.LocalFlow

/-! # Complete closed extensions of actual finite blow-up limits -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology ENNReal

universe u

namespace PoincareMT.GeneralizedBlowupConvergence

attribute [local instance] FlowCarrier.topologicalSpace FlowCarrier.chartedSpace
  FlowCarrier.isManifold FlowCarrier.t2Space FlowCarrier.t3Space

/-- The actual finite limit extends through its backward endpoint on its
original carrier, with complete slices and local backward flows at that endpoint. -/
theorem exists_complete_closed_extension_of_compact_scalar_bounds
    {S : GeneralizedBlowupSequence.{u}} {T : ℝ} (hT : 0 < T)
    (G : GeneralizedBlowupConvergence S (Ioc (-T) 0))
    (P04 : RicciFlowCurvatureTheory.{u})
    {epsilon C kappa r₀ mu : ℝ} {T₀ : ℝ≥0∞}
    (H : M30LongBlowupControls S epsilon C kappa r₀ mu T₀)
    (horizon : ENNReal.ofReal T < T₀)
    (hcompact : ∀ K : Set G.limit.carrier.carrier, IsCompact K →
      ∃ D : ℝ, ∀ t ∈ Ioc (-T) 0, ∀ x ∈ K,
        (G.limit.flow.connection t).scalarCurvature x ≤ D) :
    ∃ F : RicciFlow 3 G.limit.carrier.carrier (Icc (-T) 0),
      (∀ t ∈ Ioc (-T) 0, F.metric t = G.limit.flow.metric t) ∧
      (∀ t ∈ Icc (-T) 0, G.limit.carrier.metricComplete (F.metric t)) ∧
      (∀ t ∈ Icc (-T) 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x) ∧
      ∀ q : G.limit.carrier.carrier, ∃ rho d : ℝ, 0 < rho ∧ 0 < d ∧
        ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target ∧
        let U : Opens (EuclideanSpace ℝ (Fin 3)) := ⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩
        ∃ L : RicciFlow 3 U (Icc (-d) 0),
          (∀ t ∈ Icc (-d) 0, ∀ x : U, (L.connection t).NonnegativeCurvatureOperator x) ∧
          ∀ (x : U) (v w : TangentSpace (𝓡 3) x),
            (L.metric 0).inner x v w = (F.metric (-T)).pullbackCoefficients
              (extChartAt (𝓡 3) q).symm x v w := by
  obtain ⟨F, hF, hc, hn, hlocal⟩ :=
    ControlledBlowupBoundary.exists_complete_closed_flow_of_chart_extensions
      G.limit.carrier G.limit.base hT G.limit.flow (G.limit.complete 0 G.limit.zero_mem)
      (G.exists_local_backward_extension_of_compact_scalar_bounds hT P04 H horizon hcompact)
  refine ⟨F, hF, hc, hn, ?_⟩
  intro q
  obtain ⟨rho, V, hrho, hV, hchart, L, hL, hmetric⟩ := hlocal q
  refine ⟨rho, V - T, hrho, sub_pos.mpr hV, hchart,
    ControlledBlowupBoundary.localBackwardFlow hT hV L,
    fun _ ht x => ControlledBlowupBoundary.localBackwardFlow_nonnegativeCurvatureOperator
      hT hV L hL ht x, ?_⟩
  intro x v w
  rw [ControlledBlowupBoundary.localBackwardFlow_metric_zero]
  exact hmetric (-T) ⟨le_rfl, by linarith⟩ x v w

end PoincareMT.GeneralizedBlowupConvergence
