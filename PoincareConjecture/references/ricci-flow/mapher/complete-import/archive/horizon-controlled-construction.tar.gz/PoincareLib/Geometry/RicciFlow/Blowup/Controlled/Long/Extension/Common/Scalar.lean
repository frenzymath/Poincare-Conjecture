import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Long.Extension.Scalar

/-! # Forward scalar propagation from an interior source slice -/

set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter
open scoped Manifold ContDiff Bundle Topology

universe u

namespace PoincareMT.M30CommonBlowupControls

variable {S : GeneralizedBlowupSequence.{u}} {epsilon C kappa r₀ mu : ℝ}

theorem cylinder_scalar_lt_two_mul_after_time
    (H : M30CommonBlowupControls S epsilon C kappa r₀ mu)
    (P04 : RicciFlowCurvatureTheory.{u})
    (k : ℕ) {I : Set ℝ} {U : Set ((S.flow k).slice (S.base k).1).carrier}
    (e : GeneralizedFlowCylinder (S.flow k) ((S.flow k).slice (S.base k).1)
      (S.base k).1 (S.scale k) I U)
    {x : ((S.flow k).slice (S.base k).1).carrier} (hx : x ∈ U)
    {f : ℝ → ℝ}
    (hf : ∀ t (ht : t ∈ I), f t = (S.flow k).scalar (e.pointMap t ht x))
    {a b K : ℝ} (hK : 4 ≤ K) (hI : Icc a b ⊆ I) (hb : b ≤ 0)
    (hbound : f a < K * S.scale k)
    (hshort : b - a < 1 / (4 * (H.analytic_constant + 1) * K)) :
    ∀ s ∈ Icc a b, f s < (2 * K) * S.scale k := by
  have hscale : 0 < S.scale k := S.base_scalar_pos k
  have hcont : ContinuousOn (fun t => f t / S.scale k) (Icc a b) :=
    ((e.scalar_continuousOn P04 hx hf).mono hI).div_const _
  have hder : ∀ t ∈ Ioo a b, 4 ≤ f t / S.scale k →
      ∃ d, HasDerivAt (fun s => f s / S.scale k) d t ∧
        |d| ≤ H.analytic_constant * (f t / S.scale k) ^ 2 := by
    intro t ht hhigh
    obtain ⟨d, hd, hdbound⟩ := H.normalized_cylinder_scalar_derivative_bound k e hx hf
      (hI ⟨ht.1.le, ht.2.le⟩) (ht.2.le.trans hb) hhigh
    refine ⟨d, (hd.mono hI).hasDerivAt ?_, hdbound⟩
    exact mem_of_superset (isOpen_Ioo.mem_nhds ht) Ioo_subset_Icc_self
  have hscalar := SingularRegularLimit.scalar_lt_two_mul_of_short_interval
    H.analytic_constant_pos.le (by norm_num : (0 : ℝ) < 4) hK hcont
    ((div_lt_iff₀ hscale).mpr hbound) hder hshort
  intro s hs
  exact (div_lt_iff₀ hscale).mp (hscalar s hs)

end PoincareMT.M30CommonBlowupControls
