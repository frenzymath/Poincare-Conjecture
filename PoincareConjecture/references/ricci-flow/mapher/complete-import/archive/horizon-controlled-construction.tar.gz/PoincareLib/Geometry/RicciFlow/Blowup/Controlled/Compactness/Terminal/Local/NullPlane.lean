import PoincareLib.Geometry.RicciFlow.Blowup.Controlled.Compactness.Terminal.Local.Nullity
import PoincareLib.Geometry.Riemannian.Soul.Point.Basic

/-! # Null planes on terminal metrics with local backward realizations -/

noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false

open Set Filter Metric TopologicalSpace
open scoped Manifold ContDiff Bundle Topology

universe u v

namespace PoincareMT.ControlledTerminal

open RicciFlow.Splitting

attribute [local instance] RicciFlow.uliftChartedSpace RicciFlow.uliftIsManifold

variable {M : Type v} [TopologicalSpace M]
  [ChartedSpace (EuclideanSpace ℝ (Fin 3)) M] [IsManifold (𝓡 3) ∞ M]
  {g : RiemannianMetric 3 M}

theorem uliftFlow_metric_pullback
    {E : Type} [TopologicalSpace E]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) E] [IsManifold (𝓡 3) ∞ E]
    {J : Set ℝ} (F : RicciFlow 3 E J) (t : ℝ) {f : E → M}
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hmetric : ∀ x v w, (F.metric t).inner x v w = g.inner (f x)
      (mfderiv (𝓡 3) (𝓡 3) f x v) (mfderiv (𝓡 3) (𝓡 3) f x w)) :
    ∀ (x : ULift.{u} E) (v w : TangentSpace (𝓡 3) x),
      (F.ulift.metric t).inner x v w = g.inner (f x.down)
        (mfderiv (𝓡 3) (𝓡 3) (fun z : ULift.{u} E => f z.down) x v)
        (mfderiv (𝓡 3) (𝓡 3) (fun z : ULift.{u} E => f z.down) x w) := by
  intro x v w
  let e := Poincare.Manifold.uliftDiffeomorph (𝓡 3) E
  have hd := mfderiv_comp x (hf.contMDiff.mdifferentiable (by simp) x.down)
    (e.contMDiff.mdifferentiable (by simp) x)
  have hdv := congrArg (fun A => A v) hd
  have hdw := congrArg (fun A => A w) hd
  change (F.metric t).inner x.down (mfderiv (𝓡 3) (𝓡 3) e x v)
    (mfderiv (𝓡 3) (𝓡 3) e x w) = _
  rw [hmetric]
  exact congrArg₂ (fun v w => g.inner (f x.down) v w) hdv.symm hdw.symm

theorem ricciNullity_pos_of_local_terminal_null_plane
    {E : Type u} [TopologicalSpace E] [T2Space E]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) E] [IsManifold (𝓡 3) ∞ E]
    (hC : RicciFlowCurvatureTheory.{u}) {a b : ℝ} (hab : a < b)
    (F : RicciFlow 3 E (Icc a b))
    (hoperator : ∀ t ∈ Icc a b, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    (D : LeviCivitaData g) {f : E → M}
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hmetric : ∀ x v w, (F.metric b).inner x v w = g.inner (f x)
      (mfderiv (𝓡 3) (𝓡 3) f x v) (mfderiv (𝓡 3) (𝓡 3) f x w))
    (x : E) (v w : TangentSpace (𝓡 3) (f x))
    (hv : g.inner (f x) v v = 1) (hw : g.inner (f x) w w = 1)
    (hvw : g.inner (f x) v w = 0) (hzero : D.curvatureTensor (f x) v w v w = 0) :
    0 < ricciNullity D (f x) := by
  let A := hf.mfderivToContinuousLinearEquiv (by simp) x
  have hA (z : TangentSpace (𝓡 3) (f x)) :
      mfderiv (𝓡 3) (𝓡 3) f x (A.symm z) = z := A.apply_symm_apply z
  have hcurv := (F.connection b).curvatureTensor_eq_of_local_isometry D isOpen_univ
    hf.contMDiff.contMDiffOn (fun y _ => hmetric y) (mem_univ x)
    (A.symm v) (A.symm w) (A.symm v) (A.symm w)
  obtain ⟨z, hz, hzn⟩ := F.exists_ricci_null_vector_of_closed_slab_terminal_null_plane hC hab
    (fun t ht y v w => (F.connection t).curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator
      y (hoperator t ht y) v w) x (A.symm v) (A.symm w)
    (by rw [hmetric, hA]; exact hv) (by rw [hmetric, hA]; exact hw)
    (by rw [hmetric, hA, hA]; exact hvw)
    (by simpa only [hA, hzero] using hcurv)
  rw [← ricciNullity_eq_of_local_metric_pullback (F.connection b) D hf hmetric x]
  apply Module.finrank_pos_iff_exists_ne_zero.mpr
  refine ⟨⟨z, (mem_ricciKernel _ _ _).mpr hzn⟩, ?_⟩
  intro heq
  exact hz (congrArg Subtype.val heq)

theorem ricciNullity_pos_of_small_terminal_null_plane
    {E : Type} [TopologicalSpace E] [T2Space E]
    [ChartedSpace (EuclideanSpace ℝ (Fin 3)) E] [IsManifold (𝓡 3) ∞ E]
    (hC : RicciFlowCurvatureTheory.{u}) {a b : ℝ} (hab : a < b)
    (F : RicciFlow 3 E (Icc a b))
    (hoperator : ∀ t ∈ Icc a b, ∀ x, (F.connection t).NonnegativeCurvatureOperator x)
    (D : LeviCivitaData g) {f : E → M}
    (hf : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ f)
    (hmetric : ∀ x v w, (F.metric b).inner x v w = g.inner (f x)
      (mfderiv (𝓡 3) (𝓡 3) f x v) (mfderiv (𝓡 3) (𝓡 3) f x w))
    (x : E) (v w : TangentSpace (𝓡 3) (f x))
    (hv : g.inner (f x) v v = 1) (hw : g.inner (f x) w w = 1)
    (hvw : g.inner (f x) v w = 0) (hzero : D.curvatureTensor (f x) v w v w = 0) :
    0 < ricciNullity D (f x) := by
  let e := Poincare.Manifold.uliftDiffeomorph (𝓡 3) E
  have hf' : IsLocalDiffeomorph (𝓡 3) (𝓡 3) ∞ (fun z : ULift.{u} E => f z.down) :=
    fun z => (e.isLocalDiffeomorph z).comp (𝓡 3) M (hf z.down)
  exact ricciNullity_pos_of_local_terminal_null_plane hC hab F.ulift
    (fun t ht z => (F.ulift_nonnegativeCurvatureOperator_iff t z).mpr (hoperator t ht z.down))
    D hf' (uliftFlow_metric_pullback F b hf hmetric) (ULift.up x) v w hv hw hvw hzero

variable (hflow : ∀ q : M, ∃ rho T : ℝ, 0 < rho ∧ 0 < T ∧
  ball (extChartAt (𝓡 3) q q) rho ⊆ (extChartAt (𝓡 3) q).target ∧
  ∃ F : RicciFlow 3 (⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩ : Opens _) (Icc (-T) 0),
    (∀ t ∈ Icc (-T) 0, ∀ x, (F.connection t).NonnegativeCurvatureOperator x) ∧
    ∀ x v w, (F.metric 0).inner x v w =
      g.pullbackCoefficients (extChartAt (𝓡 3) q).symm x v w)

include hflow in
theorem ricciNullity_pos_of_local_backward_flows_null_plane
    (hC : RicciFlowCurvatureTheory.{u}) (D : LeviCivitaData g)
    (q : M) (v w : TangentSpace (𝓡 3) q)
    (hv : g.inner q v v = 1) (hw : g.inner q w w = 1)
    (hvw : g.inner q v w = 0) (hzero : D.curvatureTensor q v w v w = 0) :
    0 < ricciNullity D q := by
  obtain ⟨rho, T, hrho, hT, hchart, F, hoperator, hmetric⟩ := hflow q
  let U : Opens (EuclideanSpace ℝ (Fin 3)) :=
    ⟨ball (extChartAt (𝓡 3) q q) rho, isOpen_ball⟩
  let x : U := ⟨extChartAt (𝓡 3) q q, mem_ball_self hrho⟩
  let f : U → M := fun y => (extChartAt (𝓡 3) q).symm y
  have hfx : f x = q := extChartAt_to_inv q
  have hplane : ∃ v w : TangentSpace (𝓡 3) (f x),
      g.inner (f x) v v = 1 ∧ g.inner (f x) w w = 1 ∧
      g.inner (f x) v w = 0 ∧ D.curvatureTensor (f x) v w v w = 0 := by
    rw [hfx]
    exact ⟨v, w, hv, hw, hvw, hzero⟩
  obtain ⟨v', w', hv', hw', hvw', hzero'⟩ := hplane
  have hp := ricciNullity_pos_of_small_terminal_null_plane hC (by linarith : -T < (0 : ℝ))
    F hoperator D (partialChartMap_isLocalDiffeomorph (inverseMetricChart q) U hchart)
    (terminalChartFlow_metric_pullback q U hchart F 0 hmetric) x v' w' hv' hw' hvw' hzero'
  change 0 < ricciNullity D (f x) at hp
  simpa only [hfx] using hp

include hflow in
theorem strictlyPositive_or_ricciNullity_one_of_nonflat_local_backward_flows
    [T2Space M] [PreconnectedSpace M]
    (hC : RicciFlowCurvatureTheory.{u}) (D : LeviCivitaData g)
    (hD : D.CurvatureTensorCalculus) (hoperator : ∀ x, D.NonnegativeCurvatureOperator x)
    (p : M) (hnonflat : D.curvatureTensorNorm p ≠ 0) :
    D.StrictlyPositiveSectionalCurvature ∨ ∀ x, ricciNullity D x = 1 := by
  by_cases hpos : D.StrictlyPositiveSectionalCurvature
  · exact Or.inl hpos
  apply Or.inr
  dsimp only [LeviCivitaData.StrictlyPositiveSectionalCurvature] at hpos
  push Not at hpos
  obtain ⟨x, v, w, hv, hw, hvw, hnonpos⟩ := hpos
  have hplane : D.curvatureTensor x v w v w = 0 := by
    have heq : D.sectionalCurvature x v w = D.curvatureTensor x v w v w := by
      simp only [LeviCivitaData.sectionalCurvature, hv, hw, hvw, one_mul,
        zero_pow (by norm_num : (2 : ℕ) ≠ 0), sub_zero, div_one]
    rw [heq] at hnonpos
    exact le_antisymm hnonpos
      (D.curvatureTensor_self_nonneg_of_nonnegative_curvatureOperator x (hoperator x) v w)
  have hpositive := ricciNullity_pos_of_local_backward_flows_null_plane hflow hC D x v w
    hv hw hvw hplane
  have hupper := D.ricciNullity_le_one_of_nonflat hD p (hoperator p) hnonflat
  intro y
  have hyp := ricciNullity_eq_of_local_backward_flows hflow hC D y p
  have hyx := ricciNullity_eq_of_local_backward_flows hflow hC D y x
  omega

include hflow in
theorem strictlyPositive_or_ricciNullity_one_of_local_backward_flows
    [T2Space M] [PreconnectedSpace M]
    (hC : RicciFlowCurvatureTheory.{u}) (D : LeviCivitaData g)
    (hD : D.CurvatureTensorCalculus) (hoperator : ∀ x, D.NonnegativeCurvatureOperator x)
    (p : M) (hscalar : D.scalarCurvature p = 1) :
    D.StrictlyPositiveSectionalCurvature ∨ ∀ x, ricciNullity D x = 1 := by
  apply strictlyPositive_or_ricciNullity_one_of_nonflat_local_backward_flows
    hflow hC D hD hoperator p
  intro hz
  have hbound := D.scalarCurvature_le_curvatureTensorNorm_sharp p
  rw [hscalar, hz] at hbound
  norm_num at hbound

end PoincareMT.ControlledTerminal
